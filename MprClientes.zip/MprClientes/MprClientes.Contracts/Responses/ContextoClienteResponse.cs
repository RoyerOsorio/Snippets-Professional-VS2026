namespace MprClientes.Contracts.Responses;

/// <summary>
/// Contrato consumido por Reimbursement.Orchestrator para
/// "ValidarContextoCliente" (Paso 2 del flujo) y por la UI para mostrar
/// póliza/certificado/vigencia.
/// </summary>
public sealed record ContextoClienteResponse(
    int AseguradoId,
    string NombreCompleto,
    string Poliza,
    string Certificado,
    string RolAsegurado,
    DateTime VigenciaInicio,
    DateTime VigenciaFin,
    bool EsVigente);

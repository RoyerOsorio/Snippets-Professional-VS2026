namespace MprClientes.Contracts.Responses;

/// <summary>
/// Contrato HTTP público de MprClientes. Deliberadamente separado de
/// Application.Dtos.ClienteDto: hoy son iguales, pero Contracts es lo único
/// que otros servicios/la UI pueden referenciar — si el modelo interno de
/// Application cambia, este contrato solo cambia cuando el equipo decide
/// romper compatibilidad hacia afuera.
/// </summary>
public sealed record ClienteResponse(
    int Id,
    string NombreORazonSocial,
    string? Rfc,
    string? Telefono,
    string? NombreContacto,
    string? DescripcionCorta,
    string Estatus);

using MprClientes.Api.Extensiones;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddProblemDetails();
builder.Services.AddOpenApi();
builder.Services.AgregarServiciosMprClientes(builder.Configuration);

// Observabilidad mínima: TraceId/CorrelationId por request. La solución
// definitiva de tracing distribuido (OpenTelemetry exporter, backend) es
// una decisión de infraestructura que excede el alcance de este piloto —
// se deja el enganche ya listo (W3C traceparent vía ASP.NET Core) sin
// acoplarse a un backend concreto.
builder.Services.AddHttpLogging(_ => { });

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpLogging();
app.UseExceptionHandler();

app.MapearEndpointsClientes();

app.MapGet("/health", () => Results.Ok(new { estado = "MprClientes operativo" }));

app.Run();

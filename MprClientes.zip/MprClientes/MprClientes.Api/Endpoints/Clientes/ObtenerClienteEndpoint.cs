using MprClientes.Application.Casos;
using MprClientes.Contracts.Responses;
using MprClientes.Domain.Excepciones;

namespace MprClientes.Api.Endpoints.Clientes;

public static class ObtenerClienteEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapGet("/{clienteId:int}", ObtenerAsync).WithName("ObtenerCliente");
    }

    private static async Task<IResult> ObtenerAsync(
        int clienteId,
        ObtenerClientePorIdCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            var cliente = await casoDeUso.EjecutarAsync(clienteId, cancellationToken);

            return Results.Ok(new ClienteResponse(
                cliente.Id, cliente.NombreORazonSocial, cliente.Rfc, cliente.Telefono,
                cliente.NombreContacto, cliente.DescripcionCorta, cliente.Estatus));
        }
        catch (ClienteNoEncontradoException ex)
        {
            return Results.Problem(
                title: "Cliente no encontrado",
                detail: ex.Message,
                statusCode: StatusCodes.Status404NotFound);
        }
    }
}

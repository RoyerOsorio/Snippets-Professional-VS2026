using MprClientes.Application.Casos;
using MprClientes.Contracts.Responses;
using MprClientes.Domain.Excepciones;

namespace MprClientes.Api.Endpoints.Clientes;

/// <summary>
/// Endpoint consumido por Reimbursement.Orchestrator para
/// "ValidarContextoCliente" (Paso 2 del flujo de reembolso) y también por la
/// UI para mostrar póliza/certificado/vigencia en la pantalla de selección
/// de cliente.
/// </summary>
public static class ObtenerContextoClienteEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapGet("/contexto", ObtenerAsync).WithName("ObtenerContextoCliente");
    }

    private static async Task<IResult> ObtenerAsync(
        string poliza,
        int aseguradoId,
        ObtenerContextoClienteCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            var contexto = await casoDeUso.EjecutarAsync(poliza, aseguradoId, cancellationToken);

            return Results.Ok(new ContextoClienteResponse(
                contexto.AseguradoId, contexto.NombreCompleto, contexto.Poliza, contexto.Certificado,
                contexto.RolAsegurado, contexto.VigenciaInicio, contexto.VigenciaFin, contexto.EsVigente));
        }
        catch (ClienteNoEncontradoException ex)
        {
            return Results.Problem(
                title: "Contexto contractual no encontrado",
                detail: ex.Message,
                statusCode: StatusCodes.Status404NotFound);
        }
    }
}

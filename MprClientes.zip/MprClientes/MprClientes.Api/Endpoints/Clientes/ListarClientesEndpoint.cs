using MprClientes.Application.Casos;
using MprClientes.Contracts.Responses;

namespace MprClientes.Api.Endpoints.Clientes;

public static class ListarClientesEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapGet("/", ListarAsync).WithName("ListarClientes");
    }

    private static async Task<IResult> ListarAsync(
        ListarClientesCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        var clientes = await casoDeUso.EjecutarAsync(cancellationToken);

        var respuesta = clientes.Select(c => new ClienteResponse(
            c.Id, c.NombreORazonSocial, c.Rfc, c.Telefono, c.NombreContacto, c.DescripcionCorta, c.Estatus));

        return Results.Ok(respuesta);
    }
}

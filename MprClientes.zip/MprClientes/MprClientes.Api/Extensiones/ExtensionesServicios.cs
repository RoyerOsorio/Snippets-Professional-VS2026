using MprClientes.Application.Casos;
using MprClientes.Infrastructure.Extensiones;

namespace MprClientes.Api.Extensiones;

public static class ExtensionesServicios
{
    public static IServiceCollection AgregarServiciosMprClientes(
        this IServiceCollection servicios,
        IConfiguration configuracion)
    {
        servicios.AgregarInfrastructureMprClientes(configuracion);

        servicios.AddScoped<ListarClientesCasoDeUso>();
        servicios.AddScoped<ObtenerClientePorIdCasoDeUso>();
        servicios.AddScoped<ObtenerContextoClienteCasoDeUso>();

        return servicios;
    }
}

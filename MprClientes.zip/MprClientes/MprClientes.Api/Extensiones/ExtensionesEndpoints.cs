using MprClientes.Api.Endpoints.Clientes;

namespace MprClientes.Api.Extensiones;

public static class ExtensionesEndpoints
{
    public static void MapearEndpointsClientes(this WebApplication app)
    {
        var grupo = app.MapGroup("/v1/clientes").WithTags("Clientes");

        ListarClientesEndpoint.Mapear(grupo);
        ObtenerClienteEndpoint.Mapear(grupo);
        ObtenerContextoClienteEndpoint.Mapear(grupo);
    }
}

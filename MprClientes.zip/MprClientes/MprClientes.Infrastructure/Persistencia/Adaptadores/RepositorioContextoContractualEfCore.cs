using Microsoft.EntityFrameworkCore;
using MprClientes.Application.Puertos;
using MprClientes.Domain.Entidades;

namespace MprClientes.Infrastructure.Persistencia.Adaptadores;

/// <summary>
/// Adaptador escrito a mano. A diferencia de RepositorioClientesEfCore, aquí
/// SÍ se reconstruye el agregado de Domain (ContextoContractualCliente)
/// porque el caso de uso que lo consume aplica una regla de negocio
/// (vigencia) sobre el resultado — este es el ejemplo concreto de
/// "Database First dentro de la arquitectura hexagonal" del ejercicio:
/// SQL Server → DbContext generado → este adaptador → Domain → Application.
/// </summary>
public sealed class RepositorioContextoContractualEfCore(MprClientesDbContext dbContext) : IRepositorioContextoContractual
{
    public async Task<ContextoContractualCliente?> ObtenerPorPolizaYAseguradoAsync(
        string poliza,
        int aseguradoId,
        CancellationToken cancellationToken)
    {
        var registro = await dbContext.AseguradosCertificado
            .AsNoTracking()
            .Where(ac => ac.AsasNid == aseguradoId && ac.AscrFechaBaja == null)
            .Where(ac => ac.Certificado != null
                         && ac.Certificado.Vigencia != null
                         && ac.Certificado.Vigencia.Poliza.PlplPoliza == poliza)
            .Select(ac => new
            {
                ac.Asegurado.AsasNid,
                NombreCompleto = ac.Asegurado.AsasNombre + " " + ac.Asegurado.AsasAppaterno + " " + (ac.Asegurado.AsasApmaterno ?? string.Empty),
                Poliza = ac.Certificado!.Vigencia!.Poliza.PlplPoliza,
                Certificado = ac.Certificado!.PlcrCertificado,
                Rol = ac.Rol.RaraNombreRolAsegurado,
                VigenciaInicio = ac.Certificado!.Vigencia!.PlvgInicioVigencia,
                VigenciaFin = ac.Certificado!.Vigencia!.PlvgFinVigencia,
            })
            .FirstOrDefaultAsync(cancellationToken);

        if (registro is null)
        {
            return null;
        }

        return new ContextoContractualCliente(
            registro.AsasNid,
            registro.NombreCompleto.Trim(),
            registro.Poliza,
            registro.Certificado,
            registro.Rol,
            new Vigencia(registro.VigenciaInicio, registro.VigenciaFin));
    }
}

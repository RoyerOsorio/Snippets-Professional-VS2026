using Microsoft.EntityFrameworkCore;
using MprClientes.Application.Dtos;
using MprClientes.Application.Puertos;

namespace MprClientes.Infrastructure.Persistencia.Adaptadores;

/// <summary>
/// Adaptador escrito a mano (no generado). Implementa el puerto
/// IRepositorioClientes usando el DbContext generado por scaffold.
/// Es una consulta de lectura simple, sin comportamiento de dominio, por lo
/// que se mapea directamente a MprClientes.Application.Dtos.ClienteDto sin
/// pasar por Domain — coherente con "para consultas simples de lectura
/// puede utilizarse un acceso más directo dentro de Infrastructure".
/// </summary>
public sealed class RepositorioClientesEfCore(MprClientesDbContext dbContext) : IRepositorioClientes
{
    public async Task<IReadOnlyList<ClienteDto>> ListarAsync(CancellationToken cancellationToken)
    {
        return await dbContext.Grupos
            .AsNoTracking()
            .OrderBy(g => g.GrgrDescaseguradora)
            .Select(g => new ClienteDto(
                g.GrgrNid,
                g.GrgrDescaseguradora ?? string.Empty,
                g.GrgrRfc,
                g.GrgrTelefono,
                g.GrgrNomcontacto,
                g.GrgrDescripcionCorta,
                g.GrgrEstatus == "A" ? "Activo" : "Inactivo"))
            .ToListAsync(cancellationToken);
    }

    public async Task<ClienteDto?> ObtenerPorIdAsync(int clienteId, CancellationToken cancellationToken)
    {
        var grupo = await dbContext.Grupos
            .AsNoTracking()
            .FirstOrDefaultAsync(g => g.GrgrNid == clienteId, cancellationToken);

        if (grupo is null)
        {
            return null;
        }

        return new ClienteDto(
            grupo.GrgrNid,
            grupo.GrgrDescaseguradora ?? string.Empty,
            grupo.GrgrRfc,
            grupo.GrgrTelefono,
            grupo.GrgrNomcontacto,
            grupo.GrgrDescripcionCorta,
            grupo.GrgrEstatus == "A" ? "Activo" : "Inactivo");
    }
}

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MprClientes.Application.Puertos;
using MprClientes.Infrastructure.Persistencia;
using MprClientes.Infrastructure.Persistencia.Adaptadores;

namespace MprClientes.Infrastructure.Extensiones;

/// <summary>
/// Único punto de registro de Infrastructure. Se invoca una sola vez desde
/// Program.cs, siguiendo el mismo patrón que ya usa la UI existente
/// (Extensions/ServiceCollectionExtensions.cs → AddMultiportalUi).
/// </summary>
public static class ExtensionesServiciosInfrastructure
{
    public static IServiceCollection AgregarInfrastructureMprClientes(
        this IServiceCollection servicios,
        IConfiguration configuracion)
    {
        servicios.AddDbContext<MprClientesDbContext>(opciones =>
            opciones.UseSqlServer(configuracion.GetConnectionString("MprClientesDb")));

        servicios.AddScoped<IRepositorioClientes, RepositorioClientesEfCore>();
        servicios.AddScoped<IRepositorioContextoContractual, RepositorioContextoContractualEfCore>();

        return servicios;
    }
}

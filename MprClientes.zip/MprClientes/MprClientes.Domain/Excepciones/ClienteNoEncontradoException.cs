namespace MprClientes.Domain.Excepciones;

/// <summary>
/// Se lanza cuando se solicita un Cliente/contexto contractual que no existe.
/// Domain no depende de ASP.NET Core: el mapeo a 404/ProblemDetails ocurre
/// en la capa Api (ver MprClientes.Api/Endpoints).
/// </summary>
public sealed class ClienteNoEncontradoException(string mensaje) : Exception(mensaje);

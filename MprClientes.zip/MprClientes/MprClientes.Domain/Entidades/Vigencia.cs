namespace MprClientes.Domain.Entidades;

/// <summary>
/// Value object que representa el periodo de vigencia de una póliza.
/// Vive en Domain porque "¿está vigente una póliza en una fecha dada?" es
/// una regla de negocio de MprClientes, no un detalle de infraestructura —
/// por eso no se resuelve con un simple "if" en el Orchestrator (ver
/// Application/Casos/ObtenerContextoClienteCasoDeUso.cs).
/// </summary>
public sealed class Vigencia
{
    public DateTime Inicio { get; }
    public DateTime Fin { get; }

    public Vigencia(DateTime inicio, DateTime fin)
    {
        if (fin < inicio)
        {
            throw new ArgumentException("La fecha de fin de vigencia no puede ser anterior a la fecha de inicio.");
        }

        Inicio = inicio;
        Fin = fin;
    }

    /// <summary>
    /// Determina si la vigencia cubre la fecha indicada. Se evalúa contra
    /// UTC para no depender de la zona horaria del proceso que la invoque.
    /// </summary>
    public bool EstaVigenteEn(DateTime fechaUtc) => fechaUtc.Date >= Inicio.Date && fechaUtc.Date <= Fin.Date;
}

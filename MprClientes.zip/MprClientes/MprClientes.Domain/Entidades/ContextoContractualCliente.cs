namespace MprClientes.Domain.Entidades;

/// <summary>
/// Agregado de lectura que representa "quién es el cliente y bajo qué
/// relación contractual/póliza está cubierto" (pregunta conceptual que
/// responde MprClientes según el alcance del ejercicio). No es una entidad
/// transaccional: MprClientes en este piloto no crea ni modifica pólizas,
/// solo resuelve el contexto que otros servicios (Orchestrator, UI)
/// necesitan consultar.
/// </summary>
public sealed class ContextoContractualCliente
{
    public int AseguradoId { get; }
    public string NombreCompleto { get; }
    public string Poliza { get; }
    public string Certificado { get; }
    public string RolAsegurado { get; }
    public Vigencia Vigencia { get; }

    public ContextoContractualCliente(
        int aseguradoId,
        string nombreCompleto,
        string poliza,
        string certificado,
        string rolAsegurado,
        Vigencia vigencia)
    {
        AseguradoId = aseguradoId;
        NombreCompleto = nombreCompleto;
        Poliza = poliza;
        Certificado = certificado;
        RolAsegurado = rolAsegurado;
        Vigencia = vigencia;
    }

    /// <summary>
    /// Invariante de negocio: un contexto contractual solo es válido para
    /// iniciar un reembolso si la póliza está vigente en la fecha de
    /// evaluación. Esta es la regla que el Orchestrator consulta en vez de
    /// calcular vigencias por su cuenta (ver sección "El Orchestrator no
    /// ejecuta reglas internas" del ejercicio).
    /// </summary>
    public bool EsValidoParaReembolso(DateTime fechaEvaluacionUtc) => Vigencia.EstaVigenteEn(fechaEvaluacionUtc);
}

namespace MprClientes.Application.Dtos;

/// <summary>
/// Forma del contexto contractual de un asegurado, expuesta hacia afuera
/// (Api → Gateway → Orchestrator/UI). Es la traducción externa del agregado
/// de dominio ContextoContractualCliente; nunca se expone el tipo de Domain
/// directamente para no acoplar a consumidores externos al modelo interno.
/// </summary>
public sealed record ContextoClienteDto(
    int AseguradoId,
    string NombreCompleto,
    string Poliza,
    string Certificado,
    string RolAsegurado,
    DateTime VigenciaInicio,
    DateTime VigenciaFin,
    bool EsVigente);

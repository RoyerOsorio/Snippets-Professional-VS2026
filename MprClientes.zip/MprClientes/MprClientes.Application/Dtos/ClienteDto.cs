namespace MprClientes.Application.Dtos;

/// <summary>
/// Forma de un Cliente (= MTP_GRGR_GRUPO en el esquema legado) para consumo
/// externo. Corresponde 1:1 a los campos que la UI ya modela en
/// ClienteViewModel — se conserva esa forma a propósito para no romper el
/// contrato visual que ya fue validado con gerencia.
/// </summary>
public sealed record ClienteDto(
    int Id,
    string NombreORazonSocial,
    string? Rfc,
    string? Telefono,
    string? NombreContacto,
    string? DescripcionCorta,
    string Estatus);

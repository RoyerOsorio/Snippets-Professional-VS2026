using MprClientes.Application.Dtos;
using MprClientes.Application.Puertos;
using MprClientes.Domain.Excepciones;

namespace MprClientes.Application.Casos;

/// <summary>
/// Caso de uso que consulta Reimbursement.Orchestrator (Paso 2 del flujo:
/// "consultar MprClientes, obtener/verificar contexto contractual") y que
/// también puede usar la UI para mostrar póliza/certificado/vigencia. Es el
/// único lugar donde se evalúa la regla "¿la póliza está vigente?" — ni el
/// Orchestrator ni la UI la recalculan (ver Domain/Entidades/Vigencia.cs).
/// </summary>
public sealed class ObtenerContextoClienteCasoDeUso(IRepositorioContextoContractual repositorio)
{
    public async Task<ContextoClienteDto> EjecutarAsync(
        string poliza,
        int aseguradoId,
        CancellationToken cancellationToken)
    {
        var contexto = await repositorio.ObtenerPorPolizaYAseguradoAsync(poliza, aseguradoId, cancellationToken);

        if (contexto is null)
        {
            throw new ClienteNoEncontradoException(
                $"No existe contexto contractual para la póliza {poliza} y el asegurado {aseguradoId}.");
        }

        var fechaEvaluacion = DateTime.UtcNow;

        return new ContextoClienteDto(
            contexto.AseguradoId,
            contexto.NombreCompleto,
            contexto.Poliza,
            contexto.Certificado,
            contexto.RolAsegurado,
            contexto.Vigencia.Inicio,
            contexto.Vigencia.Fin,
            EsVigente: contexto.EsValidoParaReembolso(fechaEvaluacion));
    }
}

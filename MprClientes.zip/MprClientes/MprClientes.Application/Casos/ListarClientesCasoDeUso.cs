using MprClientes.Application.Dtos;
using MprClientes.Application.Puertos;

namespace MprClientes.Application.Casos;

/// <summary>
/// Caso de uso de solo lectura: listar Clientes para la pantalla de
/// selección de cliente (Paso 1 del flujo de reembolso). Sin lógica de
/// negocio adicional — Application aquí solo orquesta el puerto; no se
/// introduce un patrón CQRS con bus de mediador porque no aporta valor a
/// un caso de uso de una sola operación (ver "Regla contra la
/// sobreingeniería" del gobierno del proyecto).
/// </summary>
public sealed class ListarClientesCasoDeUso(IRepositorioClientes repositorioClientes)
{
    public Task<IReadOnlyList<ClienteDto>> EjecutarAsync(CancellationToken cancellationToken) =>
        repositorioClientes.ListarAsync(cancellationToken);
}

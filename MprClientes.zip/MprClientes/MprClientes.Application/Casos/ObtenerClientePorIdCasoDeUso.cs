using MprClientes.Application.Dtos;
using MprClientes.Application.Puertos;
using MprClientes.Domain.Excepciones;

namespace MprClientes.Application.Casos;

public sealed class ObtenerClientePorIdCasoDeUso(IRepositorioClientes repositorioClientes)
{
    public async Task<ClienteDto> EjecutarAsync(int clienteId, CancellationToken cancellationToken)
    {
        var cliente = await repositorioClientes.ObtenerPorIdAsync(clienteId, cancellationToken);

        return cliente ?? throw new ClienteNoEncontradoException($"No existe un cliente con id {clienteId}.");
    }
}

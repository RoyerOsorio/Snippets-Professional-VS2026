using MprClientes.Application.Dtos;

namespace MprClientes.Application.Puertos;

/// <summary>
/// Puerto (Hexagonal Architecture) que Application define e Infrastructure
/// implementa. Deliberadamente NO es un repositorio genérico
/// (IRepositorioGenerico&lt;T&gt;) — cada operación expresa una necesidad real
/// del caso de uso, no un CRUD especulativo.
/// </summary>
public interface IRepositorioClientes
{
    Task<IReadOnlyList<ClienteDto>> ListarAsync(CancellationToken cancellationToken);

    Task<ClienteDto?> ObtenerPorIdAsync(int clienteId, CancellationToken cancellationToken);
}

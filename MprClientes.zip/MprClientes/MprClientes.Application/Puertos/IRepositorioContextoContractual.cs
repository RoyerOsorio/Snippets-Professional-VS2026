using MprClientes.Domain.Entidades;

namespace MprClientes.Application.Puertos;

/// <summary>
/// Puerto para resolver el agregado de dominio ContextoContractualCliente.
/// Se mantiene separado de IRepositorioClientes porque representa una
/// necesidad de negocio distinta (consulta profunda con reglas de vigencia)
/// y no todos los consumidores de "lista de Clientes" necesitan este nivel
/// de detalle — evita sobrecargar un único puerto con responsabilidades
/// distintas (Interface Segregation).
/// </summary>
public interface IRepositorioContextoContractual
{
    Task<ContextoContractualCliente?> ObtenerPorPolizaYAseguradoAsync(
        string poliza,
        int aseguradoId,
        CancellationToken cancellationToken);
}

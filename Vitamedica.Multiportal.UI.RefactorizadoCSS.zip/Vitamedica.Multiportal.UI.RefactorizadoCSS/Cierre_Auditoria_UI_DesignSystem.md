# Cierre técnico de auditoría — UI / Design System
**Proyecto:** Vitamedica Multiportal UI
**Alcance:** Auditoría de calidad de CSS/UI post-refactorización manual, Fases 1–6
**Fecha de cierre:** 23 de julio de 2026

---

## 1. Resumen ejecutivo

Esta auditoría se ejecutó en dos rondas de revisión completa del proyecto seguidas de seis fases de corrección incremental, cada una revisada y aprobada individualmente antes de avanzar a la siguiente. El criterio de trabajo desde el inicio fue evidencia verificable sobre el código real, no mejoras hipotéticas, con separación estricta entre refactorización (bajo riesgo, sin decisiones de diseño) y evolución arquitectónica (requiere aprobación explícita antes de escribir código).

De los hallazgos originales, se corrigieron los que representaban bugs reales, inconsistencias de marca visibles para el usuario y violaciones de tokens con evidencia repetida. Se dejaron deliberadamente sin tocar los hallazgos cuyo costo de corrección superaba su beneficio, y se aisló como iniciativa propia la única decisión que sí implica evolución de arquitectura (`doc-gen-btn`).

El resultado es un Design System consolidado, no perfecto: sin bugs funcionales conocidos, con su sistema de tokens aplicado de forma consistente en las superficies migradas, y con una deuda técnica residual pequeña, documentada y de bajo riesgo.

---

## 2. Hallazgos completamente resueltos

| Hallazgo | Fase | Verificación final |
|---|---|---|
| `@@media` inválido en `index.css` (bug responsive real) | Fase 1 | 0 coincidencias de `@@media` en todo `wwwroot/css/` |
| `color: #fff` hardcodeado (11+ ocurrencias, 6 archivos) | Fase 4 | 0 coincidencias fuera de `tokens.css` |
| `rgba(255,255,255,.85/.9)` hardcodeado, divergente del token `--vm-on-header-muted` | Fase 4 | 0 coincidencias en todo el proyecto |
| `outline: 2px solid #fff` en `:focus-visible` (caso ambiguo resuelto con `--vm-focus-on-header`) | Fase 4 | Token semánticamente correcto aplicado, ya existente en `tokens.css` |
| Botones Bootstrap nativos sin marca institucional en acciones principales de formulario (Detalle, Reembolso, Alta/Edición de Cliente) | Fases 2–3 | 0 `.btn-primary`/`.btn-success`/`.btn-danger` de Bootstrap puro en los 3 archivos; migrados a la familia `-vm` |
| Duplicación de `.page-head`/`.page-display`/`.page-lead` en `clientes-index.css` y `pagos-index.css` (sin justificación documentada) | Fase 5.a | 0 coincidencias; `form-sections.css` es la única fuente para esas dos vistas |
| CSS muerto: `.brand-sub`/`.brand-name` (`header.css`) | Fase 6 | 0 coincidencias en `Views/` y en CSS |
| CSS muerto: `.kpi-grid`/`.kpi-card`/`.kpi-icon`/`.kpi-value`/`.kpi-label`, incluidas las reglas responsive huérfanas descubiertas durante la validación | Fase 6 | 0 coincidencias en todo el proyecto |
| Accesibilidad: `.icon-btn` sin `:focus-visible` en `detalle-asegurado.css` | Fase 6 | Regla replicada, idéntica a `index.css` |

Nueve hallazgos cerrados con evidencia de verificación repetida (antes y después de cada cambio), validación de sintaxis CSS y, cuando aplicaba, verificación de ausencia de consumidores.

---

## 3. Hallazgos aceptados como Deuda Técnica Aceptada

Estos puntos fueron evaluados con el mismo rigor que los anteriores y se decidió explícitamente **no invertir esfuerzo adicional en ellos**, por relación costo/beneficio desfavorable, no por omisión.

**Botón sin marca en `Login.cshtml`.**
No es un caso aislado de tokenización: toda la vista (layout, grid, inputs, labels) usa Bootstrap crudo, sin un solo token del Design System. Corregir únicamente el botón produciría una página más inconsistente consigo misma, no menos. La corrección correcta es una migración completa de esa vista, que es un proyecto de UI aparte, no un hallazgo de auditoría de CSS.

**`#0069b0` hardcodeado en `form-sections.css` (hover de `.form-section-header`/`.doc-block-header`).**
Valor idéntico en sus dos únicas ocurrencias, sin drift, sin bug visual. Resolverlo correctamente exige modificar `form-sections.css` —un componente compartido— para un problema que hoy no produce ningún síntoma observable. El costo arquitectónico de tocar un componente compartido no se justifica por una inconsistencia puramente teórica.

**Inconsistencia del prefijo `.btn` de Bootstrap junto a la familia `-vm`.**
Cero impacto visual: `.btn-primary-vm`/`.btn-success-vm`/`.btn-danger-vm`/`.btn-text-vm` definen su propio modelo de caja completo y ganan la cascada con o sin `.btn`. Es inconsistencia de marcado en 8+ ubicaciones sin ningún consumidor afectado. Corregirla sería perseguir cobertura del 100% sin beneficio medible — exactamente el tipo de sobreingeniería que se decidió evitar desde el inicio de esta auditoría.

**Estilos inline repetidos** (`style="cursor:default"` ×8 en `.form-section-header`; `style="margin:0;color:var(--vm-neutral-900)"` ×5 en párrafos de modal).
Tienen valor real de mantenibilidad, pero su corrección correcta requiere agregar un modificador a `form-sections.css` (componente compartido) o decidir un nuevo hogar para el patrón de texto de modal. Quedó identificado como el único punto de esta lista con valor medio-alto, pendiente de una decisión de diseño específica (dónde vive la nueva clase) antes de poder ejecutarse — no se abrió por decisión explícita de no continuar con más fases en este cierre.

Ninguno de estos cuatro puntos representa riesgo funcional, de seguridad ni de accesibilidad. Son costos de mantenimiento menores, acotados y ya localizados con precisión si en el futuro se decide atenderlos.

---

## 4. Hallazgo que requiere iniciativa arquitectónica independiente

**Migración de `.doc-gen-btn` de `form-sections.css` a `wwwroot/css/components/`.**

Este es el único punto pendiente que no es deuda técnica menor ni refactorización de bajo riesgo — es una decisión de arquitectura real, ya analizada en profundidad (Fase 5, análisis previo a cualquier código):

- **Evidencia que la sostiene:** `.doc-gen-btn` tiene consumidores reales en 6 vistas de 4 módulos distintos (Reembolsos, Tablero, Clientes, Pagos), superando ampliamente el dominio "documento/archivo" que su nombre y ubicación actual declaran.
- **Por qué no se ejecutó en esta ronda:** decisión tuya explícita de tratarla como iniciativa separada, una vez agotada la deuda técnica existente — postura correcta, porque mezclar "eliminar duplicación" con "mover un componente a un nuevo dominio arquitectónico" habría diluido la trazabilidad de ambos tipos de cambio.
- **Efecto colateral aceptado mientras tanto:** `index.css` conserva su propia copia de `.doc-gen-btn` y de `.page-head`/`.page-display`/`.page-lead`, duplicando `form-sections.css`. Es la única duplicación que queda sin resolver en todo el proyecto, y es consciente, documentada y con plan de resolución ya definido (ver Fase 5).

Se recomienda abrirla como su propia iniciativa cuando el equipo decida invertir en ella, con el análisis de la Fase 5 como punto de partida (ya incluye ventajas, desventajas, impacto, compatibilidad y costo de migración).

---

## 5. Estado actual del Design System

- **Tokens:** consistentes en todas las superficies migradas. No quedan colores hardcodeados que dupliquen un token existente. Los dos únicos valores hex fuera de `tokens.css` (`#0069b0` ×2) están documentados como deuda aceptada, no como incumplimiento silencioso.
- **Componentes compartidos (`wwwroot/css/components/`):** `_badge.css`, `_button.css`, `_table.css`, `_pagination.css`, `_filters-panel.css`, `_modals.css`, `date-picker.css` — cada uno con responsabilidad única y clara, cargados globalmente vía `site.css`. `_button.css` evolucionó correctamente en esta auditoría de una familia de 2 variantes (Primario/Terciario) a 4 (Primario/Éxito/Peligro/Terciario), sin invadir el dominio de `doc-gen-btn`.
- **`form-sections.css`:** consolidado como única fuente de verdad para el patrón "formulario por secciones" en las vistas que le corresponden (Reembolso, Detalle, Cliente, Pagos), con la única excepción documentada y aislada de `index.css`.
- **Bugs conocidos:** ninguno.
- **CSS muerto conocido:** ninguno.
- **Accesibilidad:** el gap detectado (foco de teclado en `.icon-btn`) fue corregido; no se identificaron otros gaps de accesibilidad durante ninguna de las rondas de auditoría.

---

## 6. Riesgos residuales

- **Bajo:** duplicación de `.doc-gen-btn`/`.page-head` en `index.css` — mientras no se resuelva, cualquier cambio futuro a esas reglas en `form-sections.css` debe recordar replicarse manualmente en `index.css`. Mitigado por estar documentado y ser de alcance conocido (2 selectores, 1 archivo).
- **Bajo:** `Login.cshtml` fuera del Design System — riesgo de que un cambio de marca institucional (color, tipografía) no se refleje ahí automáticamente, al no consumir tokens.
- **Muy bajo:** los 4 puntos de deuda técnica aceptada (sección 3) no representan riesgo de regresión, solo costo de mantenimiento marginal si se necesitara tocar esas reglas por otra razón en el futuro.

No se identificaron riesgos de seguridad, de rendimiento ni de accesibilidad pendientes.

---

## 7. Recomendaciones para futuras evoluciones

1. Tratar la migración de `.doc-gen-btn` (sección 4) como la próxima iniciativa de arquitectura cuando haya capacidad, no como parte de mantenimiento rutinario.
2. Si en algún momento se planea una modernización de `Login.cshtml`, hacerlo como migración completa de la vista al Design System, no como parches puntuales.
3. Si se agrega en el futuro cualquier necesidad real de un tono "hover oscurecido" para superficies `--vm-header-bg` (más allá del caso puntual de `#0069b0`), es el momento natural de formalizarlo como token y resolver esa deuda de paso, sin costo adicional dedicado.
4. Mantener la disciplina de esta auditoría en cambios futuros: evidencia antes que hipótesis, separación de refactorización vs. arquitectura, y consulta explícita antes de tocar cualquier componente compartido.

---

## 8. Veredicto final

**El proyecto se considera consolidado respecto al Design System.**

No quedan bugs funcionales, no queda CSS muerto conocido, no quedan violaciones de tokens con evidencia repetida, y la única inconsistencia visual de peso real para el usuario (botones sin marca en formularios principales) está resuelta. La deuda técnica que permanece es baja, está acotada, documentada y fue aceptada con criterio de ingeniería — no por falta de revisión, sino porque su costo de corrección supera su beneficio en el estado actual del proyecto. La única pieza que requiere trabajo adicional (`doc-gen-btn`) es, por definición, una evolución de arquitectura y no un defecto de calidad — queda correctamente separada como iniciativa futura.

Se cierra esta auditoría.

﻿using System;
using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class AcumuladorFilter
    {
        [DataMember]
        public string Poliza { get; set; }

        [DataMember]
        public DateTime Fecha { get; set; }

        [DataMember]
        public AcumuladorFilterType FilterType { get; set; }
    }
}

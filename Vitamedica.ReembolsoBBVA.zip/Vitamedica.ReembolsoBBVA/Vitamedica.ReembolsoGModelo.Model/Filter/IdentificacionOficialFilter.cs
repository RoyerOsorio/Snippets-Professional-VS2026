﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    public class IdentificacionOficialFilter
    {

        [DataMember]
        public int? IdIDentificacionOficial { get; set; }

        [DataMember]
        public string Poliza { get; set; }
        [DataMember]
        public string Nombre { get; set; }
        [DataMember]
        public bool Activo { get; set; }
        [DataMember]
        public bool NuevaINE { get; set; }

        [DataMember]
        public DateTime? FechaRegistro { get; set; }

        [DataMember]
        public DateTime? FechaModificacion { get; set; }

        [DataMember]
        public IdentificacionOficialFilterType FilterType { get; set; }
    }
}

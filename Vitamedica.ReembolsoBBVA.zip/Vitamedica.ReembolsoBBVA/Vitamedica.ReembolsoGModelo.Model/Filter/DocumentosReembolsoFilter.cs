﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class DocumentosReembolsoFilter
    {
        [DataMember]
        public int IdMotivo { get; set; }

        [DataMember]
        public int IdReembolso { get; set; }

        [DataMember]
        public int IdDocumento { get; set; }

        [DataMember]
        public DocumentosReembolsoFilterType FilterType { get; set; }
    }
}

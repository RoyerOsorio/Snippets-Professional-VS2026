﻿using System;
using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class TableroCheckUpFilter
    {
        [DataMember]
        public DateTime? FechaInicio { get; set; }

        [DataMember]
        public DateTime? FechaFin { get; set; }

        [DataMember]
        public string Nomina { get; set; }

        [DataMember]
        public string Folio { get; set; }

        [DataMember]
        public int IdCheckUp { get; set; }

        [DataMember]
        public TableroCheckUpFilterType FilterType { get; set; }
    }
}

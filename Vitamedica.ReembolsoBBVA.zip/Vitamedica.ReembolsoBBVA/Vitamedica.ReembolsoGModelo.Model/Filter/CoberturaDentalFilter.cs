﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class CoberturaDentalFilter
    {
        [DataMember]
        public int IdGrupo { get; set; }

        [DataMember]
        public int IdTratamiento { get; set; }

        [DataMember]
        public int IdentificadorDhb { get; set; }

        [DataMember]
        public int Edad { get; set; }

        [DataMember]
        public CoberturaDentalFilterType FilterType { get; set; }
    }
}
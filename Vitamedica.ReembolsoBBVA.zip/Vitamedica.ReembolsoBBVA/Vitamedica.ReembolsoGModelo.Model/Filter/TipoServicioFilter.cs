﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class TipoServicioFilter
    {
        [DataMember]
        public int IdTipoServicio { get; set; }

        [DataMember]
        public TipoServicioFilterType FilterType { get; set; }
    }
}

﻿using System;
using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class LayoutBancoFilter
    {
        [DataMember]
        public DateTime Fecha { get; set; }

        [DataMember]
        public string Tipo { get; set; }
    }
}

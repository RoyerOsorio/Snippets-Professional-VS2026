﻿using System.Runtime.Serialization;
using Vitamedica.ReembolsoGModelo.Model.ViewModels;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class DocAdicionalFilter : DocAdicionalResume
    {
        [DataMember]
        public DocAdicionalFilterType FilterType { get; set; }
    }
}

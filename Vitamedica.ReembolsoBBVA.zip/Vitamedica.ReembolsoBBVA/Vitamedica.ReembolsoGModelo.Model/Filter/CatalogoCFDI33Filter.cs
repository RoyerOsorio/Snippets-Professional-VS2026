﻿using System;
using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class CatalogoCFDI33Filter
    {
        [DataMember]
        public string FormaPago { get; set; }

        [DataMember]
        public string Moneda { get; set; }

        [DataMember]
        public string TipoComprobante { get; set; }

        [DataMember]
        public string MetodoPago { get; set; }

        [DataMember]
        public string TipoRelacion { get; set; }

        [DataMember]
        public string RegimenFiscalEmisor { get; set; }

        [DataMember]
        public string UsoCFDI { get; set; }


        //Campos Versión 3.3 y 4.0
        [DataMember]
        public decimal Version { get; set; }

        [DataMember]
        public string Exportacion { get; set; }

        [DataMember]
        public int TipoFiscal { get; set; }

        [DataMember]
        public int CFDIProveedor { get; set; }

        [DataMember]
        public string FechaTimbrado { get; set; }

        [DataMember]
        public string CodigoPostal { get; set; }

        [DataMember]
        public CatalogoCFDI33FilterType FilterType { get; set; }

        [DataMember]
        public string RFCReceptor { get; set; }

        [DataMember]
        public string RazonSocialSRC { get; set; }
    }
}

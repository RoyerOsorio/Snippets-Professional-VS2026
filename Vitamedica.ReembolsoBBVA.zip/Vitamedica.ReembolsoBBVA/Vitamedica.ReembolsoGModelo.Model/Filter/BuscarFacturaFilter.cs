﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class BuscarFacturaFilter
    {
        [DataMember]
        public string UUID { get; set; }

        [DataMember]
        public string RFC { get; set; }

        [DataMember]
        public string Serie { get; set; }

        [DataMember]
        public BuscarFacturaFilterType FilterType { get; set; }
    }
}

﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class StatusReembolsoFilter
    {
        [DataMember]
        public int IdStatus { get; set; }        

        [DataMember]
        public StatusReembolsoFilterType FilterType { get; set; }
    }
}

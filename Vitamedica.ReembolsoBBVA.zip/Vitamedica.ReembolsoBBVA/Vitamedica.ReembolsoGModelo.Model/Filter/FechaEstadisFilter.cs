﻿using System;
using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class FechaEstadisFilter
    {
        [DataMember]
        public DateTime? Fecha { get; set; }

        [DataMember]
        public int Year { get; set; }

        [DataMember]
        public FechaEstadisFilterType FilterType { get; set; }
    }
}

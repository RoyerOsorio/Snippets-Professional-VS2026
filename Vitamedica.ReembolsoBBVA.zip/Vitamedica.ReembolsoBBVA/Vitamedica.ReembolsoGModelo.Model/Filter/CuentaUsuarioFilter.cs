﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class CuentaUsuarioFilter
    {
        [DataMember]
        public string Titular { get; set; }

        [DataMember]
        public CuentaUsuarioFilterType FilterType { get; set; }
    }
}

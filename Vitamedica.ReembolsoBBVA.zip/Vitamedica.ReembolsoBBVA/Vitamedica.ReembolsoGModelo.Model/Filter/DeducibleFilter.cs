﻿using System;
using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class DeducibleFilter
    {
        [DataMember]
        public DateTime? FechaInicio { get; set; }

        [DataMember]
        public DateTime? FechaFin { get; set; }

        [DataMember]
        public DeducibleFilterType FilterType { get; set; }
    }
}

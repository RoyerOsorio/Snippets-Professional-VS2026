﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class TipoDerechohabienteFilter
    {
        [DataMember]
        public int IdTipoDerechohabiente { get; set; }

        [DataMember]
        public TipoDerechohabienteFilterType FilterType { get; set; }
    }
}

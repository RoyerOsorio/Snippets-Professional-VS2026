﻿using System.Runtime.Serialization;


namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class TokenFilterTesoreria
    {
        [DataMember]
        public int IdToken { get; set; }
        [DataMember]
        public string Token { get; set; }
    }
}

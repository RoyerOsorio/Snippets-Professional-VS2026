﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class NotaFilter
    {
        [DataMember]
        public int IdReembolso { get; set; }

        [DataMember]
        public int IdFlujo { get; set; }

        [DataMember]
        public int IdEstatus { get; set; }

        [DataMember]
        public NotaFilterType FilterType { get; set; }
    }
}

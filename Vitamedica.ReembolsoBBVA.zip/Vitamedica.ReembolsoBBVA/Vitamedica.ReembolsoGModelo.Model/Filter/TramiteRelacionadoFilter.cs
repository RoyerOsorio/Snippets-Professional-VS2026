﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class TramiteRelacionadoFilter
    {
        [DataMember]
        public string Folio { get; set; }

        [DataMember]
        public int Flujo { get; set; }

        [DataMember]
        public TramiteRelacionadoFilterType FilterType { get; set; }
    }
}

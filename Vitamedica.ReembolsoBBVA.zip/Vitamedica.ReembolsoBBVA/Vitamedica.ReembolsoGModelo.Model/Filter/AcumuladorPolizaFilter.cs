﻿using System;
using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class AcumuladorPolizaFilter
    {
        [DataMember]
        public string Poliza { get; set; }
        [DataMember]
        public DateTime? Fecha { get; set; }
        [DataMember]
        public int? NumBenef { get; set; }
        [DataMember]
        public int IdMotivoReembolso { get; set; }
        [DataMember]
        public int? IdTramite { get; set; }
        [DataMember]
        public AcumuladorPolizaFilterType FilterType { get; set; }
    }
}

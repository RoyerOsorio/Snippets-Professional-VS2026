﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class MotivoDocumentoFilter
    {
        [DataMember]
        public int IdMotivoReembolso { get; set; }

        //[DataMember]
        //public int IdTipoDerechohabiente { get; set; }

        [DataMember]
        public MotivoDocumentoFilterType FilterType { get; set; }
    }
}

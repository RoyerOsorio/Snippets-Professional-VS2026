﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class NominaGMMFilter
    {
        [DataMember]
        public int IdNomina { get; set; }

        [DataMember]
        public string Nomina { get; set; }

        [DataMember]
        public NominaGMMFilterType FilterType { get; set; }
    }
}

﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class CatParamFilter
    {
        [DataMember]
        public string Prefijo { get; set; }

        [DataMember]
        public int IdParam { get; set; }

        [DataMember]
        public CatParamFilterType FilterType { get; set; }
    }
}

﻿using System;
using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class TableroDictamenFilter
    {
        [DataMember]
        public int? IdReembolso { get; set; }

        [DataMember]
        public string Nomina { get; set; }

        [DataMember]
        public DateTime? FechaInicio { get; set; }

        [DataMember]
        public DateTime? FechaFin { get; set; }

        [DataMember]
        public int? IdFlujo { get; set; }

        [DataMember]
        public string Folio { get; set; }

        [DataMember]
        public int? NumBeneficiario { get; set; }

        [DataMember]
        public int? IdEstatus { get; set; }

        [DataMember]
        public int? DictamenMedico { get; set; }

        [DataMember]
        public string Rol { get; set; }

        [DataMember]
        public int? IdMotivo { get; set; }

        [DataMember]
        public string FacturaUuid { get; set; }

        [DataMember]
        public string CodEstado { get; set; }

        [DataMember]
        public string CodMunicipio { get; set; }

        [DataMember]
        public string Cliente { get; set; }

        [DataMember]
        public TableroDictamenFilterType FilterType { get; set; }
    }
}

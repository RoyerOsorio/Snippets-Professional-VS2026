﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public enum FlujoReembolsoFilterType : byte
    {
        [EnumMember]
        IdFlujoReembolso,
        [EnumMember]
        DictamenMedico,
        [EnumMember]
        All,
        [EnumMember]
        Nothing
    }

    [DataContract]
    public enum MotivoDocumentoFilterType : byte
    {
        [EnumMember]
        IdMotivoReembolso,
        //[EnumMember]
        //IdTipoDerechohabiente,
        [EnumMember]
        All,
        [EnumMember]
        Nothing
    }

    [DataContract]
    public enum MotivoReembolsoFilterType : byte
    {
        [EnumMember]
        IdMotivoReembolso,
        [EnumMember]
        All,
        [EnumMember]
        Nothing
    }

    [DataContract]
    public enum StatusReembolsoFilterType : byte
    {
        [EnumMember]
        IdStatus,
        [EnumMember]
        All,
        [EnumMember]
        Nothing
    }

    [DataContract]
    public enum TipoDerechohabienteFilterType : byte
    {
        [EnumMember]
        IdTipoDerechohabiente,
        [EnumMember]
        All,
        [EnumMember]
        Nothing
    }

    [DataContract]
    public enum PlanDerechohabienteFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing
    }

    [DataContract]
    public enum CuentaUsuarioFilterType : byte
    {
        [EnumMember]
        Titular,
        [EnumMember]
        All,
        [EnumMember]
        Nothing
    }

    [DataContract]
    public enum CatalogoCFDI33FilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing
    }

    [DataContract]
    public enum TableroDictamenFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing,
        [EnumMember]
        Tablero
    }

    [DataContract]
    public enum TableroRecepcionFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing,
        [EnumMember]
        Tablero
    }


    public enum ReembolsoFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing,
        [EnumMember]
        Nomina,
        [EnumMember]
        IdReembolso,
        [EnumMember]
        Folio,
        [EnumMember]
        NominaIdReembolso,
        [EnumMember]
        NominaFolio,
        [EnumMember]
        Poliza
    }

    public enum DocumentosReembolsoFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing,
        [EnumMember]
        IdMotivo,
        [EnumMember]
        IdReembolso,
        [EnumMember]
        IdDocumento
    }

    public enum DetalleFacturaFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing,
        [EnumMember]
        IdDetalleFactura,
        [EnumMember]
        IdDocumento
    }

    public enum NotaFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing,
        [EnumMember]
        IdReembolso,
        [EnumMember]
        IdFlujo,
        [EnumMember]
        IdEstatus,
        [EnumMember]
        IdReembolsoIdFlujo
    }

    public enum MotivoRechazoType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing,
        [EnumMember]
        Descripcion,
        [EnumMember]
        TipoMotivo,
        IdMotivo
    }

    public enum DocAdicionalFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing,
        [EnumMember]
        IdReembolso,
        [EnumMember]
        IdEstatus
    }

    [DataContract]
    public enum OrigenReembolsoFilterType : byte
    {
        [EnumMember]
        IdOrigen,
        [EnumMember]
        All,
        [EnumMember]
        Nothing
    }

    [DataContract]
    public enum MotivoRechazoReembolsoFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing,
        [EnumMember]
        IdReembolso
    }

    [DataContract]
    public enum TratamientoFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing
    }

    [DataContract]
    public enum DiagnosticoFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing
    }

    [DataContract]
    public enum ContraReciboFilterType : byte
    {
        [EnumMember]
        All
    }

    [DataContract]
    public enum ExcepcionFilterType : byte
    {
        [EnumMember]
        Nomina,
        [EnumMember]
        IdExcepcion,
        [EnumMember]
        All
    }

    public enum DerechohabienteFilterType : byte
    {
        NoDeNomina,
        NoDeNominaGrupo,
        NoDeCredencial,
        NombreCompletoGrupo,
        NoDeNominaGrupoNoBeneficiario,
        All,
        Nothing,
        NoNominaFechaNacimientoNoBeneficiario,
        NoNominaNoBeneficiario
    }

    [DataContract]
    public enum AyudaFilterType : byte
    {
        [EnumMember]
        NominaNumBenef,
        [EnumMember]
        All
    }

    [DataContract]
    public enum CoberturaDentalFilterType : byte
    {
        [EnumMember]
        Autorizado,
        [EnumMember]
        All
    }

    [DataContract]
    public enum PendienteFilterType : byte
    {
        [EnumMember]
        Dictamen,
        [EnumMember]
        All
    }

    [DataContract]
    public enum FechaEstadisFilterType : byte
    {
        [EnumMember]
        Year,
        [EnumMember]
        Fecha,
        [EnumMember]
        All
    }

    [DataContract]
    public enum UsuarioSignalRFilterType : byte
    {
        [EnumMember]
        Profile,
        [EnumMember]
        Nothing,
        [EnumMember]
        All
    }

    [DataContract]
    public enum RecepcionPagoFilterType : byte
    {        
        [EnumMember]
        Nothing,
        [EnumMember]
        All,
        [EnumMember]
        Folio,
        [EnumMember]
        IdRecepcion
    }

    [DataContract]
    public enum ContrareciboPagoFilterType : byte
    {
        [EnumMember]
        Nothing,
        [EnumMember]
        All,
        [EnumMember]
        IdContrarecibo,
        [EnumMember]
        Contrarecibo,
        [EnumMember]
        IdRecepcion
    }

    [DataContract]
    public enum ReclamacionPagoFilterType : byte
    {
        [EnumMember]
        Nothing,
        [EnumMember]
        All,
        [EnumMember]
        IdContrarecibo,
        [EnumMember]
        IdReclamacion
    }

    [DataContract]
    public enum ComentarioFilterType : byte
    {
        [EnumMember]
        Nothing,
        [EnumMember]
        All,
        [EnumMember]
        IdComentario,
        [EnumMember]
        IdReembolso,
        [EnumMember]
        Usuario,
        [EnumMember]
        IdReembolsoUsuario
    }

    [DataContract]
    public enum EncuestaFilterType : byte
    {
        [EnumMember]
        Nothing,
        [EnumMember]
        All
    }

    [DataContract]
    public enum TramiteRelacionadoFilterType : byte
    {
        [EnumMember]
        Nothing,
        [EnumMember]
        All,
        [EnumMember]
        Folio
    }

    [DataContract]
    public enum NominaGMMFilterType : byte
    {
        [EnumMember]
        Nothing,
        [EnumMember]
        All,
        [EnumMember]
        IdNomina,
        [EnumMember]
        Nomina
    }

    [DataContract]
    public enum DetallePagoFilterType : byte
    {
        [EnumMember]
        Contrarecibos,
        [EnumMember]
        All
    }

    public enum BuscarFacturaFilterType : byte
    {
        [EnumMember]
        Nothing,
        [EnumMember]
        All
    }

    public enum TramitesRezagadosFilterType: byte
    {
        [EnumMember]
        All
    }

    [DataContract]
    public enum PlazaFilterType : byte
    {
        [EnumMember]
        All
    }

    [DataContract]
    public enum DeducibleFilterType : byte
    {
        [EnumMember]
        All
    }

    [DataContract]
    public enum TipoServicioFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing
    }

    [DataContract]
    public enum EspecialidadFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing
    }

    [DataContract]
    public enum TableroCheckUpFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing,
        [EnumMember]
        Tablero
    }

    [DataContract]
    public enum CatParamFilterType : byte
    {
        [EnumMember]
        Prefijo,
        [EnumMember]
        IdParam,
        [EnumMember]
        Nothing
    }


    [DataContract]
    public enum ParametroFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Clave
    }

    public enum AcumuladorFilterType : byte
    {        
        [EnumMember]
        Poliza,
        [EnumMember]
        All
    }

    public enum AcumuladorPolizaFilterType : byte
    {
        [EnumMember]
        Acumuladores,
        [EnumMember]
        All
    }

    [DataContract]
    public enum CifraMonedaFilterType : byte
    {
        [EnumMember]
        IdReembolsoIdMotivo,
        [EnumMember]
        IdDocumentoIdMotivo,
        [EnumMember]
        IdDetalleFacturaIdMotivo
    }


    [DataContract]
    public enum IdentificacionOficialFilterType : byte
    {
        [EnumMember]
        All,
        [EnumMember]
        Nothing,
        [EnumMember]
        Activo
    }

}

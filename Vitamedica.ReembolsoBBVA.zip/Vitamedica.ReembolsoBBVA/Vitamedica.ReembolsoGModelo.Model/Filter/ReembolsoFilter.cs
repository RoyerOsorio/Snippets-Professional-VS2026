﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class ReembolsoFilter
    {
        [DataMember]
        public string Nomina { get; set; }

        [DataMember]
        public int IdReembolso { get; set; }

        [DataMember]
        public string Folio { get; set; }

        [DataMember]
        public ReembolsoFilterType FilterType { get; set; }

        [DataMember]
        public string Poliza { get; set; }

        [DataMember]
        public int Beneficiario { get; set; }
    }
}

﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class ComentarioFilter
    {
        [DataMember]
        public int IdComentario { get; set; }

        [DataMember]
        public int IdReembolso { get; set; }

        [DataMember]
        public string Usuario { get; set; }

        [DataMember]
        public ComentarioFilterType FilterType { get; set; }
    }
}

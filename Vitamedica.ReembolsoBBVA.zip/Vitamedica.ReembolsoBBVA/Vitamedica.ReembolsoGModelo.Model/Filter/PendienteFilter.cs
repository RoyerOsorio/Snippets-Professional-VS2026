﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class PendienteFilter
    {
        [DataMember]
        public int Dictamen { get; set; }

        [DataMember]
        public string Grupo { get; set; }

        [DataMember]
        public PendienteFilterType FilterType { get; set; }
    }
}

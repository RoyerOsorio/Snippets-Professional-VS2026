﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class TramitesRezagadosFilter
    {
        [DataMember]
        public int IdDictamen { get; set; }

        [DataMember]
        public int Dias { get; set; }

        [DataMember]
        public TramitesRezagadosFilterType FilterType { get; set; }
    }
}

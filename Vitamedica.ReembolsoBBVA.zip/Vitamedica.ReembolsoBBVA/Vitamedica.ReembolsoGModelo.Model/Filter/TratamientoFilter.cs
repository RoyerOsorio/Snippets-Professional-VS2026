﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class TratamientoFilter
    {
        [DataMember]
        public string IdTran { get; set; }

        [DataMember]
        public string Tratamiento { get; set; }
    }
}

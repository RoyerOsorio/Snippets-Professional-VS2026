﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class EspecialidadFilter
    {
        [DataMember]
        public int IdEspecialidad { get; set; }

        [DataMember]
        public EspecialidadFilterType FilterType { get; set; }
    }
}

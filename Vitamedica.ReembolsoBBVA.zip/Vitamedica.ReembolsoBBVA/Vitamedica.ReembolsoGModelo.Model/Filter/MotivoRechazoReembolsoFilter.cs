﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class MotivoRechazoReembolsoFilter
    {
        [DataMember]
        public int IdReembolso { get; set; }

        [DataMember]
        public int RolMotivo { get; set; }

        [DataMember]
        public MotivoRechazoReembolsoFilterType FilterType { get; set; }
    }
}

﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class OrigenReembolsoFilter
    {
        [DataMember]
        public int IdOrigen { get; set; }

        [DataMember]
        public OrigenReembolsoFilterType FilterType { get; set; }
    }
}

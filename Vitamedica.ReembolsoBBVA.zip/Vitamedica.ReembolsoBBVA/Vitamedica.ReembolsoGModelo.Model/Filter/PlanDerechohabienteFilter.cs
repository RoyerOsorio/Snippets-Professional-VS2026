﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class PlanDerechohabienteFilter
    {
        [DataMember]
        public string Plan { get; set; }

        [DataMember]
        public string Grupo { get; set; }

        [DataMember]
        public string SubGrupo { get; set; }

        [DataMember]
        public PlanDerechohabienteFilterType FilterType { get; set; }
    }
}

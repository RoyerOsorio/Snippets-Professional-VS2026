﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class MotivoReembolsoFilter
    {
        [DataMember]
        public int IdMotivoReembolso { get; set; }

        [DataMember]
        public MotivoReembolsoFilterType FilterType { get; set; }
    }
}

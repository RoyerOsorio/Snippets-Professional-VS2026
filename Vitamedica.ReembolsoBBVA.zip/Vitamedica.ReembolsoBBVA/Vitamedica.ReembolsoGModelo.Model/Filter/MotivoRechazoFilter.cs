﻿using System.Runtime.Serialization;
namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class MotivoRechazoFilter
    {
        [DataMember]
        public string Descripcion { get; set; }

        [DataMember]
        public int TipoMotivo { get; set; }

        public int IdMotivo { get; set; }

        [DataMember]
        public int TipoUsuario { get; set; }

        [DataMember]
        public MotivoRechazoType FilterType { get; set; }
    }
}

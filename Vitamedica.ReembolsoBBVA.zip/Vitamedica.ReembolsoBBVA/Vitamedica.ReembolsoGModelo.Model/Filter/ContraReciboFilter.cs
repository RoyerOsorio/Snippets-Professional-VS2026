﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class ContraReciboFilter
    {
        [DataMember]
        public ContraReciboFilterType FilterType { get; set; }
    }
}
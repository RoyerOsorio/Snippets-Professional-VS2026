﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class DetalleFacturaFilter
    {
        [DataMember]
        public int IdDetalleFactura { get; set; }

        [DataMember]
        public int IdDocumento { get; set; }

        [DataMember]
        public DetalleFacturaFilterType FilterType { get; set; }
    }
}

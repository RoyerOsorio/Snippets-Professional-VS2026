﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class PlazaFilter
    {
        [DataMember]
        public string CodMunicipio { get; set; }

        [DataMember]
        public string CodEstado { get; set; }

        [DataMember]
        public PlazaFilterType FilterType { get; set; }
    }
}

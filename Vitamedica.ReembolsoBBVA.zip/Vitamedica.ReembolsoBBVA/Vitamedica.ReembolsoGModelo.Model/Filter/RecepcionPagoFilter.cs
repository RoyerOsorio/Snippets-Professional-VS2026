﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class RecepcionPagoFilter
    {
        [DataMember]
        public int IdRecepcion { get; set; }

        [DataMember]
        public string Folio { get; set; }

        [DataMember]
        public RecepcionPagoFilterType FilterType { get; set; }
    }
}

﻿using System;
using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class TableroRecepcionFilter
    { 
        [DataMember]
        public string Folio { get; set; }

        [DataMember]
        public string Cliente { get; set; }

        [DataMember]
        public string Proveedor { get; set; }

        [DataMember]
        public string Grupo { get; set; }

        [DataMember]
        public DateTime? FechaInicio { get; set; }

        [DataMember]
        public DateTime? FechaFin { get; set; }

        [DataMember]
        public string FolioFiscal { get; set; }

        [DataMember]
        public string TipoProceso { get; set; }

        [DataMember]
        public int? Estacion { get; set; }

        [DataMember]
        public int? IdEstatus { get; set; }

        [DataMember]
        public string Contrarecibo { get; set; }

        [DataMember]
        public string Reclamacion { get; set; }

        [DataMember]
        public string Remesa { get; set; }

        [DataMember]
        public int TipoUsuario { get; set; }

        [DataMember]
        public string Prpr_id { get; set; }

        [DataMember]
        public TableroRecepcionFilterType FilterType { get; set; }
    }
}

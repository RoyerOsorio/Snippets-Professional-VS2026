﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class FlujoReembolsoFilter
    {
        [DataMember]
        public int IdFujo { get; set; }

        [DataMember]
        public bool DictamenMedico { get; set; }

        [DataMember]
        public FlujoReembolsoFilterType FilterType { get; set; }
    }
}

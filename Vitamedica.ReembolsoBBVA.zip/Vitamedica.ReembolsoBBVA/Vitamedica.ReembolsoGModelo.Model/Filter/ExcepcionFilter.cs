﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class ExcepcionFilter
    {
        [DataMember]
        public int IdExcepcion { get; set; }

        [DataMember]
        public string Nomina { get; set; }

        [DataMember]
        public ExcepcionFilterType FilterType { get; set; }
    }
}

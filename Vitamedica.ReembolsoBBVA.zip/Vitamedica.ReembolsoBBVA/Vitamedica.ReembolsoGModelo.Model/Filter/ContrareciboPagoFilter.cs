﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class ContrareciboPagoFilter
    {
        [DataMember]
        public int IdContrarecibo { get; set; }

        [DataMember]
        public int IdRecepcionPago { get; set; }

        [DataMember]
        public string Contrarecibo { get; set; }

        [DataMember]
        public ContrareciboPagoFilterType FilterType { get; set; }
    }
}

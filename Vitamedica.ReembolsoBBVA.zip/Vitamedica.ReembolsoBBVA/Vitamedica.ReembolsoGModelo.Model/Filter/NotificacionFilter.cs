﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class NotificacionFilter
    {
        [DataMember]
        public string Nomina { get; set; }

        [DataMember]
        public int NoBeneficiario { get; set; }

        [DataMember]
        public int IdTramite { get; set; }
    }
}

﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class AyudaFilter
    {
        [DataMember]
        public string Nomina { get; set; }

        [DataMember]
        public int NumBeneficiario { get; set; }

        [DataMember]
        public AyudaFilterType FilterType { get; set; }
    }
}

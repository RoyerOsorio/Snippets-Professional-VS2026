﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class DiagnosticoFilter
    {
        [DataMember]
        public string IdDiag { get; set; }

        [DataMember]
        public string Diagnostico { get; set; }
    }
}

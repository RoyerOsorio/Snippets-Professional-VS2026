﻿using System.Runtime.Serialization;


namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class ParametroResumeFilter
    {
        [DataMember]
        public string Clave { get; set; }

        [DataMember]
        public ParametroFilterType FilterType { get; set; }
    }
}

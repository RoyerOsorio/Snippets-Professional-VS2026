﻿using System;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    public class DerechohabienteFilter
    {
        public DerechohabienteFilterType FilterType { get; set; }

        public string NoDeNomina { get; set; }

        public string NoDeCredencial { get; set; }

        public string IdGrupo { get; set; }

        public string Nombre { get; set; }

        public string ApellidoPaterno { get; set; }

        public string ApellidMaterno { get; set; }

        public short NoBeneficiario { get; set; }

        public DateTime? FechaNacimiento { get; set; }
    }
}

﻿using System;
using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class EncuestaFilter
    {
        [DataMember]
        public DateTime? FechaInicio { get; set; }

        [DataMember]
        public DateTime? FechaFin { get; set; }

        [DataMember]
        public EncuestaFilterType FilterType { get; set; }
    }
}

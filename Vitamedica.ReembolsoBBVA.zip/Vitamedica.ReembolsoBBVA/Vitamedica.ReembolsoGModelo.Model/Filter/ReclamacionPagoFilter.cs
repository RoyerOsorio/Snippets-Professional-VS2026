﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class ReclamacionPagoFilter
    {
        [DataMember]
        public int IdReclamacion { get; set; }

        [DataMember]
        public int IdContrarecibo { get; set; }

        [DataMember]
        public ReclamacionPagoFilterType FilterType { get; set; }
    }
}

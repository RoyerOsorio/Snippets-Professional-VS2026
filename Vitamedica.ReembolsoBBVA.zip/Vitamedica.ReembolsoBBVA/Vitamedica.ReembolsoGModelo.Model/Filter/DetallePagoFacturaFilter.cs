﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class DetallePagoFacturaFilter
    {
        [DataMember]
        public List<string> Contrarecibos { get; set; }

        [DataMember]
        public DetallePagoFilterType FilterType { get; set; }
    }
}

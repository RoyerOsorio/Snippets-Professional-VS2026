﻿using System.Runtime.Serialization;

namespace Vitamedica.ReembolsoGModelo.Model.Filter
{
    [DataContract]
    public class CifraMonedaFilter
    {
        [DataMember]
        public int IdReembolso { get; set; }

        [DataMember]
        public int IdDocumento { get; set; }

        [DataMember]
        public int IdDetalleFactura { get; set; }

        [DataMember]
        public int IdMotivo { get; set; }

        [DataMember]
        public CifraMonedaFilterType FilterType { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Vitamedica.Models.Reembolso;
using Vitamedica.Models.Shared;
using Vitamedica.Reembolso.GModelo.Business.Model.Cuantas;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

using Vitamedica.Models.Reembolso;
using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Model.Service.Request.Reembolso;
using Vitamedica.ReembolsoGModelo.Model.Service.Response.Reembolso;
using Vitamedica.ReembolsoGModelo.Model.ViewModels;
using Vitamedica.ReembolsoGModelo.Model.Models;
using Vitamedica.ReembolsoGModelo.Model.Service.Request;
using Vitamedica.ReembolsoGModelo.Shared.Models;



namespace Vitamedica.Reembolso.GModelo.Business.Agent
{
    public class ReembolsoAgent : IDisposable
    {
        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

        //public ListDatosINEClabe ObtenerListaCuentaClabe(string Clabe)
        //{
        //    MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
        //    IMapper Mapper = config.CreateMapper();

        //    EmptyRequest request = new EmptyRequest
        //    {
        //        Param = Clabe,
        //        TipoDato = TipoParametro.String
        //    };

        //    ListDatosINEClabe result = new ListDatosINEClabe();

        //    ListDatosCuentaClabeFilterResponse response = null;

        //    using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
        //        response = proxy.ObtenerListaCuentaClabe(request);

        //    if (!response.ValidExecution)
        //    {
        //        foreach (var item in response.ErrorList)
        //        {
        //            result.Mensaje = item.Description;
        //        }
        //    }
        //    else
        //    {
        //        result.Lista = Mapper.Map<List<DatosINEClabeViewModel>>(response.List);
        //    }

        //    result.EsCorrecto = response.ValidExecution;

        //    return result;


        //}


        #region Identificación Oficial


        public MensajeViewModel RegistrarINE(INEViewModel model)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            INE Cuenta = Mapper.Map<INE>(model);
            MensajeViewModel result = new MensajeViewModel();

            INEOperationRequest request = new INEOperationRequest() { Item = Cuenta };
            EmptyResponse response = null;

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
                response = proxy.RegistrarINE(request);

            if (response.ValidExecution)
                result.Id = Convert.ToInt32(response.Result);
            else
                foreach (var item in response.ErrorList)
                    result.Mensaje = item.Description;

            result.EsCorrecto = response.ValidExecution;

            return result;
        }

        public INEResumeViewModel ObtenerINEPoliza(string Poliza)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            INEResumeViewModel Cuenta = new INEResumeViewModel();
            EmptyRequest request = new EmptyRequest
            {
                Param = Poliza,
                //TipoDato = TipoParametro.String
            };

            INEOperationResponse response = null;

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerINEPoliza(request);
            }

            if (response.ValidExecution)
            {
                Cuenta = Mapper.Map<INEResume, INEResumeViewModel>(response.Item);
                Cuenta.EsCorrecto = response.ValidExecution;
            }
            else
            {
                Cuenta.EsCorrecto = false;
                foreach (var item in response.ErrorList)
                {
                    Cuenta.Mensaje += item.Description + " ";
                }
            }

            Cuenta.EsCorrecto = response.ValidExecution;

            return Cuenta;
        }



        public ListIdentificacionOficialResumeViewModel ObtenerListaIdentificacionOficial(out List<string> errores, IdentificacionOficialFilter model, int page = 1, int records = 10)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            ListIdentificacionOficialResumeViewModel consulta = new ListIdentificacionOficialResumeViewModel();
            IdentificacionOficialFilter Filter = Mapper.Map<IdentificacionOficialFilter>(model);

            IdentificacionOficialFilterRequest request = new IdentificacionOficialFilterRequest()
            {
                Item = Filter,
                pagination = new Pagination()
                {
                    Page = page,
                    Records = records
                },
                RequiredPagination = true
            };
            ListIdentificacionOficialResumeFilterResponse response = null;

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerListaIdentificacionOficial(request);
            }

            if (response.ValidExecution)
            {
                consulta.Lista = Mapper.Map<List<INEResume>, List<INEResumeViewModel>>(response.List);
                consulta.Pagination = Mapper.Map<PaginationViewModel>(response.pagination);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }

            return consulta;
        }


        public MensajeViewModel ActualizarINE(INEViewModel model)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            INE Cuenta = Mapper.Map<INE>(model);
            MensajeViewModel result = new MensajeViewModel();

            INEOperationRequest request = new INEOperationRequest() { Item = Cuenta };
            EmptyResponse response = null;

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
                response = proxy.ActualizarINE(request);

            if (response.ValidExecution)
                result.Id = Convert.ToInt32(response.Result);
            else
                foreach (var item in response.ErrorList)
                    result.Mensaje = item.Description;

            result.EsCorrecto = response.ValidExecution;

            return result;
        }

        #endregion


        #region Reembolso


        public ListDetalleReembolsoResumeViewModel ObtenerListaDetalleReembolso(out List<string> errores, ReembolsoFilterViewModel filter, int page = 1, int records = 10)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            filter.FilterType = ReembolsoFilterType.IdReembolso;


            ListDetalleReembolsoResumeViewModel consulta = new ListDetalleReembolsoResumeViewModel();
            ReembolsoFilter FilterService = Mapper.Map<ReembolsoFilter>(filter);

            ReembolsoFilterRequest request = new ReembolsoFilterRequest()
            {
                Item = FilterService,
                pagination = new Pagination()
                {
                    Page = page,
                    Records = records
                },
                RequiredPagination = false
            };
            ListDetalleReembolsoResumeFilterResponse response = null;

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerListaDetalleReembolso(request);
            }

            if (response.ValidExecution)
            {
                consulta.Lista = Mapper.Map<List<DetalleReembolsoResume>, List<DetalleReembolsoResumeViewModel>>(response.List);
                consulta.Pagination = Mapper.Map<PaginationViewModel>(response.pagination);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }

            return consulta;
        }

        public DatosReembolsoResumeViewModel RegistrarReembolso(out List<string> errores, DatosReembolsoViewModel model)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            DatosReembolso reembolso = Mapper.Map<DatosReembolso>(model);
            DatosReembolsoResumeViewModel result = new DatosReembolsoResumeViewModel();

            DatosReembolsoOperationRequest request = new DatosReembolsoOperationRequest() { Item = reembolso };
            DatosReembolsoResumeOperationResponse response = null;

            errores = new List<string>();
            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
                response = proxy.RegistrarReembolso(request);

            if (!response.ValidExecution)
                foreach (var item in response.ErrorList)
                    errores.Add(item.Description);
            else
                result = Mapper.Map<DatosReembolsoResumeViewModel>(response.Item);

            return result;
        }

        #endregion

        #region Bitacora


        public int RegistrarBitacora(out List<string> errores, BitacoraViewModel model)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            Bitacora bitacora = Mapper.Map<Bitacora>(model);

            int result = 0;

            BitacoraOperationRequest request = new BitacoraOperationRequest() { Item = bitacora };
            EmptyResponse response = null;

            errores = new List<string>();
            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
                response = proxy.RegistrarBitacora(request);

            if (!response.ValidExecution)
                foreach (var item in response.ErrorList)
                    errores.Add(item.Description);
            else
                result = (int)response.Result;

            return result;

        }


        public ListDocumentosReembolsoResumeViewModel ObtenerListaDocumentosReembolso(out List<string> errores, DocumentosReembolsoFilterViewModel filter, int page = 1, int records = 10)
        {

            filter.FilterType = DocumentosReembolsoFilterType.IdReembolso;

            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            ListDocumentosReembolsoResumeViewModel consulta = new ListDocumentosReembolsoResumeViewModel();
            DocumentosReembolsoFilter FilterService = Mapper.Map<DocumentosReembolsoFilter>(filter);

            DocumentosReembolsoFilterRequest request = new DocumentosReembolsoFilterRequest()
            {
                Item = FilterService,
                pagination = new Pagination()
                {
                    Page = page,
                    Records = records
                },
                RequiredPagination = false
            };
            DocumentosReembolsoResumeFilterResponse response = null;

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerListaDocumentosReembolso(request);
            }

            if (response.ValidExecution)
            {
                consulta.Lista = Mapper.Map<List<DocumentosReembolsoResume>, List<DocumentosReembolsoResumeViewModel>>(response.List);
                consulta.Pagination = Mapper.Map<PaginationViewModel>(response.pagination);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }

            return consulta;
        }


        #endregion

        #region Documentos


        internal List<DocumentoRequeridoResumeViewModel> ObtenerListaDocumentoRequerido(out List<string> errores, MotivoDocumentoFilterViewModel model)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            List<DocumentoRequeridoResumeViewModel> consulta = new List<DocumentoRequeridoResumeViewModel>();

            MotivoDocumentoFilter Filter = Mapper.Map<MotivoDocumentoFilter>(model);

            MotivoDocumentoFilterRequest request = new MotivoDocumentoFilterRequest()
            {
                Item = Filter
            };

            DocumentoRequeridoResumeFilterResponse response = null;

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerListaDocumentoRequerido(request);
            }

            if (response.ValidExecution)
            {
                consulta = Mapper.Map<List<DocumentoRequeridoResume>, List<DocumentoRequeridoResumeViewModel>>(response.List);

            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }

            return consulta;
        }





        #endregion


        #region Motivo


        public List<MotivoReembolsoViewModel> ObtenerListaMotivoReembolso(out List<string> errores, MotivoReembolsoFilterViewModel model, int page = 1, int records = 10)
        {
            model.FilterType = MotivoReembolsoFilterType.Nothing;



            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            List<MotivoReembolsoViewModel> consulta = new List<MotivoReembolsoViewModel>();
            MotivoReembolsoFilter Filter = Mapper.Map<MotivoReembolsoFilter>(model);

            MotivoReembolsoFilterRequest request = new MotivoReembolsoFilterRequest()
            {
                Item = Filter,
                pagination = new Pagination()
                {
                    Page = page,
                    Records = records
                },
                RequiredPagination = false
            };
            MotivoReembolsoFilterResponse response = null;

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerListaMotivoReembolso(request);
            }

            if (response.ValidExecution)
            {
                consulta = Mapper.Map<List<MotivoReembolso>, List<MotivoReembolsoViewModel>>(response.List);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }

            return consulta;
        }

        #endregion

        #region Reembolso

        public List<ReembolsoDocumentoResumeViewModel> RegistrarReembolsoDocumento(out List<string> errores, ListReembolsoDocumentoViewModel model)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            List<ReembolsoDocumento> reembolso = Mapper.Map<List<ReembolsoDocumento>>(model.List);

            List<ReembolsoDocumentoResumeViewModel> modelResult = new List<ReembolsoDocumentoResumeViewModel>();

            ListReembolsoDocumentoOperationRequest request = new ListReembolsoDocumentoOperationRequest() { Item = reembolso };
            ListReembolsoDocumentoResumeFilterResponse response = null;

            errores = new List<string>();
            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
                response = proxy.RegistrarReembolsoDocumento(request);

            if (!response.ValidExecution)
                foreach (var item in response.ErrorList)
                    errores.Add(item.Description);
            else
                modelResult = Mapper.Map<List<ReembolsoDocumentoResumeViewModel>>(response.List);

            return modelResult;
        }

        public ListTableroDictamenResumeViewModel ObtenerListaTableroDictamen(out List<string> errores, TableroDictamenFilterViewModel model, int page = 1, int records = 10)
        {
            model.FilterType = TableroDictamenFilterType.Tablero;
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            ListTableroDictamenResumeViewModel consulta = new ListTableroDictamenResumeViewModel();
            TableroDictamenFilter Filter = Mapper.Map<TableroDictamenFilter>(model);

            TableroDictamenFilterRequest request = new TableroDictamenFilterRequest()
            {
                Item = Filter,
                pagination = new Pagination()
                {
                    Page = page,
                    Records = records
                },
                RequiredPagination = true
            };
            ListTableroDictamenResumeFilterResponse response = null;

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerListaTableroDictamen(request);
            }

            if (response.ValidExecution)
            {
                consulta.Lista = Mapper.Map<List<TableroDictamenResume>, List<TableroDictamenResumeViewModel>>(response.List);
                consulta.Pagination = Mapper.Map<PaginationViewModel>(response.pagination);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }

            return consulta;
        }

        #endregion


        #region Cuenta bancario


        public CuentaBancariaResumeViewModel ObtenerCuentaBancariaPoliza(string Poliza)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            CuentaBancariaResumeViewModel Cuenta = new CuentaBancariaResumeViewModel();
            EmptyRequest request = new EmptyRequest
            {
                Param = Poliza,
                TipoDato = TipoParametro.String
            };

            CuentaBancariaOperationResponse response = null;

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerCuentaBancariaPoliza(request);
            }

            if (response.ValidExecution)
            {
                Cuenta = Mapper.Map<CuentaBancariaResume, CuentaBancariaResumeViewModel>(response.Item);
                Cuenta.EsCorrecto = response.ValidExecution;
            }
            else
            {
                Cuenta.EsCorrecto = false;
                foreach (var item in response.ErrorList)
                {
                    Cuenta.Mensaje += item.Description + " ";
                }
            }

            Cuenta.EsCorrecto = response.ValidExecution;

            return Cuenta;
        }

        public MensajeViewModel ActualizarStatusBitacoraEnProceso(NuevaCuentaResume model)
        {

            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            MensajeViewModel result = new MensajeViewModel();

            NuevaCuentaOperationRequest request = new NuevaCuentaOperationRequest
            {
                Item = Mapper.Map<NuevaCuenta>(model)
            };


            EmptyResponse response = null;

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
                response = proxy.ActualizarStatusBitacoraEnProceso(request);

            if (response.ValidExecution)
                result.Id = Convert.ToInt32(response.Result);
            else
                foreach (var item in response.ErrorList)
                    result.Mensaje = item.Description;

            result.EsCorrecto = response.ValidExecution;

            return result;
        }

        #endregion

        #region Acumuladores


        public MensajeViewModel RegistrarCifraInicial(CifrasResumeViewModel model)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();


            MensajeViewModel result = new MensajeViewModel();
            CifraResumeOperationRequest request = new CifraResumeOperationRequest
            {
                Item = Mapper.Map<CifrasResume>(model)
            };

            EmptyResponse response = null;

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
                response = proxy.RegistrarCifraInicial(request);

            if (response.ValidExecution)
            {
                result.Id = Convert.ToInt32(response.Result);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    result.Mensaje = item.Description;
                }
            }

            result.EsCorrecto = response.ValidExecution;

            return result;


        }
        public List<AcumuladorRsumeViewModel> ObtenerListaAcumuladoresPoliza(AcumuladorPolizaFilterViewModel filter)
        {



            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            AcumuladorPolizaFilterRequest request = new AcumuladorPolizaFilterRequest
            {
                Item = Mapper.Map<AcumuladorPolizaFilter>(filter),
                RequiredPagination = false
            };

            List<AcumuladorRsumeViewModel> result = new List<AcumuladorRsumeViewModel>();

            AcumuladorResumeFilterResponse response = null;

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
                response = proxy.ObtenerListaAcumuladoresPoliza(request);

            if (response.ValidExecution)
            {
                result = Mapper.Map<List<AcumuladorRsumeViewModel>>(response.List);
            }

            //result.EsCorrecto = response.ValidExecution;

            return result;


        }


        public ListaCifrasResumeViewModel ObtenerListaAcumuladores(AcumuladorFilterViewModel filter)
        {
            filter.FilterType = AcumuladorFilterType.All;

            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            AcumuladorFilterRequest request = new AcumuladorFilterRequest
            {
                Item = Mapper.Map<AcumuladorFilter>(filter),
                RequiredPagination = false
            };

            ListaCifrasResumeViewModel result = new ListaCifrasResumeViewModel();

            CifrasResumeFilterResponse response = null;

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
                response = proxy.ObtenerListaAcumuladores(request);

            if (!response.ValidExecution)
            {
                foreach (var item in response.ErrorList)
                {
                    result.Mensaje = item.Description;
                }
            }
            else
            {
                result.Lista = Mapper.Map<List<CifrasResumeViewModel>>(response.List);
            }

            result.EsCorrecto = response.ValidExecution;

            return result;


        }


        #endregion


        #region ICD


        public DiagnosticoTratamientoResumeViewModel ActualizarDiagnosticoTratamiento(DiagnosticoTratamientoResumeViewModel model)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            DiagnosticoTratamientoResumeViewModel resultado = new DiagnosticoTratamientoResumeViewModel
            {
                CPT = model.CPT,
                ICD = model.ICD,
                IdDocumento = model.IdDocumento,
                IdFactura = model.IdFactura
            };

            EmptyResponse response = new EmptyResponse();
            DiagnosticoTratamientoResumeOperationRequest request = new DiagnosticoTratamientoResumeOperationRequest
            {
                Item = Mapper.Map<DiagnosticoTratamientoResume>(model)
            };

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ActualizarDiagnosticoTratamiento(request);
            }

            if (response.ValidExecution)
            {
                resultado.EsCorrecto = (bool)response.Result;
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    resultado.Mensaje = item.Description;
                }
            }

            return resultado;
        }


        public List<DiagnosticoResumeViewModel> ObtenerListaDiagnostico(out List<string> errores, DiagnosticoFilterViewModel filter)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            List<DiagnosticoResumeViewModel> resultado = new List<DiagnosticoResumeViewModel>();
            DiagnosticoResumeFilterResponse response = new DiagnosticoResumeFilterResponse();
            DiagnosticoFilterRequest request = new DiagnosticoFilterRequest
            {
                Item = Mapper.Map<DiagnosticoFilter>(filter),
                RequiredPagination = false
            };

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerListaDiagnostico(request);
            }

            if (response.ValidExecution)
            {
                resultado = Mapper.Map<List<DiagnosticoResumeViewModel>>(response.List);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }

            return resultado;
        }


        #endregion

        #region Documentos

        public List<DetalleFacturaViewModel> ObtenerDetalleFactura(out List<string> errores, DetalleFacturaFilterViewModel filter)
        {

            filter.FilterType = DetalleFacturaFilterType.IdDocumento;

            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            List<DetalleFacturaViewModel> consulta = new List<DetalleFacturaViewModel>();
            DetalleFacturaFilter filterRequest = Mapper.Map<DetalleFacturaFilter>(filter);

            DetalleFacturaFilterRequest request = new DetalleFacturaFilterRequest()
            {
                Item = filterRequest
            };
            DetalleFacturaFilterResponse response = null;

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerDetalleFactura(request);
            }

            if (response.ValidExecution)
            {
                consulta = Mapper.Map<List<DetalleFactura>, List<DetalleFacturaViewModel>>(response.List);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }

            return consulta;
        }

        #endregion

        #region Notas


        public List<NotaResumeViewModel> ObtenerNotas(out List<string> errores, NotaFilterViewModel filter)
        {

            filter.FilterType = NotaFilterType.IdReembolso;


            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            List<NotaResumeViewModel> resultado = new List<NotaResumeViewModel>();
            NotaResumeFilterResponse response = new NotaResumeFilterResponse();
            NotaFilter filterRequest = Mapper.Map<NotaFilter>(filter);
            NotaFilterRequest request = new NotaFilterRequest
            {
                Item = filterRequest,
                RequiredPagination = false
            };

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerNotas(request);
            }

            if (response.ValidExecution)
            {
                resultado = Mapper.Map<List<NotaResumeViewModel>>(response.List);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }

            return resultado;
        }
        #endregion


        #region Dianostico

        public MensajeViewModel ActualizarReembolsoCP(ReembolsoCPResumeViewModel model)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            MensajeViewModel result = new MensajeViewModel();

            EmptyResponse response = new EmptyResponse();
            ReembolsoCPResumeOperationRequest request = new ReembolsoCPResumeOperationRequest
            {
                Item = Mapper.Map<ReembolsoCPResume>(model)
            };

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ActualizarReembolsoCP(request);
            }

            if (!response.ValidExecution)
            {
                foreach (var item in response.ErrorList)
                {
                    result.Mensaje = item.Description;
                }
            }
            else
            {
                result.EsCorrecto = (bool)response.Result;
            }

            result.EsCorrecto = response.ValidExecution;

            return result;
        }


        #endregion

        #region Conceptos (Detalle)

        public List<DetalleFactura> RegistrarFacturaDetalle(out List<string> errores, ListDetalleFacturaViewModel model)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            List<DetalleFactura> reembolso = Mapper.Map<List<DetalleFactura>>(model.List);

            List<DetalleFactura> result = new List<DetalleFactura>();

            ListDetalleFacturaOperationRequest request = new ListDetalleFacturaOperationRequest() { Item = reembolso };
            DetalleFacturaFilterResponse response = null;

            errores = new List<string>();
            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
                response = proxy.RegistrarFacturaDetalle(request);

            if (!response.ValidExecution)
                foreach (var item in response.ErrorList)
                    errores.Add(item.Description);
            else
                result = response.List;

            return result;
        }


        #endregion

        public List<DocumentoAdicionalResumeViewModel> ObtenerListaDocAdicionales(out List<string> errores, DocAdicionalFilterViewModel filter)
        {

            filter.FilterType = DocAdicionalFilterType.All;
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            List<DocumentoAdicionalResumeViewModel> resultado = new List<DocumentoAdicionalResumeViewModel>();
            DocumentoAdicionalResumeFilterResponse response = new DocumentoAdicionalResumeFilterResponse();
            filter.FilterType = DocAdicionalFilterType.All;
            DocAdicionalFilter filterRequest = Mapper.Map<DocAdicionalFilter>(filter);
            DocAdicionalFilterRequest request = new DocAdicionalFilterRequest
            {
                Item = filterRequest,
                RequiredPagination = false
            };

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerListaDocAdicionales(request);
            }

            if (response.ValidExecution)
            {
                resultado = Mapper.Map<List<DocumentoAdicionalResumeViewModel>>(response.List);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }

            return resultado;
        }



        public Tuple<MensajeViewModel, ComentarioReembolsoViewModel> ObtenerComentarioReembolso(ComentarioFilterViewModel model)
        {
            model.FilterType = ComentarioFilterType.IdReembolso;


            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            ComentarioReembolsoViewModel result = new ComentarioReembolsoViewModel();
            MensajeViewModel msg = new MensajeViewModel();

            ComentarioReembolsoOperationResponse response = new ComentarioReembolsoOperationResponse();
            ComentarioFilterRequest request = new ComentarioFilterRequest
            {
                Item = Mapper.Map<ComentarioFilter>(model)
            };

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerComentarioReembolso(request);
            }

            if (!response.ValidExecution)
            {
                foreach (var item in response.ErrorList)
                {
                    msg.Mensaje = item.Description;
                }
            }
            else
            {
                result = Mapper.Map<ComentarioReembolsoViewModel>(response.Item);
            }

            msg.EsCorrecto = response.ValidExecution;

            return new Tuple<MensajeViewModel, ComentarioReembolsoViewModel>(msg, result);
        }

        #region PolizaPagada

        public ListPolizaPagadaResumeViewModel ObtenerListaPolizaPagada(out List<string> errores, ReembolsoFilterViewModel model, int page = 1, int records = 10, bool requiredPagination = false)
        {
            model.FilterType = ReembolsoFilterType.Nothing;
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            ListPolizaPagadaResumeViewModel consulta = new ListPolizaPagadaResumeViewModel();
            ReembolsoFilter Filter = Mapper.Map<ReembolsoFilter>(model);

            ReembolsoFilterRequest request = new ReembolsoFilterRequest()
            {
                Item = Filter,
                pagination = new Pagination()
                {
                    Page = page,
                    Records = records
                },
                RequiredPagination = requiredPagination
            };
            ListPolizaPagadaResumeFilterResponse response = null;

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerListaPolizaPagada(request);
            }

            if (response.ValidExecution)
            {
                consulta.Lista = Mapper.Map<List<PolizaPagadaResume>, List<PolizaPagadaResumeViewModel>>(response.List);
                consulta.Pagination = Mapper.Map<PaginationViewModel>(response.pagination);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }

            return consulta;
        }
        #endregion


        #region Tratamientos
        internal List<TratamientoResumeViewModel> ObtenerListaTratamientoDental(out List<string> errores, TratamientoFilterViewModel filter)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            List<TratamientoResumeViewModel> resultado = new List<TratamientoResumeViewModel>();
            TratamientoResumeFilterResponse response = new TratamientoResumeFilterResponse();
            TratamientoFilterRequest request = new TratamientoFilterRequest
            {
                Item = Mapper.Map<TratamientoFilter>(filter),
                RequiredPagination = false
            };

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerListaTratamientoDental(request);
            }

            if (response.ValidExecution)
            {
                resultado = Mapper.Map<List<TratamientoResumeViewModel>>(response.List);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }

            return resultado;
        }

        /// <summary>
        /// Obtiene el catalogo de tratamientos directo del servicio de Reembolso, diferente del servicio Reembolsos BBVA
        /// </summary>
        /// <param name="errores"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        internal List<TratamientoResumeViewModel> ObtenerListaTratamiento(out List<string> errores, TratamientoFilterViewModel filter)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            List<TratamientoResumeViewModel> resultado = new List<TratamientoResumeViewModel>();
            TratamientoResumeFilterResponse response = new TratamientoResumeFilterResponse();
            TratamientoFilterRequest request = new TratamientoFilterRequest
            {
                Item = Mapper.Map<TratamientoFilter>(filter),
                RequiredPagination = false
            };

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerListaTratamiento(request);
            }

            if (response.ValidExecution)
            {
                resultado = Mapper.Map<List<TratamientoResumeViewModel>>(response.List);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }

            return resultado;
        }
        #endregion

        #region Pagos
        internal ListLayoutSINBAResumeViewModel ObtenerLayoutPago()
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            ListLayoutSINBAResumeViewModel resultado = new ListLayoutSINBAResumeViewModel
            {
                List = new List<LayoutSINBAResumeViewModel>()
            };
            LayoutSINBAResumeFilterResponse response = new LayoutSINBAResumeFilterResponse();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerLayoutSINBA();
            }

            if (response.ValidExecution)
            {
                resultado.List = Mapper.Map<List<LayoutSINBAResumeViewModel>>(response.List);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    resultado.Mensaje = item.Description;
                }
            }
            resultado.EsCorrecto = response.ValidExecution;

            return resultado;
        }
        #endregion
    }
}

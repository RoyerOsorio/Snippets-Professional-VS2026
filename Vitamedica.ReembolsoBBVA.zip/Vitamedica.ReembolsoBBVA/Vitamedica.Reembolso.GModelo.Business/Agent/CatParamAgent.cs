﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Vitamedica.Models.Reembolso;
using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Model.Service.Request.Reembolso;
using Vitamedica.ReembolsoGModelo.Model.Service.Response.Reembolso;
using Vitamedica.ReembolsoGModelo.Model.ViewModels;




namespace Vitamedica.Reembolso.GModelo.Business.Agent
{
    public class CatParamAgent : IDisposable
    {
        internal List<CatParamDetalleViewModel> ObtenerListaCatParam(out List<string> errores, CatParamFilterViewModel model)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            List<CatParamDetalleViewModel> consulta = new List<CatParamDetalleViewModel>();

            CatParamFilter Filter = Mapper.Map<CatParamFilter>(model);

            CatParamFilterRequest request = new CatParamFilterRequest()
            {
                Item = Filter
            };

            CatParamFilterResponse response = null;

            errores = new List<string>();

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerListaCatParam(request);
            }

            if (response.ValidExecution)
            {
                consulta = Mapper.Map<List<CatParamDetalle>, List<CatParamDetalleViewModel>>(response.List);
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    errores.Add(item.Description);
                }
            }
            return consulta;
        }

        internal ParametroResumeViewModel ObtenerParametro(ParametroResumeFilterViewModel filter)
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(new ReembolsoMapperProfile()));
            IMapper Mapper = config.CreateMapper();

            ParametroResumeViewModel item = new ParametroResumeViewModel();

            ParametroResumeFilter Filter = Mapper.Map<ParametroResumeFilter>(filter);

            ParametroResumeFilterRequest request = new ParametroResumeFilterRequest()
            {
                Item = Filter
            };

            ParametroResumeOperationResponse response = null;

            using (ReembolsoGModeloServiceClient proxy = new ReembolsoGModeloServiceClient())
            {
                response = proxy.ObtenerParametro(request);
            }

            if (response.ValidExecution)
            {
                item = Mapper.Map<ParametroResumeViewModel>(response.Item);
                item.Valor = Utils.CryptoBBVA.Decrypt(item.Valor).Replace("\0", "").Trim();
            }
            else
            {
                foreach (var itemE in response.ErrorList)
                {
                    item.Mensaje = itemE.Description;
                }
            }
            item.EsCorrecto = response.ValidExecution;

            return item;
        }


        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}

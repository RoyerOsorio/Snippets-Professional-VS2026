﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Vitamedica.Models.Reembolso;
using ModelReembolso = Vitamedica.ReembolsoGModelo.Model.Models;
using FilterReembolso = Vitamedica.ReembolsoGModelo.Model.Filter;
using ViewModelReembolso = Vitamedica.ReembolsoGModelo.Model.ViewModels;
using Vitamedica.Models.Shared;
using SignalViewModelPortal = Vitamedica.Models.Hubs;





namespace Vitamedica.Reembolso.GModelo.Business.Agent
{
    public class ReembolsoMapperProfile : Profile
    {
        public ReembolsoMapperProfile()
        {
            CreateMap<ModelReembolso.MotivoReembolso, MotivoReembolsoViewModel>();
            CreateMap<MotivoReembolsoViewModel, ModelReembolso.MotivoReembolso>();
            CreateMap<ModelReembolso.MotivoReembolso, MotivoReembolsoViewModel>();
            CreateMap<MotivoReembolsoViewModel, ModelReembolso.MotivoReembolso>();
            CreateMap<FilterReembolso.MotivoReembolsoFilter, MotivoReembolsoFilterViewModel>();
            CreateMap<MotivoReembolsoFilterViewModel, FilterReembolso.MotivoReembolsoFilter>();

            //CreateMap<FilterReembolso.TipoDerechohabienteFilter, TipoDerechohabienteFilterViewModel>();
            //CreateMap<TipoDerechohabienteFilterViewModel, FilterReembolso.TipoDerechohabienteFilter>();

            //CreateMap<ModelPortal.TipoDerechohabiente, TipoDerechohabienteViewModel>();
            //CreateMap<TipoDerechohabienteViewModel, ModelPortal.TipoDerechohabiente>();

            //CreateMap<FilterPortal.PlanDerechohabienteFilter, PlanDerechohabienteFilterViewModel>();
            //CreateMap<PlanDerechohabienteFilterViewModel, FilterPortal.PlanDerechohabienteFilter>();

            CreateMap<ModelReembolso.Bitacora, BitacoraViewModel>();
            CreateMap<BitacoraViewModel, ModelReembolso.Bitacora>();

            CreateMap<ViewModelReembolso.DocumentoRequeridoResume, DocumentoRequeridoResumeViewModel>();
            CreateMap<DocumentoRequeridoResumeViewModel, ViewModelReembolso.DocumentoRequeridoResume>();

            CreateMap<ModelReembolso.DetalleFactura, DetalleFacturaViewModel>();
            CreateMap<DetalleFacturaViewModel, ModelReembolso.DetalleFactura>();

            CreateMap<FilterReembolso.MotivoDocumentoFilter, MotivoDocumentoFilterViewModel>();
            CreateMap<MotivoDocumentoFilterViewModel, FilterReembolso.MotivoDocumentoFilter>();

            CreateMap<FilterReembolso.MotivoReembolsoFilter, MotivoReembolsoFilterViewModel>();
            CreateMap<MotivoReembolsoFilterViewModel, FilterReembolso.MotivoReembolsoFilter>();

            CreateMap<ModelReembolso.MotivoReembolso, MotivoReembolsoViewModel>()
                .ForMember(model => model.MontoRealCob, options => options.MapFrom(viewmodel => viewmodel.Coaseguro > 0 ? (viewmodel.Cobertura - ((viewmodel.Coaseguro * viewmodel.Cobertura) / 100)) : viewmodel.Cobertura)); ;
            CreateMap<MotivoReembolsoViewModel, ModelReembolso.MotivoReembolso>();

            CreateMap<ModelReembolso.ReembolsoDocumento, ReembolsoDocumentoViewModel>();
            CreateMap<ReembolsoDocumentoViewModel, ModelReembolso.ReembolsoDocumento>();

            CreateMap<ModelReembolso.DatosReembolso, DatosReembolsoViewModel>();
            CreateMap<DatosReembolsoViewModel, ModelReembolso.DatosReembolso>();

            CreateMap<FilterReembolso.CuentaUsuarioFilter, CuentaUsuarioFilterViewModel>();
            CreateMap<CuentaUsuarioFilterViewModel, FilterReembolso.CuentaUsuarioFilter>();

            CreateMap<ViewModelReembolso.CuentaUsuarioResume, CuentaUsuarioResumeViewModel>();
            CreateMap<CuentaUsuarioResumeViewModel, ViewModelReembolso.CuentaUsuarioResume>();

            //CreateMap<FilterReembolso.CatalogoCFDI33Filter, CatalogoCFDI33FilterViewModel>();
            //CreateMap<CatalogoCFDI33FilterViewModel, FilterReembolso.CatalogoCFDI33Filter>();

            //CreateMap<ViewModelReembolso.CatalogoCFDI33Resume, CatalogoCFDI33ResumeViewModel>();

            //CreateMap<FactElectResumeViewModel, ViewModelReembolso.FactElectResume>();
            //CreateMap<ViewModelReembolso.FactElectResume, FactElectResumeViewModel>();

            //CreateMap<DetalleFactElectResumeViewModel, ViewModelReembolso.DetalleFactElectResume>();

            //CreateMap<ConceptoFactElectResumeViewModel, ViewModelReembolso.ConceptoFactElectResume>();

            //CreateMap<CFDIRelacionadoResumeViewModel, ViewModelReembolso.CFDIRelacionadoResume>();

            //CreateMap<BeneficiarioAseguradoResumeViewModel, ViewModelReembolso.BeneficiarioAseguradoResume>();

            //CreateMap<HistoriaFacturaResumeViewModel, ViewModelReembolso.HistoriaFacturaResume>();

            CreateMap<ViewModelReembolso.ReembolsoDocumentoResume, ReembolsoDocumentoResumeViewModel>();

            CreateMap<ViewModelReembolso.DatosReembolsoResume, DatosReembolsoResumeViewModel>();

            CreateMap<ViewModelReembolso.TableroDictamenResume, TableroDictamenResumeViewModel>();
            CreateMap<TableroDictamenFilterViewModel, FilterReembolso.TableroDictamenFilter>();
            CreateMap<Vitamedica.ReembolsoGModelo.Shared.Models.Pagination, PaginationViewModel>();
            CreateMap<ViewModelReembolso.ReporteAdmonResume, ReporteAdmonResumeViewModel>();
            CreateMap<ViewModelReembolso.ReporteAdmonTableroResume, ReporteAdmonTableroResumeViewModel>();

            CreateMap<ModelReembolso.DetalleFactura, DetalleFacturaViewModel>();
            CreateMap<ViewModelReembolso.DocumentosReembolsoResume, DocumentosReembolsoResumeViewModel>();
            CreateMap<ReembolsoFilterViewModel, FilterReembolso.ReembolsoFilter>();
            CreateMap<DocumentosReembolsoFilterViewModel, FilterReembolso.DocumentosReembolsoFilter>();
            CreateMap<ViewModelReembolso.DetalleReembolsoResume, DetalleReembolsoResumeViewModel>();
            CreateMap<DetalleFacturaResumeViewModel, ViewModelReembolso.DetalleFacturaResume>();
            CreateMap<DetalleFacturaFilterViewModel, FilterReembolso.DetalleFacturaFilter>();
            CreateMap<DocumentoReembolsoResumeViewModel, ViewModelReembolso.DocumentoReembolsoResume>();

            CreateMap<FlujoReembolsoFilterViewModel, FilterReembolso.FlujoReembolsoFilter>();
            CreateMap<ViewModelReembolso.FlujoReembolsoResume, FlujoReembolsoResumeViewModel>();
            CreateMap<StatusReembolsoFilterViewModel, FilterReembolso.StatusReembolsoFilter>();
            CreateMap<ModelReembolso.StatusReembolso, StatusReembolsoViewModel>();

            CreateMap<NotaFilterViewModel, FilterReembolso.NotaFilter>();
            CreateMap<ViewModelReembolso.NotaResume, NotaResumeViewModel>();

            CreateMap<MotivoRechazoFilterViewModel, FilterReembolso.MotivoRechazoFilter>();
            CreateMap<ModelReembolso.MotivoRechazo, MotivoRechazoViewModel>();

            CreateMap<DocAdicionalFilterViewModel, FilterReembolso.DocAdicionalFilter>();
            CreateMap<ViewModelReembolso.DocumentoAdicionalResume, DocumentoAdicionalResumeViewModel>();
            CreateMap<DocAdicionalResumeViewModel, ViewModelReembolso.DocAdicionalResume>();
            CreateMap<DocAdicionalesViewModel, ModelReembolso.DocAdicionales>();

            CreateMap<OrigenReembolsoFilterViewModel, FilterReembolso.OrigenReembolsoFilter>();
            CreateMap<ModelReembolso.OrigenReembolso, OrigenReembolsoViewModel>();

            CreateMap<ModelReembolso.MotivoConsulta, MotivoConsultaViewModel>();

            CreateMap<ReembolsoResumeViewModel, ViewModelReembolso.ReembolsoResume>();

            CreateMap<MotivoRechazoReembolsoFilterViewModel, FilterReembolso.MotivoRechazoReembolsoFilter>();

            CreateMap<FechaInicialReembolsoResumeViewModel, ViewModelReembolso.FechaInicialReembolsoResume>();

            //CreateMap<BitacoraModulosResumeViewModel, ViewModelPortal.BitacoraModulosResume>();

            //CreateMap<ViewModelReembolso.ReembolsoDentalResume, ReembolsoDentalResumeViewModel>();

            CreateMap<ViewModelReembolso.MotivoRechazoResume, MotivoRechazoResumeViewModel>();

            CreateMap<DiagnosticoFilterViewModel, FilterReembolso.DiagnosticoFilter>();
            CreateMap<TratamientoFilterViewModel, FilterReembolso.TratamientoFilter>();
            //CreateMap<CoberturaDentalFilterViewModel, FilterReembolso.CoberturaDentalFilter>();
            CreateMap<ViewModelReembolso.DiagnosticoResume, DiagnosticoResumeViewModel>();
            CreateMap<ViewModelReembolso.TratamientoResume, TratamientoResumeViewModel>();
            //CreateMap<ViewModelReembolso.CoberturaDentalResume, CoberturaDentalResumeViewModel>();
            CreateMap<DiagnosticoTratamientoResumeViewModel, ViewModelReembolso.DiagnosticoTratamientoResume>();

            CreateMap<ModelReembolso.ContraRecibo, ContraReciboResumeViewModel>();

            CreateMap<NotaViewModel, ModelReembolso.Nota>();

            //CreateMap<ExcepcionFilterViewModel, FilterReembolso.ExcepcionFilter>();
            //CreateMap<ViewModelReembolso.ExcepcionResume, ExcepcionResumeViewModel>();
            CreateMap<ViewModelReembolso.PagosBancomerResume, PagosBancomerResumeViewModel>()
                .ForMember(model => model.FechaDescargaAux, options => options.MapFrom(viewmodel => viewmodel.FechaDescarga.HasValue ? viewmodel.FechaDescarga.Value.ToShortDateString() : ""));

            //CreateMap<FolioReembolsoVIBAResumeViewModel, ViewModelReembolso.FolioReembolsoVIBAResume>();
            //CreateMap<PagoVIBAResumeViewModel, ViewModelReembolso.PagoVIBAResume>();
            //CreateMap<ViewModelReembolso.LayoutSINBAResume, LayoutSINBAResumeViewModel>();

            CreateMap<ViewModelReembolso.ReporteMovimientoResume, ReporteMovimientoResumeViewModel>();

            //CreateMap<QuejaResumenFilterViewModel, AsisteFilter.QuejaResumenFilter>();
            //CreateMap<PaginationViewModel, Asiste.Shared.Models.Pagination>();
            //CreateMap<AsisteViewModel.QuejaResumen, QuejaResumenViewModel>();
            //CreateMap<Asiste.Shared.Models.Pagination, PaginationViewModel>();

            CreateMap<ViewModelReembolso.FolioResume, FolioResumeViewModel>();
            CreateMap<ViewModelReembolso.AyudaResume, AyudaResumeViewModel>();
            CreateMap<AyudaFilterViewModel, FilterReembolso.AyudaFilter>();
            CreateMap<ViewModelReembolso.PendienteResume, PendienteResumeViewModel>();
            CreateMap<PendienteFilterViewModel, FilterReembolso.PendienteFilter>();

            //CreateMap<ViewModelReembolso.FechaEstadisResume, FechaEstadisResumeViewModel>();
            //CreateMap<FechaEstadisFilterViewModel, FilterReembolso.FechaEstadisFilter>();
            //CreateMap<FechaEstadisViewModel, ModelReembolso.FechaEstadis>();

            //CreateMap<ViewModelReembolso.ContrareciboResume, ContrareciboViewModel>();
            //CreateMap<ViewModelReembolso.DocumentoFactResume, DocumentoFactResumeViewModel>();
            //CreateMap<AsociaFctResumeViewModel, ViewModelReembolso.AsociaFctResume>();


            //CreateMap<ViewModelReembolso.TableroRecepcionResume, TableroRecepcionResumeViewModel>();
            //CreateMap<TableroRecepcionFilterViewModel, FilterReembolso.TableroRecepcionFilter>();

            //CreateMap<ModelReembolso.FlujoRecepcion, FlujoRecepcionResumeViewModel>();


            CreateMap<ViewModelReembolso.DepartamentoResume, DepartamentoResumeViewModel>();

            CreateMap<ReembolsoCPResumeViewModel, ViewModelReembolso.ReembolsoCPResume>();
            CreateMap<VoBoResumeViewModel, ViewModelReembolso.VoBoResume>();
            CreateMap<ComentarioReembolsoViewModel, ModelReembolso.ComentarioReembolso>();
            CreateMap<ComentarioFilterViewModel, FilterReembolso.ComentarioFilter>();
            CreateMap<ModelReembolso.ComentarioReembolso, ComentarioReembolsoViewModel>();
            CreateMap<ViewModelReembolso.ReporteAdmonDHBResume, ReporteAdmonDHBResumeViewModel>();
            CreateMap<EncuestaFilterViewModel, FilterReembolso.EncuestaFilter>();
            CreateMap<ViewModelReembolso.EncuestaResume, EncuestaResumeViewModel>()
                .ForMember(model => model.FechaFinalizadoAux, options => options.MapFrom(ViewModel => ViewModel.FechaFinalizado.ToString("yyyy-MM-dd HH:mm:ss")))
                .ForMember(model => model.FechaPagoAux, options => options.MapFrom(ViewModel => ViewModel.FechaPago.HasValue ? ViewModel.FechaPago.Value.ToString("yyyy-MM-dd") : ""))
                .ForMember(model => model.FechaRegistroAux, options => options.MapFrom(ViewModel => ViewModel.FechaRegistro.ToString("yyyy-MM-dd")));

            CreateMap<TramiteRelacionadoFilterViewModel, FilterReembolso.TramiteRelacionadoFilter>();
            CreateMap<ViewModelReembolso.TramiteRelacionadoResume, TramiteRelacionadoResumeViewModel>();

            //CreateMap<ViewModelReembolso.NominaGMMResume, NominaGMMResumeViewModel>();
            //CreateMap<NominaGMMFilterViewModel, FilterReembolso.NominaGMMFilter>();

            //CreateMap<ViewModelReembolso.ImpuestoResume, ImpuestoResumeViewModel>();
            //CreateMap<ViewModelReembolso.TipoFactorResume, TipoFactorResumeViewModel>();
            //CreateMap<ProvRetencionResumeViewModel, ViewModelReembolso.ProvRetencionResume>();
            //CreateMap<ProductoServicioResumeViewModel, ViewModelReembolso.ProductoServicioResume>();

            //CreateMap<BuscarFacturaFilterViewModel, FilterReembolso.BuscarFacturaFilter>();
            CreateMap<ViewModelReembolso.Notificacion200Resume, Notificacion200ResumeViewModel>();
            CreateMap<NotificacionFilterViewModel, FilterReembolso.NotificacionFilter>();

            CreateMap<TramitesRezagadosFilterViewModel, FilterReembolso.TramitesRezagadosFilter>();
            CreateMap<ViewModelReembolso.TramitesRezagadosResume, TramitesRezagadosResumeViewModel>();

            CreateMap<SignalViewModelPortal.UsuariosReembolsoViewModel, ViewModelReembolso.UsuarioSignalRResume>();
            CreateMap<ViewModelReembolso.UsuarioSignalRResume, SignalViewModelPortal.UsuariosReembolsoViewModel>();
            CreateMap<SignalViewModelPortal.UsuarioSignalRFilterViewModel, FilterReembolso.UsuarioSignalRFilter>();

            //CreateMap<PlazaFilterViewModel, FilterReembolso.PlazaFilter>();

            //CreateMap<TipoServicioFilterViewModel, FilterReembolso.TipoServicioFilter>();
            //CreateMap<ModelReembolso.TipoServicio, TipoServicioViewModel>();
            //CreateMap<EspecialidadFilterViewModel, FilterReembolso.EspecialidadFilter>();
            //CreateMap<ModelReembolso.Especialidad, EspecialidadViewModel>();

            CreateMap<CuentaBancariaViewModel, ModelReembolso.CuentaBancaria>();
            CreateMap<ViewModelReembolso.CuentaBancariaResume, CuentaBancariaResumeViewModel>();
            CreateMap<TokenTesoreriaViewModel, ModelReembolso.TokenTesoreria>();
            CreateMap<ViewModelReembolso.TokenTesoreriaResume, TokenTesoreriaResumeViewModel>();
            CreateMap<TokenFilterTesoreriaViewModel, FilterReembolso.TokenFilterTesoreria>();
            CreateMap<ViewModelReembolso.EstatusTokenTesoreriaResume, EstatusTokenTesoreriaResumeViewModel>();
            CreateMap<ModelReembolso.Banco, BancoViewModel>();
            CreateMap<ViewModelReembolso.CifrasResume, Models.Reembolso.CifrasResumeViewModel>();
            CreateMap<ViewModelReembolso.PolizaPendienteResume, Models.Reembolso.PolizaPendienteResumeViewModel>();
            CreateMap<ModelReembolso.MotivoRechazoCuenta, MotivoRechazoCuentaViewModel>();
            CreateMap<DocumentoVoucherViewModel, ViewModelReembolso.DocumentoVoucher>();

            CreateMap<CatParamDetalleViewModel, ViewModelReembolso.CatParamDetalle>();
            CreateMap<ViewModelReembolso.CatParamDetalle, CatParamDetalleViewModel>();
            CreateMap<CatParamFilterViewModel, FilterReembolso.CatParamFilter>();

            CreateMap<ParametroResumeFilterViewModel, FilterReembolso.ParametroResumeFilter>();
            CreateMap<ViewModelReembolso.ParametroResume, ParametroResumeViewModel>();
            CreateMap<ActualizaEstatusCuentaViewModel, ModelReembolso.ActualizaEstatusCuenta>();
            CreateMap<ViewModelReembolso.DocumentoTesoreria, DocumentoTesoreriaViewModel>();
            CreateMap<Models.Reembolso.ValidaDisponibilidadResumeViewModel, ViewModelReembolso.ValidaDisponibilidadResume>();
            CreateMap<Models.Reembolso.AcumuladorFilterViewModel, FilterReembolso.AcumuladorFilter>();

            CreateMap<BitacoraModulosResumeViewModel, ViewModelReembolso.BitacoraModulosResume>();
            CreateMap<ViewModelReembolso.DatosCuentaBancariaClabe, DatosCuentaBancariaClabeViewModel>();

            CreateMap<CuentaBancariaNominaViewModel, ViewModelReembolso.CuentaBancariaNomina>();
            CreateMap<ViewModelReembolso.LayoutNPSResume, LayoutNPSResumeViewModel>();
            CreateMap<SiniestroResumeViewModel, ViewModelReembolso.SiniestroResume>();
            CreateMap<ViewModelReembolso.GuardianResume, GuardianResumeViewModel>();

            CreateMap<RechazoCuentaResume, ModelReembolso.RechazoCuenta>();
            CreateMap<NuevaCuentaResume, ModelReembolso.NuevaCuenta>();
            CreateMap<ViewModelReembolso.LayoutBancosResume, LayoutBancosResumeViewModel>();
            CreateMap<PaginationViewModel, ReembolsoGModelo.Shared.Models.Pagination>();
            CreateMap<ReembolsoGModelo.Shared.Models.Pagination, PaginationViewModel>();

            CreateMap<AcumuladorPolizaFilterViewModel, FilterReembolso.AcumuladorPolizaFilter>();
            CreateMap<ViewModelReembolso.AcumuladorRsume, AcumuladorRsumeViewModel>();
            CreateMap<ViewModelReembolso.ContadorEstacionResume, ContadorEstacionResumeViewModel>();
            CreateMap<Models.Reembolso.CifrasResumeViewModel, ViewModelReembolso.CifrasResume>();

            CreateMap<Models.Reembolso.CifraMonedaFilterViewModel, FilterReembolso.CifraMonedaFilter>();
            CreateMap<ViewModelReembolso.CifraMonedaResume, Models.Reembolso.CifraMonedaResumeViewModel>();
            CreateMap<ModelReembolso.Moneda, Models.Reembolso.MonedaViewModel>()
                .ForMember(model => model.Select, options => options.MapFrom(ViewModel => string.Format("({0}) - {1}", ViewModel.Codigo, ViewModel.DescripcionEspanol)));



            CreateMap<INEViewModel, ModelReembolso.INE>();
            CreateMap<ViewModelReembolso.INEResume, INEResumeViewModel>();

            CreateMap<ViewModelReembolso.PolizaPagadaResume, PolizaPagadaResumeViewModel>();
            
        }
    }
}

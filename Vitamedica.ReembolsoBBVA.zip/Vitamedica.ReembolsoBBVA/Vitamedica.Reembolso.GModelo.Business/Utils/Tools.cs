﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Reembolso.GModelo.Business.Utils.Network;

namespace Vitamedica.Reembolso.GModelo.Business.Utils
{
    public class Tools
    {

    }
    
}

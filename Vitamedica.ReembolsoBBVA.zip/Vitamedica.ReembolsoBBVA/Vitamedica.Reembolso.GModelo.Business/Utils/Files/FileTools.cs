﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Reembolso.GModelo.Business.Utils.Network;
using System.Web.Mvc;


namespace Vitamedica.Reembolso.GModelo.Business.Utils.Files
{
    public class FileTools
    {
       

        /// <summary>
        /// Carga en el servidor el archivo de acuerdo a las credenciales proporcionadas
        /// </summary>
        /// <param name="equipo"></param>
        /// <param name="dominio"></param>
        /// <param name="usuario"></param>
        /// <param name="contrasena"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        private bool upLoadFile(string equipo, string dominio, string usuario, string contrasena, string path)
        {
            string directory = Path.GetDirectoryName(path);

            using (NetworkShareAccesser.Access(equipo, dominio, usuario, contrasena))
            {
                if (!Directory.Exists(directory))
                    Directory.CreateDirectory(directory);

                try
                {
                    if (System.IO.File.Exists(path))
                        System.IO.File.Delete(path);
                    return true;
                }
                catch {
                    return false;
                }

                //System.IO.File.Copy(path + fileName, fullDefaultPath, true);
            }
        }

    }
}

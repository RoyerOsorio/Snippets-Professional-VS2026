﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Excel;
using Vitamedica.Reembolso.GModelo.Business.Model.Cuantas;

namespace Vitamedica.Reembolso.GModelo.Business.Cuentas
{
    public class ValidacionCuenta
    {
        public String fileName;

        public string fileExtencion;

        public List<ArchivoRetro> getDatosCunatabancaria(string path, string TipoArchivo)
        {
            List<ArchivoRetro> listDatosCuentaBancariaClabe = new List<ArchivoRetro>();
            if (path != null)
                listDatosCuentaBancariaClabe = fromDataTableToCuentaBancaria(path);
            return listDatosCuentaBancariaClabe;
        }

        private DataTable getDataFromExcel(string path)
        {
            IVitaExcel vitaExcel;

            vitaExcel = new VitaExcelNPOI();


            vitaExcel.InitializeWorkbook(path);

            vitaExcel.xlsxToDT();

            return vitaExcel.getDataSet();
        }

        public List<ArchivoRetro> fromDataTableToCuentaBancaria(string path)
        {
            DataTable data = getDataFromExcel(path);
            ListDatosCuentaBancariaClabe listDatosCuentaBancariaClabe = new ListDatosCuentaBancariaClabe();
            //listDatosCuentaBancariaClabe.Lista = new List<DatosCuentaBancariaClabe>();

            ExcelValidacionesSolicitadas excelValidacionesSolicitadas = new ExcelValidacionesSolicitadas();

            List< ArchivoRetro > listArchivoRetro = new List<ArchivoRetro>();

            for (int i = excelValidacionesSolicitadas.initRow; i < data.Rows.Count; i++)
            {
                //DatosCuentaBancariaClabe datosCuentaBancariaClabe = new DatosCuentaBancariaClabe();

                //excelValidacionesSolicitadas.nombreBeneficierio = (int)row[excelValidacionesSolicitadas.nombreBeneficierio];
                //excelValidacionesSolicitadas.numeroCuenta = (int)row[excelValidacionesSolicitadas.numeroCuenta];

                ArchivoRetro item = new ArchivoRetro();



                item.CuentaOrigen = (string)data.Rows[i][excelValidacionesSolicitadas.numeroCuenta];
                item.Estatus = (string)data.Rows[i][excelValidacionesSolicitadas.Estadovalidación];
                item.Fecha = (string)data.Rows[i][excelValidacionesSolicitadas.Fecha];
                item.NombreCuenta = (string)data.Rows[i][excelValidacionesSolicitadas.nombreBeneficierio];
                item.Observaciones = (string)data.Rows[i][excelValidacionesSolicitadas.returnReason];





                listArchivoRetro.Add(item);

            //    foreach (DataColumn col in data.Columns)
            //    {
            //        //Console.WriteLine("{0} = {1}", col.ColumnName, row[col]);
            //        Console.WriteLine("{0} = {1}", col.ColumnName, row[col]);
            //    }
            }

            return listArchivoRetro;
        }


    }
}

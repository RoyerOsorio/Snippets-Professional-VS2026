﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Reembolso.GModelo.Business.Business
{
    public class ViewRules
    {
        public static bool showBtnSiguienteDictamen(string viewName)
        {
            // This method checks if the button "Siguiente Dictamen" should be shown based on the view name.


            return true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Models.Reembolso;
using Vitamedica.Models.Reembolso.UI;
using Vitamedica.Reembolso.GModelo.Business.Agent;
using Vitamedica.Reembolso.GModelo.Business.Model.Cuantas;
using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Reembolso.GModelo.Business.Business
{
    public class IdentificacionOficial
    {

        public List<string> lstErrores = new List<string>();

        Vitamedica.Models.Reembolso.INEResumeViewModel resultCuenta = new Vitamedica.Models.Reembolso.INEResumeViewModel();


        #region Bitacora


        /// <summary>
        /// Procedimiento para actualizar estatus y registro en bitacora
        /// </summary>
        /// <returns></returns>
        public bool ActualizarBitacoraRechazo(string poliza, string usuario, string tipoUsuario)
        {

            // Busca los tramites relacionados a la poliza

            bool result = true;


            ListDocumentosReembolsoResumeViewModel lstDocumentos = new ListDocumentosReembolsoResumeViewModel();
            using (ReembolsoAgent agent = new ReembolsoAgent())
            {
                ListTableroDictamenResumeViewModel lstTableroAux = agent.ObtenerListaTableroDictamen(out lstErrores, new TableroDictamenFilterViewModel
                {
                    FilterType = TableroDictamenFilterType.Tablero,
                    Nomina = poliza
                    //}, 1, 50);
                });

                CuentaBancariaResumeViewModel ctaBanc = getCuentaBancaria(poliza);

                

                // Existe algun tramite ralacionado a la poliza en dictamen administrativo (2)  y en proceso (1)

                if (lstTableroAux != null &&
                    lstTableroAux.Lista != null &&
                    (existeTramitesEnDictamenAdministrativoProceso(lstTableroAux.Lista) ||
                    existeTramitesEnValidacionIdentificacion(lstTableroAux.Lista)) ||
                    existeTramitesEnValidacionTesoreria(lstTableroAux.Lista)// Validación Identificación Oficial
                    )
                {
                    List<TableroDictamenResumeViewModel> listTableroDictamenResumeViewModel = new List<TableroDictamenResumeViewModel>();


                    //listTableroDictamenResumeViewModel = lstTableroAux.Lista.Where(x => (x.IdFlujo == 2 && x.IdEstatus == 1) || (x.IdFlujo == 2 && x.IdEstatus == 8)).ToList();

                    listTableroDictamenResumeViewModel.AddRange(getListByDictamenAdministrativoProceso(lstTableroAux.Lista));
                    listTableroDictamenResumeViewModel.AddRange(getListByValidacionIdentificacion(lstTableroAux.Lista));
                    listTableroDictamenResumeViewModel.AddRange(getListByValidacionTesoreria(lstTableroAux.Lista));


                    // Regitra nueva tubla en la tabla de bitacora

                    foreach (var tableroDictamenResumeViewModel in listTableroDictamenResumeViewModel)
                    {

                        BitacoraViewModel bitacora = new BitacoraViewModel
                        {
                            Usuario = usuario,
                            Fecha = DateTime.Now,
                            Comentario = "Identificación rechazada",
                            IdFlujo = 1,
                            IdReembolso = tableroDictamenResumeViewModel.IdReembolso,
                            IdStatus = 4, // Incompleto
                            TipoUsuario = tipoUsuario
                        };

                        agent.RegistrarBitacora(out lstErrores, bitacora);
                    }
                }

                
            }
            


            return result;
        }

        public CuentaBancariaResumeViewModel getCuentaBancaria(string poliza)
        {
            CuentaBancariaResumeViewModel ctaBanc = new CuentaBancariaResumeViewModel();

            using (ReembolsoAgent agent = new ReembolsoAgent())
                ctaBanc = agent.ObtenerCuentaBancariaPoliza(poliza);

            return ctaBanc;
        }

        public bool cuentaBancariaValidada(CuentaBancariaResumeViewModel ctaBanc)
        {
            
            if (ctaBanc == null)
                return false;
            if (!ctaBanc.Activo)
             return false;
            return true;
        }

        public bool cuentaBancariaNueva(CuentaBancariaResumeViewModel ctaBanc)
        {
            if (ctaBanc == null)
                return false;
            if (!ctaBanc.Activo)
                return string.IsNullOrWhiteSpace(ctaBanc.DescripcionRechazo) && ctaBanc.IdMotivo == null;
            return true;
        }


        /// <summary>
        /// Procedimiento para actualizar estatus y registro en bitacora
        /// </summary>
        /// <returns></returns>
        public bool ActualizarBitacoraAceptacion(string poliza, string usuario, string tipoUsuario)
        {

            // Busca los tramites relacionados a la poliza

            bool result = true;


            ListDocumentosReembolsoResumeViewModel lstDocumentos = new ListDocumentosReembolsoResumeViewModel();
            using (ReembolsoAgent agent = new ReembolsoAgent())
            {
                ListTableroDictamenResumeViewModel lstTableroAux = agent.ObtenerListaTableroDictamen(out lstErrores, new TableroDictamenFilterViewModel
                {
                    FilterType = TableroDictamenFilterType.Tablero,
                    Nomina = poliza
                    //}, 1, 50);
                });

                CuentaBancariaResumeViewModel ctaBanc = getCuentaBancaria(poliza);

                if (cuentaBancariaValidada(ctaBanc))
                {

                    // Existe algun tramite ralacionado a la poliza en dictamen administrativo (2)  y en proceso (1)

                    if (lstTableroAux != null &&
                        lstTableroAux.Lista != null &&
                        (existeTramitesEnDictamenAdministrativoProceso(lstTableroAux.Lista) ||
                        existeTramitesEnValidacionIdentificacion(lstTableroAux.Lista)))
                    {
                        List<TableroDictamenResumeViewModel> listTableroDictamenResumeViewModel = new List<TableroDictamenResumeViewModel>();


                        //listTableroDictamenResumeViewModel = lstTableroAux.Lista.Where(x => x.IdFlujo == 2 && x.IdEstatus == 8).ToList();

                        listTableroDictamenResumeViewModel.AddRange(getListByDictamenAdministrativoProceso(lstTableroAux.Lista));
                        listTableroDictamenResumeViewModel.AddRange(getListByValidacionIdentificacion(lstTableroAux.Lista));


                        // Regitra nueva tubla en la tabla de bitacora

                        foreach (var tableroDictamenResumeViewModel in listTableroDictamenResumeViewModel)
                        {

                            BitacoraViewModel bitacora = new BitacoraViewModel
                            {
                                Usuario = usuario,
                                Fecha = DateTime.Now,
                                Comentario = "Cuenta aceptada, Identificacion Aceptada",
                                IdFlujo = 2,
                                IdReembolso = tableroDictamenResumeViewModel.IdReembolso,
                                IdStatus = 1,
                                TipoUsuario = tipoUsuario
                            };

                            agent.RegistrarBitacora(out lstErrores, bitacora);
                        }

                    }


                }
                else
                {
                    if (cuentaBancariaNueva(ctaBanc))
                    {

                        // Existe algun tramite ralacionado a la poliza en dictamen administrativo (2)  y en proceso (1)

                        if (lstTableroAux != null &&
                            lstTableroAux.Lista != null &&
                            (existeTramitesEnDictamenAdministrativoProceso(lstTableroAux.Lista) ||
                            existeTramitesEnValidacionIdentificacion(lstTableroAux.Lista)))
                        {
                            List<TableroDictamenResumeViewModel> listTableroDictamenResumeViewModel = new List<TableroDictamenResumeViewModel>();


                            //listTableroDictamenResumeViewModel = lstTableroAux.Lista.Where(x => x.IdFlujo == 2 && x.IdEstatus == 8).ToList();

                            listTableroDictamenResumeViewModel.AddRange(getListByDictamenAdministrativoProceso(lstTableroAux.Lista));
                            listTableroDictamenResumeViewModel.AddRange(getListByValidacionIdentificacion(lstTableroAux.Lista));


                            // Regitra nueva tubla en la tabla de bitacora

                            foreach (var tableroDictamenResumeViewModel in listTableroDictamenResumeViewModel)
                            {

                                BitacoraViewModel bitacora = new BitacoraViewModel
                                {
                                    Usuario = usuario,
                                    Fecha = DateTime.Now,
                                    Comentario = "Cuanta nueva, identificación aceptada",
                                    IdFlujo = 2,
                                    IdReembolso = tableroDictamenResumeViewModel.IdReembolso,
                                    IdStatus = 7,
                                    TipoUsuario = tipoUsuario
                                };

                                agent.RegistrarBitacora(out lstErrores, bitacora);
                            }

                        }


                    }
                    else
                    {
                        // Existe algun tramite ralacionado a la poliza en dictamen administrativo (2)  y en proceso (1)

                        if (lstTableroAux != null &&
                            lstTableroAux.Lista != null &&
                            (existeTramitesEnDictamenAdministrativoProceso(lstTableroAux.Lista) ||
                            existeTramitesEnValidacionIdentificacion(lstTableroAux.Lista)))
                        {
                            List<TableroDictamenResumeViewModel> listTableroDictamenResumeViewModel = new List<TableroDictamenResumeViewModel>();


                            listTableroDictamenResumeViewModel.AddRange(getListByDictamenAdministrativoProceso(lstTableroAux.Lista));
                            listTableroDictamenResumeViewModel.AddRange(getListByValidacionIdentificacion(lstTableroAux.Lista));

                            // Regitra nueva tubla en la tabla de bitacora

                            foreach (var tableroDictamenResumeViewModel in listTableroDictamenResumeViewModel)
                            {

                                BitacoraViewModel bitacora = new BitacoraViewModel
                                {
                                    Usuario = usuario,
                                    Fecha = DateTime.Now,
                                    Comentario = "Validar CUentabancaria",
                                    IdFlujo = 1,
                                    IdReembolso = tableroDictamenResumeViewModel.IdReembolso,
                                    IdStatus = 4,
                                    TipoUsuario = tipoUsuario
                                };

                                agent.RegistrarBitacora(out lstErrores, bitacora);
                            }

                        }
                    }
                }
            }


            return result;
        }

        /// <summary>
        /// Procedimiento para actualizar estatus y registro en bitacora
        /// </summary>
        /// <returns></returns>
        public bool ActualizarBitacoraDocumentoNuevo(string poliza, string usuario, string tipoUsuario)
        {

            // Busca los tramites relacionados a la poliza

            ListDocumentosReembolsoResumeViewModel lstDocumentos = new ListDocumentosReembolsoResumeViewModel();

            bool result = true;

            using (ReembolsoAgent agent = new ReembolsoAgent())
            {
                ListTableroDictamenResumeViewModel lstTableroAux = agent.ObtenerListaTableroDictamen(out lstErrores, new TableroDictamenFilterViewModel
                {
                    FilterType = TableroDictamenFilterType.Tablero,
                    Nomina = poliza
                    //}, 1, 50);
                });

                CuentaBancariaResumeViewModel ctaBanc = getCuentaBancaria(poliza);


                if (cuentaBancariaValidada(ctaBanc))
                {

                    // Existe algun tramite ralacionado a la poliza en ictamen administrativo (2)  y en proceso (1)

                    if (lstTableroAux != null &&
                        lstTableroAux.Lista != null &&
                        (existeTramitesEnDictamenAdministrativoProceso(lstTableroAux.Lista) ||
                        existeTramitesEnValidacionDocumentacionIncompleta(lstTableroAux.Lista)))
                    {
                        List<TableroDictamenResumeViewModel> listTableroDictamenResumeViewModel = new List<TableroDictamenResumeViewModel>();


                        //listTableroDictamenResumeViewModel = lstTableroAux.Lista.Where(x => (x.IdFlujo == 2 && x.IdEstatus == 1) || (x.IdFlujo == 1 && x.IdEstatus == 4)).ToList();


                        listTableroDictamenResumeViewModel.AddRange(getListByDictamenAdministrativoProceso(lstTableroAux.Lista));
                        listTableroDictamenResumeViewModel.AddRange(getListByDocumentacionIncompleta(lstTableroAux.Lista));

                        // Regitra nueva tubla en la tabla de bitacora

                        foreach (var tableroDictamenResumeViewModel in listTableroDictamenResumeViewModel)
                        {

                            BitacoraViewModel bitacora = new BitacoraViewModel
                            {
                                Usuario = usuario,
                                Fecha = DateTime.Now,
                                Comentario = "Validación de identificación",
                                IdFlujo = 2,
                                IdReembolso = tableroDictamenResumeViewModel.IdReembolso,
                                IdStatus = 8, // Validación Identificación Oficial
                                TipoUsuario = tipoUsuario
                            };

                            agent.RegistrarBitacora(out lstErrores, bitacora);
                        }

                    }
                }
                else
                {
                    if (cuentaBancariaNueva(ctaBanc))
                    {

                        // Existe algun tramite ralacionado a la poliza en dictamen administrativo (2)  y en proceso (1)

                        if (lstTableroAux != null &&
                            lstTableroAux.Lista != null &&
                            (existeTramitesEnDictamenAdministrativoProceso(lstTableroAux.Lista) ||
                        existeTramitesEnValidacionDocumentacionIncompleta(lstTableroAux.Lista)))
                        {
                            List<TableroDictamenResumeViewModel> listTableroDictamenResumeViewModel = new List<TableroDictamenResumeViewModel>();


                            //listTableroDictamenResumeViewModel = lstTableroAux.Lista.Where(x => x.IdFlujo == 2 && x.IdEstatus == 8).ToList();

                            listTableroDictamenResumeViewModel.AddRange(getListByDictamenAdministrativoProceso(lstTableroAux.Lista));
                            listTableroDictamenResumeViewModel.AddRange(getListByDocumentacionIncompleta(lstTableroAux.Lista));


                            // Regitra nueva tubla en la tabla de bitacora

                            foreach (var tableroDictamenResumeViewModel in listTableroDictamenResumeViewModel)
                            {

                                BitacoraViewModel bitacora = new BitacoraViewModel
                                {
                                    Usuario = usuario,
                                    Fecha = DateTime.Now,
                                    Comentario = "Cuanta nueva, identificación nueva",
                                    IdFlujo = 2,
                                    IdReembolso = tableroDictamenResumeViewModel.IdReembolso,
                                    IdStatus = 7,
                                    TipoUsuario = tipoUsuario
                                };

                                agent.RegistrarBitacora(out lstErrores, bitacora);
                            }

                        }


                    }
                    else
                    {
                        // Existe algun tramite ralacionado a la poliza en dictamen administrativo (2)  y en proceso (1)

                        if (lstTableroAux != null &&
                            lstTableroAux.Lista != null &&
                            (existeTramitesEnDictamenAdministrativoProceso(lstTableroAux.Lista) ||
                        existeTramitesEnValidacionDocumentacionIncompleta(lstTableroAux.Lista)))
                        {
                            List<TableroDictamenResumeViewModel> listTableroDictamenResumeViewModel = new List<TableroDictamenResumeViewModel>();


                            listTableroDictamenResumeViewModel.AddRange(getListByDictamenAdministrativoProceso(lstTableroAux.Lista));
                            listTableroDictamenResumeViewModel.AddRange(getListByDocumentacionIncompleta(lstTableroAux.Lista));

                            // Regitra nueva tubla en la tabla de bitacora

                            foreach (var tableroDictamenResumeViewModel in listTableroDictamenResumeViewModel)
                            {

                                BitacoraViewModel bitacora = new BitacoraViewModel
                                {
                                    Usuario = usuario,
                                    Fecha = DateTime.Now,
                                    Comentario = "Cuanta rechazada, identificación nueva",
                                    IdFlujo = 1,
                                    IdReembolso = tableroDictamenResumeViewModel.IdReembolso,
                                    IdStatus = 4,
                                    TipoUsuario = tipoUsuario
                                };

                                agent.RegistrarBitacora(out lstErrores, bitacora);
                            }

                        }
                    }
                }
            }


            return result;
        }

        public bool ExisteIne(string poliza)
        {
            bool result = true;

            using (Vitamedica.Reembolso.GModelo.Business.Agent.ReembolsoAgent agent = new Vitamedica.Reembolso.GModelo.Business.Agent.ReembolsoAgent())
                resultCuenta = agent.ObtenerINEPoliza(poliza);

            if (resultCuenta == null || string.IsNullOrEmpty(resultCuenta.Nombre)
                    //|| !resultCuenta.Activo
                    )
            {
                result = false;
            }

            return result;
           
        }


        public INEResumeViewModel GetINE(string poliza)
        {


            using (Vitamedica.Reembolso.GModelo.Business.Agent.ReembolsoAgent agent = new Vitamedica.Reembolso.GModelo.Business.Agent.ReembolsoAgent())
                resultCuenta = agent.ObtenerINEPoliza(poliza);

            return resultCuenta;

        }


        public List<TableroDictamenResumeViewModel> getListByDictamenAdministrativoProceso(List<TableroDictamenResumeViewModel> solicitudesUsuario)
        {
            return solicitudesUsuario.Where(x => (x.IdFlujo == 2 && x.IdEstatus == 1)).ToList();

        }

        public bool existeTramitesEnDictamenAdministrativoProceso(List<TableroDictamenResumeViewModel> solicitudesUsuario)
        {
            if (solicitudesUsuario.Any(x => x.IdFlujo == 2 && x.IdEstatus == 1))
            {
                return true;
            }
            return false;
        }

        public List<TableroDictamenResumeViewModel> getListByValidacionIdentificacion(List<TableroDictamenResumeViewModel> solicitudesUsuario)
        {
            return solicitudesUsuario.Where(x => (x.IdFlujo == 2 && x.IdEstatus == 8)).ToList();

        }

        public bool existeTramitesEnValidacionIdentificacion(List<TableroDictamenResumeViewModel> solicitudesUsuario)
        {
            if (solicitudesUsuario.Any(x => x.IdFlujo == 2 && x.IdEstatus == 8))
            {
                return true;
            }
            return false;
        }


        public List<TableroDictamenResumeViewModel> getListByTesoreria(List<TableroDictamenResumeViewModel> solicitudesUsuario)
        {
            return solicitudesUsuario.Where(x => (x.IdFlujo == 2 && x.IdEstatus == 7)).ToList();

        }

        public bool existeTramitesEnValidacionTesoreria(List<TableroDictamenResumeViewModel> solicitudesUsuario)
        {
            if (solicitudesUsuario.Any(x => x.IdFlujo == 2 && x.IdEstatus == 7))
            {
                return true;
            }
            return false;
        }

        public List<TableroDictamenResumeViewModel> getListByValidacionTesoreria(List<TableroDictamenResumeViewModel> solicitudesUsuario)
        {
            return solicitudesUsuario.Where(x => (x.IdFlujo == 2 && x.IdEstatus == 7)).ToList();

        }

        public List<TableroDictamenResumeViewModel> getListByDocumentacionIncompleta(List<TableroDictamenResumeViewModel> solicitudesUsuario)
        {
            return solicitudesUsuario.Where(x => (x.IdFlujo == 1 && x.IdEstatus == 4)).ToList();

        }

        public bool existeTramitesEnValidacionDocumentacionIncompleta(List<TableroDictamenResumeViewModel> solicitudesUsuario)
        {
            if (solicitudesUsuario.Any(x => x.IdFlujo == 1 && x.IdEstatus == 4))
            {
                return true;
            }
            return false;
        }


        #endregion

        #region UI


        public IdentificacionOficialFilter mapArchivoRetro(IdentificacionOficialFilterUIModel item)
        {
            IdentificacionOficialFilter itemCopia = new IdentificacionOficialFilter();



            itemCopia.Activo = item.Activo;
            itemCopia.Poliza = item.Poliza;
            itemCopia.FechaModificacion = item.FechaModificacion;
            itemCopia.FechaRegistro = item.FechaRegistro;
            itemCopia.NuevaINE = item.NuevaINE;
            itemCopia.Nombre = item.Nombre;
            itemCopia.FilterType = item.FilterType;



            return itemCopia;
        }

        #endregion

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Models.Reembolso;

namespace Vitamedica.Reembolso.GModelo.Business.Business
{
    public class Reembolso
    {
        
    }
}

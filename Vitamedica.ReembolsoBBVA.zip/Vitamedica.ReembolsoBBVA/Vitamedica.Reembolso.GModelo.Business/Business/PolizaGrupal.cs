﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Reembolso.GModelo.Business.Business
{
    public class PolizaGrupal
    {

        string fullNoCertificado = string.Empty;
        string nominaGrupal = string.Empty;

        int lengthFullNocertificado = 8;

        /// <summary>
        /// combina el certificado y la poliza para obtrener la poliza grupal
        /// </summary>
        /// <param name="poliza"></param>
        /// <param name="certificado"></param>
        /// <returns></returns>
        public string GetGrupal(string poliza, string certificado)
        {

            string nominaGrupal = "";

            // Llena con ceros a un total de 8 caracterers el numero de certificado

            if (!string.IsNullOrWhiteSpace(certificado))
            {

                int NoCertificadoLength = certificado.Length;

                int fillCeroLengt = 0;

                fillCeroLengt = lengthFullNocertificado - NoCertificadoLength;

                fullNoCertificado = string.Concat(Enumerable.Repeat('0', fillCeroLengt)) + certificado;

                // Concatenan la nomina con el certificado con ceros para buscar en el vigor

                nominaGrupal = string.Concat(poliza, fullNoCertificado);
            }

            return nominaGrupal;

        }


        public string CeroLessPoliza(string poliza)
        {
            string poliza1 = poliza.Substring(0, 10);
            string certificado = poliza.Substring(poliza.Length - 4, 4);

            poliza = poliza1 + certificado;
            return poliza;
        }


    }
}

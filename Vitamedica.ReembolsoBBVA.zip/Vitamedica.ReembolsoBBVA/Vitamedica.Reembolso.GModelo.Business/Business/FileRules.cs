﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Models.Proxy;
using Vitamedica.Models.Reembolso;
using Vitamedica.Reembolso.GModelo.Business.Agent;
using Vitamedica.Reembolso.GModelo.Business.Utils;
using Vitamedica.Reembolso.GModelo.Business.Utils.Network;

namespace Vitamedica.Reembolso.GModelo.Business.Business
{
    public class FileRules
    {

        public string defaultPath;
        public string fullDefaultPath;
        public string pathTemp;

        private string equipo = string.Empty;
        private string dominio = string.Empty;
        private string usuario = string.Empty;
        private string contrasena = string.Empty;
        private string fileName = string.Empty;
        private string ruta = string.Empty;

        public NetworkShrAccesser credencials;

        private PathFile InePath;

        private static readonly string[] AllowedExtensions = { ".jpg", ".png", ".pdf" };


        public FileRules()
        {
            InePath = new PathFile(); 
        }

        private PathFile creatInePath(string path)
        {
            return new PathFile()
            {
                serverPath = "150.130.102.29",
                path = Path.Combine(path, "INE")
            };
        }

        /// <summary>
        /// Funcion para crear la ruta de almacenamiento de la imagen de la credencial de elector
        /// </summary>
        /// <param name="Poliza"></param>
        /// <param name="pathTemp"></param>
        public void createPathINE(string Poliza, string pathTemp, string fileName,string ruta)
        {


            if (string.IsNullOrEmpty(Poliza))
            {
                defaultPath = "Error Poliza Vacia";
                fullDefaultPath = "Error Poliza No Vacia";
            }

            InePath = creatInePath(ruta);
            defaultPath = Path.Combine( InePath.path, Poliza);
            fullDefaultPath = Path.Combine(InePath.path, Poliza, fileName);

        }   


        /// <summary>
        /// Define las rutas para almacenar los archivos de pdf y xml cargados por los usuarios
        /// </summary>
        /// <param name="ruta"></param>
        /// <param name="grupo"></param>
        /// <param name="contrarecibo"></param>
        /// <param name="path"></param>
        public void fillPath(string ruta, string grupo, string contrarecibo, string path)
        {
            defaultPath = getDafaultPath(ruta, grupo, contrarecibo);
            fullDefaultPath = getDafaultPath(ruta, grupo, contrarecibo);
            this.pathTemp = path;
        }



        /// <summary>
        /// Path sin nombre de archivo
        /// </summary>
        /// <param name="ruta"></param>
        /// <param name="grupo"></param>
        /// <param name="contrarecibo"></param>
        /// <returns></returns>
        public string getDafaultPath(string ruta, string grupo, string contrarecibo)
        {
            return ruta + grupo + @"\" + DateTime.Now.Year + @"\" + DateTime.Now.Month.ToString().PadLeft(2, '0') + @"\" + contrarecibo + @"\";
        }

        /// <summary>
        /// Path con nombre de archivo
        /// </summary>
        /// <param name="ruta"></param>
        /// <param name="grupo"></param>
        /// <param name="contrarecibo"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public string getFullDefaultPath(string ruta, string grupo, string contrarecibo, string fileName)
        {
            return ruta + grupo + @"\" + DateTime.Now.Year + @"\" + DateTime.Now.Month.ToString().PadLeft(2, '0') + @"\" + contrarecibo + @"\" + fileName;
        }


        /// <summary>
        /// Copia el archivo cargado en la ruta final
        /// </summary>
        /// <param name="ruta">Ruta temporal donde se encuentra el archivo a compiar</param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public string saveFile(string ruta, string fileName)
        {
            string rutaFinal = string.Empty;

            try
            {
                if (Directory.Exists(ruta))
                {
                    if (!Directory.Exists(defaultPath))
                        Directory.CreateDirectory(defaultPath);

                    try
                    {
                        if (System.IO.File.Exists(fullDefaultPath))
                            System.IO.File.Delete(fullDefaultPath);

                        rutaFinal = fullDefaultPath;
                    }
                    catch { }

                    System.IO.File.Copy(pathTemp + fileName, fullDefaultPath, true);
                }
                else
                {
                    using (NetworkShareAccesser.Access(credencials.equipo, credencials.dominio, credencials.usuario, credencials.contrasena))
                    //using (NetworkShareAccesser.Access(credencials.equipo, credencials.dominio, "mcunjama", "Bup@vita207*"))
                    {
                        if (!Directory.Exists(defaultPath))
                            Directory.CreateDirectory(defaultPath);

                        try
                        {
                            if (System.IO.File.Exists(fullDefaultPath))
                                System.IO.File.Delete(fullDefaultPath);

                            rutaFinal = fullDefaultPath;
                        }
                        catch { }

                        System.IO.File.Copy(pathTemp + fileName, fullDefaultPath, true);
                    }
                }

                if (System.IO.File.Exists(pathTemp + fileName))
                    System.IO.File.Delete(pathTemp + fileName);

                //if (System.IO.Directory.Exists(path))
                //    System.IO.Directory.Delete(path);

                return rutaFinal;
            }
            catch (Exception)
            {

                throw;
            }
        }

      




        /// <summary>
        /// Datos requeridos para log en el servidor de archivos
        /// </summary>
        /// <param name="path"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public (List<CatParamDetalleViewModel>, NetworkShrAccesser) getRuta()
        {
            string rutaFinal = string.Empty;

            //string path = Server.MapPath("~/Cargas/Reembolso/" + contrarecibo + "/");
            if (!Directory.Exists(pathTemp))
                Directory.CreateDirectory(pathTemp);


            
            //file.SaveAs(path + fileName);

            List<string> errores = new List<string>();
            CatParamFilterViewModel Filter = new CatParamFilterViewModel()
            {
                FilterType = ReembolsoGModelo.Model.Filter.CatParamFilterType.Prefijo,
                Prefijo = "EQREEM"
            };
            ParametroResumeFilterViewModel filParam = new ParametroResumeFilterViewModel
            {
                FilterType = ReembolsoGModelo.Model.Filter.ParametroFilterType.Clave
            };
            ParametroResumeViewModel paramResult = new ParametroResumeViewModel();
            List<CatParamDetalleViewModel> result = new List<CatParamDetalleViewModel>();
            
            NetworkShrAccesser credenciales = 
                new NetworkShrAccesser();

            using (CatParamAgent agent = new CatParamAgent())
            {
                result = agent.ObtenerListaCatParam(out errores, Filter);
                if (errores.Count > 0 || result.Count == 0)
                    return (result,credenciales);

                credenciales.equipo = result[0].Valor;

                filParam.Clave = "DOMREEM";
                paramResult = agent.ObtenerParametro(filParam);
                if (string.IsNullOrEmpty(paramResult.Valor)) 
                    return (result, credenciales);

                credenciales.dominio = paramResult.Valor;

                filParam.Clave = "USREEM";
                paramResult = agent.ObtenerParametro(filParam);
                if (string.IsNullOrEmpty(paramResult.Valor))
                    return (result, credenciales);

                credenciales.usuario = paramResult.Valor;

                filParam.Clave = "PASSREEM";
                paramResult = agent.ObtenerParametro(filParam);
                if (string.IsNullOrEmpty(paramResult.Valor))
                    return (result, credenciales);

                credenciales.contrasena = paramResult.Valor;

                Filter.Prefijo = "RUTREEM";
                result = agent.ObtenerListaCatParam(out errores, Filter);
                if (errores.Count > 0 || result.Count == 0)
                    return (result, credenciales);


            }


            //return result[0].Valor + @"DocReembolsos\";
            return (result, credenciales);
        }



        /// <summary>
        /// Datos requeridos para log en el servidor de archivos
        /// </summary>
        /// <param name="path"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public (List<CatParamDetalleViewModel>, NetworkShrAccesser) getRuta_ViewDocument()
        {
            string rutaFinal = string.Empty;

            //string path = Server.MapPath("~/Cargas/Reembolso/" + contrarecibo + "/");
            


            //file.SaveAs(path + fileName);

            List<string> errores = new List<string>();
            CatParamFilterViewModel Filter = new CatParamFilterViewModel()
            {
                FilterType = ReembolsoGModelo.Model.Filter.CatParamFilterType.Prefijo,
                Prefijo = "EQREEM"
            };
            ParametroResumeFilterViewModel filParam = new ParametroResumeFilterViewModel
            {
                FilterType = ReembolsoGModelo.Model.Filter.ParametroFilterType.Clave
            };
            ParametroResumeViewModel paramResult = new ParametroResumeViewModel();
            List<CatParamDetalleViewModel> result = new List<CatParamDetalleViewModel>();

            NetworkShrAccesser credenciales =
                new NetworkShrAccesser();

            using (CatParamAgent agent = new CatParamAgent())
            {
                result = agent.ObtenerListaCatParam(out errores, Filter);

                credenciales.equipo = result[0].Valor;

                filParam.Clave = "DomainPortal";
                paramResult = agent.ObtenerParametro(filParam);

                credenciales.dominio = paramResult.Valor;

                filParam.Clave = "UserPortal";
                paramResult = agent.ObtenerParametro(filParam);

                credenciales.usuario = paramResult.Valor;

                filParam.Clave = "PasswordPortal";
                paramResult = agent.ObtenerParametro(filParam);

                credenciales.contrasena = paramResult.Valor;

                Filter.Prefijo = "RUTREEM";
                result = agent.ObtenerListaCatParam(out errores, Filter);

                //ruta = result[0].Valor;
            }


            //return result[0].Valor + @"DocReembolsos\";
            return (result, credenciales);
        }



        /// <summary>
        /// Nuevo proceso para la carga de archivos
        /// </summary>
        /// <param name="file"></param>
        /// <param name="contrarecibo"></param>
        /// <param name="complementoRuta"></param>
        /// <param name="grupo"></param>
        /// <returns></returns>
        public string upLoadFileIne(string fileName, string PathTemp, string poliza)
        {
            string rutaFinal = string.Empty;



            pathTemp = PathTemp;


            //fileRules.ObtenerListaCatParam();


            List<Vitamedica.Models.Reembolso.CatParamDetalleViewModel> result;

            (result, credencials) = getRuta();



            // Proceso para obtener la pokliza del reembolso

            if (result != null)
            {
                ruta = result[0].Valor + @"DocReembolsos\";

            }

            createPathINE(poliza, PathTemp, fileName, ruta);

           


            //fileRules.fillPaths(ruta, grupo, contrarecibo, path);

            saveFile(defaultPath, fileName);

            //if (System.IO.Directory.Exists(path))
            //    System.IO.Directory.Delete(path);

            return fullDefaultPath.Replace(result[0].Valor, "");
        }

        public string getMimeType(string url)
        {
            return (Path.GetExtension(url).ToUpper().Contains("PNG") || Path.GetExtension(url).ToUpper().Contains("JPG")) ? "image/png" : Path.GetExtension(url).ToUpper() == ".PDF" ? "application/pdf" : "application/xml";
        }


        /// <summary>
        /// Validates whether the file extension is permitted.
        /// </summary>
        /// <param name="fileName">The name of the file to validate.</param>
        /// <returns>True if the file extension is permitted, otherwise false.</returns>
        public bool IsFileExtensionPermitted(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                return false;
            }

            // Get the file extension
            string fileExtension = Path.GetExtension(fileName)?.ToLower();

            // Check if the extension is in the list of allowed extensions
            return Array.Exists(AllowedExtensions, ext => ext == fileExtension);
        }

    }

   

    /// <summary>
    /// Objeto para la representación de la ruta de un archivo
    /// </summary>
    public class PathFile
    {
        public string serverPath = string.Empty;
        public string path = string.Empty;
    }


}

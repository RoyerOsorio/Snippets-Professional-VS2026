﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Models.Reembolso;

namespace Vitamedica.Reembolso.GModelo.Business.Business
{
    public class Concepto
    {

        /// <summary>
        /// Asginacion de diagnosticos de acuerdo a ala cobertura (Req 27)
        /// </summary>
        public DiagnosticoTratamientoResumeViewModel AsignaDiagnosticoDefault(DocumentosReembolsoResumeViewModel documento)
        {

            // Consultas: 99203 

            //Medicamentos: 1007F

            //Estudios de Laboratorio: L8812

            //Urgencia: 9920110

            //Medicamentos Plus: 1007F

            // Example with string
            int idCobertura = documento.IdMotivoReembolso;
            string icd = string.Empty;
            string cpt = string.Empty;

            //List<string> errores = new List<string>();
            //Vitamedica.Models.Reembolso.DiagnosticoFilterViewModel filtro = new Vitamedica.Models.Reembolso.DiagnosticoFilterViewModel
            //{
            //    Diagnostico = descripcion,
            //    IdDiag = codigo
            //};

            //List<Vitamedica.Models.Reembolso.DiagnosticoResumeViewModel> listDiagnostico = new List<Vitamedica.Models.Reembolso.DiagnosticoResumeViewModel>();


            //using (Vitamedica.Reembolso.GModelo.Business.Agent.ReembolsoAgent agent = new Vitamedica.Reembolso.GModelo.Business.Agent.ReembolsoAgent())
            //{
            //    listDiagnostico = agent.ObtenerListaDiagnostico(out errores, filtro);
            //}


                switch (idCobertura)
            {
                case 1:
                    cpt = "99203";
                    break;
                case 3:
                    cpt = "1007F";
                    break;
                case 2:
                    cpt = "L8812";
                    break;
                case 4:
                    cpt = "9920110";
                    break;
                case 5:
                    cpt = "1007F";
                    break;
            }


            return  new Vitamedica.Models.Reembolso.DiagnosticoTratamientoResumeViewModel
            {
                ICD = icd,
                CPT = cpt,
                IdDocumento = documento.IdDocumento,
                IdFactura = 0
            };
        }
    }
}

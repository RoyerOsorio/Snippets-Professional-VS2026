﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Models.Reembolso;
using Vitamedica.Models.Reembolso.UI.Documentos;
using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;


namespace Vitamedica.Reembolso.GModelo.Business.Business
{
    public class Documentos
    {
        private List<string> errores;

        private List<MotivoReembolsoViewModel> listMotivoReem;
        private List<DocumentoRequeridoResumeViewModel> listDocReq;
        private string open = "<h2>";
        private string close = "</h2>";

        public Documentos() 
        { 
            errores = new List<string>();
            listMotivoReem = new List<MotivoReembolsoViewModel>();
            listDocReq = new List<DocumentoRequeridoResumeViewModel>();
        }


        /// <summary>
        /// Listado para la vista de ayuda de documentos por cobertura
        /// </summary>
        public List<MotivoReembolsoViewModel> GetDocumentosPorCobertura()
        {
            List<DocumentosPorCobertura> listDocumentosPorCobertura = new List<DocumentosPorCobertura>();

            using (Vitamedica.Reembolso.GModelo.Business.Agent.ReembolsoAgent agent = new Vitamedica.Reembolso.GModelo.Business.Agent.ReembolsoAgent())
            {
                listMotivoReem = agent.ObtenerListaMotivoReembolso(out errores, new MotivoReembolsoFilterViewModel { FilterType = MotivoReembolsoFilterType.Nothing });
                listMotivoReem = listMotivoReem.GroupBy(s => s.Motivo)
                                                 .Select(grp => grp.FirstOrDefault())
                                                 .ToList();

                foreach (var motivoReem in listMotivoReem)
                {
                    motivoReem.TituloDescripcionAyuda = getTituloDescripcionAyuda(motivoReem.DescripcionAyuda);
                    motivoReem.DescripcionAyuda = getDescripcionAyuda(motivoReem.DescripcionAyuda);
                    motivoReem.Show = true;
                }
            }

            return listMotivoReem;//orderSideBar(listMotivoReem);
        }

        private List<MotivoReembolsoViewModel> orderSideBar(List<MotivoReembolsoViewModel> original)
        {
            Dictionary<string, int> sub = dictonaryOrderSidebar();

            List<MotivoReembolsoViewModel> orderList = new List<MotivoReembolsoViewModel>();

            foreach (var item in original)
            {
                var orderElement =  sub.Where(x => x.Key.Equals(item.Motivo)).FirstOrDefault();

                if (orderElement.Key != null)
                {
                    item.Order = orderElement.Value;
                    item.Show = true;
                }
                var orderElementMedicamentosPlus = sub.Where(x => x.Key.Equals("Medicamentos Plus")).FirstOrDefault();

                if (item.TituloDescripcionAyuda.Equals("Medicamentos Plus"))
                {
                    item.Show = false;
                }

                orderList.Add(item);
            }

            return orderList;
        }

        private Dictionary< string, int> dictonaryOrderSidebar()
        {
            Dictionary<string, int> sub = new Dictionary<string, int>();

            // Adding elements
            sub.Add( "Consultas", 1);
            sub.Add( "Medicamentos", 2);
            sub.Add("Estudios de laboratorio e imagenologia", 3);
            sub.Add( "Dental", 4);
            sub.Add( "Urgencia médica", 5);
            sub.Add( "Apoyo para gastos de hospitalización", 6);
            sub.Add( "1er diagnostico Cancer", 7);
            sub.Add("1er diagnostico Cardiovascular", 8);
            sub.Add("Accidente o enfermedad en el extranjero", 9);
            sub.Add( "Maternidad", 10);
            sub.Add( "Terapias de rehabilitación física", 11);

            return sub;

        }

        private DocumentosPorCobertura mapDocumentosPorCobertura(MotivoReembolsoViewModel motivoReembolso)
        {
            DocumentosPorCobertura documentosPorCobertura = new DocumentosPorCobertura();

            documentosPorCobertura.IdMotivoReembolso = motivoReembolso.IdMotivoReembolso;
            documentosPorCobertura.Motivo = motivoReembolso.Motivo;
            documentosPorCobertura.Cobertura = motivoReembolso.Cobertura;
            documentosPorCobertura.Coaseguro= motivoReembolso.Coaseguro;
            documentosPorCobertura.LimiteEvento = motivoReembolso.LimiteEvento;
            documentosPorCobertura.Acumulado = motivoReembolso.Acumulado;
            documentosPorCobertura.Moneda  = motivoReembolso.Moneda;
            documentosPorCobertura.Deducible = motivoReembolso.Deducible;
            documentosPorCobertura.ClaveConfig = motivoReembolso.ClaveConfig;
            documentosPorCobertura.MontoRealCob = motivoReembolso.MontoRealCob;

            return documentosPorCobertura;
        }


        private string getTituloDescripcionAyuda(string ayudaCode)
        {

            if (!string.IsNullOrWhiteSpace(ayudaCode))
            {
                string withOutOpen = ayudaCode.Substring(ayudaCode.IndexOf(open) + open.Length);
                string withOutClose = withOutOpen.Substring(0, withOutOpen.IndexOf(close));
                return withOutClose;
            }
            return string.Empty;
        }



        private string getDescripcionAyuda(string ayudaCode)
        {
            if (!string.IsNullOrWhiteSpace(ayudaCode))
            {

                string withOutClose = ayudaCode.Substring(ayudaCode.IndexOf(close) + open.Length + 1);
                return withOutClose.Replace("\r\n", "<br />");
            }
            return string.Empty;
        }

    }

   


}

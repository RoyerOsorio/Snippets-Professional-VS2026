﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Excel;

namespace Vitamedica.Reembolso.GModelo.Business.Business
{
    public class Pagos
    {
        public byte[] GetLayoutExcelFromList<T>(List<T> source)
        {
            IVitaExcel vitaExcel = new VitaExcelNPOI();
            List<string> columns = new List<string>();

            columns.Add("FOLIO");

            columns.Add("F.REGISTRO");
            columns.Add("IMSS");
            columns.Add("NOMINA");
            columns.Add("NOMBRE EMPLEADO");
            columns.Add("CONSECUTIVO");
            columns.Add("PARENTESCO");
            columns.Add("NOMBRE BENEFICIARIO");
            columns.Add("SERVICIO");
            columns.Add("%REEMBOLSO");
            columns.Add("FACTURA");
            columns.Add("COMPLEMENTO");
            columns.Add("CONCEPTO");
            columns.Add("RFC");
            columns.Add("$IMPORTE");
            columns.Add("$IMPORTE TABULADO");
            columns.Add("$IMPORTE REEMBOLSO");
            columns.Add("F.SERVICIO");
            columns.Add("MOTIVO");
            columns.Add("ICD");
            columns.Add("CPT");
            columns.Add("OBSERVACION");
            columns.Add("RECHAZADO");
            columns.Add("MOTIVO RECHAZO");
            columns.Add("CONTRARECIBO");
            columns.Add("FOLIO REEMBOLSO");
            columns.Add("FOLIO PORTAL");
            columns.Add("CP");

            PropertyInfo[] propiedades = typeof(T).GetProperties();

            List<string> properties = new List<string>();
            properties.Add("FechaRegistro");
            properties.Add("NSS");
            properties.Add("Nomina");
            properties.Add("NombreEmpleado");
            properties.Add("Consecutivo");
            properties.Add("Parentesco");
            properties.Add("NombreBeneficiario");
            properties.Add("Servicio");
            properties.Add("PorcenReembolso");
            properties.Add("Factura");
            properties.Add("Complemento");
            properties.Add("Concepto");
            properties.Add("RFC");
            properties.Add("Importe");
            properties.Add("ImporteTabulador");
            properties.Add("ImporteReembolsado");
            properties.Add("FechaServicio");
            properties.Add("Motivo");
            properties.Add("ICD");
            properties.Add("CPT");
            properties.Add("Observacion");
            properties.Add("Rechazado");
            properties.Add("MotivoRechazo");
            properties.Add("Contrarecibo");
            properties.Add("FolioReembolsoVIBA");
            properties.Add("FolioPortal");
            properties.Add("CP");

            List<object[]> lst = GetSpecificProperties(source, properties);



            return vitaExcel.ListToXlsx(lst, columns, "Hoja1");
        }

        private List<object[]> GetSpecificProperties<T>(List<T> list, List<string> propertieName)
        {
            var result = new List<object[]>();
            var type = typeof(T);

            foreach (var item in list)
            {
                var row = new object[propertieName.Count];

                for (int i = 0; i < propertieName.Count; i++)
                {
                    PropertyInfo prop = type.GetProperty(propertieName[i]);

                    if (prop != null)
                    {
                        row[i] = prop.GetValue(item);
                    }
                    else
                    {
                        row[i] = null;
                    }
                }
                result.Add(row);
            }

            return result;
        }
    }
}

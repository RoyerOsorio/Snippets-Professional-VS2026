﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Reembolso.GModelo.Business.Model.Cuantas
{
    public class ListDatosCuentaBancariaClabe 
    {
        public List<DatosCuentaBancariaClabe> Lista { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Reembolso.GModelo.Business.Model.Cuantas
{
    // Configiracion para Lectura de excel
    public class ExcelValidacionesSolicitadas
    {
        public int numeroCuenta;
        public int nombreBeneficierio;
        public int Estadovalidación;
        public int Fecha;
        public int returnReason;
        public int initRow;
        public string returnReasonMsg;

        public ExcelValidacionesSolicitadas()
        {
            numeroCuenta = 5;
            numeroCuenta = 6;
            nombreBeneficierio = 8;
            Fecha = 1;
            initRow = 0;
            Estadovalidación = 7;
            returnReason = 12;
            returnReasonMsg = "BLOCKED ACCOUNT";
        }
    }
}

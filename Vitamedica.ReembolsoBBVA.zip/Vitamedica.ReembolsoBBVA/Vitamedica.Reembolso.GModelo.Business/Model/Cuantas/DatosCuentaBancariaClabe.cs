﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Reembolso.GModelo.Business.Model.Cuantas
{
    public class DatosCuentaBancariaClabe
    {
        public int IdCuenta { get; set; }
        public string Poliza { get; set; }

        public string Clabe { get; set; }

        public string Nombre { get; set; }

        public string Meme_Ck { get; set; }

        public bool NuevaCuenta { get; set; }

        public DateTime Fecha { get; set; }

        public string Correo { get; set; }
    }
}

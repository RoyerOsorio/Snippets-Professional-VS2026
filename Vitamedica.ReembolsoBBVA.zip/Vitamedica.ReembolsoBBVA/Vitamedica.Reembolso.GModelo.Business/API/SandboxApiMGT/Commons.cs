﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Models.Reembolso;
using Vitamedica.Proxy.API;
using Vitamedica.Reembolso.GModelo.Business.Agent;
using static System.Net.WebRequestMethods;

namespace Vitamedica.Reembolso.GModelo.Business.API.SandboxApiMGT
{
    public class Commons
    {

        /// <summary>
        /// Obtiene especificaciones de las polizas
        /// </summary>
        /// <returns></returns>
        public async Task<string> CommonsPrefix__()
        {


            // Set the URL for the request
            string url = "https://bupamx-apimgt-prod.bupa.com.mx/Commons/commons/prefix";

            //// Create JSON data for the POST request
            //    string jsonData = @"{
            //    ""title"": ""foo"",
            //    ""body"": ""bar"",
            //    ""userId"": 1
            //}";

            // Create HttpContent with JSON data
            //HttpContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");
            //HttpContent content = new StringContent( Encoding.UTF8);

            // Create a HttpRequestMessage to include headers
            HttpRequestMessage request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(url),
                //Content = content
            };

            // Add headers to the request
            //request.Headers.Add("Authorization", "Bearer YOUR_TOKEN_HERE");
            //request.Headers.Add("Custom-Header", "MyHeaderValue");
            request.Headers.Add("Ocp-Apim-Subscription-Key", "64b55a88d33c4cceadf98333650978e7");


            HTTPRequest hTTPRequest = new HTTPRequest();

            string result =   await hTTPRequest.SendGET(request);

            return result;
        }

        /// <summary>
        /// Obtiene especificaciones de las polizas
        /// </summary>
        /// <returns></returns>
        public async Task<string> CommonsPrefix_()
        {


            // Set the URL for the request
            string url = "https://bupamx-apimgt-prod.bupa.com.mx/Commons/commons/prefix";

            //// Create JSON data for the POST request
            //    string jsonData = @"{
            //    ""title"": ""foo"",
            //    ""body"": ""bar"",
            //    ""userId"": 1
            //}";

            // Create HttpContent with JSON data
            //HttpContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");
            //HttpContent content = new StringContent( Encoding.UTF8);

            // Create a HttpRequestMessage to include headers
            HttpRequestMessage request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(url),
                //Content = content
            };

            // Add headers to the request
            //request.Headers.Add("Authorization", "Bearer YOUR_TOKEN_HERE");
            //request.Headers.Add("Custom-Header", "MyHeaderValue");
            request.Headers.Add("Ocp-Apim-Subscription-Key", "64b55a88d33c4cceadf98333650978e7");


            HTTPRequest hTTPRequest = new HTTPRequest();

            string result = await HTTPRequest.MakeGetRequestAsync(url);

            return result;
        }

        public string CommonsPrefix()
        {
            string urlApi = ConfigurationManager.AppSettings["URICommonsPolizasGrupales"];
            string HeaderKey = ConfigurationManager.AppSettings["HeaderKeyURICommonsPolizasGrupales"];

            //string urlApi = "https://bupamx-apimgt-prod.bupa.com.mx/Commons/commons/prefix";

            string jsonResponse = string.Empty;
            System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;

            var request = (HttpWebRequest)WebRequest.Create(urlApi);
            request.Method = "Get";
            request.Headers.Add("Ocp-Apim-Subscription-Key", HeaderKey);

            HTTPRequest httrequest = new HTTPRequest();

            try
            {
                string response = httrequest.MakeGetRequest(request);
                return response;

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return ex.Message;

            }

        }


        private string ObtenerParametroAc(string prefijo)
        {
            string valor = string.Empty;
            List<string> errores = new List<string>();
            CatParamFilterViewModel Filter = new CatParamFilterViewModel()
            {
                FilterType = ReembolsoGModelo.Model.Filter.CatParamFilterType.Prefijo,
                Prefijo = prefijo
            };
            ParametroResumeFilterViewModel filParam = new ParametroResumeFilterViewModel
            {
                FilterType = ReembolsoGModelo.Model.Filter.ParametroFilterType.Clave
            };
            ParametroResumeViewModel paramResult = new ParametroResumeViewModel();
            List<CatParamDetalleViewModel> result = new List<CatParamDetalleViewModel>();
            using (CatParamAgent agent = new CatParamAgent())
            {
                result = agent.ObtenerListaCatParam(out errores, Filter);
                valor = result.Any() ? result[0].Valor : string.Empty;
            }

            return valor;
        }

    }
}

﻿using System;
using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Model.ViewModels;

namespace Vitamedica.ReembolsoGModelo.IDomain
{
    public interface ICuentaUsuarioResumeDomain : IDisposable
    {
        CuentaUsuarioResume ObtenerCuentaUsuario(CuentaUsuarioFilter filter);
        bool RegistrarCuentaBancariaNomina(CuentaBancariaNomina model);

    }
}

﻿using System;
using System.Collections.Generic;
using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Model.Models;
using Vitamedica.ReembolsoGModelo.Model.ViewModels;
using Vitamedica.ReembolsoGModelo.Shared.Models;

namespace Vitamedica.ReembolsoGModelo.IDomain
{
    public interface IReembolsoDomain : IDisposable
    {
        int RegistrarBitacora(Bitacora model);
        List<DetalleFactura> RegistrarFacturaDetalle(List<DetalleFactura> model);
        FlujoReembolsoResume ObtenerFlujo(FlujoReembolsoFilter filter);
        List<DocumentoRequeridoResume> ObtenerListaDocumentoRequerido(MotivoDocumentoFilter filter);
        MotivoReembolso ObtenerMotivoReembolso(MotivoReembolsoFilter filter);
        List<ReembolsoDocumentoResume> RegistrarReembolsoDocumento(List<ReembolsoDocumento> model);
        MotivoRechazoResume ActualizarReembolso(ReembolsoResume model);
        DatosReembolsoResume RegistrarReembolso(DatosReembolso model);
        StatusReembolso ObtenerStatus(StatusReembolsoFilter filter);
        List<MotivoReembolso> ObtenerListaMotivoReembolso(MotivoReembolsoFilter filter);
        //TipoDerechohabiente ObtenerTipoDerechohabiente(PlanDerechohabienteFilter filter);
        bool BuscaFactura(string param);
        List<TableroDictamenResume> ObtenerListaTableroDictamen(TableroDictamenFilter filter, Pagination pagination);
        DetalleReembolsoResume ObtenerDetalleReembolso(ReembolsoFilter filter);
        List<DetalleReembolsoResume> ObtenerListaDetalleReembolso(ReembolsoFilter filter, Pagination pagination);
        List<DocumentosReembolsoResume> ObtenerListaDocumentosReembolso(DocumentosReembolsoFilter filter, Pagination pagination);
        List<DetalleFactura> ObtenerDetalleFactura(DetalleFacturaFilter filter);
        DocumentosReembolsoResume ObtenerDocumentoReembolso(DocumentosReembolsoFilter filter);
        MotivoRechazoResume ActualizarDocumentoReembolso(DocumentoReembolsoResume model);
        MotivoRechazoResume ActualizarFacturaDetalle(DetalleFacturaResume model);
        List<FlujoReembolsoResume> ObtenerListaFlujo(FlujoReembolsoFilter filter);
        List<StatusReembolso> ObtenerListaStatus(StatusReembolsoFilter filter);
        List<NotaResume> ObtenerNotas(NotaFilter filter);
        List<MotivoRechazo> ObtenerListaRechazo(MotivoRechazoFilter filter);
        void RegistrarDocAdicional(DocAdicionales model);
        void ActualizarDocAdicional(DocAdicionalResume model);
        List<DocumentoAdicionalResume> ObtenerListaDocAdicionales(DocAdicionalFilter filter);
        bool EnviarAUsuario(int IdReembolso);
        List<OrigenReembolso> ObtenerListaOrigenReembolso(OrigenReembolsoFilter filter);
        MotivoConsulta ObtenerMotivoConsulta(int idConsulta);
        List<MotivoConsulta> ObtenerListaMotivoConsulta();
        List<MotivoRechazo> ObtenerListaRechazoReembolso(MotivoRechazoReembolsoFilter filter);
        bool RegistrarPago(string folio);
        bool RegistrarFechaInicial(FechaInicialReembolsoResume model);
        bool RegistrarBitacoraModulo(BitacoraModulosResume model);
        DiagnosticoResume ObtenerDiagnostico(DiagnosticoFilter filter);
        List<DiagnosticoResume> ObtenerListaDiagnostico(DiagnosticoFilter filter);
        List<DiagnosticoResume> ObtenerListaDiagnosticoDental(DiagnosticoFilter filter);
        TratamientoResume ObtenerTratamiento(TratamientoFilter filter);
        List<TratamientoResume> ObtenerListaTratamiento(TratamientoFilter filter);
        List<TratamientoResume> ObtenerListaTratamientoDental(TratamientoFilter filter);
        //List<TratamientoResume> ObtenerListaTratamientoDentalXCodigo(TratamientoFilter filter);
        //List<CoberturaDentalResume> ObtenerListaCoberturaDental(CoberturaDentalFilter filter);
        //List<CoberturaDentalResume> ObtenerListaTratamientoDentalHistorico(CoberturaDentalFilter filter);
        //List<CoberturaDentalResume> ObtenerListaReembolsoDentalHistorico(CoberturaDentalFilter filter);
        //bool RegistrarReembolsoDental(List<ReembolsoDentalResume> model);
        void ActualizarDiagnosticoTratamiento(DiagnosticoTratamientoResume model);
        void RegistraNota(Nota model);
        //ExcepcionResume ObtenerNominaExcepcion(ExcepcionFilter filter);
        List<PagosBancomerResume> ObtenerListaPagosBancomer();
        //void RegistrarFolioReembolsoVIBA(FolioReembolsoVIBAResume model);
        //List<FolioResume> ActualizarDatosPagoVIBA(List<PagoVIBAResume> model);
        List<LayoutSINBAResume> ObtenerLayoutSINBA();

        List<FolioResume> RetroPagos();

        List<ReporteMovimientoResume> ObtenerReporteMovimientos();

        //bool ProcesoEstadistica(DateTime fecha);
        List<ReporteMovimientoResume> ObtenerReporteMovimientosDetalle();
        AyudaResume ObtenerAyuda(AyudaFilter filter);

        List<ReporteAdmonResume> ObtenerReporteAdmon(TableroDictamenFilter filter);
        //FolioResume ActualizarDatosPagoVIBAItem(PagoVIBAResume model);

        bool RegresarTramite(string folio);
        bool EliminarRegistroPago(string folio);
        List<PendienteResume> ObtenerListaTramitesPendientes(PendienteFilter filter);

        //List<FechaEstadisResume> ObtenerListaFechaEstadis(FechaEstadisFilter filter);
        //FechaEstadisResume ObtenerFechaEstadis(FechaEstadisFilter filter);
        //int RegistrarFechaEstadis(FechaEstadis model);
        //FechaEstadisResume ActualizarFechaEstadis(FechaEstadis model);
        List<DepartamentoResume> ObtenerListaDepartamentos();

        bool ActualizarReembolsoCP(ReembolsoCPResume model);
        bool ActualizarReembolsoVoBo(VoBoResume model);

        int RegistrarComentarioReembolso(ComentarioReembolso model);
        List<ComentarioReembolso> ObtenerListaComentarioReembolso(ComentarioFilter filter);
        ComentarioReembolso ObtenerComentarioReembolso(ComentarioFilter filter);
        List<ReporteAdmonDHBResume> ObtenerReporteAdmonDHB(TableroDictamenFilter filter);
        List<EncuestaResume> ObtenerReporteEncuesta(EncuestaFilter filter);
        List<TramiteRelacionadoResume> ObtenerListaTramitesRelacionados(TramiteRelacionadoFilter filter);
        int RegistrarComplemento(string folio);
        //NominaGMMResume ObtenerNominaGMM(NominaGMMFilter filter);
        void ActualizarNoLlamada(NoLlamadaResume model);

        Notificacion200Resume ObtenerNotificacion200(NotificacionFilter filter);
        string ObtenerNotificacionLentes(NotificacionFilter filter);

        List<TramitesRezagadosResume> ObtenerListaTramitesRezagados(TramitesRezagadosFilter filter);
        //FolioResume ActualizarDatosPagoVIBAFolio(PagoVIBAResume model);
        //bool ExistePlaza(PlazaFilter filter);
        string ObtenerCP(string nomina);

        //List<TipoServicio> ObtenerListaTipoServicio(TipoServicioFilter filter);
        //List<Especialidad> ObtenerListaEspecialidadReem(EspecialidadFilter filter);

        int RegistrarCuentaBancaria(CuentaBancaria model);
        CuentaBancariaResume ObtenerCuentaBancariaPoliza(string Poliza);
        
        int RegistrarTokenTesoreria(TokenTesoreria model);
        TokenTesoreriaResume ObtenerTokenTesoreria(TokenFilterTesoreria filter);
        EstatusTokenTesoreriaResume ObtenerEstatusUltimoTokenTesoreria(int IdCuenta);
        int InvalidarTokenTesoreria(int IdToken);
        List<Banco> ObtenerListaBancos();
        List<MotivoRechazoCuenta> ObtenerListaMotivoRechazoCuenta();
        bool RegistrarVoucherCuentaPoliza(DocumentoVoucher model);
        List<CatParamDetalle> ObtenerListaCatParam(CatParamFilter filter);
        ParametroResume ObtenerParametro(ParametroResumeFilter filter);
        int ActualizarEstatusCuentaPoliza(ActualizaEstatusCuenta model);

        List<CifrasResume> ObtenerListaAcumuladores(AcumuladorFilter filter);
        List<PolizaPendienteResume> ObtenerListaPolizaPendiente(string poliza);
        int ContarTramitesPendientesPoliza(string Poliza);
        DocumentoTesoreria ObtenerDocumentoTesoreria(int Id);
        CifrasResume ValidaDisponibilidad(ValidaDisponibilidadResume model);

        GuardianResume ObtenerGuardianPoliza(string poliza);

        List<string> ObtenerLayoutBancos(LayoutBancoFilter filter);
        bool ActualizarStatusBitacora(string poliza);
        int CuentaPreviaActiva(string Poliza);
        List<DatosCuentaBancariaClabe> ObtenerListaCuentaClabe(string Clabe);
        CuentaBancariaResume ObtenerCuentaBancariaById(int IdCuenta);
        bool ActualizarStatusBitacoraEnProceso(NuevaCuenta model);

        List<LayoutNPSResume> ObtenerLayoutNPS(DateTime fecha);
        bool RegistrarSiniestro(SiniestroResume model);
        bool ActualizarStatusBitacoraRechazoCuenta(RechazoCuenta model);
        bool ActualizaStatusBitacoraNuevaCuenta(NuevaCuenta model);
        List<LayoutBancosResume> ObtenerReporteBancos(DateTime fecha);
        List<ReporteAdmonTableroResume> ObtenerReporteAdmonTablero(TableroDictamenFilter filter, Pagination pagination);
        List<CuentaBancariaResume> ObtenerListaCuentaBancaria();
        string ObtenerTelefono(string poliza);

        int ActualizarCuentaBancariaPoliza(CuentaBancaria model);

        #region Identificacion Oficial

        int ActualizarINE(INE model);
        INEResume ObtenerINEPoliza(string Poliza);
        int RegistrarINE(INE model);

        List<INEResume> ObtenerListaIdentificacionOficial(IdentificacionOficialFilter filter, Pagination pagination);

        #endregion
        List<AcumuladorRsume> ObtenerListaAcumuladoresPoliza(AcumuladorPolizaFilter filter);
        List<ContadorEstacionResume> ObtenerConteoPorEstacion();
        int RegistrarCifraInicial(CifrasResume model);
        CifraMonedaResume ObtenerCifraMoneda(CifraMonedaFilter filter);
        List<Moneda> ObtenerListaMoneda();
        List<PolizaPagadaResume> ObtenerListaPolizaPagada(ReembolsoFilter filter, Pagination pagination);

    }
}

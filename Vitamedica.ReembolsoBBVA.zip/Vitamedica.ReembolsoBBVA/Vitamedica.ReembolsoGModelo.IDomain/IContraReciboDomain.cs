﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Model.Models;
using Vitamedica.ReembolsoGModelo.Shared.Models;

namespace Vitamedica.ReembolsoGModelo.IDomain
{
    public interface IContraReciboDomain : IDisposable
    {
        List<ContraRecibo> ObtenerContraReciboConsecutivo(ContraReciboFilter filter, Pagination pagination);
    }
}
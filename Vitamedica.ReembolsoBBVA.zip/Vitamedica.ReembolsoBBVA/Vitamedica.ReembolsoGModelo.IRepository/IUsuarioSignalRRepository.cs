﻿using System;
using System.Collections.Generic;
using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Model.ViewModels;

namespace Vitamedica.ReembolsoGModelo.IRepository
{
    public interface IUsuarioSignalRRepository : IDisposable
    {
        int RegistrarUsuarioSignalR(UsuarioSignalRResume model);

        bool ActualizarUsuarioSignalR(UsuarioSignalRResume model);

        List<UsuarioSignalRResume> ObtenerListaUsuarioSignalR(UsuarioSignalRFilter filter);
    }
}

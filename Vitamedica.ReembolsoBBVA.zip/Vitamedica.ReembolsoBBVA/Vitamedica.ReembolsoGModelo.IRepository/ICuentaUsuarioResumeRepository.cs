﻿using System;
using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Model.ViewModels;

namespace Vitamedica.ReembolsoGModelo.IRepository
{
    public interface ICuentaUsuarioResumeRepository : IDisposable
    {
        CuentaUsuarioResume ObtenerCuentaUsuario(CuentaUsuarioFilter filter);
        bool RegistrarCuentaBancariaNomina(CuentaBancariaNomina model);
    }
}

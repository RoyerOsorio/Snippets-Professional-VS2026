﻿using System.Collections.Generic;
using Vitamedica.ReembolsoGModelo.Model.ViewModels;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Request.Reembolso
{
    public class PagoVIBAResumeFilterRequest : FilterRequestBase<List<PagoVIBAResume>>
    {
    }
}

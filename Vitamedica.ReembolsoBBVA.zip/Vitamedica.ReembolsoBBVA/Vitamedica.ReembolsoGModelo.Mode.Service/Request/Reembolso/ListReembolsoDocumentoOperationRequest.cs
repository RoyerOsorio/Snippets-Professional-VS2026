﻿using System.Collections.Generic;
using Vitamedica.ReembolsoGModelo.Model.Models;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Request.Reembolso
{
    public class ListReembolsoDocumentoOperationRequest : OperationRequestBase<List<ReembolsoDocumento>>
    {
    }
}

﻿using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Request.Reembolso
{
    public class DocAdicionalFilterRequest : FilterRequestBase<DocAdicionalFilter>
    {
    }
}

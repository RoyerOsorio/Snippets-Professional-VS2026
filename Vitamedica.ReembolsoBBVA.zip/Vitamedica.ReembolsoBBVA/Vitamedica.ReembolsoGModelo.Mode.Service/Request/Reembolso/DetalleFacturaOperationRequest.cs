﻿using Vitamedica.ReembolsoGModelo.Model.Models;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Request.Reembolso
{
    public class DetalleFacturaOperationRequest : OperationRequestBase<DetalleFactura>
    {
    }
}

﻿using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Request.UsuarioSignalR
{
    public class UsuarioSignalRFilterRequest : FilterRequestBase<UsuarioSignalRFilter>
    {
    }
}

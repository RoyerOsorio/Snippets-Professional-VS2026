﻿using Vitamedica.ReembolsoGModelo.Model.ViewModels;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Request.UsuarioSignalR
{
    public class UsuarioSignalRResumeOperationRequest : OperationRequestBase<UsuarioSignalRResume>
    {
    }
}

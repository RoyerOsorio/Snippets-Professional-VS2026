﻿using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Request.ContraRecibo
{
    public class ContraReciboFilterRequest : FilterRequestBase<ContraReciboFilter>
    {
    }
}
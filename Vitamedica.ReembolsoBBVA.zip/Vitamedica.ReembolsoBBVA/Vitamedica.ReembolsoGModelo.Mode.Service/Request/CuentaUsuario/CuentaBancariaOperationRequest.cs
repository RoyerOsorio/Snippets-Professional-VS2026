﻿using Vitamedica.ReembolsoGModelo.Shared.ModelsService;
using viewModel = Vitamedica.ReembolsoGModelo.Model.ViewModels;


namespace Vitamedica.ReembolsoGModelo.Model.Service.Request.CuentaUsuario
{
    public class CuentaBancariaFacetsOperationRequest : OperationRequestBase<viewModel.CuentaBancariaNomina>
    {
    }
}

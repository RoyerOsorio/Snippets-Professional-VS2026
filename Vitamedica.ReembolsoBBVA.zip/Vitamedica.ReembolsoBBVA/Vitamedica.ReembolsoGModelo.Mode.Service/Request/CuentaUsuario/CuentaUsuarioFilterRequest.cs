﻿using Vitamedica.ReembolsoGModelo.Model.Filter;
//using Vitamedica.ReembolsoGModelo.Shared.ModelsService;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Request.CuentaUsuario
{
    public class CuentaUsuarioFilterRequest : FilterRequestBase<CuentaUsuarioFilter>
    {
    }
}

﻿using Vitamedica.ReembolsoGModelo.Model.Filter;
//using Vitamedica.ReembolsoGModelo.Shared.ModelsService;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Request.FacturacionElectronica
{
    public class CatalogoCFDI33FilterRequest : FilterRequestBase<CatalogoCFDI33Filter>
    {
    }
}

﻿using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Request.FacturacionElectronica
{
    public class DetallePagoFacturaFilterRequest : FilterRequestBase<DetallePagoFacturaFilter>
    {
    }
}

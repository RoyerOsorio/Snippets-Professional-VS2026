﻿using Vitamedica.ReembolsoGModelo.Model.ViewModels;
//using Vitamedica.ReembolsoGModelo.Shared.ModelsService;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Request.FacturacionElectronica
{
    public class HistoriaFacturaResumeOperationRequest : OperationRequestBase<HistoriaFacturaResume>
    {
    }
}

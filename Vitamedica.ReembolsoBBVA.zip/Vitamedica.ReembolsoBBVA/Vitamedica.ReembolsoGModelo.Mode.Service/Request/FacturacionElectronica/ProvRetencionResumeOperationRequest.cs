﻿using Vitamedica.ReembolsoGModelo.Model.ViewModels;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Request.FacturacionElectronica
{
    public class ProvRetencionResumeOperationRequest : OperationRequestBase<ProvRetencionResume>
    {
    }
}

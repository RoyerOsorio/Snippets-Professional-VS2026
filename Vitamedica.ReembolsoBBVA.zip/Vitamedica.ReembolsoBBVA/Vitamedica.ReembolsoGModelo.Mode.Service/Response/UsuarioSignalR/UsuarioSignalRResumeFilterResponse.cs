﻿using Vitamedica.ReembolsoGModelo.Model.ViewModels;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Response.UsuarioSignalR
{
    public class UsuarioSignalRResumeFilterResponse : FilterResponseBase<UsuarioSignalRResume>
    {
    }
}

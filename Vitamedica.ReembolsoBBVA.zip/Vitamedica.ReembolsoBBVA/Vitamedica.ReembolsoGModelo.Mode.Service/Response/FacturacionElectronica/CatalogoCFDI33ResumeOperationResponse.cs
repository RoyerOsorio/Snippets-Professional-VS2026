﻿using Vitamedica.ReembolsoGModelo.Model.ViewModels;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Response.FacturacionElectronica
{
    public class CatalogoCFDI33ResumeOperationResponse : OperationResponseBase<CatalogoCFDI33Resume>
    {
    }
}

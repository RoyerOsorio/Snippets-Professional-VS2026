﻿using Vitamedica.ReembolsoGModelo.Model.ViewModels;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Response.FacturacionElectronica
{
    public class DocumentoFactResumeFilterResponse : FilterResponseBase<DocumentoFactResume>
    {
    }
}

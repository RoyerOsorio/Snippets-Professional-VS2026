﻿using Vitamedica.ReembolsoGModelo.Shared.ModelsService;
using model = Vitamedica.ReembolsoGModelo.Model.Models;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Response.ContraRecibo
{
    public class ContraReciboResponse : FilterResponseBase<model.ContraRecibo>
    {
    }
}
﻿using Vitamedica.ReembolsoGModelo.Model.ViewModels;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Response.CuentaUsuario
{
    public class CuentaUsuarioResumeOperationResponse : OperationResponseBase<CuentaUsuarioResume>
    {
    }
}

﻿using Vitamedica.ReembolsoGModelo.Model.ViewModels;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Response.Reembolso
{
    public class Notificacion200ResumeOperationResponse : OperationResponseBase<Notificacion200Resume>
    {
    }
}

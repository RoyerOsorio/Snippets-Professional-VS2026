﻿using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Response.Reembolso
{
    public class LayoutBancoFilterResponse : FilterResponseBase<string>
    {
    }
}

﻿using Vitamedica.ReembolsoGModelo.Model.Models;
using Vitamedica.ReembolsoGModelo.Shared.ModelsService;

namespace Vitamedica.ReembolsoGModelo.Model.Service.Response.Reembolso
{
    public class StatusReembolsoFilterResponse : FilterResponseBase<StatusReembolso>
    {
    }
}

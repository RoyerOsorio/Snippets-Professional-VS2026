﻿using System;
using NLog;

namespace Vitamedica.Logger
{
    

    public class VitaLogger : IVitaLogger, IDisposable
    {
        private static readonly NLog.Logger loggerVar = NLog.LogManager.GetCurrentClassLogger();

        public void Info(string msg)
        {
            loggerVar.Info(msg);
        }

        public void Error(string msg)
        {
            loggerVar.Error(msg);
        }

        public void SuspendLogging()
        {
            LogManager.SuspendLogging();

        }

        public void ResumeLogging()
        {
            LogManager.ResumeLogging();

        }

        public void Dispose()
        {
            Console.WriteLine("Disposed");
        }

        // TODO: Implementar Fatal
    }
}
﻿namespace Vitamedica.Logger
{
    public interface IVitaLogger
    {
        void Dispose();
        void Error(string msg);
        void Info(string msg);
        void ResumeLogging();
        void SuspendLogging();
    }
}
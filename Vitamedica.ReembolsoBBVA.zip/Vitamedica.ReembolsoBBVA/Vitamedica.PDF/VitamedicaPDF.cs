﻿using iText.Kernel.Pdf;
using iText.Kernel.Utils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.PDF
{
    public class VitamedicaPDF
    {

        public void margePDF(List<string> listaUrlsFiniquitos, string outputPdf)
        {

            // Define las rutas de los archivos de entrada y salida
            //string inputPdf1 = urlFiniquitoPDF;
            //string inputPdf2 = urlIndemnizatoriaPDF;
            //string outputPdf = extrangero;

            //// Crea archivos de ejemplo si no existen para que el código sea ejecutable
            //CreateSamplePdf(inputPdf1, "Este es el Documento 1");
            //CreateSamplePdf(inputPdf2, "Este es el Documento 2");

            try
            {
                // 1. Crear un nuevo documento PDF de destino
                // PdfWriter se usa para escribir el nuevo PDF
                using (PdfWriter writer = new PdfWriter(outputPdf))
                {
                    // PdfDocument representa el documento PDF completo
                    using (PdfDocument pdf = new PdfDocument(writer))
                    {
                        // 2. Crear un objeto PdfMerger asociado al documento de destino
                        PdfMerger merger = new PdfMerger(pdf);

                        // 3. Abrir y copiar el primer documento PDF de origen

                        foreach (var urlFiniquito in listaUrlsFiniquitos)
                        {

                            using (PdfReader reader = new PdfReader(urlFiniquito))
                            {
                                using (PdfDocument srcPdf = new PdfDocument(reader))
                                {
                                    merger.Merge(srcPdf, 1, srcPdf.GetNumberOfPages());
                                }
                            }
                        }

                        // 4. Abrir y copiar el segundo documento PDF de origen

                        //using (PdfReader reader2 = new PdfReader(inputPdf2))
                        //{
                        //    using (PdfDocument srcPdf2 = new PdfDocument(reader2))
                        //    {
                        //        merger.Merge(srcPdf2, 1, srcPdf2.GetNumberOfPages());
                        //    }
                        //}

                        // Opcional: Si tuvieras más PDFs, seguirías el mismo patrón
                        // using (PdfReader reader3 = new PdfReader("documento3.pdf"))
                        // {
                        //     using (PdfDocument srcPdf3 = new PdfDocument(reader3))
                        //     {
                        //         merger.Merge(srcPdf3, 1, srcPdf3.GetNumberOfPages());
                        //     }
                        // }

                        // 5. Cerrar el PdfMerger (esto también cierra el PdfDocument de destino)
                        // El 'using' statement se encarga de cerrar PdfWriter y PdfDocument automáticamente
                    }
                }

                Console.WriteLine($"PDFs combinados exitosamente en: {Path.GetFullPath(outputPdf)}");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Error: Asegúrate de que los archivos PDF de entrada existan en la misma carpeta que el ejecutable o especifica la ruta completa.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Se produjo un error al combinar los PDFs: {ex.Message}");
                Console.WriteLine(ex.StackTrace);
            }
        }
    }

}

﻿using iText.Kernel.Colors;
using iText.Kernel.Events;
using iText.Kernel.Font;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.Layout.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Models.Reembolso;

namespace Vitamedica.PDF
{
    public class AsistenciaExtranjero
    {
        private static decimal subTotal;
        private static List<DetalleFacturaViewModel> conceptosWithMintos;
        private static List<DocumentosReembolsoResumeViewModel> documentosWithMontos;

        public static string CrearPDF(string fileName,
            DetalleTramiteViewModel facturas,
            string comentario,
            Vitamedica.Models.Reembolso.MotivoReembolsoViewModel motivoReembolso,
            decimal deducibleTomxn,
            string montoOrigenToMXN)
        {
            //string urlDocumento = HttpContext.Current.Server.MapPath(string.Format("{0}{1}", "", fileName));
            subTotal = 0;
            string urlDocumento = fileName;
            if (System.IO.File.Exists(urlDocumento))
                System.IO.File.Delete(urlDocumento);
            //Initialize PDF writer
            PdfWriter writer = new PdfWriter(urlDocumento);
            //Initialize PDF document
            PdfDocument pdf = new PdfDocument(writer);

            decimal montoTotal = 0;

            foreach (var item in facturas.DocumentosTramite.Conceptos.Where(x => x.Aprobado))
            {
                montoTotal += item.MontoAutorizado;
            }


            documentosWithMontos = facturas.DocumentosTramite.Documentos.Lista.Where(x => x.Monto > 0 && x.Aprobado).ToList();
            conceptosWithMintos = new List<DetalleFacturaViewModel>();
            conceptosWithMintos = facturas.DocumentosTramite.Conceptos.Where(x => x.Aprobado && documentosWithMontos.Any(d => d.IdDocumento == x.IdRembolsoDocumento)).ToList();

            // Initialize document
            Document document = new Document(pdf);
            //document.SetMargins(document.GetTopMargin() + 150, document.GetRightMargin(), document.GetBottomMargin(), document.GetLeftMargin());
            document.SetTopMargin(document.GetTopMargin() + 300);
            document.SetBottomMargin(document.GetBottomMargin() + 190);
            document.SetLeftMargin(document.GetLeftMargin() - 24);
            //document.SetRightMargin(document.GetRightMargin() + 30);
            //Add paragraph to the document
            //document.Add(new Paragraph("Hello World!"));            
            Table table = WriteListToPdf(document, facturas, motivoReembolso, deducibleTomxn);


            var hader = new HeaderFooterEventHandlerIAsistenciaExtranjero(
                comentario
                , subTotal.ToString()
                , documentosWithMontos.FirstOrDefault().Moneda
                , conceptosWithMintos.FirstOrDefault().MontoDolar.ToString("C")
                , subTotal.ToString("C")
                , facturas.Detalle
                , documentosWithMontos.FirstOrDefault().Monto.ToString("C")
                , montoOrigenToMXN
                );

            pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, hader);

            document.Add(table);

            //Close document
            document.Close();

            return urlDocumento;
        }

        private static Table WriteListToPdf(Document doc,
            DetalleTramiteViewModel facturas,
            Vitamedica.Models.Reembolso.MotivoReembolsoViewModel motivoReembolso,
            decimal deducibleTomxn)
        {
            Table table = new Table(6, false).SetMarginLeft(doc.GetLeftMargin()).SetMarginRight(doc.GetRightMargin() - 30);
            PdfFont bold = PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA_BOLD);
            decimal subMonto = 0;
            decimal subDescuento = 0;
            Text headerReclamacion = new Text("RECLAMACIÓN");
            //Text headerUUID = new Text("FOLIO FACTURA (S)");
            Text headerConcepto = new Text("CONCEPTO");
            Text headerMonto = new Text("TOTAL RECLAMADO");
            Text headerGastoNoCubierto = new Text("TOTAL NO CUBIERTO");
            Text headerDeducible = new Text("DEDUCIBLE");
            Text headerTotal = new Text("TOTAL A PAGAR");

            headerReclamacion.SetFontSize(6f).SetFont(bold);
            //headerUUID.SetFontSize(7.5f).SetFont(bold);
            headerConcepto.SetFontSize(6f).SetFont(bold);
            headerMonto.SetFontSize(6f).SetFont(bold);
            headerGastoNoCubierto.SetFontSize(6f).SetFont(bold);
            headerDeducible.SetFontSize(6f).SetFont(bold);
            headerTotal.SetFontSize(6f).SetFont(bold);

            table.AddHeaderCell(new Paragraph(headerReclamacion).SetBackgroundColor(ColorConstants.GRAY).SetWidth(70));
            //table.AddHeaderCell(new Paragraph(headerUUID).SetBackgroundColor(ColorConstants.GRAY).SetWidth(127));
            table.AddHeaderCell(new Paragraph(headerConcepto).SetBackgroundColor(ColorConstants.GRAY).SetWidth(130));
            table.AddHeaderCell(new Paragraph(headerMonto).SetBackgroundColor(ColorConstants.GRAY).SetWidth(70));
            table.AddHeaderCell(new Paragraph(headerGastoNoCubierto).SetBackgroundColor(ColorConstants.GRAY).SetWidth(70));
            table.AddHeaderCell(new Paragraph(headerDeducible).SetBackgroundColor(ColorConstants.GRAY).SetWidth(70));
            table.AddHeaderCell(new Paragraph(headerTotal).SetBackgroundColor(ColorConstants.GRAY).SetWidth(70));


            foreach (var itemP in facturas.DocumentosTramite.Documentos.Lista)
            {
                foreach (var item in facturas.DocumentosTramite.Conceptos.Where(x => x.IdRembolsoDocumento == itemP.IdDocumento))
                {
                    Text textReclamacion = new Text(facturas.Detalle.Folio);
                    //Text textUUID = new Text(itemP.UUID);
                    Text textConcepto = new Text(item.Concepto);
                    Text textMonto = new Text(item.ConceptoTOmxn.ToString("C") + " MXN");
                    Text textGastoNoCubierto = new Text((item.ConceptoTOmxn - item.MontoAutorizado).ToString("C") + " MXN");
                    Text textDeducible = new Text((motivoReembolso.Deducible).ToString("C") + " " + documentosWithMontos.FirstOrDefault().Moneda);
                    Text textTotal = new Text((item.MontoAutorizado - deducibleTomxn).ToString("C") + " MXN");

                    textReclamacion.SetFontSize(6f);
                    //textUUID.SetFontSize(6f);
                    textConcepto.SetFontSize(6f);
                    textMonto.SetFontSize(6f);
                    textGastoNoCubierto.SetFontSize(6f);
                    textDeducible.SetFontSize(6f);
                    textTotal.SetFontSize(6f);

                    table.AddCell(new Paragraph(textReclamacion));
                    //table.AddCell(new Paragraph(textUUID));
                    table.AddCell(new Paragraph(textConcepto));
                    table.AddCell(new Paragraph(textMonto ).SetWidth(50));
                    table.AddCell(new Paragraph(textGastoNoCubierto).SetWidth(50));
                    table.AddCell(new Paragraph(textDeducible).SetWidth(50));
                    table.AddCell(new Paragraph(textTotal).SetWidth(50));
                    subMonto += item.ConceptoTOmxn;
                    subDescuento += (item.ConceptoTOmxn - item.MontoAutorizado);

                    subTotal += item.MontoAutorizado;
                }
            }


            decimal tipoDeCambioMonedaDiaSevicio = conceptosWithMintos.FirstOrDefault().MontoDolar / subTotal;
            decimal dedicibleToMXN = tipoDeCambioMonedaDiaSevicio * motivoReembolso.Deducible;
            subTotal = subTotal - deducibleTomxn;


            Text textSub = new Text("Subtotal:");
            Text textsubMonto = new Text(subMonto.ToString("C") + " MXN");
            Text textsubDescuento = new Text(subDescuento.ToString("C") + " MXN");
            Text textsubDeducible = new Text(deducibleTomxn.ToString("C") + " MXN");
            Text textsubTotal = new Text(subTotal.ToString("C") + " MXN");

            textSub.SetFontSize(6f).SetFont(bold);
            textsubMonto.SetFontSize(6f).SetFont(bold);
            textsubDescuento.SetFontSize(6f).SetFont(bold);
            textsubDeducible.SetFontSize(6f).SetFont(bold);
            textsubTotal.SetFontSize(6f).SetFont(bold);

            table.AddCell(new Paragraph(textSub));
            table.AddCell(new Paragraph(""));
            table.AddCell(new Paragraph(textsubMonto).SetWidth(50));
            table.AddCell(new Paragraph(textsubDescuento).SetWidth(50));
            table.AddCell(new Paragraph(textsubDeducible).SetWidth(50));
            table.AddCell(new Paragraph(textsubTotal).SetWidth(50));

            //table.AddFooterCell(new Paragraph(""));
            //table.AddFooterCell(new Paragraph(""));
            //table.AddFooterCell(new Paragraph(""));
            //table.AddFooterCell(new Paragraph("").SetWidth(50));
            //table.AddFooterCell(new Paragraph("").SetWidth(50));
            //table.AddFooterCell(new Paragraph("").SetWidth(50));

            return table;
        }
    }

}

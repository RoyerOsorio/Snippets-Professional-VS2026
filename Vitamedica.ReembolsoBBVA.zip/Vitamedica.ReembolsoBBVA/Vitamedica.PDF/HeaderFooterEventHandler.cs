﻿using iText.Kernel.Colors;
using iText.Kernel.Events;
using iText.Kernel.Font;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.Layout.Properties;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.PDF
{
    public class HeaderFooterEventHandler : IEventHandler
    {
        public string Footer { get; set; }
        public string Nomina { get; set; }
        public string NombreTitular { get; set; }
        public string NombreBenef { get; set; }
        public string FechaRecepcion { get; set; }
        public string Parentesco { get; set; }
        public string Motivo { get; set; }
        public string Monto { get; set; }
        public string MontoEnLetra { get; set; }
        public DateTime? FechaPago { get; set; }

        public List<string>  GrupoCoaseguroBBVA { get; set; } // REQ 37

        public string Grupo { get; set; } // REQ 37

        public HeaderFooterEventHandler(string footer, string nomina, string nombreTitular
            , string nombreBenef, string fechaRecepcion, string parentesco, string motivo, string monto,
            DateTime? fechaPago, string grupo)
        {
            Footer = footer;
            Nomina = nomina;

            NombreTitular = nombreTitular.ToUpper();
            NombreBenef = nombreBenef.ToUpper();
            FechaRecepcion = fechaRecepcion;
            Parentesco = parentesco.ToUpper();
            Motivo = motivo.ToUpper();
            Monto = monto;
            MontoEnLetra = enletras(monto);
            FechaPago = fechaPago;
            Grupo = grupo; // REQ 37
            GrupoCoaseguroBBVA = new List<string> { "17000002", "19000001"}; // REQ 37 // Agregar los números de nómina que pertenecen al grupo BBVA Coaseguro
        }

        /// <summary>
        /// Genera header y footer del PDF
        /// </summary>
        /// <param name="event"></param>
        public void HandleEvent(Event @event)
        {
            string pathLogo = string.Empty;

            PdfDocumentEvent docEvent = (PdfDocumentEvent)@event;
            PdfPage page = docEvent.GetPage();
            Rectangle pageSize = page.GetPageSize();
            PdfDocument pdfDoc = ((PdfDocumentEvent)@event).GetDocument();
            PdfCanvas pdfCanvas = new PdfCanvas(page.NewContentStreamBefore(), page.GetResources(), pdfDoc);

            PdfFont bold = PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA_BOLD);

            //new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7.5f)
            //    .ShowTextAligned("Con el pago anterior que recibo a mi entera satisfacción, Vitamédica S.A. de C.V. queda liberada de las obligaciones derivadasd e la presente reclamación.", pageSize.GetWidth() / 2, 220, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7.5f)
                .ShowTextAligned("Observaciones:", 30, 200, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            Paragraph par = new Paragraph(Footer);
            par.SetWidth(pageSize.GetWidth() - 70);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(8f)
                .ShowTextAligned(par, 30, 180, TextAlignment.JUSTIFIED, VerticalAlignment.MIDDLE);

          
            //new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(9f)
            //    .ShowTextAligned("Cualquier duda o aclaración contacta al: 55 54 48 68 12, opción 3", pageSize.GetWidth() / 2, 80, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(9f)
                .ShowTextAligned("Correo electrónico: VMXReembolsosGMM@bupa.com.mx.", pageSize.GetWidth() / 2, 70, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(9f)
                .ShowTextAligned("Portal: www.vitamedica.com.mx", pageSize.GetWidth() / 2, 60, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            //new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(9f)
            //    .ShowTextAligned("Consulta el Aviso de Privacidad Integral en www.bbva.mx y bupasalud.com.mx", pageSize.GetWidth() / 2, 50, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);


            //HEADER
            byte[] file = null;

            // REQ 37: Determinar el logo a mostrar según el grupo

            if (GrupoCoaseguroBBVA.Contains(Grupo)) // REQ 37
            {
                pathLogo = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory + "images\\17000002__19000001_CoaseguroBBVA.png");
            }
            else
            {
                pathLogo = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory + "images\\SegurosSalud__RGB[36].png");
            }

            string rutaImag = pathLogo;


            file = System.IO.File.ReadAllBytes(rutaImag);
            Image img = new Image(iText.IO.Image.ImageDataFactory.Create(file, true));
            img.SetFixedPosition(30, pageSize.GetTop() - 70).SetWidth(100).SetHeight(50);

            new Canvas(pdfCanvas, pdfDoc, pageSize).Add(img);


            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(8f)
               .SetFont(bold)
               .SetBackgroundColor(ColorConstants.GRAY)
               .ShowTextAligned("FINIQUITO DE REEMBOLSO", pageSize.GetWidth() - 95, pageSize.GetTop() - 20, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7f)
                .SetBackgroundColor(ColorConstants.WHITE)
                .SetBorderTop(Border.NO_BORDER)
               .ShowTextAligned("FECHA DE DEPÓSITO:", pageSize.GetWidth() - 115, pageSize.GetTop() - 30, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(8f)
                .SetFont(bold)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned(FechaPago.HasValue ? FechaPago.Value.ToString("dd/MM/yyyy") : "", pageSize.GetWidth() - 85, pageSize.GetTop() - 40, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7f)
                .SetBackgroundColor(ColorConstants.WHITE)
                .SetBorderTop(Border.NO_BORDER)
               .ShowTextAligned("LUGAR DE EXPEDICION:", pageSize.GetWidth() - 111, pageSize.GetTop() - 55, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(8f)
                .SetFont(bold)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned("CIUDAD DE MÉXICO", pageSize.GetWidth() - 85, pageSize.GetTop() - 65, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(8f)
                .SetFont(bold)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned("DATOS DE LA RECLAMACIÓN", pageSize.GetWidth() / 2, pageSize.GetTop() - 65, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            //new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7f)
            //    .SetBackgroundColor(ColorConstants.WHITE)
            //   .ShowTextAligned("NOMBRE DEL CONTRATANTE O GRUPO", 30, pageSize.GetTop() - 70, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            //new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(8f)
            //    .SetFont(bold)
            //    .SetBackgroundColor(ColorConstants.WHITE)
            //   .ShowTextAligned("BANCO NACIONAL DE MÉXICO (BANAMEX)", pageSize.GetWidth() / 2, pageSize.GetTop() - 80, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7f)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned("NO. DE PÓLIZA", 30, pageSize.GetTop() - 100, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7f)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned("NOMBRE DEL ASEGURADO", 200, pageSize.GetTop() - 100, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(8f)
                .SetFont(bold)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned(Nomina, 35, pageSize.GetTop() - 110, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(8f)
                .SetFont(bold)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned(NombreTitular, 220, pageSize.GetTop() - 110, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);


            //new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7f)
            //    .SetBackgroundColor(ColorConstants.WHITE)
            //    .SetBorderTop(Border.NO_BORDER)
            //   .ShowTextAligned("TIPO DE EMPLEADO", pageSize.GetWidth() - 111, pageSize.GetTop() - 130, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            //new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7f)
            //    .SetBackgroundColor(ColorConstants.WHITE)
            //    .SetBorder(SolidBorder.NO_BORDER)
            //   .ShowTextAligned("ESTATUS:", pageSize.GetWidth() - 111, pageSize.GetTop() - 140, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            //new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7f)
            //    .SetBackgroundColor(ColorConstants.WHITE)
            //    .SetBorder(SolidBorder.NO_BORDER)
            //   .ShowTextAligned(Estatus, pageSize.GetWidth() - 85, pageSize.GetTop() - 140, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            //new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(4.5f)
            //    .SetBackgroundColor(ColorConstants.WHITE)
            //    .SetBorder(SolidBorder.NO_BORDER)
            //   .ShowTextAligned("A=ACTIVO J=JUBILADO", pageSize.GetWidth() - 111, pageSize.GetTop() - 146, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(8f)
                .SetFont(bold)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned("DATOS DEL RECLAMANTE", pageSize.GetWidth() / 2, pageSize.GetTop() - 145, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7f)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned("NOMBRE DEL ASEGURADO", 30, pageSize.GetTop() - 155, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7f)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned("FECHA DE RECEPCIÓN", (pageSize.GetWidth() / 2) + 20, pageSize.GetTop() - 155, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(8f)
                .SetFont(bold)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned(NombreBenef, 50, pageSize.GetTop() - 165, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(8f)
                .SetFont(bold)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned(FechaRecepcion, (pageSize.GetWidth() / 2) + 20, pageSize.GetTop() - 165, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7f)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned("PARENTESCO", 30, pageSize.GetTop() - 180, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            //new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(7f)
            //    .SetBackgroundColor(ColorConstants.WHITE)
            //   .ShowTextAligned("DIAGNÓSTICO", (pageSize.GetWidth() / 2) + 20, pageSize.GetTop() - 180, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(8f)
                .SetFont(bold)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned(Parentesco, 50, pageSize.GetTop() - 190, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            //new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(8f)
            //    .SetFont(bold)
            //    .SetBackgroundColor(ColorConstants.WHITE)
            //   .ShowTextAligned(Motivo, (pageSize.GetWidth() / 2) + 20, pageSize.GetTop() - 190, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(6.7f)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned("Reembolso pagado por:", 25, pageSize.GetTop() - 210, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(6.7f)
                .SetFont(bold)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned(Convert.ToDecimal(Monto).ToString("C"), 100, pageSize.GetTop() - 210, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(6.7f)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned("Importe en Letra Son:", 25, pageSize.GetTop() - 220, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(6.7f)
                .SetFont(bold)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned(MontoEnLetra, 100, pageSize.GetTop() - 220, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            //new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(6.7f)
            //    .SetBackgroundColor(ColorConstants.WHITE)
            //   .ShowTextAligned("Vitamédica Administradora S.A de C.V me entrega como pago de la reclamación presentada por concepto de", 25, pageSize.GetTop() - 230, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            //new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(6.7f)
            //    .SetBackgroundColor(ColorConstants.WHITE)
            //   .ShowTextAligned("reembolso de acuerdo al desglose que a continuación se presenta:", 25, pageSize.GetTop() - 240, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            new Canvas(pdfCanvas, pdfDoc, pageSize).SetFontColor(ColorConstants.BLACK).SetFontSize(6.7f)
                .SetBackgroundColor(ColorConstants.WHITE)
               .ShowTextAligned("La cantidad por la que se extiende el presente recibo es resultado de la siguiente liquidación:", 23, pageSize.GetTop() - 230, TextAlignment.LEFT, VerticalAlignment.MIDDLE, 0);

            //    .ShowTextAligned(HeaderText)

        }

        public string enletras(string num)
        {
            string res, dec = "";
            Int64 entero;
            int decimales;
            double nro;

            try
            {
                nro = Convert.ToDouble(num);
            }
            catch
            {
                return "";
            }
            entero = Convert.ToInt64(Math.Truncate(nro));
            decimales = Convert.ToInt32(Math.Round((nro - entero) * 100, 2));
            if (decimales > 0)
            {
                dec = " " + decimales.ToString() + "/100";
            }
            res = toText(Convert.ToDouble(entero)) + " PESOS " + dec + " M.N.";
            return res;
        }

        private string toText(double value)
        {
            string Num2Text = "";
            value = Math.Truncate(value);

            if (value == 0) Num2Text = "CERO";


            else if (value == 1) Num2Text = "UNO";
            else if (value == 2) Num2Text = "DOS";
            else if (value == 3) Num2Text = "TRES";
            else if (value == 4) Num2Text = "CUATRO";
            else if (value == 5) Num2Text = "CINCO";
            else if (value == 6) Num2Text = "SEIS";
            else if (value == 7) Num2Text = "SIETE";
            else if (value == 8) Num2Text = "OCHO";
            else if (value == 9) Num2Text = "NUEVE";
            else if (value == 10) Num2Text = "DIEZ";
            else if (value == 11) Num2Text = "ONCE";
            else if (value == 12) Num2Text = "DOCE";
            else if (value == 13) Num2Text = "TRECE";
            else if (value == 14) Num2Text = "CATORCE";
            else if (value == 15) Num2Text = "QUINCE";
            else if (value < 20) Num2Text = "DIECI" + toText(value - 10);
            else if (value == 20) Num2Text = "VEINTE";
            else if (value < 30) Num2Text = "VEINTI" + toText(value - 20);
            else if (value == 30) Num2Text = "TREINTA";
            else if (value == 40) Num2Text = "CUARENTA";
            else if (value == 50) Num2Text = "CINCUENTA";
            else if (value == 60) Num2Text = "SESENTA";
            else if (value == 70) Num2Text = "SETENTA";
            else if (value == 80) Num2Text = "OCHENTA";
            else if (value == 90) Num2Text = "NOVENTA";
            else if (value < 100) Num2Text = toText(Math.Truncate(value / 10) * 10) + " Y " + toText(value % 10);
            else if (value == 100) Num2Text = "CIEN";
            else if (value < 200) Num2Text = "CIENTO " + toText(value - 100);
            else if ((value == 200) || (value == 300) || (value == 400) || (value == 600) || (value == 800)) Num2Text = toText(Math.Truncate(value / 100)) + "CIENTOS";
            else if (value == 500) Num2Text = "QUINIENTOS";
            else if (value == 700) Num2Text = "SETECIENTOS";
            else if (value == 900) Num2Text = "NOVECIENTOS";
            else if (value < 1000) Num2Text = toText(Math.Truncate(value / 100) * 100) + " " + toText(value % 100);
            else if (value == 1000) Num2Text = "MIL";
            else if (value < 2000) Num2Text = "MIL " + toText(value % 1000);
            else if (value < 1000000)
            {
                Num2Text = toText(Math.Truncate(value / 1000)) + " MIL";
                if ((value % 1000) > 0) Num2Text = Num2Text + " " + toText(value % 1000);
            }
            else if (value == 1000000) Num2Text = "UN MILLON";
            else if (value < 2000000) Num2Text = "UN MILLON " + toText(value % 1000000);
            else if (value < 1000000000000)
            {
                Num2Text = toText(Math.Truncate(value / 1000000)) + " MILLONES ";
                if ((value - Math.Truncate(value / 1000000) * 1000000) > 0) Num2Text = Num2Text + " " + toText(value - Math.Truncate(value / 1000000) * 1000000);
            }
            else if (value == 1000000000000) Num2Text = "UN BILLON";
            else if (value < 2000000000000) Num2Text = "UN BILLON " + toText(value - Math.Truncate(value / 1000000000000) * 1000000000000);
            else
            {
                Num2Text = toText(Math.Truncate(value / 1000000000000)) + " BILLONES";
                if ((value - Math.Truncate(value / 1000000000000) * 1000000000000) > 0) Num2Text = Num2Text + " " + toText(value - Math.Truncate(value / 1000000000000) * 1000000000000);
            }

            return Num2Text;
        }



    }

}

﻿using iText.Kernel.Colors;
using iText.Kernel.Events;
using iText.Kernel.Font;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.Layout.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Models.Reembolso;

namespace Vitamedica.PDF
{
    public class Finiquito
    {
        public static string CrearPDF(string fileName, DetalleTramiteViewModel facturas, string comentario)
        {
            //string urlDocumento = HttpContext.Current.Server.MapPath(string.Format("{0}{1}", "", fileName));

            string urlDocumento = fileName;
            if (System.IO.File.Exists(urlDocumento))
                System.IO.File.Delete(urlDocumento);
            //Initialize PDF writer
            PdfWriter writer = new PdfWriter(urlDocumento);
            //Initialize PDF document
            PdfDocument pdf = new PdfDocument(writer);

            decimal montoTotal = 0;

            foreach (var item in facturas.DocumentosTramite.Conceptos.Where(x => x.Aprobado))
            {
                montoTotal += item.MontoAutorizado;
            }

            var hader = new HeaderFooterEventHandler(
                comentario
                , facturas.Detalle.Poliza
                , facturas.Detalle.Titular
                , facturas.Detalle.Beneficiario
                , facturas.Detalle.FechaRegistro.ToString("dd/MM/yyyy")
                , facturas.Detalle.Parentesco
                , facturas.Detalle.MotivoReembolso
                , montoTotal.ToString()
                , facturas.Detalle.FechaPago
                , facturas.Detalle.Grupo
                );

            pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, hader);
            // Initialize document
            Document document = new Document(pdf);
            //document.SetMargins(document.GetTopMargin() + 150, document.GetRightMargin(), document.GetBottomMargin(), document.GetLeftMargin());
            document.SetTopMargin(document.GetTopMargin() + 215);
            document.SetBottomMargin(document.GetBottomMargin() + 190);
            document.SetLeftMargin(document.GetLeftMargin() - 24);
            //document.SetRightMargin(document.GetRightMargin() + 30);
            //Add paragraph to the document
            //document.Add(new Paragraph("Hello World!"));            
            WriteListToPdf(document, facturas);
            //Close document
            document.Close();

            return urlDocumento;
        }

        private static void WriteListToPdf(Document doc, DetalleTramiteViewModel facturas)
        {
            Table table = new Table(6, false).SetMarginLeft(doc.GetLeftMargin()).SetMarginRight(doc.GetRightMargin() - 30);
            PdfFont bold = PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA_BOLD);
            decimal subMonto = 0;
            decimal subDescuento = 0;
            decimal subTotal = 0;
            Text headerReclamacion = new Text("RECLAMACIÓN");
            Text headerUUID = new Text("FOLIO FACTURA (S)");
            Text headerConcepto = new Text("CONCEPTO");
            Text headerMonto = new Text("TOTAL RECLAMADO");
            Text headerGastoNoCubierto = new Text("NO CUBIERTO");
            Text headerTotal = new Text("TOTAL A PAGAR");
            headerReclamacion.SetFontSize(7.5f).SetFont(bold);
            headerUUID.SetFontSize(7.5f).SetFont(bold);
            headerConcepto.SetFontSize(7.5f).SetFont(bold);
            headerMonto.SetFontSize(7.5f).SetFont(bold);
            headerGastoNoCubierto.SetFontSize(7.5f).SetFont(bold);
            headerTotal.SetFontSize(7.5f).SetFont(bold);

            table.AddHeaderCell(new Paragraph(headerReclamacion).SetBackgroundColor(ColorConstants.GRAY));
            table.AddHeaderCell(new Paragraph(headerUUID).SetBackgroundColor(ColorConstants.GRAY).SetWidth(127));
            table.AddHeaderCell(new Paragraph(headerConcepto).SetBackgroundColor(ColorConstants.GRAY).SetWidth(180));
            table.AddHeaderCell(new Paragraph(headerMonto).SetBackgroundColor(ColorConstants.GRAY).SetWidth(50));
            table.AddHeaderCell(new Paragraph(headerGastoNoCubierto).SetBackgroundColor(ColorConstants.GRAY).SetWidth(50));
            table.AddHeaderCell(new Paragraph(headerTotal).SetBackgroundColor(ColorConstants.GRAY).SetWidth(50));


            foreach (var itemP in facturas.DocumentosTramite.Documentos.Lista)
            {
                foreach (var item in facturas.DocumentosTramite.Conceptos.Where(x => x.IdRembolsoDocumento == itemP.IdDocumento))
                {
                    Text textReclamacion = new Text(facturas.Detalle.Folio);
                    Text textUUID = new Text(itemP.UUID);
                    Text textConcepto = new Text(item.Concepto);
                    Text textMonto = new Text(item.MontoConcepto.ToString("C"));
                    Text textGastoNoCubierto = new Text((item.MontoConcepto - item.MontoAutorizado).ToString("C"));
                    Text textTotal = new Text(item.MontoAutorizado.ToString("C"));
                    textReclamacion.SetFontSize(6f);
                    textUUID.SetFontSize(6f);
                    textConcepto.SetFontSize(6f);
                    textMonto.SetFontSize(6f);
                    textGastoNoCubierto.SetFontSize(6f);
                    textTotal.SetFontSize(6f);

                    table.AddCell(new Paragraph(textReclamacion));
                    table.AddCell(new Paragraph(textUUID));
                    table.AddCell(new Paragraph(textConcepto));
                    table.AddCell(new Paragraph(textMonto).SetWidth(50));
                    table.AddCell(new Paragraph(textGastoNoCubierto).SetWidth(50));
                    table.AddCell(new Paragraph(textTotal).SetWidth(50));
                    subMonto += item.MontoConcepto;
                    subDescuento += (item.MontoConcepto - item.MontoAutorizado);
                    subTotal += item.MontoAutorizado;
                }
            }


            Text textSub = new Text("Subtotal:");
            Text textsubMonto = new Text(subMonto.ToString("C"));
            Text textsubDescuento = new Text(subDescuento.ToString("C"));
            Text textsubTotal = new Text(subTotal.ToString("C"));

            textSub.SetFontSize(6f).SetFont(bold);
            textsubMonto.SetFontSize(6f).SetFont(bold);
            textsubDescuento.SetFontSize(6f).SetFont(bold);
            textsubTotal.SetFontSize(6f).SetFont(bold);

            table.AddCell(new Paragraph(textSub));
            table.AddCell(new Paragraph(""));
            table.AddCell(new Paragraph(""));
            table.AddCell(new Paragraph(textsubMonto).SetWidth(50));
            table.AddCell(new Paragraph(textsubDescuento).SetWidth(50));
            table.AddCell(new Paragraph(textsubTotal).SetWidth(50));

            table.AddFooterCell(new Paragraph(""));
            table.AddFooterCell(new Paragraph(""));
            table.AddFooterCell(new Paragraph(""));
            table.AddFooterCell(new Paragraph("").SetWidth(50));
            table.AddFooterCell(new Paragraph("").SetWidth(50));
            table.AddFooterCell(new Paragraph("").SetWidth(50));
            doc.Add(table);
        }
    }

}

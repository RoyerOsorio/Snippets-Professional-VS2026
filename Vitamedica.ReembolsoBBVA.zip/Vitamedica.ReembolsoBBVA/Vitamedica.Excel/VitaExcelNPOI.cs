﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using NPOI.HSSF.UserModel;
using NPOI.SS.Formula.Functions;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;

namespace Vitamedica.Excel
{
    public class VitaExcelNPOI : IVitaExcel
    {

        static XSSFWorkbook hssfworkbook;
        static DataSet dataSet1 = new DataSet();


        public void InitializeWorkbook(string path)
        {
            using (FileStream file = new FileStream(path, FileMode.Open, FileAccess.Read))
            {
                hssfworkbook = new XSSFWorkbook(file);
            }
        }


        public void xlsxToDT()
        {
            DataTable dt = new DataTable();
            ISheet sheet = hssfworkbook.GetSheetAt(0);
            IRow headerRow = sheet.GetRow(0);
            IEnumerator rows = sheet.GetRowEnumerator();

            //int colCount = headerRow.LastCellNum;
            //int rowCount = sheet.LastRowNum;

            int colCount = 16;
            int rowCount = sheet.LastRowNum;

            for (int c = 0; c < colCount; c++)
            {
                ICell cellHead = headerRow.GetCell(c, MissingCellPolicy.RETURN_NULL_AND_BLANK);

                //dt.Columns.Add(headerRow.GetCell(c).ToString());

                if (cellHead != null)
                {
                    if (!string.IsNullOrWhiteSpace(cellHead.StringCellValue))
                    {

                        dt.Columns.Add(headerRow.GetCell(c).ToString());
                    }
                    else
                    {
                        dt.Columns.Add(string.Empty);
                    }
                }
                else
                {

                    dt.Columns.Add(string.Empty);

                }


            }

            bool skipReadingHeaderRow = rows.MoveNext();

            for (int i = 0; i < 6; i++)
            {
               skipReadingHeaderRow = rows.MoveNext();
            }

            while (rows.MoveNext())
            {
                IRow row = (XSSFRow)rows.Current;
                DataRow dr = dt.NewRow();

                for (int i = 0; i < colCount; i++)
                {
                    ICell cell = row.GetCell(i, MissingCellPolicy.RETURN_NULL_AND_BLANK);
                    //ICell cell = row.GetCell(i);

                    if (cell != null)
                    {
                        if (!string.IsNullOrWhiteSpace(cell.StringCellValue))
                        {

                            dr[i] = cell.ToString();
                        }
                        else
                        {
                            dr[i] = string.Empty;
                        }
                    }
                    else
                    {
                        
                        dr[i] = string.Empty;
                        
                    }
                }
                dt.Rows.Add(dr);
            }

            hssfworkbook = null;
            sheet = null;
            dataSet1.Tables.Add(dt);
        }

        public void DisplayData(DataTable table)
        {
            foreach (DataRow row in table.Rows)
            {
                foreach (DataColumn col in table.Columns)
                {
                    Console.WriteLine("{0} = {1}", col.ColumnName, row[col]);
                }
                Console.WriteLine("-------------------------------------------");
            }
        }


        public DataTable getDataSet()
        {
            return dataSet1.Tables[0];
        }

        public byte[] ListToXlsx<T>(List<T> dataSource, List<string> columns, string sheetName = "Reporte")
        {
            IWorkbook workbook = new XSSFWorkbook();
            ISheet sheet = workbook.CreateSheet(sheetName);
            PropertyInfo[] propiedades = typeof(T).GetProperties();

            ICellStyle headerStyle = workbook.CreateCellStyle();
            IFont fontHeader = workbook.CreateFont();
            fontHeader.IsBold = true;
            headerStyle.SetFont(fontHeader);

            IRow filaHeader = sheet.CreateRow(0);
            for (int i = 0; i < columns.Count; i++)
            {
                ICell celda = filaHeader.CreateCell(i);
                celda.SetCellValue(columns[i]);
                celda.CellStyle = headerStyle;
            }

            for (int i = 0; i < dataSource.Count; i++)
            {
                IRow fila = sheet.CreateRow(i + 1);
                for (int j = 0; j < propiedades.Length && j < columns.Count; j++)
                {
                    var valor = propiedades[j].GetValue(dataSource[i], null);
                    ICell celda = fila.CreateCell(j);

                    SetCellValue(celda, valor, propiedades[j].PropertyType);
                }
            }

            for (int i = 0; i < columns.Count; i++)  
                sheet.AutoSizeColumn(i);

            using (var ms = new MemoryStream())
            {
                workbook.Write(ms);
                return ms.ToArray();
            }
        }
        private void SetCellValue(ICell cell, object value, Type propertyType)
        {
            if (value == null) { cell.SetCellValue(""); return; }

            Type tipoReal = Nullable.GetUnderlyingType(propertyType) ?? propertyType;

            if (tipoReal == typeof(int) || tipoReal == typeof(double) || tipoReal == typeof(decimal) || tipoReal == typeof(float))
            {
                cell.SetCellValue(Convert.ToDouble(value));
            }
            else if (tipoReal == typeof(DateTime))
            {
                cell.SetCellValue(((DateTime)value).ToString("ToString(\"yyyy-MM-dd\")"));
            }
            else if (tipoReal == typeof(bool))
            {
                cell.SetCellValue((bool)value);
            }
            else
            {
                cell.SetCellValue(value.ToString());
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;

namespace Vitamedica.Excel
{
    public interface IVitaExcel 
    {
        void InitializeWorkbook(string path);

        void xlsxToDT();

        void DisplayData(DataTable table);

        DataTable getDataSet();

        //Generar Excel pagos

        byte[] ListToXlsx<T>(List<T> dataSource , List<string> columns, string sheetName);//List<T> datos, string[] nombresColumnas, string nombreHoja
    }
}

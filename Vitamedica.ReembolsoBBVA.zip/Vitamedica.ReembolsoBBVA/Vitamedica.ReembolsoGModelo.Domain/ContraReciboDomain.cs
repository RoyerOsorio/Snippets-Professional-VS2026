﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Base.Factory;
using Vitamedica.ReembolsoGModelo.IDomain;
using Vitamedica.ReembolsoGModelo.IRepository;
using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Model.Models;
using Vitamedica.ReembolsoGModelo.Shared.Models;

namespace Vitamedica.ReembolsoGModelo.Domain
{
    public class ContraReciboDomain : IContraReciboDomain
    {
        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

        public List<ContraRecibo> ObtenerContraReciboConsecutivo(ContraReciboFilter filter, Pagination pagination)
        {
            List<ContraRecibo> result = new List<ContraRecibo>();
            using (IContraReciboRepository respository = FactoryEngine<IContraReciboRepository>.GetInstance("IContraReciboRepository"))
            {
                result = respository.ObtenerContraReciboConsecutivo(filter, pagination);
            }
            return result;
        }
    }
}

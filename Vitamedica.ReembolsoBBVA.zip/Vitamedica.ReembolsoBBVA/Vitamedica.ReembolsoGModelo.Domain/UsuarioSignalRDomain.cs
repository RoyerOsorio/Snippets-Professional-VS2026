﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Base.Factory;
using Vitamedica.ReembolsoGModelo.IDomain;
using Vitamedica.ReembolsoGModelo.IRepository;
using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Model.ViewModels;

namespace Vitamedica.ReembolsoGModelo.Domain
{
    public class UsuarioSignalRDomain : IUsuarioSignalRDomain
    {
        public bool ActualizarUsuarioSignalR(UsuarioSignalRResume model)
        {
            bool result = false;

            using (IUsuarioSignalRRepository repository = FactoryEngine<IUsuarioSignalRRepository>.GetInstance("IUsuarioSignalRRepository"))
            {
                result = repository.ActualizarUsuarioSignalR(model);
            }

            return result;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

        public List<UsuarioSignalRResume> ObtenerListaUsuarioSignalR(UsuarioSignalRFilter filter)
        {
            List<UsuarioSignalRResume> items = new List<UsuarioSignalRResume>();

            using (IUsuarioSignalRRepository repository = FactoryEngine<IUsuarioSignalRRepository>.GetInstance("IUsuarioSignalRRepository"))
            {
                items = repository.ObtenerListaUsuarioSignalR(filter);
            }

            return items;
        }

        public int RegistrarUsuarioSignalR(UsuarioSignalRResume model)
        {
            int result;

            using (IUsuarioSignalRRepository repository = FactoryEngine<IUsuarioSignalRRepository>.GetInstance("IUsuarioSignalRRepository"))
            {
                result = repository.RegistrarUsuarioSignalR(model);
            }

            return result;
        }
    }
}

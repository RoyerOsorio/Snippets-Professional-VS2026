﻿using System;
using Vitamedica.Base.Factory;
using Vitamedica.ReembolsoGModelo.IDomain;
using Vitamedica.ReembolsoGModelo.IRepository;
using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Model.ViewModels;

namespace Vitamedica.ReembolsoGModelo.Domain
{
    public class CuentaUsuarioResumeDomain : ICuentaUsuarioResumeDomain
    {
        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

        public CuentaUsuarioResume ObtenerCuentaUsuario(CuentaUsuarioFilter filter)
        {
            CuentaUsuarioResume item = new CuentaUsuarioResume();

            using (ICuentaUsuarioResumeRepository repository = FactoryEngine<ICuentaUsuarioResumeRepository>.GetInstance("ICuentaUsuarioResumeRepository"))
            {
                item = repository.ObtenerCuentaUsuario(filter);
            }

            return item;
        }

        public bool RegistrarCuentaBancariaNomina(CuentaBancariaNomina model)
        {
            bool item;
            using (ICuentaUsuarioResumeRepository repository = FactoryEngine<ICuentaUsuarioResumeRepository>.GetInstance("ICuentaUsuarioResumeRepository"))
            {
                item = repository.RegistrarCuentaBancariaNomina(model);
            }
            return item;
        }
    }
}

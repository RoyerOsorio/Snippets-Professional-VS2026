﻿using System;
using System.Collections.Generic;
using Vitamedica.Base.Factory;
using Vitamedica.ReembolsoGModelo.IDomain;
using Vitamedica.ReembolsoGModelo.IRepository;
using Vitamedica.ReembolsoGModelo.Model.Filter;
using Vitamedica.ReembolsoGModelo.Model.Models;
using Vitamedica.ReembolsoGModelo.Model.ViewModels;
using Vitamedica.ReembolsoGModelo.Shared.Models;
using System.Linq;

namespace Vitamedica.ReembolsoGModelo.Domain
{
    public class ReembolsoDomain : IReembolsoDomain
    {
        public MotivoRechazoResume ActualizarReembolso(ReembolsoResume model)
        {
            MotivoRechazoResume item = new MotivoRechazoResume();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                repository.ActualizarReembolso(model);
            }
            if (model.IdMotivoRechazo.HasValue)
                if (model.IdMotivoRechazo.Value > 0)
                    item = ObtenerMotivoRechazo(model.IdMotivoRechazo.Value);

            return item;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

        public bool BuscaFactura(string param)
        {
            bool result;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.BuscaFactura(param);
            }

            return result;
        }

        public FlujoReembolsoResume ObtenerFlujo(FlujoReembolsoFilter filter)
        {
            FlujoReembolsoResume flujo = new FlujoReembolsoResume();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                flujo = repository.ObtenerFlujo(filter);
            }

            return flujo;
        }

        public List<DocumentoRequeridoResume> ObtenerListaDocumentoRequerido(MotivoDocumentoFilter filter)
        {
            List<DocumentoRequeridoResume> items = new List<DocumentoRequeridoResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                items = repository.ObtenerListaDocumentoRequerido(filter);
            }

            return items;
        }

        public List<MotivoReembolso> ObtenerListaMotivoReembolso(MotivoReembolsoFilter filter)
        {
            List<MotivoReembolso> items = new List<MotivoReembolso>();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                items = repository.ObtenerListaMotivoReembolso(filter);
            }

            return items;
        }

        public MotivoReembolso ObtenerMotivoReembolso(MotivoReembolsoFilter filter)
        {
            MotivoReembolso motivo = new MotivoReembolso();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                motivo = repository.ObtenerMotivoReembolso(filter);
            }

            return motivo;
        }

        public StatusReembolso ObtenerStatus(StatusReembolsoFilter filter)
        {
            StatusReembolso status = new StatusReembolso();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                status = repository.ObtenerStatus(filter);
            }

            return status;
        }

        //public TipoDerechohabiente ObtenerTipoDerechohabiente(PlanDerechohabienteFilter filter)
        //{
        //    TipoDerechohabiente items = new TipoDerechohabiente();
        //    if (string.IsNullOrEmpty(filter.SubGrupo))
        //        filter.SubGrupo = null;

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        items = repository.ObtenerTipoDerechohabiente(filter);
        //    }

        //    return items;
        //}

        public int RegistrarBitacora(Bitacora model)
        {
            int id = 0;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                id = repository.RegistrarBitacora(model);
            }

            return id;
        }

        public List<DetalleFactura> RegistrarFacturaDetalle(List<DetalleFactura> model)
        {
            List<DetalleFactura> Items = new List<DetalleFactura>();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                foreach (var current in model)
                {
                    int id = 0;
                    DetalleFactura item = new DetalleFactura();
                    id = repository.RegistrarFacturaDetalle(current);
                    if (id > 0)
                    {
                        Items.Add(new DetalleFactura
                        {
                            IdFacturaDetalle = id

                        });
                    }
                }
            }

            return Items;
        }

        public DatosReembolsoResume RegistrarReembolso(DatosReembolso model)
        {
            DatosReembolsoResume item = new DatosReembolsoResume();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.RegistrarReembolso(model);
            }

            return item;
        }

        public List<ReembolsoDocumentoResume> RegistrarReembolsoDocumento(List<ReembolsoDocumento> model)
        {
            List<ReembolsoDocumentoResume> list = new List<ReembolsoDocumentoResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                foreach (var item in model)
                {
                    int id = 0;
                    id = repository.RegistrarReembolsoDocumento(item);
                    if (id == 0)
                        break;
                    else
                        list.Add(new ReembolsoDocumentoResume
                        {
                            Contrarecibo = item.Contrarecibo,
                            IdReembolsoDocumento = id
                        });
                }
            }

            return list;
        }

        public List<TableroDictamenResume> ObtenerListaTableroDictamen(TableroDictamenFilter filter, Pagination pagination)
        {
            List<TableroDictamenResume> list = new List<TableroDictamenResume>();

            if (filter.FilterType == TableroDictamenFilterType.Tablero)
            {
                if (string.IsNullOrEmpty(filter.Folio))
                    filter.Folio = null;

                if (string.IsNullOrEmpty(filter.Nomina))
                    filter.Nomina = null;
            }

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerListaTableroDictamen(filter, pagination);
            }

            return list;
        }


        public List<PolizaPagadaResume> ObtenerListaPolizaPagada(ReembolsoFilter filter, Pagination pagination)
        {
            List<PolizaPagadaResume> list = new List<PolizaPagadaResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerListaPolizaPagada(filter, pagination);
            }

            return list;
        }
        public DetalleReembolsoResume ObtenerDetalleReembolso(ReembolsoFilter filter)
        {
            DetalleReembolsoResume list = new DetalleReembolsoResume();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerDetalleReembolso(filter);
            }

            return list;
        }

        public List<DetalleReembolsoResume> ObtenerListaDetalleReembolso(ReembolsoFilter filter, Pagination pagination)
        {
            List<DetalleReembolsoResume> list = new List<DetalleReembolsoResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerListaDetalleReembolso(filter, pagination);
            }

            return list;
        }

        public List<DocumentosReembolsoResume> ObtenerListaDocumentosReembolso(DocumentosReembolsoFilter filter, Pagination pagination)
        {
            List<DocumentosReembolsoResume> list = new List<DocumentosReembolsoResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerListaDocumentosReembolso(filter, pagination);
            }

            return list;
        }

        public List<DetalleFactura> ObtenerDetalleFactura(DetalleFacturaFilter filter)
        {
            List<DetalleFactura> list = new List<DetalleFactura>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerDetalleFactura(filter);
            }

            return list;
        }

        public DocumentosReembolsoResume ObtenerDocumentoReembolso(DocumentosReembolsoFilter filter)
        {
            DocumentosReembolsoResume list = new DocumentosReembolsoResume();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerDocumentoReembolso(filter);
            }

            return list;
        }

        public MotivoRechazoResume ActualizarDocumentoReembolso(DocumentoReembolsoResume model)
        {
            MotivoRechazoResume item = new MotivoRechazoResume();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                repository.ActualizarDocumentoReembolso(model);
            }
            if (model.IdMotivoRechazo > 0)
                item = ObtenerMotivoRechazo(model.IdMotivoRechazo);

            return item;
        }

        public MotivoRechazoResume ActualizarFacturaDetalle(DetalleFacturaResume model)
        {
            MotivoRechazoResume item = new MotivoRechazoResume();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                repository.ActualizarFacturaDetalle(model);
            }
            if (model.IdMotivo > 0)
                item = ObtenerMotivoRechazo(model.IdMotivo);

            return item;
        }

        public List<FlujoReembolsoResume> ObtenerListaFlujo(FlujoReembolsoFilter filter)
        {
            List<FlujoReembolsoResume> flujo = new List<FlujoReembolsoResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                flujo = repository.ObtenerListaFlujo(filter);
            }

            return flujo;
        }

        public List<StatusReembolso> ObtenerListaStatus(StatusReembolsoFilter filter)
        {
            List<StatusReembolso> status = new List<StatusReembolso>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                status = repository.ObtenerListaStatus(filter);
            }

            return status;
        }

        public List<NotaResume> ObtenerNotas(NotaFilter filter)
        {
            List<NotaResume> notas = new List<NotaResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                notas = repository.ObtenerNotas(filter);
            }

            return notas;
        }

        public List<MotivoRechazo> ObtenerListaRechazo(MotivoRechazoFilter filter)
        {
            List<MotivoRechazo> motivos = new List<MotivoRechazo>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                motivos = repository.ObtenerListaRechazo(filter);
            }

            return motivos;
        }

        public void RegistrarDocAdicional(DocAdicionales model)
        {
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                repository.RegistrarDocAdicional(model);
            }
        }

        public void ActualizarDocAdicional(DocAdicionalResume model)
        {
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                repository.ActualizarDocAdicional(model);
            }
        }

        public List<DocumentoAdicionalResume> ObtenerListaDocAdicionales(DocAdicionalFilter filter)
        {
            List<DocumentoAdicionalResume> docAdicionales = new List<DocumentoAdicionalResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                docAdicionales = repository.ObtenerListaDocAdicionales(filter);
            }

            return docAdicionales;
        }

        public bool EnviarAUsuario(int IdReembolso)
        {
            bool result;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.EnviarAUsuario(IdReembolso);
            }

            return result;
        }

        public List<OrigenReembolso> ObtenerListaOrigenReembolso(OrigenReembolsoFilter filter)
        {
            List<OrigenReembolso> lstOrigen = new List<OrigenReembolso>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                lstOrigen = repository.ObtenerListaOrigenReembolso(filter);
            }

            return lstOrigen;
        }

        public MotivoConsulta ObtenerMotivoConsulta(int idConsulta)
        {
            MotivoConsulta item = new MotivoConsulta();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.ObtenerMotivoConsulta(idConsulta);
            }

            return item;
        }

        public List<MotivoConsulta> ObtenerListaMotivoConsulta()
        {
            List<MotivoConsulta> lstItem = new List<MotivoConsulta>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                lstItem = repository.ObtenerListaMotivoConsulta();
            }

            return lstItem;
        }

        public List<MotivoRechazo> ObtenerListaRechazoReembolso(MotivoRechazoReembolsoFilter filter)
        {
            List<MotivoRechazo> motivos = new List<MotivoRechazo>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                motivos = repository.ObtenerListaRechazoReembolso(filter);
            }

            return motivos;
        }

        public bool RegistrarPago(string folio)
        {
            //var lstItems = new List<TramitePagoDetalleResume>();
            var item = new TramitePagoResume();
            var valRegFiscal = false;
            //var valRegFiscalDetalle = false;
            //var valRelRegFiscal = false;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.ObtenerComprobanteFiscal(folio);
                //lstItems = repository.ObtenerComprobanteFiscalDetalle(folio);

                string status = "1";
                item.Estatus = 1;

                //if (EsBancomer(item.Grupo))
                //{
                //status = "1";
                //item.Estatus = 1;
                //}

                //int conRel = 0;
                //foreach (var itemUUID in lstItems)
                //{
                //    if (string.IsNullOrEmpty(itemUUID.FolioComplemento))
                //        break;
                //    conRel++;
                //    itemUUID.UUID = itemUUID.UUID.Substring(0, itemUUID.UUID.Length - 3) + "COM";
                //    itemUUID.Contrarecibo = itemUUID.Contrarecibo + conRel;
                //}

                if (!string.IsNullOrEmpty(item.RefPago))
                    valRegFiscal = repository.RegistrarComprobanteFiscal(item);

                //if (valRegFiscal)
                //    foreach (var itemR in lstItems)
                //    {
                //        valRegFiscalDetalle = repository.RegistrarComprobanteFiscalDetalle(itemR);
                //        if (!valRegFiscalDetalle)
                //            break;
                //        else
                //        {
                //            //string status = "1";

                //            //if (EsBancomer(item.Grupo))
                //            //    status = "0";

                //            valRelRegFiscal = repository.RegistrarRelComprobanteFiscal(new RelComprobanteFiscalResume
                //            {
                //                Contrarecibo = itemR.Contrarecibo,
                //                Reclamacion = item.Reclamacion,
                //                FechaEmision = itemR.FechaEmision,
                //                PRPR_ID = item.PRPR_ID,
                //                FechaLigRecl = item.FechaCaptura,
                //                Estatus = status
                //            });

                //            if (!valRelRegFiscal)
                //                break;
                //        }
                //    }
            }

            //return valRegFiscal && valRegFiscalDetalle && valRelRegFiscal;
            return valRegFiscal;
        }

        public bool RegistrarFechaInicial(FechaInicialReembolsoResume model)
        {
            bool result = false;

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.RegistrarFechaInicial(model);
            }

            return result;
        }

        public bool RegistrarBitacoraModulo(BitacoraModulosResume model)
        {
            bool result = false;

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.RegistrarBitacoraModulo(model);
            }

            return result;
        }

        private MotivoRechazoResume ObtenerMotivoRechazo(int idMotivo)
        {
            MotivoRechazoResume item = new MotivoRechazoResume();
            List<MotivoRechazo> lstItems = new List<MotivoRechazo>();
            lstItems = ObtenerListaRechazo(new MotivoRechazoFilter() { FilterType = MotivoRechazoType.IdMotivo, IdMotivo = idMotivo });
            foreach (var row in lstItems)
                item = new MotivoRechazoResume
                {
                    IdMotivo = row.IdMotivo,
                    Motivo = row.Descripcion,
                    TipoRechazo = row.Rechazo
                };

            return item;
        }

        public DiagnosticoResume ObtenerDiagnostico(DiagnosticoFilter filter)
        {
            DiagnosticoResume item = new DiagnosticoResume();
            if (string.IsNullOrEmpty(filter.Diagnostico))
                filter.Diagnostico = "";

            if (string.IsNullOrEmpty(filter.IdDiag))
                filter.IdDiag = "";

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.ObtenerDiagnostico(filter);
            }

            return item;
        }

        public List<DiagnosticoResume> ObtenerListaDiagnostico(DiagnosticoFilter filter)
        {
            List<DiagnosticoResume> listItem = new List<DiagnosticoResume>();

            if (string.IsNullOrEmpty(filter.Diagnostico))
                filter.Diagnostico = "";

            if (string.IsNullOrEmpty(filter.IdDiag))
                filter.IdDiag = "";

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                listItem = repository.ObtenerListaDiagnostico(filter);
            }

            return listItem;
        }

        public List<DiagnosticoResume> ObtenerListaDiagnosticoDental(DiagnosticoFilter filter)
        {
            List<DiagnosticoResume> listItem = new List<DiagnosticoResume>();

            if (string.IsNullOrEmpty(filter.Diagnostico))
                filter.Diagnostico = "";

            if (string.IsNullOrEmpty(filter.IdDiag))
                filter.IdDiag = "";

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                listItem = repository.ObtenerListaDiagnosticoDental(filter);
            }

            return listItem;
        }

        public TratamientoResume ObtenerTratamiento(TratamientoFilter filter)
        {
            TratamientoResume item = new TratamientoResume();

            if (string.IsNullOrEmpty(filter.IdTran))
                filter.IdTran = "";

            if (string.IsNullOrEmpty(filter.Tratamiento))
                filter.Tratamiento = "";

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.ObtenerTratamiento(filter);
            }

            return item;
        }

        public List<TratamientoResume> ObtenerListaTratamiento(TratamientoFilter filter)
        {
            List<TratamientoResume> listItem = new List<TratamientoResume>();

            if (string.IsNullOrEmpty(filter.IdTran))
                filter.IdTran = "";

            if (string.IsNullOrEmpty(filter.Tratamiento))
                filter.Tratamiento = "";

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                listItem = repository.ObtenerListaTratamiento(filter);
            }

            return listItem;
        }

        public List<TratamientoResume> ObtenerListaTratamientoDental(TratamientoFilter filter)
        {
            List<TratamientoResume> listItem = new List<TratamientoResume>();

            if (string.IsNullOrEmpty(filter.IdTran))
                filter.IdTran = "";

            if (string.IsNullOrEmpty(filter.Tratamiento))
                filter.Tratamiento = "";

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                listItem = repository.ObtenerListaTratamientoDental(filter);
            }

            return listItem;
        }

        //public List<TratamientoResume> ObtenerListaTratamientoDentalXCodigo(TratamientoFilter filter)
        //{
        //    List<TratamientoResume> listItem = new List<TratamientoResume>();

        //    if (string.IsNullOrEmpty(filter.IdTran))
        //        filter.IdTran = "";

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        listItem = repository.ObtenerListaTratamientoDentalXCodigo(filter);
        //    }

        //    return listItem;
        //}

        //public List<CoberturaDentalResume> ObtenerListaTratamientoDentalHistorico(CoberturaDentalFilter filter)
        //{
        //    List<CoberturaDentalResume> listItem = new List<CoberturaDentalResume>();

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        listItem = repository.ObtenerListaTratamientoDentalHistorico(filter);
        //    }

        //    return listItem;
        //}

        //public List<CoberturaDentalResume> ObtenerListaReembolsoDentalHistorico(CoberturaDentalFilter filter)
        //{
        //    List<CoberturaDentalResume> listItem = new List<CoberturaDentalResume>();

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        listItem = repository.ObtenerListaReembolsoDentalHistorico(filter);
        //    }

        //    return listItem;
        //}

        //public bool RegistrarReembolsoDental(List<ReembolsoDentalResume> model)
        //{
        //    bool result = false;

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        result = repository.RegistrarReembolsoDental(model);
        //    }

        //    return result;
        //}

        //public List<CoberturaDentalResume> ObtenerListaCoberturaDental(CoberturaDentalFilter filter)
        //{
        //    List<CoberturaDentalResume> listItem = new List<CoberturaDentalResume>();

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        listItem = repository.ObtenerListaCoberturaDental(filter);
        //    }

        //    return listItem;
        //}

        public void ActualizarDiagnosticoTratamiento(DiagnosticoTratamientoResume model)
        {
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                repository.ActualizarDiagnosticoTratamiento(model);
            }
        }

        private bool EsBancomer(string grupo)
        {
            List<string> lstGrupos = new List<string>();
            lstGrupos.Add("13000006");
            lstGrupos.Add("13000043");
            lstGrupos.Add("20001004");
            lstGrupos.Add("20001005");
            lstGrupos.Add("20001008");
            lstGrupos.Add("20001009");
            lstGrupos.Add("20001013");
            lstGrupos.Add("20001018");
            lstGrupos.Add("20001020");
            lstGrupos.Add("20002002");
            lstGrupos.Add("20002010");
            lstGrupos.Add("20002022");
            lstGrupos.Add("20002025");
            lstGrupos.Add("20002026");
            lstGrupos.Add("20002027");
            lstGrupos.Add("20002028");
            lstGrupos.Add("20002029");
            lstGrupos.Add("20002030");
            lstGrupos.Add("20002031");
            lstGrupos.Add("20002032");
            lstGrupos.Add("20002033");
            lstGrupos.Add("20002034");
            lstGrupos.Add("20002035");
            lstGrupos.Add("20002041");
            lstGrupos.Add("20002042");
            lstGrupos.Add("20002043");
            lstGrupos.Add("20002044");
            lstGrupos.Add("20002045");
            lstGrupos.Add("20002046");
            lstGrupos.Add("20002047");
            lstGrupos.Add("20002048");
            lstGrupos.Add("20002061");
            lstGrupos.Add("20002062");
            lstGrupos.Add("20002063");
            lstGrupos.Add("20002064");
            lstGrupos.Add("20002065");
            lstGrupos.Add("20002066");
            lstGrupos.Add("20002067");
            lstGrupos.Add("BMRJUB");
            lstGrupos.Add("EMABMER");
            lstGrupos.Add("SSB");
            lstGrupos.Add("13000053");
            lstGrupos.Add("13000055");
            lstGrupos.Add("13000056");
            lstGrupos.Add("13000057");
            lstGrupos.Add("13000058");
            lstGrupos.Add("13000059");

            //foreach (string item in lstGrupos)
            //    if (item == grupo.Trim())
            //        return true;

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                return repository.ObtenerGrupoResumen(grupo.Trim());
            }

            //return false;
        }

        public void RegistraNota(Nota model)
        {
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                repository.RegistraNota(model);
            }
        }

        //public ExcepcionResume ObtenerNominaExcepcion(ExcepcionFilter filter)
        //{
        //    ExcepcionResume item = new ExcepcionResume();

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        item = repository.ObtenerNominaExcepcion(filter);
        //    }

        //    return item;
        //}

        public List<PagosBancomerResume> ObtenerListaPagosBancomer()
        {
            List<PagosBancomerResume> listItem = new List<PagosBancomerResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                listItem = repository.ObtenerListaPagosBancomer();
            }

            return listItem;
        }

        //public void RegistrarFolioReembolsoVIBA(FolioReembolsoVIBAResume model)
        //{
        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        repository.RegistrarFolioReembolsoVIBA(model);
        //    }
        //}

        //public List<FolioResume> ActualizarDatosPagoVIBA(List<PagoVIBAResume> model)
        //{
        //    List<FolioResume> folios = new List<FolioResume>();
        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        folios = repository.ActualizarDatosPagoVIBA(model);
        //    }
        //    return folios;
        //}

        //public FolioResume ActualizarDatosPagoVIBAItem(PagoVIBAResume model)
        //{
        //    FolioResume item = new FolioResume();
        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        item = repository.ActualizarDatosPagoVIBAItem(model);
        //    }
        //    return item;
        //}

        public List<LayoutSINBAResume> ObtenerLayoutSINBA()
        {
            List<LayoutSINBAResume> listItem = new List<LayoutSINBAResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                listItem = repository.ObtenerLayoutSINBA();
                foreach (var item in listItem)
                {
                    string grupoAux = string.Empty;
                    int idGrupo = 0;
                    try
                    {
                        grupoAux = repository.ObtenerListaTableroDictamen(new TableroDictamenFilter
                        {
                            FilterType = TableroDictamenFilterType.Tablero,
                            Folio = item.FolioPortal
                        }, null).FirstOrDefault().Grupo;

                        idGrupo = repository.ObtenerIdGrupo(grupoAux);
                    }
                    catch (Exception ex)
                    {

                    }

                    //item.NSS = repository.ObtenerNSS(item.Nomina, idGrupo);
                }
            }

            return listItem;
        }

        public List<FolioResume> RetroPagos()
        {
            List<FolioResume> folios = new List<FolioResume>();
            RetroPagosResume resp = new RetroPagosResume();
            List<FolioResume> resultFolios = new List<FolioResume>();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                folios = repository.ObtenerListaFolios();

                foreach (var item in folios)
                {
                    resp = repository.ObtenerRetroPagos(item);
                    if (!string.IsNullOrEmpty(resp.Folio))
                    {
                        resp.Folio = item.Folio.Substring(0, item.Folio.Length - 2);
                        repository.ActualizarDatosPago(resp);
                        item.FechaPago = resp.FechaPago;

                        if (item.FechaPago.HasValue)
                            resultFolios.Add(item);
                    }
                }
            }

            return resultFolios;
        }

        public List<ReporteMovimientoResume> ObtenerReporteMovimientos()
        {
            List<ReporteMovimientoResume> listItem = new List<ReporteMovimientoResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                listItem = repository.ObtenerReporteMovimientos();
            }

            return listItem;
        }

        //public bool ProcesoEstadistica(DateTime fecha)
        //{            
        //    List<ReclamacionResume> listItem = new List<ReclamacionResume>();
        //    List<ReclamacionDetalleResume> listItemDet = new List<ReclamacionDetalleResume>();

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        listItem = repository.ObtenerListaReclamacion(fecha);
        //        listItemDet = repository.ObtenerListaReclamacionDetalle(fecha);
        //    }

        //    //using (IDerechohabienteRepository repository = FactoryEngine<IDerechohabienteRepository>.GetInstance("IDerechohabienteRepository"))
        //    //{
        //    //    foreach (var item in listItem)
        //    //    {
        //    //        var derechohabiente = repository.ObtenerDerechohabiente(new DerechohabienteFilter
        //    //        {
        //    //            FilterType = DerechohabienteFilterType.NoDeNominaGrupoNoBeneficiario,
        //    //            NoDeNomina = item.Nomina,
        //    //            IdGrupo = item.Grupo,
        //    //            NoBeneficiario = Convert.ToInt16(item.NumBenef)
        //    //        });

        //    //        if (!string.IsNullOrEmpty(derechohabiente.NoNomina))
        //    //        {
        //    //            item.Edad = derechohabiente.Edad;
        //    //            item.Genero = derechohabiente.Sexo.Substring(0, 1);
        //    //        }                    
        //    //    }

        //    //}

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        repository.LimpiarReclamacion();

        //        foreach (var item in listItem)
        //        {
        //            repository.RegistrarReclamacion(item);
        //        }
        //        int count = 1;
        //        if (listItem.Any())
        //            foreach (var item in listItemDet)
        //            {
        //                repository.RegistrarReclamacionDetalle(item);
        //                count++;
        //            }

        //        repository.ActualizarFechaEstadis(new FechaEstadis
        //        {
        //            OperationType = FechaEstadisOperationType.ActualziarFinEjecucion,
        //            CantidadRegistros = listItem.Any() ? listItem.Count : 0,
        //            FechaFinEjecucion = DateTime.Now,
        //            FechaEjecucion = fecha
        //        });
        //    }

        //    return true;
        //}

        public List<ReporteMovimientoResume> ObtenerReporteMovimientosDetalle()
        {
            List<ReporteMovimientoResume> listItem = new List<ReporteMovimientoResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                listItem = repository.ObtenerReporteMovimientosDetalle();
            }

            return listItem;
        }

        public AyudaResume ObtenerAyuda(AyudaFilter filter)
        {
            AyudaResume item = new AyudaResume();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.ObtenerAyuda(filter);
            }

            return item;
        }

        public List<ReporteAdmonResume> ObtenerReporteAdmon(TableroDictamenFilter filter)
        {
            List<ReporteAdmonResume> list = new List<ReporteAdmonResume>();

            if (filter.FilterType == TableroDictamenFilterType.Tablero)
            {
                if (string.IsNullOrEmpty(filter.Folio))
                    filter.Folio = null;

                if (string.IsNullOrEmpty(filter.Nomina))
                    filter.Nomina = null;
            }

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerReporteAdmon(filter);
            }

            return list;
        }

        public bool RegresarTramite(string folio)
        {
            bool result = true;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                repository.RegresarTramite(folio);
            }

            return result;
        }

        public bool EliminarRegistroPago(string folio)
        {
            bool result = true;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                repository.EliminarRegistroPago(folio + "08");
            }

            return result;
        }

        public List<PendienteResume> ObtenerListaTramitesPendientes(PendienteFilter filter)
        {
            List<PendienteResume> list = new List<PendienteResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerListaTramitesPendientes(filter);
                foreach (var item in list)
                {
                    item.Descripcion = "<a class='buscar' onClick='FiltroCampana(this)' data-lista='' data-dictamen='" + filter.Dictamen + "' data-dia='" + item.Dia + "' data-fechaInicio='" + (item.FechaInicio.HasValue ? item.FechaInicio.Value.ToString("yyyy-MM-dd") : "") + "' data-fechaFin='" + (item.FechaFin.HasValue ? item.FechaFin.Value.ToString("yyyy-MM-dd") : "") + "'>" + item.Descripcion + " " + item.Cantidad + "</a>";
                }
            }

            return list;
        }

        //public List<FechaEstadisResume> ObtenerListaFechaEstadis(FechaEstadisFilter filter)
        //{
        //    List<FechaEstadisResume> list = new List<FechaEstadisResume>();

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        list = repository.ObtenerListaFechaEstadis(filter);                
        //    }

        //    return list;
        //}

        //public FechaEstadisResume ObtenerFechaEstadis(FechaEstadisFilter filter)
        //{
        //    FechaEstadisResume item = new FechaEstadisResume();

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        item = repository.ObtenerFechaEstadis(filter);
        //    }

        //    return item;
        //}

        //public int RegistrarFechaEstadis(FechaEstadis model)
        //{
        //    int id;

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        id = repository.RegistrarFechaEstadis(model);
        //    }

        //    return id;
        //}

        //public FechaEstadisResume ActualizarFechaEstadis(FechaEstadis model)
        //{
        //    FechaEstadisResume item = new FechaEstadisResume();

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        item = repository.ActualizarFechaEstadis(model);
        //    }

        //    return item;
        //}

        public List<DepartamentoResume> ObtenerListaDepartamentos()
        {
            List<DepartamentoResume> list = new List<DepartamentoResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerListaDepartamentos();
            }

            return list;
        }

        public bool ActualizarReembolsoCP(ReembolsoCPResume model)
        {
            bool item = false;

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.ActualizarReembolsoCP(model);
            }

            return item;
        }

        public bool ActualizarReembolsoVoBo(VoBoResume model)
        {
            bool item = false;

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.ActualizarReembolsoVoBo(model);
            }

            return item;
        }

        public int RegistrarComentarioReembolso(ComentarioReembolso model)
        {
            int result = 0;

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.RegistrarComentarioReembolso(model);
            }

            return result;
        }

        public List<ComentarioReembolso> ObtenerListaComentarioReembolso(ComentarioFilter filter)
        {
            List<ComentarioReembolso> result = new List<ComentarioReembolso>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ObtenerListaComentarioReembolso(filter);
            }

            return result;
        }

        public ComentarioReembolso ObtenerComentarioReembolso(ComentarioFilter filter)
        {
            ComentarioReembolso result = new ComentarioReembolso();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ObtenerComentarioReembolso(filter);
            }

            return result;
        }

        public List<ReporteAdmonDHBResume> ObtenerReporteAdmonDHB(TableroDictamenFilter filter)
        {
            List<ReporteAdmonDHBResume> result = new List<ReporteAdmonDHBResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ObtenerReporteAdmonDHB(filter);
            }

            return result;
        }

        public List<EncuestaResume> ObtenerReporteEncuesta(EncuestaFilter filter)
        {
            List<EncuestaResume> result = new List<EncuestaResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ObtenerReporteEncuesta(filter);
            }

            return result;
        }

        public List<TramiteRelacionadoResume> ObtenerListaTramitesRelacionados(TramiteRelacionadoFilter filter)
        {
            List<TramiteRelacionadoResume> result = new List<TramiteRelacionadoResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ObtenerListaTramitesRelacionados(filter);
            }

            return result;
        }

        public int RegistrarComplemento(string folio)
        {
            int result = 0;

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.RegistrarComplemento(folio);
            }

            return result;
        }

        //public NominaGMMResume ObtenerNominaGMM(NominaGMMFilter filter)
        //{
        //    NominaGMMResume result = new NominaGMMResume();

        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        result = repository.ObtenerNominaGMM(filter);
        //    }

        //    return result;
        //}

        public void ActualizarNoLlamada(NoLlamadaResume model)
        {
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                repository.ActualizarNoLlamada(model);
            }
        }

        public Notificacion200Resume ObtenerNotificacion200(NotificacionFilter filter)
        {
            Notificacion200Resume item = new Notificacion200Resume();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.ObtenerNotificacion200(filter);
            }

            return item;
        }

        public string ObtenerNotificacionLentes(NotificacionFilter filter)
        {
            string folio = string.Empty;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                folio = repository.ObtenerNotificacionLentes(filter);
            }

            return folio;
        }

        public List<TramitesRezagadosResume> ObtenerListaTramitesRezagados(TramitesRezagadosFilter filter)
        {
            List<TramitesRezagadosResume> list = new List<TramitesRezagadosResume>();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerListaTramitesRezagados(filter);
            }

            return list;
        }

        //public FolioResume ActualizarDatosPagoVIBAFolio(PagoVIBAResume model)
        //{
        //    FolioResume folio = new FolioResume();
        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        folio = repository.ActualizarDatosPagoVIBAFolio(model);
        //    }
        //    return folio;
        //}

        //public bool ExistePlaza(PlazaFilter filter)
        //{
        //    bool result = false;
        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        result = repository.ExistePlaza(filter);
        //    }
        //    return result;
        //}

        public string ObtenerCP(string nomina)
        {
            string result = string.Empty;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ObtenerCP(nomina);
            }
            return result;
        }

        //public List<TipoServicio> ObtenerListaTipoServicio(TipoServicioFilter filter)
        //{
        //    List<TipoServicio> result;
        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        result = repository.ObtenerListaTipoServicio(filter);
        //    }
        //    return result;
        //}

        //public List<Especialidad> ObtenerListaEspecialidadReem(EspecialidadFilter filter)
        //{
        //    List<Especialidad> result;
        //    using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
        //    {
        //        result = repository.ObtenerListaEspecialidadReem(filter);
        //    }
        //    return result;
        //}

        public int RegistrarCuentaBancaria(CuentaBancaria model)
        {
            int item = 0;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.RegistrarCuentaBancaria(model);
            }
            return item;
        }



        public CuentaBancariaResume ObtenerCuentaBancariaPoliza(string Poliza)
        {
            CuentaBancariaResume model = new CuentaBancariaResume();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                model = repository.ObtenerCuentaBancariaPoliza(Poliza);
            }
            return model;
        }



        public int RegistrarTokenTesoreria(TokenTesoreria model)
        {
            int item = 0;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.RegistrarTokenTesoreria(model);
            }
            return item;
        }

        public TokenTesoreriaResume ObtenerTokenTesoreria(TokenFilterTesoreria filter)
        {
            TokenTesoreriaResume model = new TokenTesoreriaResume();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                model = repository.ObtenerTokenTesoreria(filter);
            }
            return model;
        }

        public EstatusTokenTesoreriaResume ObtenerEstatusUltimoTokenTesoreria(int IdCuenta)
        {
            EstatusTokenTesoreriaResume Token = new EstatusTokenTesoreriaResume();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                Token = repository.ObtenerEstatusUltimoTokenTesoreria(IdCuenta);

            }

            return Token;
        }

        public int InvalidarTokenTesoreria(int IdToken)
        {
            int Id = 0;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                Id = repository.InvalidarTokenTesoreria(IdToken);
            }
            return Id;
        }

        public List<Banco> ObtenerListaBancos()
        {
            List<Banco> listBancos = new List<Banco>();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                listBancos = repository.ObtenerListaBancos();
            }
            return listBancos;
        }

        public List<MotivoRechazoCuenta> ObtenerListaMotivoRechazoCuenta()
        {
            List<MotivoRechazoCuenta> list = new List<MotivoRechazoCuenta>();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerListaMotivoRechazoCuenta();
            }
            return list;
        }

        public bool RegistrarVoucherCuentaPoliza(DocumentoVoucher model)
        {
            bool result = true;

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.RegistrarVoucherCuentaPoliza(model);
            }

            return result;
        }

        public List<CatParamDetalle> ObtenerListaCatParam(CatParamFilter filter)
        {
            List<CatParamDetalle> list = new List<CatParamDetalle>();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerListaCatParam(filter);
            }
            return list;
        }


        public ParametroResume ObtenerParametro(ParametroResumeFilter filter)
        {
            ParametroResume item = new ParametroResume();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.ObtenerParametro(filter);
            }

            return item;
        }

        public int ActualizarEstatusCuentaPoliza(ActualizaEstatusCuenta model)
        {
            int Id = 0;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                Id = repository.ActualizarEstatusCuentaPoliza(model);
            }
            return Id;
        }

        public List<CifrasResume> ObtenerListaAcumuladores(AcumuladorFilter filter)
        {
            List<CifrasResume> lista;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                lista = repository.ObtenerListaAcumuladores(filter);
            }
            return lista;

        }

        public List<PolizaPendienteResume> ObtenerListaPolizaPendiente(string poliza)
        {
            List<PolizaPendienteResume> lista;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                lista = repository.ObtenerListaPolizaPendiente(poliza);
            }
            return lista;
        }

        public int ContarTramitesPendientesPoliza(string Poliza)
        {
            int total = 0;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                total = repository.ContarTramitesPendientesPoliza(Poliza);
            }
            return total;
        }

        public DocumentoTesoreria ObtenerDocumentoTesoreria(int Id)
        {
            DocumentoTesoreria model = new DocumentoTesoreria();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                model = repository.ObtenerDocumentoTesoreria(Id);
            }
            return model;
        }


        public CifrasResume ValidaDisponibilidad(ValidaDisponibilidadResume model)
        {
            CifrasResume item;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.ValidaDisponibilidad(model);
            }
            return item;
        }

        public GuardianResume ObtenerGuardianPoliza(string poliza)
        {
            GuardianResume guardian;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                guardian = repository.ObtenerGuardianPoliza(poliza);
            }
            return guardian;
        }

        public List<string> ObtenerLayoutBancos(LayoutBancoFilter filter)
        {
            List<string> list;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerLayoutBancos(filter);
            }
            return list;
        }

        public bool ActualizarStatusBitacora(string poliza)
        {
            bool result;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ActualizarStatusBitacora(poliza);
            }
            return result;
        }

        public int CuentaPreviaActiva(string Poliza)
        {
            int total = 0;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                total = repository.CuentaPreviaActiva(Poliza);
            }
            return total;
        }

        public List<DatosCuentaBancariaClabe> ObtenerListaCuentaClabe(string Clabe)
        {
            List<DatosCuentaBancariaClabe> lista;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                lista = repository.ObtenerListaCuentaClabe(Clabe);
            }
            return lista;
        }

        public CuentaBancariaResume ObtenerCuentaBancariaById(int IdCuenta)
        {
            CuentaBancariaResume model = new CuentaBancariaResume();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                model = repository.ObtenerCuentaBancariaById(IdCuenta);
            }
            return model;
        }

        public bool ActualizarStatusBitacoraEnProceso(NuevaCuenta model)
        {
            bool result;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ActualizarStatusBitacoraEnProceso(model);
            }
            return result;
        }

        public List<LayoutNPSResume> ObtenerLayoutNPS(DateTime fecha)
        {
            List<LayoutNPSResume> lista;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                lista = repository.ObtenerLayoutNPS(fecha);
            }
            return lista;
        }

        public bool RegistrarSiniestro(SiniestroResume model)
        {
            bool result;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.RegistrarSiniestro(model);
            }
            return result;
        }

        public bool ActualizarStatusBitacoraRechazoCuenta(RechazoCuenta model)
        {
            bool result;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ActualizarStatusBitacoraRechazoCuenta(model);
            }

            return result;
        }

        public bool ActualizaStatusBitacoraNuevaCuenta(NuevaCuenta model)
        {
            bool result;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ActualizaStatusBitacoraNuevaCuenta(model);
            }
            return result;
        }

        public List<LayoutBancosResume> ObtenerReporteBancos(DateTime fecha)
        {
            List<LayoutBancosResume> lista;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                lista = repository.ObtenerReporteBancos(fecha);
            }
            return lista;
        }

        public List<ReporteAdmonTableroResume> ObtenerReporteAdmonTablero(TableroDictamenFilter filter, Pagination pagination)
        {
            List<ReporteAdmonTableroResume> list = new List<ReporteAdmonTableroResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerReporteAdmonTablero(filter, pagination);
            }

            return list;
        }

        public List<CuentaBancariaResume> ObtenerListaCuentaBancaria()
        {
            List<CuentaBancariaResume> list = new List<CuentaBancariaResume>();

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerListaCuentaBancaria();
            }

            return list;
        }

        public string ObtenerTelefono(string poliza)
        {
            string result = string.Empty;

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ObtenerTelefono(poliza);
            }

            return result;
        }

        public int ActualizarCuentaBancariaPoliza(CuentaBancaria model)
        {
            int Id = 0;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                Id = repository.ActualizarCuentaBancariaPoliza(model);
            }
            return Id;
        }

        #region Identificacion Oficial

        public int ActualizarINE(INE model)
        {
            int Id = 0;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                Id = repository.ActualizarINE(model);
            }
            return Id;
        }


        public int RegistrarINE(INE model)
        {
            int item = 0;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                item = repository.RegistrarINE(model);
            }
            return item;
        }


        public INEResume ObtenerINEPoliza(string Poliza)
        {
            INEResume model = new INEResume();
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                model = repository.ObtenerINEPoliza(Poliza);
            }
            return model;
        }

        public List<INEResume> ObtenerListaIdentificacionOficial(IdentificacionOficialFilter filter, Pagination pagination)
        {
            List<INEResume> list = new List<INEResume>();

            //if (filter.FilterType == IdentificacionOficialFilterType.Activo)
            //{
            //    if (string.IsNullOrEmpty(filter.Poliza))
            //    {
            //        filter.NuevaINE = true;
            //        filter.Activo = false;
            //    }
                    
            //}

            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                list = repository.ObtenerListaIdentificacionOficial(filter, pagination);
            }

            return list;
        }

        #endregion


        public List<AcumuladorRsume> ObtenerListaAcumuladoresPoliza(AcumuladorPolizaFilter filter)
        {
            List<AcumuladorRsume> lista;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                lista = repository.ObtenerListaAcumuladoresPoliza(filter);
            }
            return lista;
        }

        public List<ContadorEstacionResume> ObtenerConteoPorEstacion()
        {
            List<ContadorEstacionResume> result;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ObtenerConteoPorEstacion();
            }
            return result;
        }

        public int RegistrarCifraInicial(CifrasResume model)
        {
            int result;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.RegistrarCifraInicial(model);
            }
            return result;
        }

        public CifraMonedaResume ObtenerCifraMoneda(CifraMonedaFilter filter)
        {
            CifraMonedaResume result;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ObtenerCifraMoneda(filter);
            }
            return result;
        }

        public List<Moneda> ObtenerListaMoneda()
        {
            List<Moneda> result;
            using (IReembolsoRepository repository = FactoryEngine<IReembolsoRepository>.GetInstance("IReembolsoRepository"))
            {
                result = repository.ObtenerListaMoneda();
            }
            return result;
        }
    }
}

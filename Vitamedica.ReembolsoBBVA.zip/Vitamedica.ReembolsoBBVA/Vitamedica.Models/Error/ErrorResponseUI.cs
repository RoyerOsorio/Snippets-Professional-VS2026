﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Models.Error
{
    public class ErrorResponseUI
    {
        public ErrorResponseUI() {

        }
        
        public ErrorResponseUI(string folio = null, int idReembolso = 0, bool success = false, bool validation = false, bool Generado = false, string message = null) {

            this.folio = folio;
            this.success = success;
            this.validation = validation;
            this.Generado = Generado;
            this.message = message;
        }    

        public ErrorResponseUI(string message) {
            

        }  
           
        public string folio { get; set; } 
        public int idReembolso { get; set; } 
        public bool success { get; set; } 
        public bool validation { get; set; } 
        public bool Generado { get; set; } 
        public string message { get; set; } 

        public int tipoMensage { get; set; }

        public string html { get; set; }
        public bool existe { get; set; }

    }

    public enum ErrorResponseType
    {
        BD,
        Server,
        Internal,
        NullData,
        timeOut

    }

}

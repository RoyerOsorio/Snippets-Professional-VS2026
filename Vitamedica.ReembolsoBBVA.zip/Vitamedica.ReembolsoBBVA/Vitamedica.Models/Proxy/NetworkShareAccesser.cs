﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Models.Proxy
{
    public class NetworkShrAccesser
    {

        public string equipo = string.Empty;
        public string dominio = string.Empty;

        public string usuario = string.Empty;

        public string contrasena = string.Empty;

       
            
    }
}

﻿namespace Vitamedica.Models.Reembolso
{
    public class Notificacion200ResumeViewModel : Shared.MensajeViewModel
    {
        public string Titular { get; set; }

        public string Beneficiario { get; set; }

        public int NoBeneficiario { get; set; }

        public decimal Monto { get; set; }

        public string Grupo { get; set; }
    }
}
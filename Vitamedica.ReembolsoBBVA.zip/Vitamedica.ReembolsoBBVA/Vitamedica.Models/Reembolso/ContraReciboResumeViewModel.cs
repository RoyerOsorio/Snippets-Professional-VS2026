﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace Vitamedica.Models.Reembolso
{
    public class ContraReciboResumeViewModel
    {
        public string Numero { get; set; }
    }
}
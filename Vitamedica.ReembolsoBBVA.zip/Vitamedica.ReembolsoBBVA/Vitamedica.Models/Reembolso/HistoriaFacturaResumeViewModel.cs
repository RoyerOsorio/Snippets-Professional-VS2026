﻿namespace Vitamedica.Models.Reembolso
{
    public class HistoriaFacturaResumeViewModel
    {
        public string Contrarecibo { get; set; }

        public int Estatus { get; set; }

        public string User { get; set; }

        public string Motivo { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class LayoutNPSResumeViewModel
    {
        public string Poliza { get; set; }

        public string Proveedor { get; set; }

        public string Folio { get; set; }

        public string Diagnostico { get; set; }

        public string MotivoReembolso { get; set; }

        public string Paid { get; set; }

        public decimal Motno { get; set; }

        public DateTime FechaServicio { get; set; }

        public string Correo { get; set; }

        public DateTime FechaRecepcion { get; set; }

        public DateTime FechaPago { get; set; }

        public string Ciudad { get; set; }

        public string Region { get; set; }
    }
}
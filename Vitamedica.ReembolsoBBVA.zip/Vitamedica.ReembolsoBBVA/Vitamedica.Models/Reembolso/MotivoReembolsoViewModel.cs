﻿namespace Vitamedica.Models.Reembolso
{
    public class MotivoReembolsoViewModel
    {
        public int IdMotivoReembolso { get; set; }

        public string Motivo { get; set; }

        //public bool EsDental { get; set; }

        //public string Indicaciones { get; set; }

        public decimal Cobertura { get; set; }

        public decimal Coaseguro { get; set; }

        public decimal LimiteEvento { get; set; }

        public decimal Acumulado { get; set; }

        public string Moneda { get; set; }

        public decimal Deducible { get; set; }

        public string ClaveConfig { get; set; }

        public decimal MontoRealCob { get; set; }
        public string DescripcionAyuda { get; set; }
        public string TituloDescripcionAyuda { get; set; }

        public int Order { get; set; }

        public bool Show { get; set; }

        public string PlantillaFiniquito { get; set; }
    }
}
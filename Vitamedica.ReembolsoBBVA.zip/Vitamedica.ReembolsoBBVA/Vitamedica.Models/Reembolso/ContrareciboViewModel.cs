﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class ContrareciboViewModel
    {
        public string Contrarecibo { get; set; }

        public string NoProveedor { get; set; }

        public string RFCEmisor { get; set; }

        public string Serie { get; set; }

        public string Folio { get; set; }

        public decimal? Monto { get; set; }

        public DateTime? FechaTimbrado { get; set; }

        public string RFCCliente { get; set; }

        public string Estatus { get; set; }

        public int NoDocumento { get; set; }

        public DateTime? FechaFactura { get; set; }

        public string FechaFacturaAux { get; set; }

        public string FormaPago { get; set; }

        public decimal? Subtotal { get; set; }

        public decimal? Descuento { get; set; }

        public string TipoComprobante { get; set; }

    }
}
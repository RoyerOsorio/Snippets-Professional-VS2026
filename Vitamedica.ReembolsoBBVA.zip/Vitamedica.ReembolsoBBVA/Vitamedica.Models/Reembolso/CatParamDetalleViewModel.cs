﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class CatParamDetalleViewModel
    {
        public int IdParam { get; set; }

        public string Prefijo { get; set; }

        public string Descripcion { get; set; }

        public string Valor { get; set; }

        public bool Estatus { get; set; }
    }
}
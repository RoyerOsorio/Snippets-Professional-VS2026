﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class EstatusTokenTesoreriaResumeViewModel : Shared.MensajeViewModel
    {
        public int IdToken { get; set; }

        public string Token { get; set; }

        public bool EstatusToken { get; set; }

        public string Observacion { get; set; }

        public DateTime FechaCreacion { get; set; }
    }
}
﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class FlujoReembolsoFilterViewModel
    {
        public int IdFujo { get; set; }

        public bool DictamenMedico { get; set; }

        public FlujoReembolsoFilterType FilterType { get; set; }
    }
}
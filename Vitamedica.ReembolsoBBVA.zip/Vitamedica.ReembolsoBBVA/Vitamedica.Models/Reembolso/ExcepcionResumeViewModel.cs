﻿using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ExcepcionResumeViewModel : MensajeViewModel
    {
        public int IdExcepcion { get; set; }

        public string Nombre { get; set; }

        public string NombreViuda { get; set; }

        public string Nomina { get; set; }

        public decimal Porcentaje { get; set; }

        public bool? EsComite { get; set; }

        public string Comite { get; set; }

        public bool? EsExcepcion { get; set; }

        public int? TipoComite { get; set; }
    }
}
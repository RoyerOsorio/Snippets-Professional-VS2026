﻿namespace Vitamedica.Models.Reembolso
{
    public class DocAdicionalResumeViewModel
    {
        public int IdReembolso { get; set; }

        public int IdEstatus { get; set; }

        public int IdNuevoEstatus { get; set; }
    }
}
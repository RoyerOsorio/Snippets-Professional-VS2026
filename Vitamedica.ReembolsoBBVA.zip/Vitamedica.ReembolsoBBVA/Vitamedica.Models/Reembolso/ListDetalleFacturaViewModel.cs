﻿using System.Collections.Generic;

namespace Vitamedica.Models.Reembolso
{
    public class ListDetalleFacturaViewModel
    {
        public List<DetalleFacturaViewModel> List { get; set; }
    }
}
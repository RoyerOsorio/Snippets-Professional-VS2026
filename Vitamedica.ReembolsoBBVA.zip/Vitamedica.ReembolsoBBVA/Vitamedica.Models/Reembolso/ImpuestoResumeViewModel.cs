﻿namespace Vitamedica.Models.Reembolso
{
    public class ImpuestoResumeViewModel
    {
        public string ClaveImpuesto { get; set; }

        public string Descripcion { get; set; }

        public string Retencion { get; set; }

        public string Traslado { get; set; }

        public string LocalFederal { get; set; }

        public string EntradaCapital { get; set; }
    }
}
﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class PolizaPendienteResumeViewModel
    {
        public int IdPolizaPendiente { get; set; }

        public string Poliza { get; set; }

        public int NoBeneficiario { get; set; }

        public decimal Monto { get; set; }

        public DateTime FechaVigencia { get; set; }

        public bool Status { get; set; }

        public int IdMotivoReembolso { get; set; }

        public string Motivo { get; set; }
    }
}
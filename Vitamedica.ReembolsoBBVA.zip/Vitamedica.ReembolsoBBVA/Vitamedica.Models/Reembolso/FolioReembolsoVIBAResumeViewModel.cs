﻿namespace Vitamedica.Models.Reembolso
{
    public class FolioReembolsoVIBAResumeViewModel
    {
        public int IdReembolso { get; set; }

        public string FolioReembolso { get; set; }
    }
}
﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListaComentarioReembolsoViewModel : MensajeViewModel
    {
        public List<ComentarioReembolsoViewModel> Lista { get; set; }
    }
}
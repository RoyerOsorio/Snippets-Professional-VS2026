﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class LayoutSINBAResumeViewModel
    {
        public DateTime FechaRegistro { get; set; }
        public string Nomina { get; set; }
        public string NombreEmpleado { get; set; }
        public int Consecutivo { get; set; }
        public string Parentesco { get; set; }
        public string NombreBeneficiario { get; set; }
        public string Servicio { get; set; }
        public string PorcenReembolso { get; set; }
        public string Factura { get; set; }
        public string Complemento { get; set; }
        public string Concepto { get; set; }
        public string RFC { get; set; }
        public decimal Importe { get; set; }
        public decimal ImporteTabulador { get; set; }
        public decimal ImporteReembolsado { get; set; }
        public DateTime FechaServicio { get; set; }
        public string Motivo { get; set; }
        public string ICD { get; set; }
        public string CPT { get; set; }
        public string Observacion { get; set; }
        public string Rechazado { get; set; }
        public string MotivoRechazo { get; set; }
        public DateTime FechaAutorizacion { get; set; }
        public DateTime? FechaContable { get; set; }
        public string Contrarecibo { get; set; }
        public string CodigoM { get; set; }
        public string FolioReembolsoVIBA { get; set; }
        public string BaseLimite { get; set; }
        public string NSS { get; set; }
        public string FolioPortal { get; set; }
        public string CP { get; set; }
    }
}
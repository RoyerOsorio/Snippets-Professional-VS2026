﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Models.Reembolso
{
    public class INEResumeViewModel : Shared.MensajeViewModel
    {

        public int IdIne { get; set; }

        public string Poliza { get; set; }
        public string PathFile { get; set; }


        public bool Activo { get; set; }
        [Display(Name = "Nombre titular cuenta")]
        [Required(ErrorMessage = "El Nombre titular cuenta es requerido")]
        public string Nombre { get; set; }
        [Display(Name = "Apellido Paterno")]
        [Required(ErrorMessage = "El Apellido Paterno es requerido")]
        public string ApellidoP { get; set; }
        [Display(Name = "Apellido Materno")]
        [Required(ErrorMessage = "El Apellido Materno es requerido")]
        public string ApellidoM { get; set; }
        public bool CuentaNueva { get; set; }
        public DateTime FechaRegistro { get; set; }
        public DateTime? FechaModificacion { get; set; }
        public bool showUpdateIne { get; set; }
        public string extencionINE { get; set; }
        public bool statusINE { get; set; }
        public bool INEnueva { get; set; }
        public bool ExisteINE { get; set; }
        public string UsuarioCarga { get; set; }

    }

}

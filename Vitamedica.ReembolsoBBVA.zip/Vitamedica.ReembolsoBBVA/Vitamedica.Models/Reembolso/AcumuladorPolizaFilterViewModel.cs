﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class AcumuladorPolizaFilterViewModel
    {
        public string Poliza { get; set; }
        public DateTime? Fecha { get; set; }
        public int? NumBenef { get; set; }
        public int IdMotivoReembolso { get; set; }
        public int? IdTramite { get; set; }
        public AcumuladorPolizaFilterType FilterType { get; set; }
    }

    public enum AcumuladorPolizaFilterType 
    {

        Acumuladores = 0,

        All = 1,
    }
}
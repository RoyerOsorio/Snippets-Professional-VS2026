﻿namespace Vitamedica.Models.Reembolso
{
    public class DiagnosticoResumeViewModel
    {
        public string IdDiagnostico { get; set; }

        public string ICD { get; set; }

        public string Descripcion { get; set; }
        public string Grupo { get; set; }
    }
}
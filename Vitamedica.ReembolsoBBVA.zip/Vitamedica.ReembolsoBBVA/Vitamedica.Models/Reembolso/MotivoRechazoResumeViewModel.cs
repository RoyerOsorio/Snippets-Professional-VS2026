﻿namespace Vitamedica.Models.Reembolso
{
    public class MotivoRechazoResumeViewModel
    {
        public int IdMotivo { get; set; }

        public string Motivo { get; set; }

        public string TipoRechazo { get; set; }
    }
}
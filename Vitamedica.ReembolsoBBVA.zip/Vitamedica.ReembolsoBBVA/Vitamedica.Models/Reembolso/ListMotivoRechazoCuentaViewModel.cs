﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;


namespace Vitamedica.Models.Reembolso
{
    public class ListMotivoRechazoCuentaViewModel : MensajeViewModel
    {
        public List<MotivoRechazoCuentaViewModel> Lista { get; set; }
    }
}
﻿using System;
using Vitamedica.ReembolsoGModelo.Model.Models;

namespace Vitamedica.Models.Reembolso
{
    public class DatosReembolsoViewModel
    {
        public int IdReembolso { get; set; }

        public string Meme_Ck { get; set; }

        public int IdMotivoReembolso { get; set; }

        public string Nomina { get; set; }

        public string Titular { get; set; }

        public string Grupo_Ck { get; set; }

        public string Beneficiario { get; set; }

        public int NumeroBeneficiario { get; set; }

        public string CorreoTitular { get; set; }

        public string Parentesco { get; set; }

        public string NoLlamada { get; set; }

        public int IdOrigen { get; set; }

        public int? IdConsulta { get; set; }

        public int CveTitular { get; set; }

        public DateTime FechaCaptura { get; set; }

        public int IdGrupo { get; set; }

        //public string TipoPago { get; set; }

        public DateTime? FechaInicial { get; set; }

        public string ctaClabe { get; set; }

        //public string TipoReclamo { get; set; }

        public string Diagnostico { get; set; }

        //public string Procedimiento { get; set; }

        //public int NoConceptos { get; set; }

        //public string Capturista { get; set; }
        public string NumTelefono { get; set; }

        public string Departamento { get; set; }

        public int Edad { get; set; }

        public string Sexo { get; set; }

        public string SubGrupo { get; set; }

        public string Plan { get; set; }

        public int Porcentaje { get; set; }

        public string TramiteRelacionado { get; set; }

        public string Banco { get; set; }

        public string Sucursal { get; set; }

        public string Clabe { get; set; }

        public string CP { get; set; }

        public int IdTipoServicio { get; set; }

        public int IdEspecialidad { get; set; }

        public OperationType OperationType { get; set; }

        public DateTime FechaInicioPadecimiento { get; set; }
        public string Poliza { get; set; }

    }
}
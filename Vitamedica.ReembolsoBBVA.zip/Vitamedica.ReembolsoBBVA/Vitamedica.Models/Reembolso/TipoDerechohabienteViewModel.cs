﻿namespace Vitamedica.Models.Reembolso
{
    public class TipoDerechohabienteViewModel
    {
        public int IdTipoDerechohabiente { get; set; }

        public string Plan { get; set; }

        public string Descripcion { get; set; }

        public string TipoServicio { get; set; }

        public decimal Porcentaje { get; set; }

        public string SubGrupo { get; set; }

        public bool EsEmpleado { get; set; }

        public bool EsFuncionario { get; set; }

        public int TipoPeriodo { get; set; }
    }
}
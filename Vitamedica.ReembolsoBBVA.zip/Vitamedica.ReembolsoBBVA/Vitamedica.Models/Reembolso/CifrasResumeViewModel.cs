﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class CifrasResumeViewModel
    {
        public int IdCifras { get; set; }

        public string Poliza { get; set; }

        public int NoBeneficiario { get; set; }

        public int IdMotivo { get; set; }

        public string Motivo { get; set; }

        public decimal Monto { get; set; }
        public decimal Reclamacion { get; set; }

        public DateTime FechaInicioVigencia { get; set; }

        public DateTime FechaFinVigencia { get; set; }

        public int Vigencia { get; set; }

        public decimal MontoDisponible { get; set; }

        public int IdReembolso { get; set; }

        public decimal MontoReclamado { get; set; }

        public string Moneda { get; set; }
    }
}
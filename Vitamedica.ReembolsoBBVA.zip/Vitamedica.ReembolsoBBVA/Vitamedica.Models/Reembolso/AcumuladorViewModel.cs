﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class AcumuladorViewModel
    {
        public List<AcumuladorRsumeViewModel> ListaCifras { get; set; }

        public List<MotivoReembolsoViewModel> ListaMotivoReembolso { get; set; }

        //public List<ViewModels.Salud.DerechohabienteSaludIntegralViewModel> ListaBeneficiarios { get; set; }

        public List<DocumentosReembolsoResumeViewModel> ListaDocumentos { get; set; }

        public List<TableroDictamenResumeViewModel> ListaTablero { get; set; }
    }
}
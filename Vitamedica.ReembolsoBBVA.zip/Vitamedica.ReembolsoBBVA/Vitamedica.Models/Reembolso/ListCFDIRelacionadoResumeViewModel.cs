﻿using System.Collections.Generic;

namespace Vitamedica.Models.Reembolso
{
    public class ListCFDIRelacionadoResumeViewModel
    {
        public List<CFDIRelacionadoResumeViewModel> List { get; set; }
    }
}
﻿namespace Vitamedica.Models.Reembolso
{
    public class NotificacionTablero
    {
        public int Cantidad { get; set; }

        public string Mensaje { get; set; }

        public string Fecha { get; set; }

        public string Dictamen { get; set; }
    }
}
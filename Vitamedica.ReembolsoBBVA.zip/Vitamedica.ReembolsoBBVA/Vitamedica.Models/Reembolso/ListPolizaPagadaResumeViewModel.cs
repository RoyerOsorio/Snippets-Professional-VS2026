﻿
using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListPolizaPagadaResumeViewModel
    {
        public List<PolizaPagadaResumeViewModel> Lista { get; set; } = new List<PolizaPagadaResumeViewModel>();
        public PaginationViewModel Pagination { get; set; }
    }
}

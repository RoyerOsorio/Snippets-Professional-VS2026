﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class NoReclamacionResumeViewModel
    {
        public int IdReclamacion { get; set; }

        public string NoReclamacion { get; set; }

        public DateTime? FechaPago { get; set; }

        public DateTime? FechaContable { get; set; }

        public bool EsFecha { get; set; }
    }
}
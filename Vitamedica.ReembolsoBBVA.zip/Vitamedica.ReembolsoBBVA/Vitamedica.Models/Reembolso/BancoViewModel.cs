﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class BancoViewModel
    {
        public int IdBanco { get; set; }

        public string Clave { get; set; }

        public string Descripcion { get; set; }
    }
}
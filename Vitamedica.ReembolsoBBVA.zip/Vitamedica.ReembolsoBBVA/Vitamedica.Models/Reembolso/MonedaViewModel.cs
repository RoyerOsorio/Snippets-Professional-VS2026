﻿namespace Vitamedica.Models.Reembolso
{
    public class MonedaViewModel
    {
        public int IdMoneda { get; set; }
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public string DescripcionEspanol { get; set; }
        public int Inactivo { get; set; }

        public string Select { get; set; }
    }
}
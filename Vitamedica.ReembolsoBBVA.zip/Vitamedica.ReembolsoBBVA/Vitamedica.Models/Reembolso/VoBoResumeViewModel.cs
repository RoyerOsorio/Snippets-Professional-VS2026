﻿namespace Vitamedica.Models.Reembolso
{
    public class VoBoResumeViewModel
    {
        public int IdReembolso { get; set; }

        public bool? VoBo { get; set; }

        public string Rol { get; set; }
    }
}
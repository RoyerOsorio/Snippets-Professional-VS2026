﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListDatosCuentaBancariaClabeViewModel : MensajeViewModel
    {
        public List<DatosCuentaBancariaClabeViewModel> Lista { get; set; }
    }
}
﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class ReembolsoDentalResumeViewModel
    {
        public int IdConsecutivo { get; set; }
        public int IdReembolsoDoc { get; set; }
        public int IdDetalleFactura { get; set; }
        public int IdCoberturaDental { get; set; }
        public int IdDiagnostico { get; set; }
        public string Diagnostico { get; set; }
        public int IdTratamiento { get; set; }
        public string Tratamiento { get; set; }
        public int Cantidad { get; set; }
        public decimal MontoConcepto { get; set; }
        public DateTime? Fecha { get; set; }
        public string Dientes { get; set; }
        public string Superficies { get; set; }
    }
}
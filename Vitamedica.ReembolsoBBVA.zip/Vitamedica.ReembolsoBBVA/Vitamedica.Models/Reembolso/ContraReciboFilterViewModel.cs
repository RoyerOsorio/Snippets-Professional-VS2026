﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class ContraReciboFilterViewModel
    {
        public string Numero { get; set; }

        public ContraReciboFilterType FilterType { get; set; }
    }
}
﻿namespace Vitamedica.Models.Reembolso
{
    public class ContadorEstacionResumeViewModel
    {
        public string Estacion { get; set; }

        public string Estatus { get; set; }

        public int Cantidad { get; set; }
    }
}
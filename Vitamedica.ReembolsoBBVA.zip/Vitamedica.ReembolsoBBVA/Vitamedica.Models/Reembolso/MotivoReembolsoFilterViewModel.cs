﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class MotivoReembolsoFilterViewModel
    {
        public int IdMotivoReembolso { get; set; }

        public MotivoReembolsoFilterType FilterType { get; set; }
    }
}
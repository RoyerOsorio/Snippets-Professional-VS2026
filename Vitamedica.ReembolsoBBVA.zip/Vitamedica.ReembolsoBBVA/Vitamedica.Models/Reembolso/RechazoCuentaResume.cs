﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class RechazoCuentaResume
    {
        public string Poliza { get; set; }

        public int IdMotivo { get; set; }
        public string Usuario { get; set; }
    }
}
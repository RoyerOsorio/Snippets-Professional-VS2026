﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class DocumentoAdicionalResumeViewModel
    {
        public int IdDocAdicional { get; set; }

        public string Usuario { get; set; }

        public DateTime Fecha { get; set; }

        public int IdDocRequerido { get; set; }

        public string Documento { get; set; }

        public bool EsFactura { get; set; }

        public string Observaciones { get; set; }
    }
}
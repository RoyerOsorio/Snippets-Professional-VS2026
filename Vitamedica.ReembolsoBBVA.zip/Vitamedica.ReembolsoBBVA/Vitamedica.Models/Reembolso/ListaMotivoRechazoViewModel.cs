﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListaMotivoRechazoViewModel : MensajeViewModel
    {
        public List<MotivoRechazoViewModel> Lista { get; set; }
    }
}
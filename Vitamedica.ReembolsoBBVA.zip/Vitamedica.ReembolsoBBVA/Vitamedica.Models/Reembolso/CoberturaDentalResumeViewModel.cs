﻿namespace Vitamedica.Models.Reembolso
{
    public class CoberturaDentalResumeViewModel
    {
        public int IdCoberturaDental { get; set; }
        public int IdGrupo { get; set; }
        public int IdTratamiento { get; set; }
        public string Tratamiento { get; set; }
        public string Fecha { get; set; }
        public string Dientes { get; set; }
        public string Superficies { get; set; }
        public string Garantia { get; set; }
        public string Nivel { get; set; }
        public string TipoDiente { get; set; }
        public string TipoHerramienta { get; set; }
        public string TipoCobertura { get; set; }
        public int IdReembolsoDoc { get; set; }
        public int IdReembolsoDen { get; set; }
        public int IdDetalleFactura { get; set; }
        public string Color { get; set; }
        public string CodeTratamiento { get; set; }
    }
}
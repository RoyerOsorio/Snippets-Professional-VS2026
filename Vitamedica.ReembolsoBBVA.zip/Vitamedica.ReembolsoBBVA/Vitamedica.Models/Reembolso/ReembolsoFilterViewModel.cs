﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class ReembolsoFilterViewModel
    {
        public string Nomina { get; set; }

        public int IdReembolso { get; set; }

        public string Folio { get; set; }
        public string Poliza { get; set; }
        public int Beneficiario { get; set; }

        public ReembolsoFilterType FilterType { get; set; }
    }
}
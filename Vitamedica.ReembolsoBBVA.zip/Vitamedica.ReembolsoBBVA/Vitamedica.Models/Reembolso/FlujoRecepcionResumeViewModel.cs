﻿

namespace Vitamedica.Models.Reembolso
{
    public class FlujoRecepcionResumeViewModel
    {
        public int IdFlujo { get; set; }

        public string Flujo { get; set; }

        public string Descripcion { get; set; }
    }
}
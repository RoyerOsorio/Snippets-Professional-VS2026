﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class NotaFilterViewModel
    {
        public int IdReembolso { get; set; }

        public int IdFlujo { get; set; }

        public int IdEstatus { get; set; }

        public NotaFilterType FilterType { get; set; }
    }
}
﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class MotivoRechazoFilterViewModel
    {
        public string Descripcion { get; set; }

        public int TipoMotivo { get; set; }

        public int TipoUsuario { get; set; }

        public MotivoRechazoType FilterType { get; set; }
    }
}
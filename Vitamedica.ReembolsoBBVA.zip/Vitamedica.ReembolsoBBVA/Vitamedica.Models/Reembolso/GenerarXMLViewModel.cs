﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class GenerarXMLViewModel
    {
        public string ArchivoAux { get; set; }
        public string UUIDAux { get; set; }
        public string RFCEmisorAux { get; set; }
        public string EmisorAux { get; set; }
        public string SerieAux { get; set; }
        public string FolioAux { get; set; }
        public DateTime? FechaEmisionAux { get; set; }
        public decimal MontoFacturaAux { get; set; }

        public List<GenerarXMLDetalleViewModel> ConceptosXML { get; set; }
    }
}
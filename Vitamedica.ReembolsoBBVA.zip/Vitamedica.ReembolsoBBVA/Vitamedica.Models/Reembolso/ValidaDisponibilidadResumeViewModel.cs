﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class ValidaDisponibilidadResumeViewModel
    {
        public string Poliza { get; set; }

        public int NoBeneficiario { get; set; }

        public int IdMotivoReembolso { get; set; }

        public DateTime FechaFactura { get; set; }

        public DateTime FechaInicio { get; set; }

        public DateTime FechaFin { get; set; }

        public int Vigencia { get; set; }
    }
}
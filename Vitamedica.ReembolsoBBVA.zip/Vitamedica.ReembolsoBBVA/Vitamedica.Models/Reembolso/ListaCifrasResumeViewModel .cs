﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Models.Reembolso
{
    public class ListaCifrasResumeViewModel : Vitamedica.Models.Shared.MensajeViewModel
    {
        public List<CifrasResumeViewModel> Lista { get; set; }
    }
}

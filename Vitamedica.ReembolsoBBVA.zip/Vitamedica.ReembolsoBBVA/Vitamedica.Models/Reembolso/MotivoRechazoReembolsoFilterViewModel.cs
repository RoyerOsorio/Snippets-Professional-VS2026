﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class MotivoRechazoReembolsoFilterViewModel
    {
        public int IdReembolso { get; set; }

        public int RolMotivo { get; set; }

        public MotivoRechazoReembolsoFilterType FilterType { get; set; }
    }
}
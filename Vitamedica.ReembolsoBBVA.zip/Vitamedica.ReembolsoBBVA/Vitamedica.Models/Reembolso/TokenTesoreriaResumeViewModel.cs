﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class TokenTesoreriaResumeViewModel : Shared.MensajeViewModel
    {
        public int IdToken { get; set; }

        public int IdCuenta { get; set; }

        public bool Valido { get; set; }
        public string Poliza { get; set; }
    }
}
﻿namespace Vitamedica.Models.Reembolso
{
    public class ReembolsoDocumentoResumeViewModel
    {
        public int IdReembolsoDocumento { get; set; }

        public string Contrarecibo { get; set; }
    }
}
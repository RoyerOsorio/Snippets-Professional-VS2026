﻿using System.Collections.Generic;

namespace Vitamedica.Models.Reembolso
{
    public class DatosXMLViewModel
    {
        public DatosXMLViewModel()
        {
            ListConceptos = new List<ConceptoFactElectResumeViewModel>();
            //ListCFDIRelacionados = new List<CFDIRelacionadoResumeViewModel>();
        }

        public List<ConceptoFactElectResumeViewModel> ListConceptos { get; set; }

        public DetalleFactElectResumeViewModel DetalleFactura { get; set; }

        //public List<CFDIRelacionadoResumeViewModel> ListCFDIRelacionados { get; set; /*}*/
    }
}
﻿namespace Vitamedica.Models.Reembolso
{
    public class AsignarReclamacionResumeViewModel
    {
        public int IdReclamacion { get; set; }

        public string PrPrId { get; set; }

        public string Folio { get; set; }
    }
}
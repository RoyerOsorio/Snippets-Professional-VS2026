﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using Label = Vitamedica.ReembolsoGModelo.Resource.Label;
using Message = Vitamedica.ReembolsoGModelo.Resource.Message;

namespace Vitamedica.Models.Reembolso
{
    public class NotaLlamadaViewModel
    {
        [Display(ResourceType = typeof(Label.NotaLlamada), Name = "LABEL_IDNOTA")]
        [Key()]
        public long IdNota { get; set; }

        [Required(ErrorMessageResourceType = typeof(Message.NotaLlamada), ErrorMessageResourceName = "MESSAGE_NOTA_REQUIRED")]
        [Display(ResourceType = typeof(Label.NotaLlamada), Name = "LABEL_NOTA")]
        public string Nota { get; set; }

        [Required(ErrorMessageResourceType = typeof(Message.NotaLlamada), ErrorMessageResourceName = "MESSAGE_LLAMADA_REQUIRED")]
        [Display(ResourceType = typeof(Label.NotaLlamada), Name = "LABEL_IDLLAMADA")]
        public long IdLlamada { get; set; }

        [Required(ErrorMessageResourceType = typeof(Message.NotaLlamada), ErrorMessageResourceName = "MESSAGE_USUARIO_REQUIRED")]
        [Display(ResourceType = typeof(Label.NotaLlamada), Name = "LABEL_IDUSUARIO")]
        public int IdUsuario { get; set; }

        [Display(ResourceType = typeof(Label.NotaLlamada), Name = "LABEL_FECHA")]
        public DateTime Fecha { get; set; }

        public DateTime Hora { get; set; }

        public string Usuario { get; set; }
    }
}

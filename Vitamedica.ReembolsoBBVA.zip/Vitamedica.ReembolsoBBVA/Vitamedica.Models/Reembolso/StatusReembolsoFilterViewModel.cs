﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class StatusReembolsoFilterViewModel
    {
        public int IdStatus { get; set; }

        public StatusReembolsoFilterType FilterType { get; set; }
    }
}
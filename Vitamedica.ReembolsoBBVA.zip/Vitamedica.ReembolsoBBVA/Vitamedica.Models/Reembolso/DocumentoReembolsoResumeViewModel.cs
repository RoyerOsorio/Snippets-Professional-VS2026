﻿namespace Vitamedica.Models.Reembolso
{
    public class DocumentoReembolsoResumeViewModel
    {
        public int IdDocumentoReembolso { get; set; }

        public bool? Aprobado { get; set; }

        public int IdMotivoRechazo { get; set; }
    }
}
﻿namespace Vitamedica.Models.Reembolso
{
    public class ReembolsoResumeViewModel
    {
        public int IdReembolso { get; set; }

        public int? IdMotivoRechazo { get; set; }

        public string ctaClabe { get; set; }
    }
}
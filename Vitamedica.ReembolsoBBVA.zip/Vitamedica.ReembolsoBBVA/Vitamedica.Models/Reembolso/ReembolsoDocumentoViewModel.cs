﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class ReembolsoDocumentoViewModel
    {
        public int IdReembolsoDocumento { get; set; }

        public int IdReembolso { get; set; }

        public int IdDocumento { get; set; }

        public string Url { get; set; }

        public decimal Monto { get; set; }

        public DateTime Fecha { get; set; }

        public string Contrarecibo { get; set; }

        public string UUID { get; set; }

        public string Emisor { get; set; }

        public string Serie { get; set; }

        public string Folio { get; set; }

        public DateTime FechaEmision { get; set; }

        public string RFCEmisor { get; set; }

        public int IdMotivoReembolso { get; set; }

        public int? IdMotivoConsulta { get; set; }

        public string RazonSocial { get; set; }

        public string Moneda { get; set; }
    }
}
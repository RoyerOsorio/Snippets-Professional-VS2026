﻿using Vitamedica.ReembolsoGModelo.Model.Filter;


namespace Vitamedica.Models.Reembolso
{
    public class ParametroResumeFilterViewModel
    {
        public string Clave { get; set; }

        public ParametroFilterType FilterType { get; set; }
    }
}
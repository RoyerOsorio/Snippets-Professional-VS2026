﻿using Vitamedica.Models.Shared;


namespace Vitamedica.Models.Reembolso
{
    public class ParametroResumeViewModel : MensajeViewModel
    {
        public int IdParametro { get; set; }

        public string Clave { get; set; }

        public string Descripcion { get; set; }

        public string Valor { get; set; }
    }
}
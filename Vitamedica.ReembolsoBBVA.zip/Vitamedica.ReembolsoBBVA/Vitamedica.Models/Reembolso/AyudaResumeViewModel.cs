﻿using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class AyudaResumeViewModel : MensajeViewModel
    {
        public bool TieneAyudaLentes { get; set; }

        public string FolioLentes { get; set; }

        public int IdTramiteLentes { get; set; }

        public string IndicacionesLentes { get; set; }

        public decimal MontoLentes { get; set; }

        public bool TieneAyudaDental { get; set; }

        public string FolioDental { get; set; }

        public int IdTramiteDental { get; set; }

        public string IndicacionesDental { get; set; }

        public decimal MontoDental { get; set; }
    }
}
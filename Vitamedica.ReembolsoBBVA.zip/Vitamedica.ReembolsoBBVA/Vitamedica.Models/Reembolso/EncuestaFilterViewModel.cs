﻿using System;
using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class EncuestaFilterViewModel
    {
        public DateTime? FechaInicio { get; set; }

        public DateTime? FechaFin { get; set; }

        public EncuestaFilterType FilterType { get; set; }
    }
}
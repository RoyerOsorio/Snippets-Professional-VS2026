﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListaDocumentoFactResumeViewModel : MensajeViewModel
    {
        public List<DocumentoFactResumeViewModel> Lista { get; set; }
    }
}
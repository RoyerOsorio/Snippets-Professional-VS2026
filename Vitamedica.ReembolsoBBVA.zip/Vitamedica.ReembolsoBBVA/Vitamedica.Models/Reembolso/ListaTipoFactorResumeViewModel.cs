﻿using System.Collections.Generic;

namespace Vitamedica.Models.Reembolso
{
    public class ListaTipoFactorResumeViewModel : Shared.MensajeViewModel
    {
        public List<TipoFactorResumeViewModel> Lista { get; set; }
    }
}
﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class DocAdicionalFilterViewModel : DocAdicionalResumeViewModel
    {
        public DocAdicionalFilterType FilterType { get; set; }
    }
}
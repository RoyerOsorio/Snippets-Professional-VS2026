﻿namespace Vitamedica.Models.Reembolso
{
    public class TratamientoResumeViewModel
    {
        public string IdTratamiento { get; set; }

        public string CPT { get; set; }

        public string Descripcion { get; set; }

        public string Color { get; set; }
    }
}
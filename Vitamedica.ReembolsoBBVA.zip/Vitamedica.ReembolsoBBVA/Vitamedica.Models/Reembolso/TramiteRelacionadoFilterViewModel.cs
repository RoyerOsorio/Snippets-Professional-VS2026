﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class TramiteRelacionadoFilterViewModel
    {
        public string Folio { get; set; }

        public int Flujo { get; set; }

        public TramiteRelacionadoFilterType FilterType { get; set; }
    }
}
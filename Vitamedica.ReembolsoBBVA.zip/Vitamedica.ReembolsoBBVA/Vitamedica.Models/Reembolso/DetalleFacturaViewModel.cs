﻿namespace Vitamedica.Models.Reembolso
{
    public class DetalleFacturaViewModel
    {
        public int IdFacturaDetalle { get; set; }

        public int IdRembolsoDocumento { get; set; }

        public string Concepto { get; set; }

        public decimal MontoConcepto { get; set; }

        public decimal MontoSugerido { get; set; }

        public decimal MontoAutorizado { get; set; }

        public decimal MontoPagado { get; set; }

        public bool Aprobado { get; set; }

        public string Contrarecibo { get; set; }

        public string Nota { get; set; }

        public int Cantidad { get; set; }

        public decimal ValorUnitario { get; set; }

        public int IdTipoRechazo { get; set; }

        public string Rechazo { get; set; }

        public string ICD { get; set; }

        public string CPT { get; set; }

        public string Dientes { get; set; }

        public decimal MontoDolares { get; set; }

        public decimal MontoPesos { get; set; }

        public decimal MontoDolar { get; set; }
        public string Moneda { get; set; }
        public decimal ConceptoTOmxn { get; set; }

    }
}
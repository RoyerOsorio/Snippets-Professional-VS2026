﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class DocumentosReembolsoFilterViewModel
    {
        public int IdMotivo { get; set; }

        public int IdReembolso { get; set; }

        public int IdDocumento { get; set; }

        public DocumentosReembolsoFilterType FilterType { get; set; }
    }
}
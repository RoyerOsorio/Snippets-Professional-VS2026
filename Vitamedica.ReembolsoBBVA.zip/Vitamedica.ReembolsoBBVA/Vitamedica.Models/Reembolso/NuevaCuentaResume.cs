﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class NuevaCuentaResume
    {

        public string Poliza { get; set; }

        public string Usuario { get; set; }

        public string TipoUsuario { get; set; }

        public int IdFlujo { get; set; }
  
        public int IdEstatus { get; set; }
   
        public string Comentario { get; set; }
    }
}
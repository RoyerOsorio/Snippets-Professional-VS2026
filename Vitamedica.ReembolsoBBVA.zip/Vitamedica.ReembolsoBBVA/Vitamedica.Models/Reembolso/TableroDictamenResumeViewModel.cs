﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Vitamedica.Models.Reembolso
{
    public class TableroDictamenResumeViewModel
    {
        public int IdReembolso { get; set; }

        [Display(Name = "Póliza")]
        public string Nomina { get; set; }

        public string Beneficiario { get; set; }

        public string Parentesco { get; set; }

        public DateTime Fecha { get; set; }

        public string Estatus { get; set; }

        public int IdEstatus { get; set; }

        [Display(Name = "Estación actual")]
        public string Flujo { get; set; }

        public int IdFlujo { get; set; }

        public string Folio { get; set; }

        public string Comentario { get; set; }

        public string TipoUsuario { get; set; }

        public int IdFlujoAnterior { get; set; }

        //Param Adicional
        public bool? Complemento { get; set; }

        public string Grupo { get; set; }

        public decimal Monto { get; set; }

        public bool EsExcepcion { get; set; }

        public string FolioViba { get; set; }

        public bool EsBancomer { get; set; }

        //Comite

        public bool EsComite { get; set; }

        public string Comite { get; set; }

        public bool? VoBo { get; set; }

        public DateTime? FechaVoBo { get; set; }

        public bool RequiereComentario { get; set; }

        public bool? VoBoM { get; set; }

        public DateTime? FechaVoBoM { get; set; }

        public DateTime? FechaVoBoCliente { get; set; }

        public DateTime? FechaVoBoMCliente { get; set; }

        public int NoBeneficiario { get; set; }
        public string Poliza { get; set; }

        public string Dep { get; set; }

    }
}
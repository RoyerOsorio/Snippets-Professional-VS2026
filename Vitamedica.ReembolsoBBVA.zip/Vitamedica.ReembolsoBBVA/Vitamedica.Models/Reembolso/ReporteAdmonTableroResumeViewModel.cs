﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class ReporteAdmonTableroResumeViewModel
    {
        public string Folio { get; set; }

        public string Grupo { get; set; }

        public decimal MontoReclamado { get; set; }

        public string NombreDHB { get; set; }

        public string Titular { get; set; }

        public string Nomina { get; set; }

        public int NumBeneficiario { get; set; }

        public string Parentesco { get; set; }

        public DateTime FechaRegistro { get; set; }

        public DateTime? FechaDA { get; set; }

        public int DevueltoDA { get; set; }

        public string UsuarioDA { get; set; }

        public DateTime? FechaDM { get; set; }

        public int DevueltoDM { get; set; }

        public string UsuarioDM { get; set; }

        public string Estacion { get; set; }

        public string Estatus { get; set; }

        public Decimal MontoTabulador { get; set; }

        public decimal MontoAutorizado { get; set; }

        public DateTime? FechaServicio { get; set; }

        public DateTime? FechaContable { get; set; }

        public DateTime? FechaPago { get; set; }

        public string Origen { get; set; }

        public string MotivoReembolso { get; set; }

        public DateTime? FechaCorreccionAdmi { get; set; }

        public DateTime? FechaCorreccionMed { get; set; }

        public bool? VoBo { get; set; }

        public DateTime? FechaVoBo { get; set; }

        public bool? VoBoM { get; set; }

        public DateTime? FechaVoBoM { get; set; }

        public string FolioComplemento { get; set; }

        public string Estado { get; set; }

        public string Municipio { get; set; }

        public DateTime FechaVoBoCliente { get; set; }

        public DateTime FechaVoBoMCliente { get; set; }

        public string TipoServicio { get; set; }

        public string Especialidad { get; set; }

        public int IdOrigen { get; set; }

        public string Cuenta { get; set; }

        public string Siniestro { get; set; }

        public string UsuarioRegistra { get; set; }

        public string Diagnostico { get; set; }

        public string MotivoRechazo { get; set; }
        public string Poliza { get; set; }
    }
}
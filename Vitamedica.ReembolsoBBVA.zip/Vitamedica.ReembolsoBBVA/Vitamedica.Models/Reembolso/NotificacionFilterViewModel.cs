﻿namespace Vitamedica.Models.Reembolso
{
    public class NotificacionFilterViewModel
    {
        public string Nomina { get; set; }

        public int NoBeneficiario { get; set; }

        public int IdTramite { get; set; }
    }
}
﻿namespace Vitamedica.Models.Reembolso
{
    public class DocumentoFactResumeViewModel
    {
        public int IdDocumento { get; set; }

        public string Descripcion { get; set; }
    }
}
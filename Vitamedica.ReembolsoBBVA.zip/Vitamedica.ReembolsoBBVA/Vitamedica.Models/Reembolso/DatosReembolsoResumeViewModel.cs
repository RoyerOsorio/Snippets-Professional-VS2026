﻿namespace Vitamedica.Models.Reembolso
{
    public class DatosReembolsoResumeViewModel
    {
        public int IdReembolso { get; set; }

        public string Folio { get; set; }
    }
}
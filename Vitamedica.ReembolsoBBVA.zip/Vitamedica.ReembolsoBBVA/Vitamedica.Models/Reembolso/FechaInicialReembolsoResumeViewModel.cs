﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class FechaInicialReembolsoResumeViewModel
    {
        public int IdReembolso { get; set; }

        public DateTime? FechaInicial { get; set; }

        //public int IdTipoDerechohabiente { get; set; }
    }
}
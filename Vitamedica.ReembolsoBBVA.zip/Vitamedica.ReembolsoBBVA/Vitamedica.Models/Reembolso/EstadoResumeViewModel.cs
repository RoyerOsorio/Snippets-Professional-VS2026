﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Models.Reembolso
{
    public class EstadoResumeViewModel
    {
        public string CodEstado { get; set; }

        public string Estado { get; set; }
    }
}

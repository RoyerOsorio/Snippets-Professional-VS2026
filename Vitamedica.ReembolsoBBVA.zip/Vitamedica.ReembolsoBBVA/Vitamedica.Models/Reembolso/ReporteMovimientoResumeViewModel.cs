﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class ReporteMovimientoResumeViewModel
    {
        public string Grupo { get; set; }

        public string Titular { get; set; }

        public string Nomina { get; set; }

        public int NumBeneficiario { get; set; }

        public string Parentesco { get; set; }

        public string Beneficiario { get; set; }

        public string Motivo { get; set; }

        public int IdMotivo { get; set; }

        public decimal Gasto { get; set; }

        public decimal IVA { get; set; }

        public decimal ISR { get; set; }

        public decimal IVARet { get; set; }

        public decimal ImporteCedular { get; set; }

        public decimal NetoAPagar { get; set; }

        public string Emisor { get; set; }

        public string RFC { get; set; }

        public string Factura { get; set; }

        public DateTime FechaContable { get; set; }

        public string Folio { get; set; }

        public DateTime FechaServicio { get; set; }

        public string Departamento { get; set; }

        public string Tipo { get; set; }

        public string Fondos { get; set; }

        public string Contrarecivo { get; set; }

        public string ClaveProveedor { get; set; }

        public DateTime FechaReclamo { get; set; }

        public string Diagnostico { get; set; }

        public string Tratamiento { get; set; }

        public string Cuenta_Altamira { get; set; }

        public decimal MontoFactura { get; set; }
        public string Poliza { get; set; }
    }
}
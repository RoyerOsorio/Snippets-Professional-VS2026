﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListPagosBancomerResumeViewModel : MensajeViewModel
    {
        public List<PagosBancomerResumeViewModel> Lista { get; set; }
    }
}
﻿

namespace Vitamedica.Models.Reembolso
{
    public class ActualizaEstatusCuentaViewModel
    {
        public int IdCuenta { get; set; }

        public bool Activo { get; set; }

        public bool? NuevaCuenta { get; set; }
    }
}
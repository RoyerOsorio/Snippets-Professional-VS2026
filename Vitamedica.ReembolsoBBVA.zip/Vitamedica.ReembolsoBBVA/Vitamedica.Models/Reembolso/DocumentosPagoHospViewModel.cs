﻿using System.Collections.Generic;

namespace Vitamedica.Models.Reembolso
{
    public class DocumentosPagoHospViewModel
    {
        public int IdFacturaPago { get; set; }

        public string UrlFactura { get; set; }

        public string Factura { get; set; }

        public List<ComandaPagoViewModel> ListaComanda { get; set; }

        public string UrlNotaCredito { get; set; }

        public string NotaCredito { get; set; }
    }
}
﻿using System.Collections.Generic;

namespace Vitamedica.Models.Reembolso
{
    public class ListContadorEstacionResumeViewModel : Shared.MensajeViewModel
    {
        public List<ContadorEstacionResumeViewModel> Lista { get; set; }
    }
}
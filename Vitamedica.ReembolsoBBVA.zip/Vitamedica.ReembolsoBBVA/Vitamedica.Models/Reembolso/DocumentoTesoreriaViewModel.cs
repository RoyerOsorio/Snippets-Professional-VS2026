﻿using System;


namespace Vitamedica.Models.Reembolso
{
    public class DocumentoTesoreriaViewModel:Shared.MensajeViewModel
    {
        public int IdDocumento { get; set; }

        public int IdCuenta { get; set; }

        public string Ruta { get; set; }

        public DateTime Fecha { get; set; }
    }
}
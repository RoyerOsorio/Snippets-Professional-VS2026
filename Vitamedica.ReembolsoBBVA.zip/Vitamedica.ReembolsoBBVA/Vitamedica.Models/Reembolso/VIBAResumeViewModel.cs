﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class VIBAResumeViewModel
    {
        public string FolioReembolso { get; set; }

        public string Estatus { get; set; }

        public DateTime? FechaPago { get; set; }

        public DateTime? FechaContable { get; set; }
    }
}
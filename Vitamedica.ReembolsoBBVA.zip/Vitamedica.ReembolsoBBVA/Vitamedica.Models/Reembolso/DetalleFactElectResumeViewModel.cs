﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class DetalleFactElectResumeViewModel
    {
        public string Contrarecibo { get; set; }

        public string Uuid { get; set; }

        public string DomicilioFiscalEmisor { get; set; }

        public string LugarExpedicion { get; set; }

        public string RegimenFiscalEmisor { get; set; }

        public string FormaPago { get; set; }

        public string NumeroCuentaPago { get; set; }

        public string TipoComprobante { get; set; }

        public string Version { get; set; }

        public string Sello { get; set; }

        public decimal SubTotal { get; set; }

        public decimal IvaImporte { get; set; }

        public decimal IvaTasa { get; set; }

        public decimal IvaImporte2 { get; set; }

        public decimal IvaTasa2 { get; set; }

        public decimal IsrRetenido { get; set; }

        public decimal IvaRetenido { get; set; }

        public decimal Total { get; set; }

        public string NumeroAprobacion { get; set; }

        public string AnoAprobacion { get; set; }

        public string Certificado { get; set; }

        public string NumeroCertificado { get; set; }

        public string SelloSat { get; set; }

        public string CertificadoSat { get; set; }

        public string FechaCertificado { get; set; }

        public string NombreEmisor { get; set; }

        public string NombreReceptor { get; set; }

        public string DomicilioReceptor { get; set; }

        public decimal Descuento { get; set; }

        public string MetodoPago { get; set; }

        public decimal ImpuestoCedular { get; set; }

        public decimal TasaCedula { get; set; }

        public string Moneda { get; set; }

        public string TipoRelacion { get; set; }

        public string UsoCFDI { get; set; }
    }
}
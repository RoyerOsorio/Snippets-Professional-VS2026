﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Vitamedica.Models.Reembolso
{
    public class CuentaBancariaResumeViewModel : Shared.MensajeViewModel
    {

        public int IdCuenta { get; set; }
  
        public string Poliza { get; set; }

        public string Banco { get; set; }
        public string ClaveBanco { get; set; }
        [Display(Name = "Clabe Interbancaria")]
        [Required(ErrorMessage = "La clabe interbancaria es requerida")]
        [StringLength(18, MinimumLength = 18)]
        public string Clabe { get; set; }

        public bool Activo { get; set; }
        [Display(Name = "Nombre titular cuenta")]
        [Required(ErrorMessage = "El Nombre titular cuenta es requerido")]
        public string Nombre { get; set; }
        [Display(Name = "Apellido Paterno")]
        [Required(ErrorMessage = "El Apellido Paterno es requerido")]
        public string ApellidoP { get; set; }
        [Display(Name = "Apellido Materno")]
        [Required(ErrorMessage = "El Apellido Materno es requerido")]
        public string ApellidoM { get; set; }
        public string Meme_Ck { get; set; }
        public bool CuentaNueva { get; set; }
        public DateTime FechaBitacora { get; set; }
        public int? IdMotivo { get; set; }

        public string DescripcionRechazo { get; set; }
  
        public string Observacion { get; set; }

        public bool HabilitarSolicitudCambio { get; set; }

        public EstatusCuenta Estatus { get; set; }

        public string RutaVoucher { get; set; }

        public int? IdBitacora { get; set; }
        [Required]
        [DataType(DataType.EmailAddress)]
        public string Correo { get; set; }
        public DateTime FechaRegistro { get; set; }
        public bool EnviadoTesoreria { get; set; }
        public bool CuentaActualizadaMismoDia { get; set; }
        public DateTime? FechaModificacion { get; set; }

    }

    public enum EstatusCuenta : int
    {
        Aprobada = 0,
        Pendiente = 1,
        Rechazada = 2,
        NoExiste = 3
    }
}
﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class PagosBancomerResumeViewModel
    {
        public int IdReembolso { get; set; }

        public string Folio { get; set; }

        public string Nomina { get; set; }

        public string MotivoReembolso { get; set; }

        public decimal MontoAutorizado { get; set; }

        public string Titular { get; set; }

        public string FolioComplemento { get; set; }

        public DateTime? FechaDescarga { get; set; }

        public string FechaDescargaAux { get; set; }
    }
}
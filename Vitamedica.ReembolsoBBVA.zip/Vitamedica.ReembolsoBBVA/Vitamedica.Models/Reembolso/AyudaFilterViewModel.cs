﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class AyudaFilterViewModel
    {
        public string Nomina { get; set; }

        public int NumBeneficiario { get; set; }

        public AyudaFilterType FilterType { get; set; }
    }
}
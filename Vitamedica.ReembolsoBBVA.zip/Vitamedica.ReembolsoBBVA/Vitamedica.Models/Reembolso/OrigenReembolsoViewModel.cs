﻿namespace Vitamedica.Models.Reembolso
{
    public class OrigenReembolsoViewModel
    {
        public int IdOrigen { get; set; }

        public string Descripcion { get; set; }

        public decimal Porcentaje { get; set; }
    }
}
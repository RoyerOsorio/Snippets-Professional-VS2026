﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class ListaCobDetalleViewModel
    {
        public int IdMotivoReembolso { get; set; }

        public string Poliza { get; set; }

        public int NoBenef { get; set; }

        public DateTime Fecha { get; set; }

        public decimal MontoCifras { get; set; }

        public decimal MontoDetalle { get; set; }
    }
}
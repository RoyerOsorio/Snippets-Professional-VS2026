﻿namespace Vitamedica.Models.Reembolso
{
    public class CatalogoCFDI33ResumeViewModel
    {
        public string FormaPago { get; set; }

        public string Moneda { get; set; }

        public string TipoComprobante { get; set; }

        public string MetodoPago { get; set; }

        public string LugarExpedicion { get; set; }

        public string TipoRelacion { get; set; }

        public string RegimenFiscalEmisor { get; set; }

        public string UsoCFDI { get; set; }

        public string FormaPagoDescripcion { get; set; }

        public string MonedaDescripcion { get; set; }

        public string TipoComprobanteDescripcion { get; set; }

        public string MetodoPagoDescripcion { get; set; }

        public string TipoRelacionDescripcion { get; set; }

        public string RegimenFiscalEmisorDescripcion { get; set; }

        public string UsoCFDIDescripcion { get; set; }

        public string Errores { get; set; }

        public string UUID { get; set; }

        public string DescripcionExportacion { get; set; }

        public string CodigoPostal { get; set; }
    }
}
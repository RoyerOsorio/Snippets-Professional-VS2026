﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class BitacoraModulosResumeViewModel
    {
        public int IdModulo { get; set; }

        public int IdAccion { get; set; }

        public int IdCaso { get; set; }

        public string TipoUsuario { get; set; }

        public string Usuario { get; set; }

        public string Parametros { get; set; }
    }
}
﻿using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class DiagnosticoTratamientoResumeViewModel : MensajeViewModel
    {
        public int IdFactura { get; set; }

        public int IdDocumento { get; set; }

        public string ICD { get; set; }

        public string CPT { get; set; }
    }
}
﻿using System.Collections.Generic;

namespace Vitamedica.Models.Reembolso
{
    public class ListConceptoFactElectResumeViewModel
    {
        public List<ConceptoFactElectResumeViewModel> List { get; set; }
    }
}
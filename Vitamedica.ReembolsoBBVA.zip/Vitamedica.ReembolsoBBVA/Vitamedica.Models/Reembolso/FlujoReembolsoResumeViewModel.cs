﻿namespace Vitamedica.Models.Reembolso
{
    public class FlujoReembolsoResumeViewModel
    {
        public int IdFujo { get; set; }

        public string Flujo { get; set; }
    }
}
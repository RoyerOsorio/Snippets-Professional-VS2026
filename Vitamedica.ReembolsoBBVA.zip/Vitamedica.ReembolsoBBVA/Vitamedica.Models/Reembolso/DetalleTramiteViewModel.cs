﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Models.Reembolso;

namespace Vitamedica.Models.Reembolso
{
    public class DetalleTramiteViewModel
    {
        public DetalleReembolsoResumeViewModel Detalle { get; set; }
        public DocumentosTramiteViewModel DocumentosTramite { get; set; }
        public List<NotaResumeViewModel> Notas { get; set; }
        public List<EstadoResumeViewModel> ListaEstado { get; set; }

        public List<NotaLlamadaViewModel> ListaNotas { get; set; }

        public bool EsIncompleto { get; set; }

        public int IdEstatus { get; set; }

        public bool ShowDisponible { get; set; }
    }
}

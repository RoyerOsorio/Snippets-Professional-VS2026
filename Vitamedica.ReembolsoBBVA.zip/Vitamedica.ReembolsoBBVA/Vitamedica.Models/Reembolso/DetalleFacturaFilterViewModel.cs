﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class DetalleFacturaFilterViewModel
    {
        public int IdDetalleFactura { get; set; }

        public int IdDocumento { get; set; }

        public DetalleFacturaFilterType FilterType { get; set; }
    }
}
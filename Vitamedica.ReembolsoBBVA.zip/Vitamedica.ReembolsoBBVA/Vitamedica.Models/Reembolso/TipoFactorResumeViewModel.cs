﻿namespace Vitamedica.Models.Reembolso
{
    public class TipoFactorResumeViewModel
    {
        public string Descripcion { get; set; }
    }
}
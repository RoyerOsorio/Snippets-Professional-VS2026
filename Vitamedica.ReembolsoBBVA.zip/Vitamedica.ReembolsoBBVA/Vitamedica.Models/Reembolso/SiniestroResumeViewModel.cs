﻿namespace Vitamedica.Models.Reembolso
{
    public class SiniestroResumeViewModel
    {
        public int IdReembolso { get; set; }

        public string Siniestro { get; set; }
    }
}
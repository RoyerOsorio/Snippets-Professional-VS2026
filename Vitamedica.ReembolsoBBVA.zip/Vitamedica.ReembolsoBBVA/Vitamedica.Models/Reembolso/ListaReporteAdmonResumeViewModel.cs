﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListaReporteAdmonResumeViewModel : MensajeViewModel
    {
        public List<ReporteAdmonResumeViewModel> Lista { get; set; }
    }
}
﻿using System.Collections.Generic;

namespace Vitamedica.Models.Reembolso
{
    public class ListTramitesRezagadosResumeViewModel : Shared.MensajeViewModel
    {
        public List<TramitesRezagadosResumeViewModel> Lista { get; set; }
    }
}
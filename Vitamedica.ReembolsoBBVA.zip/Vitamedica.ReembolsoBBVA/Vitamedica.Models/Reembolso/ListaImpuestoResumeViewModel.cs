﻿using System.Collections.Generic;

namespace Vitamedica.Models.Reembolso
{
    public class ListaImpuestoResumeViewModel : Shared.MensajeViewModel
    {
        public List<ImpuestoResumeViewModel> Lista { get; set; }
    }
}
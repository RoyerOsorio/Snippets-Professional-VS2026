﻿using System;


namespace Vitamedica.Models.Reembolso
{
    public class DatosCuentaBancariaClabeViewModel
    {
        public int IdCuenta { get; set; }
        public string Poliza { get; set; }

        public string Clabe { get; set; }

        public string Nombre { get; set; }

        public string Meme_Ck { get; set; }

        public bool NuevaCuenta { get; set; }

        public DateTime Fecha { get; set; }

        public string Correo { get; set; }
    }
}
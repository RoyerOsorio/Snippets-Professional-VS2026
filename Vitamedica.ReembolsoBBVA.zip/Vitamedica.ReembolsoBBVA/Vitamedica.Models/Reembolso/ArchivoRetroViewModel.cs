﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class ArchivoRetroViewModel : ICloneable
    {
        public int IdCuenta { get; set; }
        public string CuentaOrigen { get; set; }
        public string Fecha { get; set; }
        public string NombreCuenta { get; set; }
        public string Guardian { get; set; }
        public int? IdEstatus { get; set; }
        public string Estatus { get; set; }
        public bool Validado { get; set; }
        public string Observaciones { get; set; }
        public bool ClabeRepetida { get; set; }
        public bool CuentaModificada { get; set; }
        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
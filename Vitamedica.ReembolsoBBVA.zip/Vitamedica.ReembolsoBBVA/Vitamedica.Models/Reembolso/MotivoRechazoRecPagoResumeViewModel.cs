﻿namespace Vitamedica.Models.Reembolso
{
    public class MotivoRechazoRecPagoResumeViewModel
    {
        public int IdRecepcion { get; set; }

        public int IdMotivo { get; set; }
    }
}
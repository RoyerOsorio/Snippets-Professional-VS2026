﻿namespace Vitamedica.Models.Reembolso
{
    public class GuardianResumeViewModel : Shared.MensajeViewModel
    {
        public string Nombre { get; set; }

        public string ApellidoPaterno { get; set; }

        public string ApellidoMaterno { get; set; }
    }
}
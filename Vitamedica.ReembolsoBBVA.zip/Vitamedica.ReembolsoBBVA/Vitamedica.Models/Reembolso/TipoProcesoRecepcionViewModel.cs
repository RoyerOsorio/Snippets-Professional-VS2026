﻿

namespace Vitamedica.Models.Reembolso
{
    public class TipoProcesoRecepcionViewModel
    {
        public string Id { get; set; }
        public string TipoProceso { get; set; }
    }
}
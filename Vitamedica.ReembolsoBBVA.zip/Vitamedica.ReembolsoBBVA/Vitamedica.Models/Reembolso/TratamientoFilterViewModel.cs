﻿namespace Vitamedica.Models.Reembolso
{
    public class TratamientoFilterViewModel
    {
        public string IdTran { get; set; }

        public string Tratamiento { get; set; }
    }
}
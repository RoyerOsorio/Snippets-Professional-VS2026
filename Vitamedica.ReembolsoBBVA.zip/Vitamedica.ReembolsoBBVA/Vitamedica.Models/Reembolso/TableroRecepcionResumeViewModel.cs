﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Vitamedica.Models.Reembolso
{
    public class TableroRecepcionResumeViewModel
    {
        public int IdTramite { get; set; }

        public string Folio { get; set; }

        public string Cliente { get; set; }

        public string Proveedor { get; set; }

        public string Remesa { get; set; }

        public string Contrarecibo { get; set; }

        public string Grupo { get; set; }

        public int Reclamaciones { get; set; }

        public decimal Monto { get; set; }

        public DateTime Fecha { get; set; }

        [Display(Name = "Folio Fiscal")]
        public string FolioFiscal { get; set; }

        [Display(Name = "Tipo Proceso")]
        public string TipoProceso { get; set; }

        [Display(Name = "Estación")]
        public string Estacion { get; set; }

        public string Estatus { get; set; }

        public int TipoUsuario { get; set; }

        [Display(Name = "Contrarecibos")]
        public int NumeroContrarecibos { get; set; }

        [Display(Name = "Reclamaciones")]
        public int NumeroReclamaciones { get; set; }

        public string FechaPago { get; set; }

        public string FechaContable { get; set; }

        public string PorcentajePago { get; set; }

        public string PorcentajeContable { get; set; }
    }
}
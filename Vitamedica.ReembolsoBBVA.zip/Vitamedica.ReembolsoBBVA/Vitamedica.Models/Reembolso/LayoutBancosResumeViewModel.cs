﻿namespace Vitamedica.Models.Reembolso
{
    public class LayoutBancosResumeViewModel
    {
        public string Nombre { get; set; }

        public string Banco { get; set; }

        public string Clabe { get; set; }
    }
}
﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class ComentarioFilterViewModel
    {
        public int IdComentario { get; set; }

        public int IdReembolso { get; set; }

        public string Usuario { get; set; }

        public ComentarioFilterType FilterType { get; set; }
    }
}
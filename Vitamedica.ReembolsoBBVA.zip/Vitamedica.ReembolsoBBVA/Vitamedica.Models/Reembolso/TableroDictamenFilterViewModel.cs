﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class TableroDictamenFilterViewModel
    {
        public int? IdReembolso { get; set; }

        [Display(ResourceType = typeof(ReembolsoGModelo.Resource.Label.Tablero1), Name = "Nomina")]
        public string Nomina { get; set; }

        [Display(ResourceType = typeof(ReembolsoGModelo.Resource.Label.Tablero1), Name = "FechaInicio")]
        [DisplayFormat(ApplyFormatInEditMode = true, ConvertEmptyStringToNull = true, DataFormatString = "{0:dd/MM/yyyy}")]
        [DataType(DataType.Date)]
        public DateTime? FechaInicio { get; set; }

        [Display(ResourceType = typeof(ReembolsoGModelo.Resource.Label.Tablero1), Name = "FechaFin")]
        [DisplayFormat(ApplyFormatInEditMode = true, ConvertEmptyStringToNull = true, DataFormatString = "{0:dd/MM/yyyy}")]
        [DataType(DataType.Date)]
        public DateTime? FechaFin { get; set; }

        public int? IdFlujo { get; set; }

        public string Folio { get; set; }

        public int? NumBeneficiario { get; set; }

        public int? IdEstatus { get; set; }

        public int? DictamenMedico { get; set; }

        public string Rol { get; set; }

        public int? IdMotivo { get; set; }

        [Display(ResourceType = typeof(ReembolsoGModelo.Resource.Label.Tablero1), Name = "FacturaUuid")]
        [DisplayName("Folio FIscal")]
        public string FacturaUuid { get; set; }

        [Display(ResourceType = typeof(ReembolsoGModelo.Resource.Label.Tablero1), Name = "CodEstado")]
        public string CodEstado { get; set; }

        [Display(ResourceType = typeof(ReembolsoGModelo.Resource.Label.Tablero1), Name = "CodMunicipio")]
        public string CodMunicipio { get; set; }

        public string Cliente { get; set; }

        public TableroDictamenFilterType FilterType { get; set; }

        public bool SeCarganFiltros { get; set; }
    }
}
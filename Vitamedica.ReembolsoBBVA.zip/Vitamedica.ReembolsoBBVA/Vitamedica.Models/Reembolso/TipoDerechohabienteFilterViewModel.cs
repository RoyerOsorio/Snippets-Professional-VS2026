﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class TipoDerechohabienteFilterViewModel
    {
        public int IdTipoDerechohabiente { get; set; }

        //public TipoDerechohabienteFilterType FilterType { get; set; }
    }
}
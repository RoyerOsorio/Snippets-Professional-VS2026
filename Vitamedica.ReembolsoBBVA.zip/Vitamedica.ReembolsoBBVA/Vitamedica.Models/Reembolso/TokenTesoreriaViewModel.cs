﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class TokenTesoreriaViewModel
    {
        public int IdToken { get; set; }

        public int IdCuenta { get; set; }

        public string Token { get; set; }

        public bool Valido { get; set; }
    }
}
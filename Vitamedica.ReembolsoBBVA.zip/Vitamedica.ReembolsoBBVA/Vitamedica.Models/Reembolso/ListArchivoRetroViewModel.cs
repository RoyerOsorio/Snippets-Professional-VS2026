﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class ListArchivoRetroViewModel
    {
        public List<ArchivoRetroViewModel> Lista;


        public ListArchivoRetroViewModel()
        {
            Lista = new List<ArchivoRetroViewModel>();
        }
    }
}
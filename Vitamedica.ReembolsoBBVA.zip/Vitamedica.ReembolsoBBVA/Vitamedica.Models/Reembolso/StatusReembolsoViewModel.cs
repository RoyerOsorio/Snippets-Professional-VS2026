﻿namespace Vitamedica.Models.Reembolso
{
    public class StatusReembolsoViewModel
    {
        public int IdStatus { get; set; }

        public string Status { get; set; }
    }
}
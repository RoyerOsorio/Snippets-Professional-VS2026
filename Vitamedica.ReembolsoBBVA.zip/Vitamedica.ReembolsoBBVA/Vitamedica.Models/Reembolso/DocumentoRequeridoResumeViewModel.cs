﻿namespace Vitamedica.Models.Reembolso
{
    public class DocumentoRequeridoResumeViewModel
    {
        public int IdDocumentoRequerido { get; set; }

        public string Documento { get; set; }

        public int MaxPermitido { get; set; }

        public bool EsFactura { get; set; }

        public string Observaciones { get; set; }

        public int IdMotivoReembolso { get; set; }
        public bool Obligatorio { get; set; }
    }
}
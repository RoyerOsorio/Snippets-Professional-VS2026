﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class CuentaBancariaNominaViewModel
    {
        public string TipoMovimiento { get; set; }

        public string Identificador { get; set; }

        public string Banco { get; set; }

        public string Clabe { get; set; }

        public DateTime FechaInicio { get; set; }

        public DateTime FechaTermino { get; set; }

        public string Usuario { get; set; }
    }
}
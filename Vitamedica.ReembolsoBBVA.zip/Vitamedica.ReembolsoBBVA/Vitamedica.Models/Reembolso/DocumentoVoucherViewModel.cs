﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class DocumentoVoucherViewModel
    {
        public int IdCuenta { get; set; }

        public string Ruta { get; set; }
   
        public int? IdMotivo { get; set; }
     
        public string Observaciones { get; set; }
    }
}
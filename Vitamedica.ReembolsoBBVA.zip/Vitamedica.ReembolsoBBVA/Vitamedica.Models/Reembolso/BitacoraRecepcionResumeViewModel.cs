﻿namespace Vitamedica.Models.Reembolso
{
    public class BitacoraRecepcionResumeViewModel
    {
        public int IdRecepcion { get; set; }

        public int IdFlujo { get; set; }

        public string Usuario { get; set; }

        public int IdEstatus { get; set; }
    }
}
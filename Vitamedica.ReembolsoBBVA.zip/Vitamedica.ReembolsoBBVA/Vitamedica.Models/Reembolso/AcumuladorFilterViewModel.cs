﻿using System;
using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class AcumuladorFilterViewModel
    {
        public string Poliza { get; set; }

        public DateTime Fecha { get; set; }

        public AcumuladorFilterType FilterType { get; set; }
    }
}
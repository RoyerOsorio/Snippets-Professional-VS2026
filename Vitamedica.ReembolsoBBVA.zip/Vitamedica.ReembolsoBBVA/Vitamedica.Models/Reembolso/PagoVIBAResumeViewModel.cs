﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class PagoVIBAResumeViewModel
    {
        public string FolioReembolso { get; set; }

        public DateTime? FechaPago { get; set; }

        public DateTime? FechaContable { get; set; }

        public string Estatus { get; set; }

        public string Usuario { get; set; }

        public string TipoUsuario { get; set; }

        public string Nomina { get; set; }
    }
}
﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class ReporteAdmonDHBResumeViewModel
    {
        public string Folio { get; set; }

        public string UUID { get; set; }

        public string Grupo { get; set; }

        public string Cliente { get; set; }

        public string Nomina { get; set; }

        public string Titular { get; set; }

        public string Concepto { get; set; }

        public decimal MontoConcepto { get; set; }

        public decimal MontoNoCubierto { get; set; }

        public decimal MontoAutorizado { get; set; }

        public DateTime? FechaPago { get; set; }

        public string RFC { get; set; }
        public string Poliza { get; set; }
    }
}
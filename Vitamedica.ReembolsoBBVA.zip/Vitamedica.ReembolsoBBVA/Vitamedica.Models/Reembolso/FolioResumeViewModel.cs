﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class FolioResumeViewModel
    {
        public int IdReembolso { get; set; }

        public string Folio { get; set; }

        public decimal Monto { get; set; }

        public string Correo { get; set; }

        public string Nombre { get; set; }

        public string Firma { get; set; }

        public DateTime? FechaPago { get; set; }

        public string FolioVIBA { get; set; }
    }
}
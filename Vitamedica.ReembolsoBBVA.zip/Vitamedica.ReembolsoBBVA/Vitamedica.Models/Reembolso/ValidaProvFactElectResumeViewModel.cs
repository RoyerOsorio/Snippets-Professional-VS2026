﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class ValidaProvFactElectResumeViewModel
    {
        public string RfcEmisor { get; set; }

        public DateTime? FechaFacturacion { get; set; }
    }
}
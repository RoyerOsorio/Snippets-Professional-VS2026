﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class MotivoDocumentoFilterViewModel
    {
        public int IdMotivoReembolso { get; set; }

        //public int IdTipoDerechohabiente { get; set; }

        public MotivoDocumentoFilterType FilterType { get; set; }
    }
}
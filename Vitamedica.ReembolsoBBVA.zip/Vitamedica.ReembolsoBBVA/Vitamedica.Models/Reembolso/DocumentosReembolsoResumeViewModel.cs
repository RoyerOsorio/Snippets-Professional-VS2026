﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class DocumentosReembolsoResumeViewModel
    {
        public int IdDocumentoRequerido { get; set; }

        public string Contrarecibo { get; set; }

        public DateTime Fecha { get; set; }

        public decimal Monto { get; set; }

        public int IdDocumento { get; set; }

        public string Url { get; set; }

        public string UUID { get; set; }

        public int IdReembolso { get; set; }

        public string Documento { get; set; }

        public bool EsFactura { get; set; }

        public string Observaciones { get; set; }

        public string Nota { get; set; }

        public string NombreArchivo { get; set; }

        public bool Aprobado { get; set; }

        public string Emisor { get; set; }

        public int IdTipoRechazo { get; set; }

        public string Rechazo { get; set; }

        public DateTime? FechaEmision { get; set; }

        public int IdMotivoReembolso { get; set; }

        public int IdMotivoConsulta { get; set; }
        public string Moneda { get; set; }
    }
}
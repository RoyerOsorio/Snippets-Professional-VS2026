﻿namespace Vitamedica.Models.Reembolso
{
    public class TramiteRelacionadoResumeViewModel
    {
        public int IdTramite { get; set; }

        public string Folio { get; set; }

        public int IdFlujo { get; set; }

        public string MotivoReembolso { get; set; }

        public string FolioGrupo { get; set; }
    }
}
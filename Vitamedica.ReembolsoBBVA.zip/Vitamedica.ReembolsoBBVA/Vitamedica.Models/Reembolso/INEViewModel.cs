﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Models.Reembolso
{
    public class INEViewModel
    {
      
        
        public int IdIne { get; set; }
        
        public string Poliza { get; set; }
        
        public string PathFile { get; set; }
        
        public bool Activo { get; set; }
        
        public string Nombre { get; set; }
        
        public bool CuentaNueva { get; set; }
        
        public DateTime FechaRegistro { get; set; }
        
        public DateTime? FechaModificacion { get; set; }
        public string UsuarioEvaluador { get; set; }
        public string UsuarioCarga { get; set; }
        public DateTime? FechaEvaluacion { get; set; }
    }
}

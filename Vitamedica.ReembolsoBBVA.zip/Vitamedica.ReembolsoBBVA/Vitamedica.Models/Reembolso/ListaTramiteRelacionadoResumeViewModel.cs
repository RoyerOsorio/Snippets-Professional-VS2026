﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListaTramiteRelacionadoResumeViewModel : MensajeViewModel
    {
        public List<TramiteRelacionadoResumeViewModel> Lista { get; set; }
    }
}
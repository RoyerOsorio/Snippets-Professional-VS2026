﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class CifraMonedaResumeViewModel : Vitamedica.Models.Shared.MensajeViewModel
    {
        public decimal Monto { get; set; }

        public string Moneda { get; set; }

        public int NoBenef { get; set; }

        public decimal MontoPagado { get; set; }

        public DateTime FechaEmision { get; set; }
    }
}
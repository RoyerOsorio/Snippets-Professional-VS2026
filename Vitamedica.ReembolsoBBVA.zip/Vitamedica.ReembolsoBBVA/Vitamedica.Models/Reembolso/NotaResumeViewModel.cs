﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class NotaResumeViewModel
    {
        public string Descripcion { get; set; }

        public string Usuario { get; set; }

        public DateTime Fecha { get; set; }

        public string TipoUsuario { get; set; }

        public string Estatus { get; set; }

        public string Flujo { get; set; }

        public bool Bitacora { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Models.Reembolso.UI.Documentos
{
    public class DocumentosPorCobertura
    {

        public DocumentosPorCobertura()
        {
            DocumentosRequeridos = new List<DocumentoRequeridoResumeViewModel>();
        }

        public int IdMotivoReembolso { get; set; }

        public string Motivo { get; set; }

        //public bool EsDental { get; set; }

        //public string Indicaciones { get; set; }

        public decimal Cobertura { get; set; }

        public decimal Coaseguro { get; set; }

        public decimal LimiteEvento { get; set; }

        public decimal Acumulado { get; set; }

        public string Moneda { get; set; }

        public decimal Deducible { get; set; }

        public string ClaveConfig { get; set; }

        public decimal MontoRealCob { get; set; }

        public List<DocumentoRequeridoResumeViewModel> DocumentosRequeridos { get; set; }
    }
}

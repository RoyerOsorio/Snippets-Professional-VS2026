﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Vitamedica.Models.Reembolso.UI
{
    public class IdentificacionOficialFilterUIModel
    {

        private bool ActivoField;

        private System.Nullable<System.DateTime> FechaModificacionField;

        private System.Nullable<System.DateTime> FechaRegistroField;

        private Vitamedica.ReembolsoGModelo.Model.Filter.IdentificacionOficialFilterType FilterTypeField;

        private System.Nullable<int> IdIDentificacionOficialField;

        private string NombreField;

        private bool NuevaINEField;

        private string PolizaField;
        private string StatusField;

        private static SelectList ListEstatusField;



        public IdentificacionOficialFilterUIModel()
        {
            ListEstatusField = new SelectList(
                new List<SelectListItem>
                {
                    new SelectListItem { Selected = false, Text = "Nuevo Documento Cargado", Value = "3"},
                    new SelectListItem { Selected = false, Text = "Aprobado", Value = "1"},
                    new SelectListItem { Selected = false, Text = "Rechazado", Value = "0"},
                }, "Value", "Text",3);
        }


        public string status
        {
            get
            {
                return this.StatusField;
            }
            set
            {
                this.StatusField = value;
            }
        }

        public bool Activo
        {
            get
            {
                return this.ActivoField;
            }
            set
            {
                this.ActivoField = value;
            }
        }

        [Display( Name = "Fecha Modificación")]
        [DisplayFormat(ApplyFormatInEditMode = true, ConvertEmptyStringToNull = true, DataFormatString = "{0:dd/MM/yyyy}")]
        [DataType(DataType.Date)]
        public System.Nullable<System.DateTime> FechaModificacion
        {
            get
            {
                return this.FechaModificacionField;
            }
            set
            {
                this.FechaModificacionField = value;
            }
        }

        [Display(Name = "Fecha Inicio")]
        [DisplayFormat(ApplyFormatInEditMode = true, ConvertEmptyStringToNull = true, DataFormatString = "{0:dd/MM/yyyy}")]
        [DataType(DataType.Date)]
        public System.Nullable<System.DateTime> FechaRegistro
        {
            get
            {
                return this.FechaRegistroField;
            }
            set
            {
                this.FechaRegistroField = value;
            }
        }


        public Vitamedica.ReembolsoGModelo.Model.Filter.IdentificacionOficialFilterType FilterType
        {
            get
            {
                return this.FilterTypeField;
            }
            set
            {
                this.FilterTypeField = value;
            }
        }

        
        public System.Nullable<int> IdIDentificacionOficial
        {
            get
            {
                return this.IdIDentificacionOficialField;
            }
            set
            {
                this.IdIDentificacionOficialField = value;
            }
        }

        
        public string Nombre
        {
            get
            {
                return this.NombreField;
            }
            set
            {
                this.NombreField = value;
            }
        }

        
        public bool NuevaINE
        {
            get
            {
                return this.NuevaINEField;
            }
            set
            {
                this.NuevaINEField = value;
            }
        }

        [Display(Name = "Póliza")]
        public string Poliza
        {
            get
            {
                return this.PolizaField;
            }
            set
            {
                this.PolizaField = value;
            }
        }

        public SelectList ListEstatus
        {
            get
            {
                return ListEstatusField;
            }
        }


    }
}




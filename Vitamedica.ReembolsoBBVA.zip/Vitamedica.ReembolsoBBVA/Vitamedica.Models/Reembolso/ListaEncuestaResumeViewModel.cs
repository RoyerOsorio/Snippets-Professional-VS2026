﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListaEncuestaResumeViewModel : MensajeViewModel
    {
        public List<EncuestaResumeViewModel> Lista { get; set; }
    }
}
﻿using System.Collections.Generic;

namespace Vitamedica.Models.Reembolso
{
    public class ListReembolsoDocumentoViewModel
    {
        public List<ReembolsoDocumentoViewModel> List { get; set; }
    }
}
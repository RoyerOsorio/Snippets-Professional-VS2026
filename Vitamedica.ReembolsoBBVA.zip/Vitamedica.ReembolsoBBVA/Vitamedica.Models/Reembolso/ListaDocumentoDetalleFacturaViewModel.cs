﻿using System.Collections.Generic;

namespace Vitamedica.Models.Reembolso
{
    public class ListaDocumentoDetalleFacturaViewModel : Shared.MensajeViewModel
    {
        public List<DocumentosReembolsoResumeViewModel> ListaDocumento { get; set; }

        public List<DetalleFacturaViewModel> ListaDetalleFactura { get; set; }
    }
}
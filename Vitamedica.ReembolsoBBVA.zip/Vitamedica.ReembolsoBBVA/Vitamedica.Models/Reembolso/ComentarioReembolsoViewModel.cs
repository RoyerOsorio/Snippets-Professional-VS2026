﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class ComentarioReembolsoViewModel
    {
        public int IdComentairo { get; set; }

        public string Comentario { get; set; }

        public string Usuario { get; set; }

        public int IdReembolso { get; set; }

        public DateTime FechaRegistro { get; set; }
    }
}
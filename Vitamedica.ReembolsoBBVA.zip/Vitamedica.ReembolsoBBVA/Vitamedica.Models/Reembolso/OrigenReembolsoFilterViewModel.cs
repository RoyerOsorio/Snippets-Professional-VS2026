﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class OrigenReembolsoFilterViewModel
    {
        public int IdOrigen { get; set; }

        public OrigenReembolsoFilterType FilterType { get; set; }
    }
}
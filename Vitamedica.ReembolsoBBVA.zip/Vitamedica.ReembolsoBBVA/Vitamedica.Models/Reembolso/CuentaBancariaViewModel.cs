﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class CuentaBancariaViewModel
    {
        public int IdCuenta { get; set; }
        public string Banco { get; set; }
        public string ClaveBanco { get; set; }
        public string Poliza { get; set; }
        public string Clabe { get; set; }
        public string Nombre { get; set; }
        public string Meme_Ck { get; set; }
        public bool CuentaNueva { get; set; }
        public string Correo { get; set; }
        public bool EsActualizacion { get; set; }
        public bool CuentaActualizadaMismoDia { get; set; }
    }
}
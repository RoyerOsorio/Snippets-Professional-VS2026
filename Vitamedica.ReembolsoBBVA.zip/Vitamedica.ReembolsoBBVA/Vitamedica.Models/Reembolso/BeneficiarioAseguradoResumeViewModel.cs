﻿namespace Vitamedica.Models.Reembolso
{
    public class BeneficiarioAseguradoResumeViewModel
    {
        public string FolioRecibo { get; set; }

        public int MEME_CK { get; set; }

        public string Nombre { get; set; }

        public string APaterno { get; set; }

        public string AMaterno { get; set; }

        public string MEME_REL { get; set; }

        public string Parentesco { get; set; }

        public string Usuario { get; set; }
    }
}
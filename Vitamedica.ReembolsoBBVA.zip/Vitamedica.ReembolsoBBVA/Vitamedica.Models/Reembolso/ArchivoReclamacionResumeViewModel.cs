﻿namespace Vitamedica.Models.Reembolso
{
    public class ArchivoReclamacionResumeViewModel
    {
        public int IdReclamacion { get; set; }

        public string Url { get; set; }

        public string Url2 { get; set; }

        public string Url3 { get; set; }
    }
}
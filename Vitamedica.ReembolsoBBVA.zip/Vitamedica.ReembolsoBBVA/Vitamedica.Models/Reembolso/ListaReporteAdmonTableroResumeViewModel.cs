﻿using System.Collections.Generic;

namespace Vitamedica.Models.Reembolso
{
    public class ListaReporteAdmonTableroResumeViewModel : Shared.MensajeViewModel
    {
        public List<ReporteAdmonTableroResumeViewModel> Lista { get; set; }
    }
}
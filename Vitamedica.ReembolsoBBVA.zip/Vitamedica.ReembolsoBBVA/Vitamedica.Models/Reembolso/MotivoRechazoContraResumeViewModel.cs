﻿namespace Vitamedica.Models.Reembolso
{
    public class MotivoRechazoContraResumeViewModel
    {
        public int IdContrarecibo { get; set; }

        public int IdMotivo { get; set; }
    }
}
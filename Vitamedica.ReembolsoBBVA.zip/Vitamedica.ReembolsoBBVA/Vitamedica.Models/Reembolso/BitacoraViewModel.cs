﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class BitacoraViewModel
    {
        public int IdBitacora { get; set; }

        public int IdReembolso { get; set; }

        public int IdFlujo { get; set; }

        public DateTime Fecha { get; set; }

        public string Usuario { get; set; }

        public string Comentario { get; set; }

        public int IdStatus { get; set; }

        public string TipoUsuario { get; set; }
    }
}
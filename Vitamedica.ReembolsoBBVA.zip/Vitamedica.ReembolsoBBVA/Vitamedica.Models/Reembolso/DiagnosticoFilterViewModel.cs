﻿namespace Vitamedica.Models.Reembolso
{
    public class DiagnosticoFilterViewModel
    {
        public string IdDiag { get; set; }

        public string Diagnostico { get; set; }
    }
}
﻿using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class MotivoConsultaViewModel : MensajeViewModel
    {
        public int IdConsulta { get; set; }

        public string Descripcion { get; set; }
    }
}
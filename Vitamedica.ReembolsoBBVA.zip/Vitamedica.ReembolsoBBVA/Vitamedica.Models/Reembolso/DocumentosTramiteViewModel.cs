﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Models.Reembolso
{
    public class DocumentosTramiteViewModel
    {
        public ListDocumentosReembolsoResumeViewModel Documentos { get; set; }
        public List<DetalleFacturaViewModel> Conceptos { get; set; }
        public List<DocumentoRequeridoResumeViewModel> DocRequeridos { get; set; }
        public List<MotivoReembolsoViewModel> ListaMotivoReembolso { get; set; }

        public int IdMotivoReembolsoAux { get; set; }

        public decimal LimiteEvento { get; set; }
        public decimal MaximoBeneficio { get; set; }
        public decimal Coaseguro { get; set; }
        public decimal Acumulado { get; set; }
    }
}

﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListaPendienteResumeViewModel : MensajeViewModel
    {
        public List<PendienteResumeViewModel> Lista { get; set; }
    }
}
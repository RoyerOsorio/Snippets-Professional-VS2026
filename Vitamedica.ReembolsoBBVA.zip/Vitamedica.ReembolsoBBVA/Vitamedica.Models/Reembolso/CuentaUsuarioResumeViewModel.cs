﻿namespace Vitamedica.Models.Reembolso
{
    public class CuentaUsuarioResumeViewModel
    {
        public string Titular { get; set; }

        public string TipoPago { get; set; }

        public string Cuenta { get; set; }

        public string Clabe { get; set; }
    }
}
﻿namespace Vitamedica.Models.Reembolso
{
    public class EspecialidadViewModel
    {
        public int IdEspecialidad { get; set; }

        public string Descripcion { get; set; }
    }
}
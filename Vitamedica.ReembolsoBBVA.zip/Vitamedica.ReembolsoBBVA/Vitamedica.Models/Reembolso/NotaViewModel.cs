﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class NotaViewModel
    {
        public int IdNota { get; set; }

        public string Descripcion { get; set; }

        public int IdReembolso { get; set; }

        public string Usuario { get; set; }

        public string TipoUsuario { get; set; }

        public int IdFlujo { get; set; }

        public DateTime FechaCreacion { get; set; }
    }
}
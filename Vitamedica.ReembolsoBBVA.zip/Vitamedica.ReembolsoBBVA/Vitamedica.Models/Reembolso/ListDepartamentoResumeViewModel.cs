﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;


namespace Vitamedica.Models.Reembolso
{
    public class ListDepartamentoResumeViewModel : MensajeViewModel
    {
        public List<DepartamentoResumeViewModel> Lista { get; set; }
    }
}
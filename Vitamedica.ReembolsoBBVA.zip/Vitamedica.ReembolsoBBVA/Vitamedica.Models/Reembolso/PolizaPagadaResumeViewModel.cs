﻿

namespace Vitamedica.Models.Reembolso
{
    public class PolizaPagadaResumeViewModel
    {
        public string Folio { get; set; }
        public string Motivo { get; set; }
        public string Concepto { get; set; }
        public string ICD { get; set; }
    }
}

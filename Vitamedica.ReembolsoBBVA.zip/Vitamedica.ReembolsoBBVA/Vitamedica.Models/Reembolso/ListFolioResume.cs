﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListFolioResume : MensajeViewModel
    {
        public List<FolioResumeViewModel> Lista { get; set; }
    }
}
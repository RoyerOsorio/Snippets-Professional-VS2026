﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListFechaEstadisResumeViewModel : MensajeViewModel
    {
        public List<FechaEstadisResumeViewModel> Lista { get; set; }

        public bool EsRegistro { get; set; }

        public bool EsBloqueado { get; set; }

        public int Year { get; set; }
    }
}
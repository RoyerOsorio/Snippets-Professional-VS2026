﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class EncuestaResumeViewModel
    {
        public string Elegibilidad { get; set; }

        public string Nomina { get; set; }

        public string Titular { get; set; }

        public string Plus { get; set; }

        public string CentroRegional { get; set; }

        public string Beneficiario { get; set; }

        public string Parentesco { get; set; }

        public string Folio { get; set; }

        public DateTime FechaFinalizado { get; set; }

        public string FechaFinalizadoAux { get; set; }

        public string FechaRegistroAux { get; set; }

        public string FechaPagoAux { get; set; }

        public string Grupo { get; set; }

        public string GrupoCliente { get; set; }

        public string Telefono { get; set; }

        public string Estado { get; set; }

        public string Municipio { get; set; }

        public string Origen { get; set; }

        public DateTime? FechaPago { get; set; }

        public decimal MontoReclamado { get; set; }

        public decimal MontoAutorizado { get; set; }

        public DateTime FechaRegistro { get; set; }

        public string TipoServicio { get; set; }

        public string Especialidad { get; set; }

        public int IdOrigen { get; set; }
    }
}
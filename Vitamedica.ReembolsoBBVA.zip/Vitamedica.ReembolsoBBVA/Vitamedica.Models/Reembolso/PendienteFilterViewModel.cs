﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class PendienteFilterViewModel
    {
        public int Dictamen { get; set; }

        public string Grupo { get; set; }

        public PendienteFilterType FilterType { get; set; }
    }
}
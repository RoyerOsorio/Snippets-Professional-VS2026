﻿namespace Vitamedica.Models.Reembolso
{
    public class MotivoRechazoViewModel
    {
        public int IdMotivo { get; set; }

        public string Descripcion { get; set; }

        public int RolMotivo { get; set; }

        public int IdTipoRechazo { get; set; }

        public string Rechazo { get; set; }

        public string Mensaje { get; set; }
    }
}
﻿using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class NominaGMMResumeViewModel : MensajeViewModel
    {
        public int IdNomina { get; set; }

        public string Nomina { get; set; }

        public string Nombre { get; set; }

        public bool GMM { get; set; }

        public bool SaludBBVA { get; set; }
    }
}
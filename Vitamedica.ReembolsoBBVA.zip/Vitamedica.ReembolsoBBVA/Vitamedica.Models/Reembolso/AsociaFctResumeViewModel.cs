﻿namespace Vitamedica.Models.Reembolso
{
    public class AsociaFctResumeViewModel
    {
        public string TipoAsocia { get; set; }

        public string NoAsocia { get; set; }

        public string Contrarecibo { get; set; }

        public string PrprId { get; set; }
    }
}
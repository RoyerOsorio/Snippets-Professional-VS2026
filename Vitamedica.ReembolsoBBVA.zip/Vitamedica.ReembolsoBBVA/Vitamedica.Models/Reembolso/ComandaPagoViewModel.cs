﻿namespace Vitamedica.Models.Reembolso
{
    public class ComandaPagoViewModel
    {
        public int IdComandaPago { get; set; }

        public string UrlComanda { get; set; }

        public string Comanda { get; set; }
    }
}
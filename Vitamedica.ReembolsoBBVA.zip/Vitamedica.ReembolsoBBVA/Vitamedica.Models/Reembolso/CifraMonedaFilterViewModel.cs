﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class CifraMonedaFilterViewModel
    {
        public int IdReembolso { get; set; }

        public int IdDocumento { get; set; }

        public int IdDetalleFactura { get; set; }

        public int IdMotivo { get; set; }

        public CifraMonedaFilterType FilterType { get; set; }
    }
}
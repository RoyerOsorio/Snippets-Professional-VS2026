﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class FactElectResumeViewModel
    {
        public string IdProveedor { get; set; }

        public string RfcEmisor { get; set; }

        public string Serie { get; set; }

        public string Folio { get; set; }

        public string RfcReceptor { get; set; }

        public decimal MontoFactura { get; set; }

        public int LineaNegocio { get; set; }

        public string IdAseguradora { get; set; }

        public string Usuario { get; set; }

        public DateTime? FechaFacturacion { get; set; }

        public DateTime? FechaEnvio { get; set; }

        public DateTime? FechaValidacion { get; set; }

        public decimal SubTotal { get; set; }

        public DateTime? FechaTimbrado { get; set; }

        public string UUID { get; set; }

        public decimal Descuento { get; set; }

        public string RazonSocial { get; set; }
    }
}
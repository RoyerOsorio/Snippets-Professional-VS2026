﻿namespace Vitamedica.Models.Reembolso
{
    public class CFDIRelacionadoResumeViewModel
    {
        public string Contrarecibo { get; set; }

        public string CfdiRelacionados { get; set; }
    }
}
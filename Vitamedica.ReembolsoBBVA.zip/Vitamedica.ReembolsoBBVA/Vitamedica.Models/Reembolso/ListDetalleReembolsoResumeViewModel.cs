﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListDetalleReembolsoResumeViewModel
    {
        public List<DetalleReembolsoResumeViewModel> Lista { get; set; }

        public PaginationViewModel Pagination { get; set; }
    }
}

﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class FechaEstadisResumeViewModel
    {
        public DateTime? Fecha { get; set; }

        public bool SeEjecuto { get; set; }

        public string NombreMes { get; set; }

        public int NumeroMes { get; set; }

        public int CantidadRegistros { get; set; }

        public DateTime? FechaInicioProceso { get; set; }

        public DateTime? FechaFinProceso { get; set; }
    }
}
﻿namespace Vitamedica.Models.Reembolso
{
    public class ConceptoFactElectResumeViewModel
    {
        public string Cantidad { get; set; }

        public string Unidad { get; set; }

        public string Descripcion { get; set; }

        public decimal ValorUnitario { get; set; }

        public decimal Importe { get; set; }

        public string ClaveProductoServicio { get; set; }

        public string ClaveUnidad { get; set; }

        public string Contrarecibo { get; set; }

        //Propiedades complementarias
        public decimal Descuento { get; set; }

        public decimal Traslado { get; set; }

        public decimal Retencion { get; set; }
    }
}
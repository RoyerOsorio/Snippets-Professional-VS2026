﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class ProductoServicioResumeViewModel
    {
        public DateTime FechaTimbrado { get; set; }

        public string Productos { get; set; }
    }
}
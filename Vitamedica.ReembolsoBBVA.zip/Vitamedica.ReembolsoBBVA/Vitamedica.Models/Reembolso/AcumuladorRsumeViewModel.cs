﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class AcumuladorRsumeViewModel
    {
        public string Poliza { get; set; }
        public int NumBenef { get; set; }
        public decimal MontoCifra { get; set; }
        public DateTime FechaInicioVigencia { get; set; }
        public DateTime FechaFinVigencia { get; set; }
        public decimal MontoReclamado { get; set; }
        public string MotivoReembolso { get; set; }
        public int IdMotivoReembolso { get; set; }
        public decimal? MontoAutorizado { get; set; }
    }
}
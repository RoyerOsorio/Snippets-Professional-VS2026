﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class TokenFilterTesoreriaViewModel
    {
        public int IdToken { get; set; }

        public string Token { get; set; }
    }
}
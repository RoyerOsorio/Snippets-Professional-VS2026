﻿namespace Vitamedica.Models.Reembolso
{
    public class DetalleFacturaResumeViewModel
    {
        public bool? Aprobado { get; set; }

        public decimal MontoAutorizado { get; set; }

        public decimal MontoConcepto { get; set; }

        public decimal MontoPagado { get; set; }

        public decimal MontoSugerido { get; set; }

        public int IdDetalleFactura { get; set; }

        public int IdMotivo { get; set; }

        public int Cantidad { get; set; }

        public decimal ValorUnitario { get; set; }

        public decimal MontoDolar { get; set; }
    }
}
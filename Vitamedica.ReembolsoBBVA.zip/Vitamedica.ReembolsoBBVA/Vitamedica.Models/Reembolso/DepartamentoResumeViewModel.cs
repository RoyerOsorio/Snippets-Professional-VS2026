﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class DepartamentoResumeViewModel
    {
        public string Departamento { get; set; }
    }
}
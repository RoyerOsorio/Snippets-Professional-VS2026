﻿namespace Vitamedica.Models.Reembolso
{
    public class MotivoRechazoReclamacionResumeViewModel
    {
        public int IdMotivo { get; set; }

        public int IdReclamacion { get; set; }

        public int IdEstatus { get; set; }
    }
}
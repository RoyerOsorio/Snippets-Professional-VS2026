﻿namespace Vitamedica.Models.Reembolso
{
    public class TipoServicioViewModel
    {
        public int IdTipoServicio { get; set; }

        public string Descripcion { get; set; }
    }
}
﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListaContrareciboResumeViewModel : MensajeViewModel
    {
        public List<ContrareciboViewModel> Lista { get; set; }
    }
}
﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListLayoutSINBAResumeViewModel : MensajeViewModel
    {
        public List<LayoutSINBAResumeViewModel> List { get; set; }
    }
}
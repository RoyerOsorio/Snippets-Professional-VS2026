﻿namespace Vitamedica.Models.Reembolso
{
    public class DocAdicionalesViewModel
    {
        public int IdReembolso { get; set; }

        public int IdEstatus { get; set; }

        public int IdDocRequerido { get; set; }

        public string Usuario { get; set; }
    }
}
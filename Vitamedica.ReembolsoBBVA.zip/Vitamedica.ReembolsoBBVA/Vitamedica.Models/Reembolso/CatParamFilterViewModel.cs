﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class CatParamFilterViewModel
    {
        public string Prefijo { get; set; }

        public int IdParam { get; set; }

        public CatParamFilterType FilterType { get; set; }
    }
}
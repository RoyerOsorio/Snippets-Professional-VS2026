﻿namespace Vitamedica.Models.Reembolso
{
    public class ReembolsoCPResumeViewModel
    {
        public int IdReembolso { get; set; }

        public string CodEstado { get; set; }

        public string CodMunicipio { get; set; }

        public string Url { get; set; }
    }
}
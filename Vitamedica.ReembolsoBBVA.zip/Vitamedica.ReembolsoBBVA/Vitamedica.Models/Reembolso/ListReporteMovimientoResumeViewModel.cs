﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListReporteMovimientoResumeViewModel : MensajeViewModel
    {
        public List<ReporteMovimientoResumeViewModel> Lista { get; set; }

        public ListFechaEstadisResumeViewModel Fechas { get; set; }
    }
}
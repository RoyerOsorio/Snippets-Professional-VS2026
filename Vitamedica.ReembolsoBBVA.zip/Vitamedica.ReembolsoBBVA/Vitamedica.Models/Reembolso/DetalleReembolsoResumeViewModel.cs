﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Vitamedica.Models.Reembolso
{
    public class DetalleReembolsoResumeViewModel
    {
        [Display(Name ="Nómina")]
        public string Nomina { get; set; }

        public string Beneficiario { get; set; }

        public string Parentesco { get; set; }

        public string Grupo { get; set; }

        public string IdDerechohabiente { get; set; }

        public string Correo { get; set; }

        public string NoLlamada { get; set; }

        public string Titular { get; set; }

        public int NumBeneficiario { get; set; }

        public int IdReembolso { get; set; }

        public string Folio { get; set; }

        public int IdMotivoReembolso { get; set; }

        public string MotivoReembolso { get; set; }

        public int IdFlujo { get; set; }

        public int IdOrigen { get; set; }

        public string Origen { get; set; }

        public int IdConsulta { get; set; }

        public string Consulta { get; set; }

        public int IdMotivoRechazo { get; set; }

        public string MotivoRechazo { get; set; }

        public bool EsDental { get; set; }

        public DateTime? FechaInicial { get; set; }

        public int IdTipoRechazo { get; set; }

        public string ctaClabe { get; set; }

        public string NoTelefono { get; set; }

        public DateTime? FechaPago { get; set; }

        public DateTime? FechaContable { get; set; }

        public DateTime FechaRegistro { get; set; }

        public int Edad { get; set; }

        public string Sexo { get; set; }

        public string SubGrupo { get; set; }

        public string Plan { get; set; }

        public int GrupoId { get; set; }

        public string Meme_Ck { get; set; }

        public string Sbsb_Ck { get; set; }

        public string Municipio { get; set; }

        public string Estado { get; set; }

        public bool? VoBo { get; set; }

        public DateTime? FechaVoBo { get; set; }

        public bool? VoBoM { get; set; }

        public DateTime? FechaVoBoM { get; set; }

        public string FolioComplemento { get; set; }

        public DateTime? FechaVoBoCliente { get; set; }

        public DateTime? FechaVoBoMCliente { get; set; }

        public string Banco { get; set; }

        public string Sucursal { get; set; }

        public string Clabe { get; set; }

        public string CP { get; set; }

        [Display(Name = "Tipo Servicio")]
        public string TipoServicio { get; set; }

        [Display(Name = "Especialidad")]
        public string Especialidad { get; set; }

        public string Url { get; set; }
        public string Siniestro { get; set; }
        public string Poliza { get; set; }
    }
}
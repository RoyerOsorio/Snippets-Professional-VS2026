﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class TramitesRezagadosFilterViewModel
    {
        public int IdDictamen { get; set; }

        public int Dias { get; set; }

        public TramitesRezagadosFilterType FilterType { get; set; }
    }
}
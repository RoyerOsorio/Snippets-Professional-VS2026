﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class PendienteResumeViewModel
    {
        public string Descripcion { get; set; }

        public int Cantidad { get; set; }

        public int Dia { get; set; }

        public DateTime? FechaInicio { get; set; }

        public DateTime? FechaFin { get; set; }
    }
}
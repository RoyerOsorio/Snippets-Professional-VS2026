﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Reembolso
{
    public class CuentaUsuarioFilterViewModel
    {
        public string Titular { get; set; }

        public CuentaUsuarioFilterType FilterType { get; set; }
    }
}
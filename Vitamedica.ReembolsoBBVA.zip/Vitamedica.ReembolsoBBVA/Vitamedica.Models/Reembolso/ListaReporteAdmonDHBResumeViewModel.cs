﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Reembolso
{
    public class ListaReporteAdmonDHBResumeViewModel : MensajeViewModel
    {
        public List<ReporteAdmonDHBResumeViewModel> Lista { get; set; }
    }
}
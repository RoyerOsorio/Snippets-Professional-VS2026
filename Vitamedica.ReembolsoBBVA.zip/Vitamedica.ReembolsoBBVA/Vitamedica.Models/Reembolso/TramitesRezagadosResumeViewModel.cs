﻿using System;

namespace Vitamedica.Models.Reembolso
{
    public class TramitesRezagadosResumeViewModel
    {
        public DateTime FechaRegistro { get; set; }

        public DateTime FechaDictamen { get; set; }

        public int IdBitacora { get; set; }

        public int IdFlujo { get; set; }

        public string Folio { get; set; }

        public string Grupo { get; set; }
    }
}
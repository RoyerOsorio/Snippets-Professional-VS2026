﻿namespace Vitamedica.Models.Reembolso
{
    public class ProvRetencionResumeViewModel
    {
        public int IdGrupo { get; set; }

        public string PrprId { get; set; }

        public string Rfc { get; set; }
    }
}
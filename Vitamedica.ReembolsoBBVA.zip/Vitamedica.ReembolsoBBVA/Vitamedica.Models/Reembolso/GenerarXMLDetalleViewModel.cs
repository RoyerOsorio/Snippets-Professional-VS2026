﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class GenerarXMLDetalleViewModel
    {
        public string DescripcionAux { get; set; }
        public decimal ValorUnitarioAux { get; set; }
        public int CantidadAux { get; set; }
        public decimal ImporteAux { get; set; }
    }
}
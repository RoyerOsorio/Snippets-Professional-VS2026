﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Reembolso
{
    public class MotivoRechazoCuentaViewModel
    {
        public int IdMotivo { get; set; }

        public string Descripcion { get; set; }
    }
}
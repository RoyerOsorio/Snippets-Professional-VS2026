﻿using System.Collections.Generic;
using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Shared
{
    public class ListEspecialidadProveedorResumeViewModel:MensajeViewModel
    {
        public List<EspecialidadProveedorResumeViewModel> Lista { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vitamedica.Models.Shared
{
    public class EntidadViewModel
    {
        public string IdEntidad { get; set; }
        public string NombreEntidad { get; set; }
    }
}
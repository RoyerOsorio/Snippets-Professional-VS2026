﻿using Vitamedica.Models.Shared;

namespace Vitamedica.Models.Shared
{
    public class ProveedorAltaViewModel : MensajeViewModel
    {
        public string Nombre { get; set; }
        public string Especialidad { get; set; }
        public string EspecialidadDescripcion { get; set; }
        public string Red { get; set; }
        public string Estatus { get; set; }
    }
}
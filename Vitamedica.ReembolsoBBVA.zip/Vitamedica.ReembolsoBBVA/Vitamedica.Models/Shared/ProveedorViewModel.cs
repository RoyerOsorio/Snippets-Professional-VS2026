﻿using Vitamedica.Models.Shared;

namespace Vitamedica.ReembolsoGModelo.ViewModels.Shared
{
    public class ProveedorViewModel : MensajeViewModel
    {
        public string Nombre { get; set; }

        public string NoProveedor { get; set; }

        public string Especialidad { get; set; }

        public string RFC { get; set; }

        public string Cuenta { get; set; }

        public string Ciudad { get; set; }

        public string Entidad { get; set; }

        public string Colonia { get; set; }

        public string CodigoPostal { get; set; }

        public string Direccion { get; set; }

        public string NoExterior { get; set; }

        public string NoInterior { get; set; }

        public int NoDeBeneficiario { get; set; }

        public string Telefono { get; set; }

        public bool EsVigente { get; set; }

        public string Red { get; set; }
    }
}

﻿namespace Vitamedica.Models.Shared
{
    public static class TipoNotificacion
    {
        public const string Correcto = "success";
        public const string Informacion = "info";
        public const string Advertencia = "warning";
        public const string Error = "danger";
    }

    public class NotificacionViewModel
    {
        public const string TempDataKey = "TempDataAlerts";

        public string TipoNotificacion { get; set; }
        public string Mensaje { get; set; }
        public bool Descartable { get; set; }
    }
}
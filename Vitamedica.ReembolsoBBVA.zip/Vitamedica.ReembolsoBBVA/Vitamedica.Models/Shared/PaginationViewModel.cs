﻿using System.ComponentModel.DataAnnotations;
using Label = Vitamedica.ReembolsoGModelo.Resource.Label;
using Message = Vitamedica.ReembolsoGModelo.Resource.Message;

namespace Vitamedica.Models.Shared
{
    public class PaginationViewModel
    {
        [Required(ErrorMessageResourceType = typeof(Message.Pagination), ErrorMessageResourceName = "MESSAGE_PAGE_REQUIRED")]
        [Display(ResourceType = typeof(Label.Pagination), Name = "LABEL_PAGE")]
        public int Page { get; set; }
        [Required(ErrorMessageResourceType = typeof(Message.Pagination), ErrorMessageResourceName = "MESSAGE_RECORDS_REQUIRED")]
        [Display(ResourceType = typeof(Label.Pagination), Name = "LABEL_RECORDS")]
        public int Records { get; set; }
        [Required(ErrorMessageResourceType = typeof(Message.Pagination), ErrorMessageResourceName = "MESSAGE_TOTALRECORDS_REQUIRED")]
        [Display(ResourceType = typeof(Label.Pagination), Name = "LABEL_TOTALRECORDS")]
        public long TotalRecords { get; set; }

        public bool RequiredPagination { get; set; }
    }
}
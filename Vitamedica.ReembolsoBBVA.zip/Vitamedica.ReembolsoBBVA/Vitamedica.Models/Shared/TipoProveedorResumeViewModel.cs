﻿using System.Collections.Generic;


namespace Vitamedica.Models.Shared
{
    public class TipoProveedorResumeViewModel
    {
        public string IdTipoProveedor { get; set; }

        public string NombreTipoProveedor { get; set; }

        public bool Seleccionado { get; set; }
    }
}
﻿namespace Vitamedica.Models.Shared
{
    public class MensajeViewModel
    {
        public bool EsCorrecto { get; set; }
        public string Mensaje { get; set; }
        public virtual int Id { get; set; }

    }
}
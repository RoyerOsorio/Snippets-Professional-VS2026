﻿

namespace Vitamedica.Models.Shared
{
    public class EspecialidadProveedorResumeViewModel : MensajeViewModel
    {
        public string IdEspecialidadProveedor { get; set; }

        public string NombreEspecialidadProveedor { get; set; }

        public bool Seleccionado { get; set; }
    }
}
﻿using Vitamedica.ReembolsoGModelo.Model.Filter;

namespace Vitamedica.Models.Hubs
{
    public class UsuarioSignalRFilterViewModel
    {
        public string Profile { get; set; }

        public UsuarioSignalRFilterType FilterType { get; set; }
    }
}
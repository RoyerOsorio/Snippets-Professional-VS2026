﻿namespace Vitamedica.Models.Hubs
{
    public class UsuariosReembolsoViewModel
    {
        public string IdConexion { get; set; }

        public string UserName { get; set; }

        public string Profile { get; set; }

        public int IdTramite { get; set; }
    }
}
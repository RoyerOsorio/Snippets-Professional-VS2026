﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Vitamedica.Proxy.API
{
    public class HTTPRequest
    {
        public string url;
        public string method; 
        public string path;



        public async Task<String> SendGET(HttpRequestMessage request)
        {
            HttpClient client = new HttpClient();

            try
            {
                // Send the request
                HttpResponseMessage response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    string responseBody = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(responseBody);

                    return responseBody;
                }
                else
                {
                    Console.WriteLine($"Error: {response.StatusCode}");
                    return response.StatusCode.ToString();

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return ex.Message;

            }

        }

        public static async Task<string> MakeGetRequestAsync(string url)
        {
            try
            {

                HttpClient client = new HttpClient();

                // Set headers for the request
                //client.DefaultRequestHeaders.Add("Accept", "application/json");
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "29daf4994e21448b846b2ba533c9d6c4");

                HttpResponseMessage response = await client.GetAsync(url);

                if (response.IsSuccessStatusCode)
                {
                    // Return the JSON response as a string
                    return await response.Content.ReadAsStringAsync();
                }
                else
                {
                    //throw new Exception($"Error: {response.StatusCode}");
                    return response.StatusCode.ToString();
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Exception: {ex.Message}");
                return ex.Message;
            }
        }

        public string MakeGetRequest(WebRequest request)
        {
            try
            {
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        using (StreamReader objReader = new StreamReader(strReader))
                        {
                            string responseBody = objReader.ReadToEnd();
                            // Do something with responseBody
                            //Console.WriteLine(responseBody);
                            return responseBody;

                        }
                    }
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return string.Empty;

            }
        }

    }
}

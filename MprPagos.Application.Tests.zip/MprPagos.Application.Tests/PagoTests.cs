using FluentAssertions;
using MprPagos.Domain.Entidades;
using MprPagos.Domain.Excepciones;
using Xunit;

namespace MprPagos.Application.Tests;

public class PagoTests
{
    private static readonly DateTime Ahora = new(2026, 8, 18, 12, 0, 0, DateTimeKind.Utc);

    [Fact]
    public void CrearDesdeReclamoAprobado_devuelve_un_Pago_en_estado_Pendiente()
    {
        var pago = Pago.CrearDesdeReclamoAprobado(1, "POL-001", 10, 1500m, mensajeIdOrigen: 99, Ahora);

        pago.Estado.Should().Be(EstadoPago.Pendiente);
        pago.MensajeIdOrigen.Should().Be(99);
    }

    [Fact]
    public void Confirmar_transiciona_de_Pendiente_a_Completado()
    {
        var pago = Pago.CrearDesdeReclamoAprobado(1, "POL-001", 10, 1500m, 99, Ahora);

        pago.Confirmar(Ahora.AddDays(1));

        pago.Estado.Should().Be(EstadoPago.Completado);
        pago.FechaConfirmacion.Should().Be(Ahora.AddDays(1));
    }

    [Fact]
    public void Confirmar_lanza_excepcion_si_el_Pago_ya_esta_Completado()
    {
        var pago = Pago.CrearDesdeReclamoAprobado(1, "POL-001", 10, 1500m, 99, Ahora);
        pago.Confirmar(Ahora);

        var accion = () => pago.Confirmar(Ahora);

        accion.Should().Throw<TransicionEstadoInvalidaException>();
    }
}

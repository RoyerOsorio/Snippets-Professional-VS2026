using FluentAssertions;
using MprPagos.Application.Casos;
using MprPagos.Application.Eventos;
using MprPagos.Application.Puertos;
using MprPagos.Domain.Entidades;
using Xunit;

namespace MprPagos.Application.Tests;

public class ProcesarReclamoAprobadoParaPagoCasoDeUsoTests
{
    private sealed class RepositorioFalso : IRepositorioPagos
    {
        private int siguienteId = 1;
        public List<Pago> Guardados { get; } = [];

        public Task<Pago?> ObtenerPorIdAsync(int pagoId, CancellationToken cancellationToken) =>
            Task.FromResult(Guardados.FirstOrDefault(p => p.Id == pagoId));

        public Task<Pago?> ObtenerPorMensajeIdOrigenAsync(long mensajeIdOrigen, CancellationToken cancellationToken) =>
            Task.FromResult(Guardados.FirstOrDefault(p => p.MensajeIdOrigen == mensajeIdOrigen));

        public Task<Pago> CrearAsync(Pago pago, CancellationToken cancellationToken)
        {
            var conId = new Pago(
                siguienteId++, pago.ReclamoId, pago.Poliza, pago.AseguradoId, pago.MontoAprobado,
                pago.Estado, pago.MensajeIdOrigen, pago.FechaCreacion, pago.FechaConfirmacion);
            Guardados.Add(conId);
            return Task.FromResult(conId);
        }

        public Task ActualizarYPublicarEventoAsync(Pago pago, PagoCompletadoEvento evento, CancellationToken cancellationToken)
        {
            var indice = Guardados.FindIndex(p => p.Id == pago.Id);
            Guardados[indice] = pago;
            return Task.CompletedTask;
        }
    }

    private static readonly DateTime Ahora = new(2026, 8, 18, 12, 0, 0, DateTimeKind.Utc);

    [Fact]
    public async Task Crea_un_Pago_nuevo_cuando_el_mensaje_no_se_habia_procesado()
    {
        var repositorio = new RepositorioFalso();
        var casoDeUso = new ProcesarReclamoAprobadoParaPagoCasoDeUso(repositorio);

        var resultado = await casoDeUso.EjecutarAsync(99, 1, "POL-001", 10, 1500m, Ahora, CancellationToken.None);

        resultado.Id.Should().BeGreaterThan(0);
        resultado.Estado.Should().Be(EstadoPago.Pendiente);
        repositorio.Guardados.Should().HaveCount(1);
    }

    [Fact]
    public async Task Es_idempotente_ante_el_mismo_MensajeIdOrigen()
    {
        var repositorio = new RepositorioFalso();
        var casoDeUso = new ProcesarReclamoAprobadoParaPagoCasoDeUso(repositorio);

        var primero = await casoDeUso.EjecutarAsync(99, 1, "POL-001", 10, 1500m, Ahora, CancellationToken.None);
        var segundo = await casoDeUso.EjecutarAsync(99, 1, "POL-001", 10, 1500m, Ahora, CancellationToken.None);

        segundo.Id.Should().Be(primero.Id);
        repositorio.Guardados.Should().HaveCount(1);
    }
}

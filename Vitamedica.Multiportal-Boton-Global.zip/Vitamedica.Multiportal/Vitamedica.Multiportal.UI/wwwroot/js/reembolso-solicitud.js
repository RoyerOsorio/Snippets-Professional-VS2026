/* ============================================================================
   reembolso-solicitud.js — Interacciones exclusivas de la vista Solicitud de
   Reembolso. Sin lógica de negocio en el cliente.

   Fase G2 (ver UI_Decision_Log.md): la búsqueda de Derechohabiente pasa de
   comparar contra un objeto hardcodeado (DERECHOHABIENTE_DEMO) a consultar
   ReembolsosController.BuscarDerechohabiente vía fetch (core/http.js,
   getJson — JSON y no PartialView, porque a diferencia de Reembolsos/Index
   no hay un renderizado inicial de esta tabla que reutilizar). De paso se
   corrige la fila de resultado, que antes se construía con concatenación
   de strings asignada a innerHTML (violación de JavaScript_Architecture_
   Guide.md) — ahora se arma con document.createElement/textContent, mismo
   criterio que ya usa aplicarDerechohabiente() para el <select> de
   beneficiarios.

   Fase G3 (ver UI_Decision_Log.md): "Registrar" pasa de solo abrir el
   modal de éxito (sin tocar el servidor) a un POST simulado vía
   postJson contra ReembolsosController.Registrar. Alcance acotado: solo
   se envían los campos que Crear.cshtml ya declaraba con `name` (ver
   DEC-ReembolsosCrear-RegistrarPost.md) — identidad del derechohabiente,
   líneas de factura y documentos quedan fuera de esta fase.

   Fase G4a/G4b: identidad del derechohabiente y datos de factura se
   agregan al payload de Registrar leyendo el DOM por selector (ver
   construirPayloadRegistro/leerFacturaCategoria) — el POST sigue siendo
   JSON, los `name`/índice de la vista son solo documentación de intención.

   Fase G4c: primer manejo real de archivos del proyecto. Los botones
   "Cargar" (formato de instrucción, factura estandar, líneas de factura,
   documentos por categoría) ahora abren un <input type="file"> real
   (agregado en Crear.cshtml) y suben el archivo de inmediato vía
   postForm/ReembolsosController.SubirArchivo — sin esperar a "Registrar".
   ============================================================================ */
import { refreshIcons } from "./core/icons.js";
import { reinitDatePicker } from "./components/date-picker.js";
import { getJson, postJson, postForm, HttpError } from "./core/http.js";

// Demo: Estado/Municipio ya no se capturan manualmente (dropdowns) — se
// autocompletan como inputs deshabilitados a partir del Código Postal.
// Reemplazar por una llamada real de catálogo (SEPOMEX u otro servicio).
var ESTADO_MUNICIPIO_POR_CP = {
    "75070": { estado: "Puebla", municipio: "Chilchotla" },
    "03100": { estado: "Ciudad de México", municipio: "Benito Juárez" },
    "44100": { estado: "Jalisco", municipio: "Guadalajara" }
};

// ---- Revelado progresivo de secciones (Sección 1 -> 2 -> 3) ----
// Alcance: únicamente el comportamiento de mostrar/ocultar. Sin nuevas
// validaciones, sin nuevos campos, sin cambios en el flujo de envío.
var aseguradoSeleccionado = false;
var seccion2Revelada = false;
var seccion3Revelada = false;

document.addEventListener("DOMContentLoaded", function () {
    initDerechohabienteModal();
    initCodigoPostalLookup();
    initBeneficiarioSelect();
    initCategorySelection();
    initDocBlocks();
    initFacturaGenerators();
    initFacturaLineas();
    initCancelConfirm();
    initProgressiveSections();
    initRegistrarGate();
    initRegistroExitoso();
    refreshIcons();
});

// ---- 1. Modal Derechohabiente: búsqueda + autocompletado ----
function initDerechohabienteModal() {
    var modalEl = document.getElementById("modalDerechohabiente");
    if (!modalEl) return;

    // Fiel a la referencia: el modal se muestra automáticamente al entrar,
    // ya que es el punto de partida obligatorio del flujo.
    if (modalEl.hasAttribute("data-autoshow")) {
        bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    var form = modalEl.querySelector("[data-buscar-form]");
    var resultsWrap = modalEl.querySelector("[data-buscar-resultados]");

    var btnBuscar = form.querySelector("button[type=submit]");

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        var input = form.querySelector("input[name='numeroEmpleado']");
        var valor = (input.value || "").trim();

        if (btnBuscar) btnBuscar.disabled = true;

        getJson("/Reembolsos/BuscarDerechohabiente?numeroEmpleado=" + encodeURIComponent(valor))
            .then(function (data) {
                mostrarResultadoEncontrado(data, modalEl, resultsWrap);
            })
            .catch(function (error) {
                if (error instanceof HttpError && error.status === 404) {
                    mostrarResultadoNoEncontrado(resultsWrap);
                } else {
                    console.error("[reembolso-solicitud]", error);
                    window.alert("No se pudo buscar el derechohabiente. Intenta de nuevo.");
                }
            })
            .finally(function () {
                if (btnBuscar) btnBuscar.disabled = false;
            });
    });
}

// Construye la fila de resultado con DOM seguro (createElement/textContent)
// — nunca innerHTML + concatenación (ver cabecera del archivo, Fase G2).
function mostrarResultadoEncontrado(data, modalEl, resultsWrap) {
    resultsWrap.textContent = "";

    var table = document.createElement("table");
    table.className = "table table-sm align-middle mb-0";
    table.setAttribute("role", "table");

    var thead = document.createElement("thead");
    var headRow = document.createElement("tr");
    ["Número de Empleado", "Nombre Completo", "Grupo", ""].forEach(function (texto) {
        var th = document.createElement("th");
        th.textContent = texto;
        headRow.appendChild(th);
    });
    thead.appendChild(headRow);

    var tbody = document.createElement("tbody");
    var row = document.createElement("tr");
    row.className = "derechohabiente-row";
    row.style.cursor = "pointer";
    row.tabIndex = 0;
    row.setAttribute("role", "button");

    [data.numeroEmpleado, data.nombre, data.grupo].forEach(function (texto) {
        var td = document.createElement("td");
        td.textContent = texto;
        row.appendChild(td);
    });

    var tdAccion = document.createElement("td");
    var span = document.createElement("span");
    span.className = "btn-text-vm";
    span.style.padding = "4px 8px";
    span.textContent = "Seleccionar";
    tdAccion.appendChild(span);
    row.appendChild(tdAccion);

    tbody.appendChild(row);
    table.appendChild(thead);
    table.appendChild(tbody);
    resultsWrap.appendChild(table);
    resultsWrap.hidden = false;

    var seleccionar = function () {
        aplicarDerechohabiente(data);
        bootstrap.Modal.getOrCreateInstance(modalEl).hide();
    };
    row.addEventListener("click", seleccionar);
    row.addEventListener("keydown", function (ev) {
        if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); seleccionar(); }
    });
}

function mostrarResultadoNoEncontrado(resultsWrap) {
    resultsWrap.textContent = "";

    var hint = document.createElement("div");
    hint.className = "solicitar-hint";

    var icon = document.createElement("i");
    icon.setAttribute("data-lucide", "search-x");
    icon.setAttribute("aria-hidden", "true");

    hint.appendChild(icon);
    hint.appendChild(document.createTextNode("No se encontró ningún derechohabiente con ese número de empleado."));

    resultsWrap.appendChild(hint);
    resultsWrap.hidden = false;
    refreshIcons();
}

function aplicarDerechohabiente(data) {
    setFieldText("campoNumeroEmpleado", data.numeroEmpleado);
    setFieldText("campoNombreTitular", data.nombre);
    setFieldText("campoFechaInicioVigencia", data.fechaInicioVigencia);
    setFieldText("campoFechaFinVigencia", data.fechaFinVigencia);
    setFieldText("campoMiembroDesde", data.miembroDesde);

    // Fase G4a (ver UI_Decision_Log.md): los <span> de arriba son de solo
    // lectura y nunca se enviaban al servidor — se replican en inputs
    // ocultos para que Registrar (Fase G3) sí reciba la identidad del
    // derechohabiente seleccionado.
    setFieldValue("hiddenNumeroEmpleado", data.numeroEmpleado);
    setFieldValue("hiddenNombreTitular", data.nombre);
    setFieldValue("hiddenFechaInicioVigencia", data.fechaInicioVigencia);
    setFieldValue("hiddenFechaFinVigencia", data.fechaFinVigencia);
    setFieldValue("hiddenMiembroDesde", data.miembroDesde);

    var resumen = document.getElementById("resumenAsegurado");
    if (resumen) resumen.textContent = data.nombre + " · Núm. " + data.numeroEmpleado;

    var select = document.getElementById("selectBeneficiario");
    if (select) {
        select.innerHTML = '<option value="">-- Seleccionar Beneficiario --</option>';
        data.beneficiarios.forEach(function (b) {
            var opt = document.createElement("option");
            opt.value = b.id;
            opt.textContent = b.nombre + " (" + b.parentesco + ")";
            opt.setAttribute("data-parentesco", b.parentesco);
            select.appendChild(opt);
        });
        select.disabled = false;
    }

    aseguradoSeleccionado = true;
    evaluarGateSeccion2();
}

function setFieldText(id, value) {
    var el = document.getElementById(id);
    if (el) el.textContent = value;
}

function setFieldValue(id, value) {
    var el = document.getElementById(id);
    if (el) el.value = value;
}

// ---- 2. Código Postal -> Estado/Municipio (demo, inputs deshabilitados) ----
function initCodigoPostalLookup() {
    var cp = document.getElementById("inputCP");
    var estado = document.getElementById("inputEstado");
    var municipio = document.getElementById("inputMunicipio");
    if (!cp || !estado || !municipio) return;

    function sync() {
        var valor = (cp.value || "").trim();
        var datos = ESTADO_MUNICIPIO_POR_CP[valor];
        estado.value = datos ? datos.estado : "";
        municipio.value = datos ? datos.municipio : "";
        // Los inputs quedan deshabilitados (no editables ni disparan sus
        // propios eventos): se notifica el gate de la Sección 1 aquí mismo.
        evaluarGateSeccion2();
    }

    cp.addEventListener("input", sync);
    cp.addEventListener("change", sync);
}

// ---- 3. Beneficiario -> Parentesco autocompletado ----
function initBeneficiarioSelect() {
    var select = document.getElementById("selectBeneficiario");
    var parentesco = document.getElementById("campoParentesco");
    if (!select || !parentesco) return;

    select.addEventListener("change", function () {
        var opt = select.options[select.selectedIndex];
        parentesco.textContent = opt ? (opt.getAttribute("data-parentesco") || "—") : "—";
        evaluarGateSeccion3(select.value);
    });
}

// ---- 4. Selector de categorías: un clic selecciona Y agrega la categoría
// a la solicitud en un solo gesto (sustituye el antiguo par "clic en tab" +
// checkbox "Solicitar" independiente — ver Analisis_UX_SolicitudReembolso_
// DatosReclamacion.md §2.2). La navegación por flechas SOLO mueve el foco
// (roving tabindex), sin alterar la inclusión: así recorrer categorías con
// el teclado no las agrega por accidente. Activar (clic/Enter/Espacio) es
// lo único que decide inclusión.
function initCategorySelection() {
    var nav = document.querySelector("[data-category-nav]");
    if (!nav) return;
    var buttons = Array.prototype.slice.call(nav.querySelectorAll(".category-nav-btn"));

    function mostrarPanel(btn) {
        buttons.forEach(function (b) {
            var seleccionado = b === btn;
            b.setAttribute("aria-selected", String(seleccionado));
            b.tabIndex = seleccionado ? 0 : -1;
            var panel = document.getElementById(b.getAttribute("aria-controls"));
            if (panel) panel.classList.toggle("is-active", seleccionado);
        });
    }

    function alternarInclusion(btn) {
        var key = btn.getAttribute("data-category-key");
        var input = document.querySelector("[data-categoria-incluida='" + key + "']");
        if (!input) return;

        var yaActiva = btn.getAttribute("aria-selected") === "true";
        var yaIncluida = input.value === "true";

        if (yaIncluida && yaActiva) {
            // Un segundo clic sobre la categoría que ya se está viendo Y ya
            // está incluida la retira de la solicitud (no descarta los
            // documentos ya cargados, por si el usuario la vuelve a
            // seleccionar más adelante en la misma sesión — ver pregunta 7
            // del análisis, pendiente de confirmación de negocio).
            input.value = "false";
        } else {
            input.value = "true";
            mostrarPanel(btn);
        }

        actualizarBadgeCategoria(key);
        actualizarResumenReclamacion();
    }

    buttons.forEach(function (btn, idx) {
        btn.tabIndex = btn.getAttribute("aria-selected") === "true" ? 0 : -1;
        btn.addEventListener("click", function () { alternarInclusion(btn); });
        btn.addEventListener("keydown", function (e) {
            if (e.key === "ArrowDown") { e.preventDefault(); enfocarSiguiente(idx, 1); }
            if (e.key === "ArrowUp") { e.preventDefault(); enfocarSiguiente(idx, -1); }
            if (e.key === "Enter" || e.key === " ") { e.preventDefault(); alternarInclusion(btn); }
        });
    });

    function enfocarSiguiente(idx, delta) {
        buttons[(idx + delta + buttons.length) % buttons.length].focus();
    }

    // Pinta el estado inicial (categoría 0 activa + incluida por defecto,
    // igual que el comportamiento previo con el checkbox premarcado).
    buttons.forEach(function (btn) {
        actualizarBadgeCategoria(btn.getAttribute("data-category-key"));
    });
    actualizarResumenReclamacion();
}

// ---- 4.1 Badge de categoría (check + contador) y resumen agregado ----
function actualizarBadgeCategoria(key) {
    var input = document.querySelector("[data-categoria-incluida='" + key + "']");
    var badge = document.querySelector("[data-category-badge='" + key + "']");
    if (!input || !badge) return;
    badge.hidden = input.value !== "true";
    actualizarContadorCategoria(key);
}

// Cuenta documentos "cargados" dentro de la categoría: hoy solo Factura
// simula un estado real de carga (ver initFacturaGenerators); los demás
// campos de documento no tienen todavía un mecanismo de carga real (ver
// documentoRequeridoCargado más abajo), así que de momento solo suman si
// llegaran a tener valor. Único punto a extender cuando exista carga real.
function contarDocumentosCategoria(key) {
    var panel = document.querySelector("[data-category-panel='" + key + "']");
    if (!panel) return 0;
    var total = 0;
    panel.querySelectorAll(".doc-file-input").forEach(function (input) {
        if ((input.value || "").trim().length > 0) total++;
    });
    return total;
}

function actualizarContadorCategoria(key) {
    var countEl = document.querySelector("[data-category-count='" + key + "']");
    if (countEl) countEl.textContent = String(contarDocumentosCategoria(key));
}

// Resumen agregado fijo en el encabezado de la Sección 3 (categorías
// incluidas · documentos cargados · monto total) — visión de conjunto que
// el flujo anterior no ofrecía (solo mostraba una categoría a la vez).
function actualizarResumenReclamacion() {
    var resumen = document.getElementById("resumenReclamacion");
    if (!resumen) return;

    var categoriasIncluidas = 0;
    var documentosTotales = 0;
    var montoTotal = 0;

    document.querySelectorAll("[data-categoria-incluida]").forEach(function (input) {
        if (input.value !== "true") return;
        categoriasIncluidas++;
        var key = input.getAttribute("data-categoria-incluida");
        documentosTotales += contarDocumentosCategoria(key);
        var montoEl = document.querySelector("#panel-" + key + " [data-factura-monto]");
        if (montoEl) {
            var monto = parseFloat(montoEl.textContent.replace(/[^\d.]/g, ""));
            if (!isNaN(monto)) montoTotal += monto;
        }
    });

    if (categoriasIncluidas === 0) {
        resumen.textContent = "Aún no se ha seleccionado ningún servicio";
    } else {
        var textoCategorias = categoriasIncluidas + (categoriasIncluidas === 1 ? " categoría" : " categorías");
        var textoDocumentos = documentosTotales + (documentosTotales === 1 ? " documento" : " documentos");
        var textoMonto = montoTotal.toLocaleString("es-MX", { style: "currency", currency: "MXN" });
        resumen.textContent = textoCategorias + " · " + textoDocumentos + " · " + textoMonto;
    }

    evaluarBotonRegistrar();
}

// ---- 6. Bloques de documento (acordeón interno + agregar/quitar filas) ----
function initDocBlocks() {
    document.querySelectorAll("[data-doc-toggle]").forEach(function (header) {
        var body = document.getElementById(header.getAttribute("aria-controls"));
        header.addEventListener("click", function () {
            var expanded = header.getAttribute("aria-expanded") === "true";
            header.setAttribute("aria-expanded", String(!expanded));
            if (body) body.hidden = expanded;
        });
    });

    document.querySelectorAll("[data-doc-add]").forEach(function (btn) {
        var list = document.getElementById(btn.getAttribute("data-doc-add"));
        if (!list) return;

        // Fase G4c (ver UI_Decision_Log.md): las filas ya renderizadas por
        // el servidor también necesitan el picker de archivo real
        // conectado, no solo las que se agregan después.
        list.querySelectorAll(".doc-file-row").forEach(function (row) {
            wireDocFileRow(row, "documento");
        });

        btn.addEventListener("click", function () {
            var template = list.querySelector(".doc-file-row");
            if (!template) return;
            var clone = template.cloneNode(true);
            clone.querySelectorAll("input[type=text]").forEach(function (i) { i.value = ""; });

            var removeBtn = clone.querySelector(".doc-file-remove");
            // Fase G4c — hallazgo corregido de paso: cloneNode copia el
            // atributo data-wired del botón "Quitar" de la fila plantilla
            // (ya wireado por el querySelectorAll(".doc-file-remove") de
            // más abajo), así que sin este reseteo wireRemoveButton() nunca
            // engancha el clic en las filas agregadas dinámicamente — el
            // botón "Quitar archivo" quedaba muerto en toda fila agregada
            // con "Agregar otro archivo" (bug preexistente, no introducido
            // en esta fase, corregido aquí por tocar el mismo código).
            if (removeBtn) delete removeBtn.dataset.wired;

            // Ciclo 1 (Fase9_MejorasUI_RetrocederTramite, ver DEC-...): una
            // fila agregada dinámicamente debe poder quitarse de inmediato,
            // sin esperar a que se suba un archivo — igual que ya hace
            // .factura-line (initFacturaLineas), cuyo botón "Quitar" nunca
            // nace oculto. El botón de la fila plantilla SÍ nace oculto
            // (style="display:none", ver Crear.cshtml/Detalle.cshtml) hasta
            // que hay un archivo cargado con éxito (wireDocFileRow) — eso
            // no cambia. Solo el clon, que es siempre una fila nueva y
            // vacía, se revela de inmediato.
            if (removeBtn) removeBtn.style.display = "";

            list.appendChild(clone);
            wireRemoveButton(removeBtn);
            wireDocFileRow(clone, "documento");
            refreshIcons();
        });
    });

    // Fase G5 (ver UI_Decision_Log.md): se excluyen los botones "Quitar"
    // dentro de .factura-line — initFacturaLineas los wirea aparte, con un
    // callback que recalcula Total/Monto de la categoría al quitar una
    // línea. Sin esta exclusión, esta línea (que corre antes) los dejaba
    // wireados sin ese callback.
    //
    // Fase Detalle-G1 (ver UI_Decision_Log.md): también se excluye el botón
    // "Limpiar motivo" (#motivoRechazoWrapper, Reembolsos/Detalle) — reusa
    // la clase .doc-file-remove solo por estilo visual (icono/botón), pero
    // su comportamiento ("limpiar texto") ya lo wirea detalle-solicitud.js
    // por separado. Sin esta exclusión, este wiring genérico también lo
    // engancharía (hallazgo: acoplamiento accidental clase visual/JS, ver
    // Regla 18 del proyecto) — hoy no rompía nada solo porque su fila está
    // sola (list.children.length > 1 nunca se cumple), pero quedaba frágil
    // ante cualquier cambio futuro de esa sección.
    document.querySelectorAll(".doc-file-remove").forEach(function (btn) {
        if (btn.closest(".factura-line")) return;
        if (btn.closest("#motivoRechazoWrapper")) return;
        wireRemoveButton(btn);
    });

    // "Formato de instrucción de reembolso" (Sección 3, fuera del bucle de
    // categorías) — misma mecánica de carga, contexto "documento".
    var campoFormato = document.getElementById("inputFormatoInstruccion");
    if (campoFormato) wireDocFileRow(campoFormato.closest(".doc-file-row"), "documento");
}

function wireRemoveButton(btn, onQuitar) {
    if (!btn || btn.dataset.wired) return;
    btn.dataset.wired = "1";
    btn.addEventListener("click", function () {
        var row = btn.closest(".doc-file-row") || btn.closest(".factura-line");
        var list = row ? row.parentElement : null;
        if (list && list.children.length > 1) {
            row.remove();
            if (onQuitar) onQuitar();
        }
    });
}

// ---- Carga real de archivos (Fase G4c, ver UI_Decision_Log.md) ----
//
// Conecta una fila que tiene: un input de texto de solo lectura
// (.doc-file-input), un botón disparador (.doc-gen-btn--secondary) y un
// <input type="file" hidden> real (.doc-file-picker) agregado en
// Crear.cshtml. Al elegir un archivo, se sube de inmediato (no se espera a
// "Registrar") vía postForm/ReembolsosController.SubirArchivo. El servidor
// valida tamaño/extensión y no persiste nada (ver DEC-ReembolsosCrear-
// G4c-UploadsReales.md) — en éxito se reemplaza el nombre de archivo
// hardcodeado por el que devuelve el servidor.
function wireDocFileRow(row, contexto, onExito) {
    if (!row) return;
    var picker = row.querySelector(".doc-file-picker");
    var trigger = row.querySelector(".doc-gen-btn--secondary");
    var textInput = row.querySelector(".doc-file-input");
    if (!picker || !trigger || !textInput) return;

    trigger.addEventListener("click", function () {
        picker.click();
    });

    picker.addEventListener("change", function () {
        var archivo = picker.files && picker.files[0];
        if (!archivo) return;

        trigger.disabled = true;
        subirArchivoDocumento(archivo, contexto)
            .then(function (data) {
                textInput.value = data.nombreArchivo;
                var removeBtn = row.querySelector(".doc-file-remove");
                if (removeBtn) removeBtn.style.display = "";

                // Fase G5 — hallazgo corregido de paso: desde G4c, subir un
                // documento por categoría nunca refrescaba su contador
                // (badge) de la pestaña — solo lo hacían los flujos de
                // factura, vía refrescarCategoria(). Se corrige aquí de
                // forma genérica, para cualquier fila con upload real.
                var panel = row.closest("[data-category-panel]");
                if (panel) actualizarContadorCategoria(panel.getAttribute("data-category-panel"));

                if (onExito) onExito(data);
            })
            .catch(function (error) {
                console.error("[reembolso-solicitud]", error);
                window.alert(mensajeErrorCarga(error));
                picker.value = "";
            })
            .finally(function () {
                trigger.disabled = false;
            });
    });
}

function subirArchivoDocumento(archivo, contexto) {
    var form = document.getElementById("formSolicitudReembolso");
    var tokenInput = form ? form.querySelector("input[name='__RequestVerificationToken']") : null;
    var token = tokenInput ? tokenInput.value : "";
    var datos = new FormData();
    datos.append("archivo", archivo);
    datos.append("contexto", contexto);
    return postForm("/Reembolsos/SubirArchivo", datos, token);
}

// El servidor responde con BadRequest(mensaje) en texto plano cuando el
// archivo no pasa validación (ver ReembolsosController.SubirArchivo) — se
// muestra ese mensaje en vez de uno genérico cuando está disponible.
function mensajeErrorCarga(error) {
    if (error instanceof HttpError && error.body) return error.body;
    return "No se pudo cargar el archivo. Intenta de nuevo.";
}

// Fase G5 (ver UI_Decision_Log.md) — mismo formato que ya usaba el "$
// 1,250.00" hardcodeado, ahora aplicado a montos reales/simulados.
function formatMonto(valor) {
    return "$ " + (valor || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// ---- 7. Generador de Factura: tabs de método (PDF/XML/Generar XML) +
// una sola acción de carga, en vez de 4 botones de color compitiendo entre
// sí (ver Analisis_UX_SolicitudReembolso_DatosReclamacion.md §2.4). ----
var FACTURA_METODOS = {
    pdf: { icono: "upload", etiqueta: "Cargar PDF", pista: "Formatos permitidos: PDF · máx. 5 MB" },
    xml: { icono: "upload", etiqueta: "Cargar XML", pista: "Formatos permitidos: XML · máx. 5 MB" },
    generar: { icono: "sparkles", etiqueta: "Generar XML", pista: "Se genera a partir de los datos ya capturados en esta solicitud" }
};

function initFacturaGenerators() {
    document.querySelectorAll("[data-factura-generator]").forEach(function (gen) {
        var empty = gen.querySelector("[data-factura-empty]");
        var loaded = gen.querySelector("[data-factura-loaded]");
        var totalEl = gen.querySelector("[data-factura-total]");
        var montoEl = gen.querySelector("[data-factura-monto]");
        var actionBtn = gen.querySelector("[data-factura-action='cargar']");
        var actionIcon = gen.querySelector("[data-factura-action-icon]");
        var actionLabel = gen.querySelector("[data-factura-action-label]");
        var hint = gen.querySelector("[data-factura-hint]");
        var picker = gen.querySelector(".doc-file-picker");
        var loadedTextInput = loaded ? loaded.querySelector(".doc-file-input") : null;
        var methodTabs = Array.prototype.slice.call(gen.querySelectorAll("[data-factura-method]"));
        var panel = gen.closest("[data-category-panel]");
        var categoryKey = panel ? panel.getAttribute("data-category-panel") : null;
        var metodoActual = "pdf";

        function refrescarCategoria() {
            if (!categoryKey) return;
            actualizarContadorCategoria(categoryKey);
            actualizarResumenReclamacion();
        }

        function mostrarCargado(monto) {
            if (empty) empty.hidden = true;
            if (loaded) loaded.hidden = false;
            if (totalEl) totalEl.textContent = "1";
            if (montoEl) montoEl.textContent = formatMonto(monto);
            refrescarCategoria();
        }

        function aplicarMetodo(metodo) {
            metodoActual = metodo;
            methodTabs.forEach(function (tab) {
                var activo = tab.getAttribute("data-factura-method") === metodo;
                tab.classList.toggle("is-active", activo);
                tab.setAttribute("aria-selected", String(activo));
            });
            var config = FACTURA_METODOS[metodo];
            if (!config) return;
            if (actionIcon) actionIcon.setAttribute("data-lucide", config.icono);
            if (actionLabel) actionLabel.textContent = config.etiqueta;
            if (hint) hint.textContent = config.pista;
            refreshIcons();
        }

        methodTabs.forEach(function (tab) {
            tab.addEventListener("click", function () {
                aplicarMetodo(tab.getAttribute("data-factura-method"));
            });
        });

        if (actionBtn && picker) {
            actionBtn.addEventListener("click", function () {
                // Fase G4c (ver UI_Decision_Log.md): "generar" no tiene un
                // archivo real que seleccionar — sigue siendo simulado,
                // igual que antes (ver FACTURA_METODOS). "pdf"/"xml" sí
                // abren el selector de archivo real.
                if (metodoActual === "generar") {
                    // Fase G5 (ver UI_Decision_Log.md): "generar" no sube
                    // ningún archivo real — no hay nada que "leer", así que
                    // mantiene el monto simulado fijo que ya usaba antes.
                    mostrarCargado(1250.00);
                    return;
                }
                picker.click();
            });

            picker.addEventListener("change", function () {
                var archivo = picker.files && picker.files[0];
                if (!archivo) return;

                actionBtn.disabled = true;
                subirArchivoDocumento(archivo, "factura")
                    .then(function (data) {
                        if (loadedTextInput) loadedTextInput.value = data.nombreArchivo;
                        mostrarCargado(data.montoDetectado);
                    })
                    .catch(function (error) {
                        console.error("[reembolso-solicitud]", error);
                        window.alert(mensajeErrorCarga(error));
                        picker.value = "";
                    })
                    .finally(function () {
                        actionBtn.disabled = false;
                    });
            });
        }

        gen.querySelectorAll("[data-factura-action='limpiar']").forEach(function (btn) {
            btn.addEventListener("click", function () {
                if (empty) empty.hidden = false;
                if (loaded) loaded.hidden = true;
                if (totalEl) totalEl.textContent = "0";
                if (montoEl) montoEl.textContent = formatMonto(0);
                refrescarCategoria();
            });
        });

        aplicarMetodo("pdf");
    });
}

// ---- 8. Gastos en el Extranjero: líneas de factura con Moneda/Fecha/Monto ----
function initFacturaLineas() {
    document.querySelectorAll("[data-factura-lineas-add]").forEach(function (btn) {
        var list = document.getElementById(btn.getAttribute("data-factura-lineas-add"));
        if (!list) return;

        var panel = list.closest("[data-category-panel]");
        var categoryKey = panel ? panel.getAttribute("data-category-panel") : null;

        // Fase G5 (ver UI_Decision_Log.md): conecta el upload real (G4c) y
        // el botón "Quitar" de una línea, ambos con el mismo callback de
        // recálculo de Total/Monto de la categoría.
        function wireLinea(linea) {
            wireDocFileRow(linea.querySelector(".doc-file-row"), "factura", function (data) {
                linea.dataset.montoDetectado = data.montoDetectado;
                recalcularFacturaLineas(list, categoryKey);
            });
            wireRemoveButton(linea.querySelector(".doc-file-remove"), function () {
                recalcularFacturaLineas(list, categoryKey);
            });
        }

        // Fase G4c: filas ya renderizadas por el servidor, mismo criterio
        // que initDocBlocks.
        list.querySelectorAll(".factura-line").forEach(wireLinea);

        btn.addEventListener("click", function () {
            var template = list.querySelector(".factura-line");
            if (!template) return;
            var clone = template.cloneNode(true);
            clone.querySelectorAll("input").forEach(function (i) { i.value = ""; });
            clone.querySelectorAll("select").forEach(function (s) { s.selectedIndex = 0; });
            delete clone.dataset.montoDetectado;

            var removeBtn = clone.querySelector(".doc-file-remove");
            // Fase G4c — mismo hallazgo/corrección que en initDocBlocks: sin
            // esto, "Quitar línea de factura" queda muerto en toda línea
            // agregada con "Agregar otra factura".
            if (removeBtn) delete removeBtn.dataset.wired;

            list.appendChild(clone);
            wireLinea(clone);
            // Date Picker de la fila clonada: reembolso-solicitud.js ya es módulo ES
            // (ver DEC-Limpieza-WindowVM.md), así que se usa el componente
            // compartido en vez de duplicar la configuración de Flatpickr a mano
            // (ver DEC-ReembolsoSolicitud-DatePickerClonado.md).
            reinitDatePicker(clone);
            refreshIcons();
        });
    });
}

// Fase G5 — Total = número de líneas con archivo ya "leído" (con
// montoDetectado); Monto = suma de esos montos, sin conversión de divisa
// entre USD/EUR/MXN (decisión confirmada por el usuario: se tratan como si
// fueran la misma unidad, no existe un tipo de cambio real en el proyecto).
function recalcularFacturaLineas(list, categoryKey) {
    var total = 0;
    var monto = 0;
    list.querySelectorAll(".factura-line").forEach(function (linea) {
        if (linea.dataset.montoDetectado === undefined) return;
        total++;
        monto += parseFloat(linea.dataset.montoDetectado) || 0;
    });

    var panel = list.closest("[data-category-panel]");
    var totalEl = panel ? panel.querySelector("[data-factura-total]") : null;
    var montoEl = panel ? panel.querySelector("[data-factura-monto]") : null;
    if (totalEl) totalEl.textContent = String(total);
    if (montoEl) montoEl.textContent = formatMonto(monto);

    if (categoryKey) {
        actualizarContadorCategoria(categoryKey);
        actualizarResumenReclamacion();
    }
}

// ---- 9. Confirmación al cancelar ----
function initCancelConfirm() {
    var cancelBtn = document.querySelector("[data-cancelar-solicitud]");
    var modalEl = document.getElementById("modalConfirmarCancelar");
    if (!cancelBtn || !modalEl) return;
    cancelBtn.addEventListener("click", function () {
        bootstrap.Modal.getOrCreateInstance(modalEl).show();
    });
    var confirmBtn = modalEl.querySelector("[data-confirmar-cancelar]");
    if (confirmBtn) {
        confirmBtn.addEventListener("click", function () {
            window.location.href = confirmBtn.getAttribute("data-href") || "/";
        });
    }
}

// ---- 10. Revelado progresivo de secciones (Sección 1 -> 2 -> 3) ----

// Lista única y centralizada de campos de la Sección 1 que determinan si
// está "completa". Cualquier ajuste a este gate se hace en un solo lugar.
var SECCION1_CAMPOS_REQUERIDOS = [
    "inputCorreo",
    "inputTelefono",
    "inputCP",
    "inputEstado",
    "inputMunicipio",
    "inputFechaPadecimiento"
];

// Campos de SECCION1_CAMPOS_REQUERIDOS que son de solo lectura (autocompletados,
// no capturados por el usuario) — no necesitan listener propio de "input"/"change"
// en initProgressiveSections(), ya que su cambio se notifica desde quien los llena
// (ver initCodigoPostalLookup, que llama a evaluarGateSeccion2() directamente).
var SECCION1_CAMPOS_AUTOCOMPLETADOS = ["inputEstado", "inputMunicipio"];

function campoTieneValor(id) {
    var el = document.getElementById(id);
    if (!el) return false;
    return (el.value || "").trim().length > 0;
}

function seccion1Completa() {
    return aseguradoSeleccionado && SECCION1_CAMPOS_REQUERIDOS.every(campoTieneValor);
}

// Revela una <section> oculta con transición vía bootstrap.Collapse (ya
// usado en esta misma vista para los modales) y mueve el foco a su primer
// campo interactivo, sin recargar la página ni afectar datos capturados.
function revelarSeccion(wrapperId, collapseId) {
    var wrapper = document.getElementById(wrapperId);
    var collapseEl = document.getElementById(collapseId);
    if (!wrapper || !collapseEl) return;

    wrapper.hidden = false;
    bootstrap.Collapse.getOrCreateInstance(collapseEl, { toggle: false }).show();

    var primerCampo = wrapper.querySelector("input, select, textarea, button");
    if (primerCampo) primerCampo.focus();
}

function evaluarGateSeccion2() {
    if (seccion2Revelada) return; // Regla: una vez revelada, no se vuelve a evaluar ni a ocultar.
    if (!seccion1Completa()) return;
    seccion2Revelada = true;
    revelarSeccion("seccionPacienteWrapper", "seccionPaciente");
}

function evaluarGateSeccion3(valorSeleccionado) {
    if (seccion3Revelada) return; // Regla: una vez revelada, no se vuelve a evaluar ni a ocultar.
    if (!valorSeleccionado) return;
    seccion3Revelada = true;
    revelarSeccion("seccionReclamacionWrapper", "seccionReclamacion");
}

// El campo de fecha (Date Picker / Flatpickr) es inicializado por el
// componente compartido components/date-picker.js, cargado vía site.js.
// Ese componente no se modifica en esta solicitud: en su lugar, se lee su
// instancia pública (input._flatpickr, convención propia de Flatpickr) una
// vez ya creada, para enterarse también de fechas elegidas con el
// calendario (no solo tecleadas). Espera acotada sin temporizadores: si la
// instancia aún no existe, reintenta en la siguiente vuelta de microtareas
// hasta un límite fijo; si nunca aparece, el campo sigue cubierto por los
// listeners nativos de "input"/"change" ya registrados en
// initProgressiveSections (degradación seguridad, sin romper el resto).
var FLATPICKR_INTENTOS_MAXIMOS = 20;

function engancharFechaPadecimiento(intentosRestantes) {
    var input = document.getElementById("inputFechaPadecimiento");
    if (!input) return;

    var instancia = input._flatpickr;
    if (instancia) {
        instancia.config.onChange.push(evaluarGateSeccion2);
        return;
    }
    if (intentosRestantes <= 0 || !window.queueMicrotask) return;
    queueMicrotask(function () {
        engancharFechaPadecimiento(intentosRestantes - 1);
    });
}

function initProgressiveSections() {
    var seccion1 = document.getElementById("seccionAsegurado");
    if (!seccion1) return; // Esta vista no aplica.

    SECCION1_CAMPOS_REQUERIDOS.forEach(function (id) {
        if (SECCION1_CAMPOS_AUTOCOMPLETADOS.indexOf(id) !== -1) return;
        var el = document.getElementById(id);
        if (!el) return;
        el.addEventListener("input", evaluarGateSeccion2);
        el.addEventListener("change", evaluarGateSeccion2);
    });

    engancharFechaPadecimiento(FLATPICKR_INTENTOS_MAXIMOS);
}

// ---- 11. Habilitación de Registrar (validación continua de Sección 3) ----

// Único punto de extensión para cuando exista carga real de archivos: hoy
// ningún botón "Cargar" de documento individual registra estado real (no
// hay mecanismo que lo permita todavía), así que esta función no bloquea
// el botón. El día que exista ese mecanismo, es la única función a
// cambiar — no la lógica de habilitación que la llama.
function documentoRequeridoCargado(fila) {
    return true;
}

// Una categoría con documentos marcados "Documento requerido" (banner ya
// renderizado por el servidor) solo cuenta como completa si cada una de
// sus filas de archivo pasa documentoRequeridoCargado.
function categoriaDocumentosRequeridosCompletos(dataId) {
    var contenedor = document.getElementById(dataId);
    if (!contenedor) return true;
    var completo = true;
    contenedor.querySelectorAll(".doc-block-body").forEach(function (body) {
        if (!body.querySelector(".doc-required-banner")) return; // sin requisito, no evalúa
        body.querySelectorAll(".doc-file-row").forEach(function (fila) {
            if (!documentoRequeridoCargado(fila)) completo = false;
        });
    });
    return completo;
}

function seccion3Completa() {
    var inputs = document.querySelectorAll("[data-categoria-incluida]");
    var algunaSolicitada = false;
    var completa = true;
    inputs.forEach(function (input) {
        if (input.value !== "true") return;
        algunaSolicitada = true;
        var key = input.getAttribute("data-categoria-incluida");
        if (!categoriaDocumentosRequeridosCompletos("data-" + key)) completa = false;
    });
    return algunaSolicitada && completa;
}

function evaluarBotonRegistrar() {
    var btn = document.getElementById("btnRegistrar");
    if (!btn) return;
    btn.disabled = !seccion3Completa();
}

// La activación/desactivación de categorías ya notifica a
// evaluarBotonRegistrar() desde actualizarResumenReclamacion() (single
// choke point, ver initCategorySelection) — initRegistrarGate() solo
// pinta el estado inicial del botón al cargar la página.
function initRegistrarGate() {
    evaluarBotonRegistrar();
}

// ---- 12. Registrar -> POST simulado -> modal de confirmación -> redirect ----
function initRegistroExitoso() {
    var form = document.getElementById("formSolicitudReembolso");
    var modalEl = document.getElementById("modalRegistroExitoso");
    if (!form || !modalEl) return;

    var btnRegistrar = document.getElementById("btnRegistrar");

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        if (btnRegistrar && btnRegistrar.disabled) return;

        var tokenInput = form.querySelector("input[name='__RequestVerificationToken']");
        var token = tokenInput ? tokenInput.value : "";
        var payload = construirPayloadRegistro(form);

        if (btnRegistrar) btnRegistrar.disabled = true;

        postJson("/Reembolsos/Registrar", payload, token)
            .then(function (respuesta) {
                var textoFolio = document.getElementById("textoFolioRegistrado");
                if (textoFolio) textoFolio.textContent = respuesta && respuesta.folio ? respuesta.folio : "";
                bootstrap.Modal.getOrCreateInstance(modalEl).show();
            })
            .catch(function (error) {
                console.error("[reembolso-solicitud]", error);
                window.alert("No se pudo registrar la solicitud. Intenta de nuevo.");
            })
            .finally(function () {
                // Reevalúa el gate real (initRegistrarGate/evaluarBotonRegistrar,
                // ver sección 11) en vez de asumir "habilitado": si el estado de
                // la Sección 3 cambió mientras la petición estaba en curso, el
                // botón debe reflejarlo, no simplemente reactivarse.
                evaluarBotonRegistrar();
            });
    });

    var btnCerrar = document.getElementById("btnCerrarRegistroExitoso");
    if (btnCerrar) {
        btnCerrar.addEventListener("click", function () {
            window.location.href = btnCerrar.getAttribute("data-href") || "/";
        });
    }
}

// Arma el payload JSON de Registrar — mismos campos que ya declaraba
// Crear.cshtml con `name` (ver cabecera del archivo, Fase G3). Se
// construye a mano (no vía FormData) porque el body va como JSON
// (postJson), no como formulario codificado: la notación `name="Reclamacion.
// Comentarios"` es para model binding de formularios, no para JSON.
function construirPayloadRegistro(form) {
    return {
        aseguradoTitular: {
            numeroEmpleado: valorPorId("hiddenNumeroEmpleado"),
            nombre: valorPorId("hiddenNombreTitular"),
            fechaInicioVigencia: valorPorId("hiddenFechaInicioVigencia"),
            fechaFinVigencia: valorPorId("hiddenFechaFinVigencia"),
            miembroDesde: valorPorId("hiddenMiembroDesde"),
            correoElectronico: valorPorId("inputCorreo"),
            telefono: valorPorId("inputTelefono"),
            codigoPostal: valorPorId("inputCP"),
            estado: valorPorId("inputEstado"),
            municipio: valorPorId("inputMunicipio"),
            fechaInicioPadecimiento: valorPorId("inputFechaPadecimiento"),
        },
        paciente: {
            beneficiarioId: valorPorId("selectBeneficiario"),
        },
        reclamacion: {
            categorias: Array.prototype.map.call(
                form.querySelectorAll("[data-categoria-incluida]"),
                function (input) {
                    var key = input.getAttribute("data-categoria-incluida");
                    var motivoSelect = document.getElementById("motivo-" + key);
                    var factura = leerFacturaCategoria(key);
                    return {
                        solicitado: input.value === "true",
                        motivo: motivoSelect ? motivoSelect.value : null,
                        facturaCargada: factura.facturaCargada,
                        facturaMetodo: factura.facturaMetodo,
                        facturaArchivoNombre: factura.facturaArchivoNombre,
                        facturaLineas: factura.facturaLineas,
                    };
                }
            ),
            comentarios: valorPorId("textareaComentarios"),
        },
    };
}

// Fase G4b (ver UI_Decision_Log.md): lee el bloque de factura de una
// categoría por selector, no por `name`/índice — el POST de Registrar va
// como JSON (postJson), no como formulario codificado, así que no hay
// model binding de listas que gestionar aquí (mismo criterio ya usado
// arriba para leer las categorías vía [data-categoria-incluida]).
//
// Cada categoría usa UNA de las dos estructuras de factura según su
// TipoFactura (ver SolicitudReembolsoCatalogosViewModel, Fase G1):
// "estandar" (un único archivo, generator con tabs PDF/XML/Generar XML) o
// "multimoneda" (N líneas con Moneda/Fecha, ver initFacturaLineas). Nunca
// las dos a la vez, por eso el resultado siempre trae un grupo de campos
// vacío/en null y el otro con datos.
function leerFacturaCategoria(key) {
    var panel = document.getElementById("panel-" + key);
    var vacio = { facturaCargada: false, facturaMetodo: null, facturaArchivoNombre: null, facturaLineas: [] };
    if (!panel) return vacio;

    var generador = panel.querySelector("[data-factura-generator]");
    if (generador) {
        var loaded = generador.querySelector("[data-factura-loaded]");
        var cargada = !!(loaded && !loaded.hidden);
        var metodoActivo = generador.querySelector("[data-factura-method].is-active");
        var archivoInput = cargada ? loaded.querySelector(".doc-file-input") : null;
        return {
            facturaCargada: cargada,
            facturaMetodo: metodoActivo ? metodoActivo.getAttribute("data-factura-method") : null,
            facturaArchivoNombre: archivoInput ? archivoInput.value : null,
            facturaLineas: [],
        };
    }

    var lineasContainer = document.getElementById("lineas-" + key);
    if (!lineasContainer) return vacio;

    var lineas = Array.prototype.map.call(
        lineasContainer.querySelectorAll(".factura-line"),
        function (linea) {
            var archivo = linea.querySelector(".doc-file-input");
            var moneda = linea.querySelector("select");
            var fecha = linea.querySelector(".date-picker-input");
            return {
                archivoNombre: archivo ? archivo.value : null,
                moneda: moneda ? moneda.value : null,
                fechaServicio: fecha ? fecha.value : null,
            };
        }
    );

    return { facturaCargada: false, facturaMetodo: null, facturaArchivoNombre: null, facturaLineas: lineas };
}

function valorPorId(id) {
    var el = document.getElementById(id);
    return el ? el.value : null;
}

using Microsoft.AspNetCore.Authentication.Cookies;
using System.ServiceModel;
using Vitamedica.Multiportal.UI.Agents;
using Vitamedica.Multiportal.UI.Extensions;
using Vitamedica.Multiportal.UI.Infrastructure.Filters;
using Vitamedica.Multiportal.UI.Models.EndPoint;
using Vitamedica.Multiportal.UI.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
//builder.Services.AddControllersWithViews();

//builder.Services.AddApplication();
//builder.Services.AddInfrastructure(builder.Configuration);

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Sesion/Login";
        //options.AccessDeniedPath = "/Sesion/AccessDenied";
    });

//builder.Services.AddControllersWithViews();
builder.Services.AddControllersWithViews(options => options.Filters.Add<LayoutActionFilter>());
builder.Services.AddMultiportalUi(builder.Configuration);

builder.Services.AddAntiforgery(options => options.HeaderName = "RequestVerificationToken");

var authSettings = builder.Configuration.GetSection("ExternalServices:ActiveDirectory").Get<EndPointSetting>();

if (authSettings != null)
{
    builder.Services.AddSingleton(authSettings);
    builder.Services.AddScoped<IActiveDirectoryService>(provider =>
    {
        var mode = authSettings.BaseUrl.StartsWith("https")
                   ? BasicHttpSecurityMode.Transport
                   : BasicHttpSecurityMode.None;

        var binding = new BasicHttpBinding(mode);
        var endPoint = new EndpointAddress(authSettings.BaseUrl);

        return new ActiveDirectoryServiceClient(binding, endPoint);
    });
}

//API's

builder.Services.AddHttpClient<MultiportalApiClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Apis:apiMultiportal:BaseUrl"]!);
});
builder.Services.AddHttpClient<VigorApiClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Apis:apiVigor:BaseUrl"]!);
});

//Agentes
builder.Services.AddScoped<AuthAgent>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Reembolsos}/{action=Index}/{id?}")
    .WithStaticAssets();

app.Run();

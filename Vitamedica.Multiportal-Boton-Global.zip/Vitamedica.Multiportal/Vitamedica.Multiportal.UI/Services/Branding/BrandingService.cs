using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Vitamedica.Multiportal.UI.Models.ViewModels;

namespace Vitamedica.Multiportal.UI.Services.Branding;

public sealed class BrandingOptions
{
    public const string SectionName = "Branding";

    public string SystemName { get; set; } = "Multiportal";
    public string CompanyName { get; set; } = "Vitamédica";
    public string LegalName { get; set; } = "Vitamédica — Administradora de Servicios de Salud";
    public string AddressLine { get; set; } = string.Empty;
    public string Version { get; set; } = "1.0.0";

    public bool ShowChangePassword { get; set; }

    public IDictionary<string, string> SystemNameByClient { get; set; } = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
}

/// <summary>Resuelve la identidad institucional de la petición actual.</summary>
public interface IBrandingService
{
    BrandingViewModel GetBranding(HttpContext httpContext);
}

public sealed class BrandingService(IOptions<BrandingOptions> options) : IBrandingService
{
    private readonly BrandingOptions _options = options.Value;

    public BrandingViewModel GetBranding(HttpContext httpContext)
    {
        return new BrandingViewModel
        {
            SystemName = ResolveSystemName(httpContext),
            CompanyName = _options.CompanyName,
            LegalName = _options.LegalName,
            AddressLine = _options.AddressLine,
            Version = _options.Version,
            Year = DateTime.Now.Year
        };
    }

    private string ResolveSystemName(HttpContext httpContext)
    {
        var fromClaim = httpContext.User.FindFirst("system_name")?.Value;
        if (!string.IsNullOrWhiteSpace(fromClaim))
        {
            return fromClaim;
        }

        var host = httpContext.Request.Host.Host;
        if (!string.IsNullOrEmpty(host) &&
            _options.SystemNameByClient.TryGetValue(host, out var byClient) &&
            !string.IsNullOrWhiteSpace(byClient))
        {
            return byClient;
        }

        return _options.SystemName;
    }
}

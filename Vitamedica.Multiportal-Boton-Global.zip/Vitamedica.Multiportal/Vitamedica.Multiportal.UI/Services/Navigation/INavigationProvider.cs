using Vitamedica.Multiportal.UI.Models.ViewModels;

namespace Vitamedica.Multiportal.UI.Services.Navigation;

public interface INavigationProvider
{
    /// <summary>Devuelve el árbol de navegación SIN estado activo. Debe devolver una
    /// instancia nueva en cada llamada para que el marcado por petición sea seguro.</summary>
    IReadOnlyList<MenuItemViewModel> GetMenu();
}

public sealed class StaticNavigationProvider : INavigationProvider
{
    public IReadOnlyList<MenuItemViewModel> GetMenu() =>
    [
        new MenuItemViewModel
        {
            Key = "tablero",
            Text = "Tablero",
            Icon = "layout-dashboard",
            Controller = "Reembolsos",
            Action = "Index"
        },
        new MenuItemViewModel
        {
            Key = "clientes",
            Text = "Clientes",
            Icon = "users",
            Children =
            [
                new MenuItemViewModel
                {
                    Key = "cliente-gm",
                    Text = "Grupo Modelo",
                    Icon = "user",
                    Controller = "Home",
                    Action = "ReembolsoSolicitud"
                },
                new MenuItemViewModel
                {
                    Key = "cliente-aon",
                    Text = "Smurfit",
                    Icon = "user",
                    Controller = "Home",
                    Action = "PagoSolicitud"
                }
            ]
        },
        new MenuItemViewModel
        {
            Key = "configuracion",
            Text = "Configuración",
            Icon = "cog",
            Controller = "Clientes",
            Action = "Index"
        },
        new MenuItemViewModel
        {
            Key = "cuentas-bancarias",
            Text = "Cuentas Bancarias",
            Icon = "landmark",
            Controller = "CuentasBancarias",
            Action = "Index"
        },
        new MenuItemViewModel
        {
            Key = "asegurado",
            Text = "Asegurado",
            Icon = "shield-user",
            Controller = "Home",
            Action = "Asegurado"
        }
        //new MenuItemViewModel
        //{
        //    Key = "reembolsos",
        //    Text = "Reembolsos",
        //    Icon = "receipt",
        //    Children =
        //    [
        //        new MenuItemViewModel
        //        {
        //            Key = "reembolsos-nueva",
        //            Text = "Nueva solicitud",
        //            Icon = "file-plus",
        //            Controller = "Home",
        //            Action = "ReembolsoSolicitud"
        //        },
        //        new MenuItemViewModel
        //        {
        //            Key = "reembolsos-retroceder",
        //            Text = "Retroceder trámite",
        //            Icon = "undo-2",
        //            Controller = "Home",
        //            Action = "Retroceder"
        //        },
        //        new MenuItemViewModel
        //        {
        //            Key = "reembolsos-pagos",
        //            Text = "Pagos",
        //            Icon = "wallet",
        //            Controller = "Home",
        //            Action = "Pagos"
        //        },
        //        new MenuItemViewModel
        //        {
        //            Key = "reembolsos-consultar",
        //            Text = "Consultar solicitudes",
        //            Icon = "search",
        //            Controller = "Home",
        //            Action = "Consultar"
        //        }
        //    ]
        //}
    ];
}

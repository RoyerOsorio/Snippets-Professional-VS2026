namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class SolicitudReembolsoResultadoViewModel
{
    /// <summary>Las solicitudes de la página actual únicamente (ya paginadas), no el total.</summary>
    public IReadOnlyList<SolicitudReembolsoResumenViewModel> Solicitudes { get; set; } = new List<SolicitudReembolsoResumenViewModel>();

    /// <summary>Página actual, 1-based. Siempre queda dentro de [1, TotalPaginas].</summary>
    public int Pagina { get; set; } = 1;

    /// <summary>Tamaño de página solicitado (10/25/50/100 en la UI actual).</summary>
    public int TamanioPagina { get; set; } = 25;

    /// <summary>Total de solicitudes que cumplen el filtro aplicado (antes de paginar).</summary>
    public int TotalRegistros { get; set; }

    /// <summary>Total de páginas resultantes. Nunca menor a 1, incluso sin resultados.</summary>
    public int TotalPaginas { get; set; } = 1;
}

namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class FilialViewModel
{
    public int? Id { get; set; } // SBGR_NID

    public string? NombreORazonSocial { get; set; } // SBGR_DESCASEGURADORA
    public string? Rfc { get; set; } // SBGR_RFC
    public string? Telefono { get; set; } // SBGR_TELEFONO
    public string? Direccion { get; set; } // SBGR_DIRECCION
    public string? NombreContacto { get; set; } // SBGR_NOMCONTACTO
    public string? DescripcionCorta { get; set; } // SBGR_DESCRIPCION_CORTA
}

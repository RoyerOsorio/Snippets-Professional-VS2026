namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class CuentaBancariaFormViewModel
{
    
    public int? Id { get; set; }

    public string? Poliza { get; set; }
    public string? Cliente { get; set; }
    public string? Banco { get; set; }
    public string? Clabe { get; set; }
    public string? Titular { get; set; }
    public bool EsPrincipal { get; set; }
}

namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class CuentaBancariaFiltroViewModel
{
    public string? Poliza { get; set; }
    public string? Banco { get; set; }
    public string? Estatus { get; set; }
}

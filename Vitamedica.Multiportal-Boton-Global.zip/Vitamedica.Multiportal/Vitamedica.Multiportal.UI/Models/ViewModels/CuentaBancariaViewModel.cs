namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class CuentaBancariaViewModel
{
    public int Id { get; set; }
        
    public string Poliza { get; set; } = string.Empty;
        
    public string Cliente { get; set; } = string.Empty;

    public string Banco { get; set; } = string.Empty;
    public string ClaveBanco { get; set; } = string.Empty;
        
    public string Clabe { get; set; } = string.Empty;
        
    public string Titular { get; set; } = string.Empty;

    public string Estatus { get; set; } = "Activa";

    public bool EsPrincipal { get; set; }

    public DateTime FechaAlta { get; set; }
    public DateTime? FechaModificacion { get; set; }

    public string ClabeEnmascarada =>
        Clabe.Length >= 4
            ? new string('•', Math.Max(0, Clabe.Length - 4)) + " " + Clabe[^4..]
            : Clabe;
}

namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class SolicitudReembolsoResumenViewModel
{
    /// <summary>Identificador de la solicitud. Habilita el enlace a
    /// Reembolsos/Detalle/{id}; ReembolsosController.Detalle() todavía no lo
    /// consume (queda para una fase posterior).</summary>
    public int Id { get; set; }

    public string Folio { get; set; } = string.Empty;
    public string Poliza { get; set; } = string.Empty;
    public string NombreBeneficiario { get; set; } = string.Empty;
    public string Parentesco { get; set; } = string.Empty;
    public decimal Monto { get; set; }
    public DateTime Fecha { get; set; }
    public string EstacionActual { get; set; } = string.Empty;

    /// <summary>"En proceso" | "Corregido" | "Aprobado" | "Rechazado". El mapeo a
    /// clase CSS/ícono del badge es presentación pura y se resuelve en la vista.</summary>
    public string Estatus { get; set; } = string.Empty;

    /// <summary>"GMM Mayor" | "GMM Menor" | "Dental" | "Maternidad". Solo para el filtro "Cobertura".</summary>
    public string Cobertura { get; set; } = string.Empty;

    /// <summary>"Ordinario" | "Urgencia" | "Maternidad". Solo para el filtro "Flujo".</summary>
    public string Flujo { get; set; } = string.Empty;

    /// <summary>Folio fiscal (CFDI) simulado. Solo para el filtro "Folio fiscal".</summary>
    public string FolioFiscal { get; set; } = string.Empty;
        
    public string Nota { get; set; } = string.Empty;

    /// <summary>Autor de <see cref="Nota"/>. Vacío si Nota también lo está.</summary>
    public string AutorNota { get; set; } = string.Empty;

    /// <summary>Fecha/hora de <see cref="Nota"/>. Null si Nota está vacía.</summary>
    public DateTime? FechaNota { get; set; }
}

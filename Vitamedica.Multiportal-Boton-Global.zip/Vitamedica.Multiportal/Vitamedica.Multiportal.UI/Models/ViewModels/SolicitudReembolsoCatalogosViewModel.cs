namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class SolicitudReembolsoCatalogosViewModel
{
    public IReadOnlyList<CategoriaReclamacionViewModel> Categorias { get; set; } = new List<CategoriaReclamacionViewModel>();
    public IReadOnlyList<string> MotivosConsulta { get; set; } = new List<string>();
    public IReadOnlyList<MonedaViewModel> Monedas { get; set; } = new List<MonedaViewModel>();
}

public class CategoriaReclamacionViewModel
{
    public string Key { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public string Icono { get; set; } = string.Empty;
    public bool TieneMotivo { get; set; }

    /// <summary>"estandar" (carga de PDF/XML) o "multimoneda" (líneas de factura con Moneda/Fecha/Monto).</summary>
    public string TipoFactura { get; set; } = "estandar";

    public IReadOnlyList<DocumentoReclamacionViewModel> Documentos { get; set; } = new List<DocumentoReclamacionViewModel>();
}

public class DocumentoReclamacionViewModel
{
    public string Nombre { get; set; } = string.Empty;
    public bool Requerido { get; set; }
}

public class MonedaViewModel
{
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;

    public string Texto => $"{Codigo} - {Nombre}";
}

namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class PagoFiltroViewModel
{
    public string? Folio { get; set; }
    public DateTime? FechaDesde { get; set; }
    public DateTime? FechaHasta { get; set; }
}

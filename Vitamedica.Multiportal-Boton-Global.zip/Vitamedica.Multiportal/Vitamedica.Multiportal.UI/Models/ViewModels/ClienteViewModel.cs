namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class ClienteViewModel
{
    public int? Id { get; set; } // GRGR_NID

    public string? NombreORazonSocial { get; set; } // GRGR_DESCASEGURADORA
    public string? Rfc { get; set; } // GRGR_RFC
    public string? Direccion { get; set; } // GRGR_DIRECCION
    public string? Telefono { get; set; } // GRGR_TELEFONO
    public string? NombreContacto { get; set; } // GRGR_NOMCONTACTO
    public string? TelefonoContacto { get; set; } // GRGR_TELCONTACTO
    public string? TelefonoInterior { get; set; } // GRGR_TEL_INTERIOR
    public string? TelefonoAtencion { get; set; } // GRGR_TELATENCION
    public string? DescripcionCorta { get; set; } // GRGR_DESCRIPCION_CORTA
    public string? FechaCorte { get; set; } // GRGR_FECHA_CORTE
    public string? FechaDiaHabil { get; set; } // GRGR_FECHA_DIA_HABIL
    public string? PrestadorServicio { get; set; } // GRGR_PRESTADOR_SERVICIO
    public bool ImprimeCredencial { get; set; } // GRGR_IMPRIME_CREDENCIAL

    /// <summary>Solo lectura fuera de este formulario. Activo por defecto al crear.</summary>
    public string Estatus { get; set; } = "Activo"; // GRGR_ESTATUS

    public List<FilialViewModel> Filiales { get; set; } = new();

    public List<int> ModulosSeleccionados { get; set; } = new();
    public List<int> CoberturasSeleccionadas { get; set; } = new();
    public List<int> DocumentosSeleccionados { get; set; } = new();

    public List<ModuloCatalogoItem> CatalogoModulos { get; set; } = new();
    public List<CoberturaCatalogoItem> CatalogoCoberturas { get; set; } = new();
    public List<DocumentoCatalogoItem> CatalogoDocumentos { get; set; } = new();
}

/// <summary>Catálogo simulado de Módulos. Ver <see cref="ClienteViewModel"/> para contexto.</summary>
public class ModuloCatalogoItem
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
}

/// <summary>
/// Catálogo simulado de Coberturas. Independiente del catálogo de Módulos —
/// sin relación entre ambos. Es padre de <see cref="DocumentoCatalogoItem"/>.
/// </summary>
public class CoberturaCatalogoItem
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
}

/// <summary>Catálogo simulado de Documentos requeridos, relacionado a su Cobertura por <see cref="CoberturaId"/>.</summary>
public class DocumentoCatalogoItem
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public int CoberturaId { get; set; }
}

﻿namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class SolicitudReembolsoRegistroViewModel
{
    public AseguradoTitularViewModel AseguradoTitular { get; set; } = new();
    public PacienteViewModel Paciente { get; set; } = new();
    public ReclamacionViewModel Reclamacion { get; set; } = new();
}

public class AseguradoTitularViewModel
{
    public string? NumeroEmpleado { get; set; }
    public string? Nombre { get; set; }
    public string? FechaInicioVigencia { get; set; }
    public string? FechaFinVigencia { get; set; }
    public string? MiembroDesde { get; set; }

    public string? CorreoElectronico { get; set; }
    public string? Telefono { get; set; }
    public string? CodigoPostal { get; set; }
    public string? Estado { get; set; }
    public string? Municipio { get; set; }
    public string? FechaInicioPadecimiento { get; set; }
}

public class PacienteViewModel
{
    public string? BeneficiarioId { get; set; }
}

public class ReclamacionViewModel
{
    public IReadOnlyList<CategoriaSolicitadaViewModel> Categorias { get; set; } = new List<CategoriaSolicitadaViewModel>();
    public string? Comentarios { get; set; }
}

public class CategoriaSolicitadaViewModel
{
    public bool Solicitado { get; set; }
    public string? Motivo { get; set; }

    public bool FacturaCargada { get; set; }
    public string? FacturaMetodo { get; set; }
    public string? FacturaArchivoNombre { get; set; }

    // "multimoneda" (N líneas con Moneda/Fecha, ver Gastos en el Extranjero):
    public IReadOnlyList<FacturaLineaViewModel> FacturaLineas { get; set; } = new List<FacturaLineaViewModel>();
}

public class FacturaLineaViewModel
{
    public string? ArchivoNombre { get; set; }
    public string? Moneda { get; set; }
    public string? FechaServicio { get; set; }
}

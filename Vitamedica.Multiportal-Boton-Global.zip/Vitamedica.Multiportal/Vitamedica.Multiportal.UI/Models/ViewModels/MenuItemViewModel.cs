namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public sealed class MenuItemViewModel
{
    /// <summary>Identificador estable y único del ítem. Se usa para aria-controls y persistencia.</summary>
    public required string Key { get; init; }

    /// <summary>Texto visible del ítem (Sentence case, orientado al usuario).</summary>
    public required string Text { get; init; }

    /// <summary>Nombre del ícono Lucide (atributo data-lucide). Opcional.</summary>
    public string? Icon { get; init; }

    /// <summary>Controller destino (para enlaces de hoja). Nulo en grupos.</summary>
    public string? Controller { get; init; }

    /// <summary>Action destino (para enlaces de hoja). Nulo en grupos.</summary>
    public string? Action { get; init; }

    /// <summary>Area destino (opcional).</summary>
    public string? Area { get; init; }

    /// <summary>URL absoluta opcional (para enlaces externos). Si se define, tiene prioridad sobre Controller/Action.</summary>
    public string? Url { get; init; }

    /// <summary>Texto de badge opcional (ej. contador). No es un color semántico por sí mismo.</summary>
    public string? Badge { get; init; }

    /// <summary>Permiso requerido para ver el ítem (gancho de autorización futura). Nulo = visible para todos.</summary>
    public string? Permission { get; init; }

    /// <summary>Hijos del ítem. Vacío = ítem hoja (enlace).</summary>
    public IReadOnlyList<MenuItemViewModel> Children { get; init; } = Array.Empty<MenuItemViewModel>();

    // --- Estado calculado por petición (no forma parte de la definición) ---

    /// <summary>El ítem hoja corresponde exactamente a la pantalla actual.</summary>
    public bool IsActive { get; set; }

    /// <summary>Algún descendiente está activo (se usa para auto-abrir la rama).</summary>
    public bool HasActiveDescendant { get; set; }

    /// <summary>True si el ítem agrupa otros (no es un enlace directo).</summary>
    public bool IsGroup => Children.Count > 0;

    /// <summary>True si el grupo debe renderizarse abierto (contiene la pantalla activa).</summary>
    public bool IsOpen => HasActiveDescendant;
}

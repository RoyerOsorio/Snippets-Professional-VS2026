namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class AseguradoDetalleViewModel
{
    public int Id { get; set; }
    public string Folio { get; set; } = string.Empty;

    public IReadOnlyList<EstacionDetalleViewModel> Estaciones { get; set; } = new List<EstacionDetalleViewModel>();
}

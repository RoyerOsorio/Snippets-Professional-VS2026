namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class SolicitudReembolsoFiltroViewModel
{
    // Filtros rápidos
    public string? Folio { get; set; }
    public DateTime? FechaDesde { get; set; }
    public DateTime? FechaHasta { get; set; }
    public string? Estatus { get; set; }

    // "Más filtros"
    public string? Poliza { get; set; }
    public string? Cobertura { get; set; }
    public string? Flujo { get; set; }
    public string? FolioFiscal { get; set; }
}

namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class SolicitudReembolsoDetalleViewModel
{
    public int Id { get; set; }
    public string Folio { get; set; } = string.Empty;
    public string Poliza { get; set; } = string.Empty;
    public string NombreBeneficiario { get; set; } = string.Empty;
    public string Parentesco { get; set; } = string.Empty;
    public DateTime Fecha { get; set; }
    public string Estatus { get; set; } = string.Empty;
    public string EstacionActual { get; set; } = string.Empty;

    public decimal Monto { get; set; }

    public string Cobertura { get; set; } = string.Empty;

    public IReadOnlyList<EstacionDetalleViewModel> Estaciones { get; set; } = new List<EstacionDetalleViewModel>();

    public IReadOnlyList<SaldoCoberturaViewModel> SaldoCoberturas { get; set; } = new List<SaldoCoberturaViewModel>();

    public TitularSimuladoViewModel Titular { get; set; } = new();

    public int EdadPaciente { get; set; }

    public string EstadoPaciente { get; set; } = string.Empty;
    public string MunicipioPaciente { get; set; } = string.Empty;
}

public class TitularSimuladoViewModel
{
    public string NumeroEmpleado { get; set; } = string.Empty;

    public string NombreCompleto { get; set; } = string.Empty;
    public string Grupo { get; set; } = string.Empty;
    public string Correo { get; set; } = string.Empty;
    public string Telefono { get; set; } = string.Empty;
    public DateTime FechaInicioVigencia { get; set; }
    public DateTime FechaFinVigencia { get; set; }
    public DateTime MiembroDesde { get; set; }
}

public class SaldoCoberturaViewModel
{
    public string Cobertura { get; set; } = string.Empty;
    public decimal SumaAsegurada { get; set; }
    public decimal SumaPagada { get; set; }
    public decimal SumaReclamada { get; set; }

    public decimal Coaseguro { get; set; }

    public decimal SumaRemanente => Math.Max(0m, SumaAsegurada - (SumaPagada + SumaReclamada));
}

public class EstacionDetalleViewModel
{
    public string Nombre { get; set; } = string.Empty;

    public string Estado { get; set; } = string.Empty;
}

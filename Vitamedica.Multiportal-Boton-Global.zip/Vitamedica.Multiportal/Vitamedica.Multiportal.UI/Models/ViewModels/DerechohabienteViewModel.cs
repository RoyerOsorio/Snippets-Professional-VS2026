namespace Vitamedica.Multiportal.UI.Models.ViewModels;

public class DerechohabienteViewModel
{
    public string NumeroEmpleado { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public string Grupo { get; set; } = string.Empty;
    public string FechaInicioVigencia { get; set; } = string.Empty;
    public string FechaFinVigencia { get; set; } = string.Empty;
    public string MiembroDesde { get; set; } = string.Empty;
    public IReadOnlyList<BeneficiarioViewModel> Beneficiarios { get; set; } = new List<BeneficiarioViewModel>();
}

public class BeneficiarioViewModel
{
    public string Id { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public string Parentesco { get; set; } = string.Empty;
}

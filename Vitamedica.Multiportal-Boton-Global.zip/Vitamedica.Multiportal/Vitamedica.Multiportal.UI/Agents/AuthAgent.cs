﻿using AutoMapper;
using Vitamedica.ActiveDirectory.Model.Service.Response.Usuario;
using Vitamedica.ActiveDirectory.Shared.Models;
using Vitamedica.ActiveDirectory.Shared.ModelsService;
using Vitamedica.Multiportal.UI.Models.ActiveDirectory;

namespace Vitamedica.Multiportal.UI.Agents
{
    public class AuthAgent
    {
        private readonly IActiveDirectoryService _activeDirectoryService;
        public AuthAgent(IActiveDirectoryService activeDirectoryService)
        {
            _activeDirectoryService = activeDirectoryService;
        }

        public VerificacionResumeViewModel VerificaUsuario(string user, string password)
        {
            //var resultExist = _activeDirectoryService.ExisteUsuario(new ActiveDirectory.Model.Service.Request.Usuario.UsuarioVerificacionOperationRequest
            //{
            //    Item = new ActiveDirectory.Model.ViewModels.UsuarioVerificacionResume
            //    {
            //        NombreUsuario = user
            //    }
            //});

            //if (resultExist != null && resultExist.ValidExecution && !resultExist.Item.ExisteUsuario)
            //{
            //    return new VerificacionResumeViewModel
            //    {
            //        Mensaje = "El usuario no existe!",
            //        EsCorrecto = false
            //    };
            //}
            //else if (resultExist != null && !resultExist.ValidExecution)
            //{
            //    return new VerificacionResumeViewModel
            //    {
            //        Mensaje = resultExist.ErrorList[0].Description,
            //        EsCorrecto = false
            //    };
            //}

            //var result = _activeDirectoryService.Autenticar(new ActiveDirectory.Model.Service.Request.Usuario.UsuarioAutenticacionOperationRequest
            //{
            //    Item = new ActiveDirectory.Model.ViewModels.UsuarioAutenticacionResume
            //    {
            //        NombreUsuario = user,
            //        Password = password
            //    }
            //});

            //if (result != null && result.Item != null && result.ValidExecution)
            //{
            //    return new VerificacionResumeViewModel
            //    {
            //        EsAutenticado = result.Item.EsAutenticado,
            //        EsBloqueado = result.Item.EsBloqueado,
            //        ExisteUsuario = result.Item.ExisteUsuario,
            //        NombreUsuario = result.Item.NombreUsuario,
            //        EsCorrecto = true
            //    };
            //}
            //else if (result != null && !result.ValidExecution)
            //{
            //    return new VerificacionResumeViewModel
            //    {
            //        Mensaje = result.ErrorList[0].Description,
            //        EsCorrecto = false
            //    };
            //}
            //else
            //{
            //    return new VerificacionResumeViewModel
            //    {
            //        Mensaje = "Error al consultar proxy",
            //        EsCorrecto = false
            //    };
            //}

            return new VerificacionResumeViewModel
            {
                EsAutenticado = true,
                EsBloqueado = false,
                ExisteUsuario = true,
                NombreUsuario = "Juan Jimenez",
                EsCorrecto = true
            };

        }

        internal TokenValidoResume ValidaToken(string token)
        {
           

            TokenValidoResume result = new TokenValidoResume();
            //CorreoListaArchivoResume modelRequest = Mapper.Map<CorreoListaArchivoResume>(model);

            EmptyRequest request = new EmptyRequest()
            {
                Param = token,
                TipoDato = TipoParametro.String
            };

            TokenValidoResumeOperationResponse response = new TokenValidoResumeOperationResponse();

            response = _activeDirectoryService.ValidaToken(request);            

            if (response.ValidExecution && response.Item != null)
            {
                result = new TokenValidoResume
                {
                    ApellidoMaterno = response.Item.ApellidoMaterno,
                    ApellidoPaterno = response.Item.ApellidoPaterno,
                    Clave = response.Item.Clave,
                    CorreoElectronico = response.Item.CorreoElectronico,
                    EsTokenValido = response.Item.EsTokenValido,
                    GrgrCk = response.Item.GrgrCk,
                    MemeCk = response.Item.MemeCk,
                    Nombre = response.Item.Nombre,
                    NombreCompleto = response.Item.NombreCompleto,
                    NombreORazonSocial = response.Item.NombreORazonSocial,
                    NombreUsuario = response.Item.NombreUsuario,
                    NominaEmpleado = response.Item.NominaEmpleado,
                    PrprId = response.Item.PrprId,
                    RFC = response.Item.RFC,
                    TipoUsuario = (int)response.Item.TipoUsuario
                };
            }
            else
            {
                foreach (var item in response.ErrorList)
                {
                    result.Mensaje = item.Description;
                }
            }

            result.EsCorrecto = response.ValidExecution;

            return result;
        }
    }
}

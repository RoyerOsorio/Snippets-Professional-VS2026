using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Vitamedica.Multiportal.UI.Models.ViewModels;

namespace Vitamedica.Multiportal.UI.Controllers
{
    
    [Authorize]
    public class CuentasBancariasController : Controller
    {
        private const int TamanioPaginaPorDefecto = 25;

        public IActionResult Index()
        {
            var resultado = Paginar(ObtenerCuentasSimuladas(), pagina: 1, tamanioPagina: TamanioPaginaPorDefecto);
            return View(resultado);
        }

        [HttpGet]
        public IActionResult Buscar(CuentaBancariaFiltroViewModel filtro, int pagina = 1, int tamanioPagina = TamanioPaginaPorDefecto)
        {
            var filtrado = AplicarFiltro(ObtenerCuentasSimuladas(), filtro);
            var resultado = Paginar(filtrado, pagina, tamanioPagina);
            return PartialView("Partials/_ResultadosYPaginacionCuentasBancarias", resultado);
        }

        public IActionResult Crear()
        {
            return View(new CuentaBancariaFormViewModel());
        }

        public IActionResult Detalle(int id)
        {
            var cuenta = ObtenerCuentasSimuladas().FirstOrDefault(c => c.Id == id);
            if (cuenta == null)
                return NotFound();

            var modelo = new CuentaBancariaFormViewModel
            {
                Id = cuenta.Id,
                Poliza = cuenta.Poliza,
                Cliente = cuenta.Cliente,
                Banco = cuenta.Banco,
                Clabe = cuenta.Clabe,
                Titular = cuenta.Titular,
                EsPrincipal = cuenta.EsPrincipal,
            };

            return View(modelo);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Guardar([FromBody] CuentaBancariaFormViewModel modelo)
        {
            if (modelo == null)
                return BadRequest("Cuerpo de la solicitud vacío o mal formado.");

            if (string.IsNullOrWhiteSpace(modelo.Poliza)
                || string.IsNullOrWhiteSpace(modelo.Cliente)
                || string.IsNullOrWhiteSpace(modelo.Banco)
                || string.IsNullOrWhiteSpace(modelo.Titular))
                return BadRequest("Faltan campos requeridos.");

            if (string.IsNullOrWhiteSpace(modelo.Clabe) || modelo.Clabe.Length != 18 || !modelo.Clabe.All(char.IsDigit))
                return BadRequest("La Clabe interbancaria debe tener exactamente 18 dígitos.");

            if (!ClavesBancoSimuladas.ContainsKey(modelo.Banco))
                return BadRequest("Banco no reconocido.");

            var id = modelo.Id ?? new Random().Next(100, 999);
            return Json(new { ok = true, id });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CambiarEstado(int id, string accion)
        {
            if (accion != "Desactivar" && accion != "Reactivar")
                return BadRequest("Acción no reconocida.");

            var cuenta = ObtenerCuentasSimuladas().FirstOrDefault(c => c.Id == id);
            if (cuenta == null)
                return NotFound();

            var nuevoEstado = accion == "Desactivar" ? "Inactiva" : "Activa";
            return Json(new { ok = true, nuevoEstado });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult MarcarPrincipal(int id)
        {
            var cuenta = ObtenerCuentasSimuladas().FirstOrDefault(c => c.Id == id);
            if (cuenta == null)
                return NotFound();

            if (cuenta.Estatus != "Activa")
                return BadRequest("Solo una cuenta activa puede marcarse como principal.");

            return Json(new { ok = true, poliza = cuenta.Poliza });
        }

        private static readonly Dictionary<string, string> ClavesBancoSimuladas = new()
        {
            ["BBVA"] = "012",
            ["Santander"] = "014",
            ["Banorte"] = "072",
            ["HSBC"] = "021",
            ["Banamex"] = "002",
        };

        private static List<CuentaBancariaViewModel> ObtenerCuentasSimuladas() => new()
        {
            new CuentaBancariaViewModel
            {
                Id = 1,
                Poliza = "38603787",
                Cliente = "Grupo Modelo",
                Banco = "BBVA",
                ClaveBanco = "012",
                Clabe = "012180001234567895",
                Titular = "Carlos Moncayo Espinosa",
                Estatus = "Activa",
                EsPrincipal = true,
                FechaAlta = new DateTime(2026, 3, 12),
                FechaModificacion = null
            },
            new CuentaBancariaViewModel
            {
                Id = 2,
                Poliza = "38603787",
                Cliente = "Grupo Modelo",
                Banco = "Santander",
                ClaveBanco = "014",
                Clabe = "014180009876543211",
                Titular = "Carlos Moncayo Espinosa",
                Estatus = "Inactiva",
                EsPrincipal = false,
                FechaAlta = new DateTime(2025, 11, 4),
                FechaModificacion = new DateTime(2026, 3, 12)
            },
            new CuentaBancariaViewModel
            {
                Id = 3,
                Poliza = "32183470",
                Cliente = "Grupo Modelo",
                Banco = "Banorte",
                ClaveBanco = "072",
                Clabe = "072180004455667783",
                Titular = "Jáder Medina",
                Estatus = "Activa",
                EsPrincipal = true,
                FechaAlta = new DateTime(2026, 1, 22),
                FechaModificacion = null
            },
            new CuentaBancariaViewModel
            {
                Id = 4,
                Poliza = "32195643",
                Cliente = "Smurfit",
                Banco = "BBVA",
                ClaveBanco = "012",
                Clabe = "012320011223344556",
                Titular = "Mariana Isabel Cordero Luna",
                Estatus = "Activa",
                EsPrincipal = true,
                FechaAlta = new DateTime(2026, 5, 2),
                FechaModificacion = null
            },
            new CuentaBancariaViewModel
            {
                Id = 5,
                Poliza = "38612078",
                Cliente = "Grupo Modelo",
                Banco = "HSBC",
                ClaveBanco = "021",
                Clabe = "021180002233445567",
                Titular = "Emilio Rodrigo Vargas Nuño",
                Estatus = "Activa",
                EsPrincipal = false,
                FechaAlta = new DateTime(2026, 6, 18),
                FechaModificacion = null
            },
            new CuentaBancariaViewModel
            {
                Id = 6,
                Poliza = "38634512",
                Cliente = "Grupo Modelo",
                Banco = "Banamex",
                ClaveBanco = "002",
                Clabe = "002180007766554432",
                Titular = "Iván Alberto Reséndiz Cano",
                Estatus = "Inactiva",
                EsPrincipal = false,
                FechaAlta = new DateTime(2025, 8, 30),
                FechaModificacion = new DateTime(2026, 2, 14)
            },
        };

        private static List<CuentaBancariaViewModel> AplicarFiltro(
            List<CuentaBancariaViewModel> cuentas,
            CuentaBancariaFiltroViewModel filtro)
        {
            IEnumerable<CuentaBancariaViewModel> query = cuentas;

            if (!string.IsNullOrWhiteSpace(filtro.Poliza))
                query = query.Where(c => c.Poliza.Contains(filtro.Poliza, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.Banco) && filtro.Banco != "Todos")
                query = query.Where(c => string.Equals(c.Banco, filtro.Banco, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.Estatus) && filtro.Estatus != "Todos")
                query = query.Where(c => string.Equals(c.Estatus, filtro.Estatus, StringComparison.OrdinalIgnoreCase));

            return query.ToList();
        }

        private static CuentaBancariaResultadoViewModel Paginar(
            List<CuentaBancariaViewModel> cuentas,
            int pagina,
            int tamanioPagina)
        {
            if (tamanioPagina <= 0)
                tamanioPagina = TamanioPaginaPorDefecto;

            var totalRegistros = cuentas.Count;
            var totalPaginas = totalRegistros == 0
                ? 1
                : (int)Math.Ceiling(totalRegistros / (double)tamanioPagina);

            if (pagina < 1)
                pagina = 1;
            if (pagina > totalPaginas)
                pagina = totalPaginas;

            var cuentasPagina = cuentas
                .Skip((pagina - 1) * tamanioPagina)
                .Take(tamanioPagina)
                .ToList();

            return new CuentaBancariaResultadoViewModel
            {
                Cuentas = cuentasPagina,
                Pagina = pagina,
                TamanioPagina = tamanioPagina,
                TotalRegistros = totalRegistros,
                TotalPaginas = totalPaginas,
            };
        }
    }
}

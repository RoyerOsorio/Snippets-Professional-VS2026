﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Vitamedica.Multiportal.UI.Models.ViewModels;

namespace Vitamedica.Multiportal.UI.Controllers
{
    [Authorize]
    public class ClientesController : Controller
    {
        public IActionResult Index()
        {
            var clientes = new List<ClienteViewModel>
            {
                new ClienteViewModel
                {
                    Id = 1,
                    NombreORazonSocial = "Grupo Modelo",
                    Rfc = "GMO850101AB1",
                    Telefono = "3336012000",
                    NombreContacto = "Laura Fuentes",
                    DescripcionCorta = "GRPMOD",
                    Estatus = "Activo"
                },
                new ClienteViewModel
                {
                    Id = 2,
                    NombreORazonSocial = "Smurfit",
                    Rfc = "SKP970615C22",
                    Telefono = "5555230000",
                    NombreContacto = "Roberto Díaz",
                    DescripcionCorta = "SMURFIT",
                    Estatus = "Activo"
                },
                new ClienteViewModel
                {
                    Id = 3,
                    NombreORazonSocial = "Cliente Demo Inactivo",
                    Rfc = "CDI010101X11",
                    Telefono = "5511112222",
                    NombreContacto = "Ana Torres",
                    DescripcionCorta = "DEMOINA",
                    Estatus = "Inactivo"
                }
            };

            return View(clientes);
        }

        public IActionResult Crear()
        {
            var cliente = new ClienteViewModel { ModulosSeleccionados = new List<int> { 1 } };
            CargarCatalogosModuloCoberturaDocumento(cliente);
            return View(cliente);
        }

        public IActionResult Detalle(int id)
        {
            var cliente = new ClienteViewModel
            {
                Id = id,
                NombreORazonSocial = "Grupo Modelo",
                Rfc = "GMO850101AB1",
                Direccion = "Av. Revolución 1000, Guadalajara, Jalisco",
                Telefono = "3336012000",
                NombreContacto = "Laura Fuentes",
                TelefonoContacto = "3336012001",
                TelefonoInterior = "102",
                TelefonoAtencion = "018001234567",
                DescripcionCorta = "GRPMOD",
                FechaCorte = "25/07/2026",
                FechaDiaHabil = "05/08/2026",
                PrestadorServicio = "Bupa México",
                ImprimeCredencial = true,
                Estatus = "Activo",
                Filiales = new List<FilialViewModel>
                {
                    new FilialViewModel
                    {
                        Id = 1,
                        NombreORazonSocial = "Grupo Modelo — Planta Guadalajara",
                        Rfc = "GMO850101AB2",
                        Telefono = "3336012050",
                        NombreContacto = "Mario Solís",
                        DescripcionCorta = "GDL"
                    }
                },
                ModulosSeleccionados = new List<int> { 1, 3 },
                CoberturasSeleccionadas = new List<int> { 1, 4 },
                DocumentosSeleccionados = new List<int> { 1, 2, 8 }
            };

            CargarCatalogosModuloCoberturaDocumento(cliente);
            return View(cliente);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Guardar([FromBody] ClienteViewModel modelo)
        {
            if (modelo == null)
                return BadRequest("Cuerpo de la solicitud vacío o mal formado.");

            if (string.IsNullOrWhiteSpace(modelo.NombreORazonSocial)
                || string.IsNullOrWhiteSpace(modelo.Rfc)
                || string.IsNullOrWhiteSpace(modelo.Telefono)
                || string.IsNullOrWhiteSpace(modelo.NombreContacto)
                || string.IsNullOrWhiteSpace(modelo.DescripcionCorta))
                return BadRequest("Faltan campos requeridos de Sección 1.");

            if (modelo.ModulosSeleccionados.Count == 0 || modelo.CoberturasSeleccionadas.Count == 0 || modelo.DocumentosSeleccionados.Count == 0)
                return BadRequest("Debe seleccionar al menos un Módulo, una Cobertura y un Documento.");

            var id = modelo.Id ?? new Random().Next(100, 999);
            return Json(new { ok = true, id });
        }
                
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CambiarEstado(int id, string accion)
        {
            if (accion != "Desactivar" && accion != "Reactivar")
                return BadRequest("Acción no reconocida.");

            var nuevoEstado = accion == "Desactivar" ? "Inactivo" : "Activo";
            return Json(new { ok = true, nuevoEstado });
        }

        private static void CargarCatalogosModuloCoberturaDocumento(ClienteViewModel vm)
        {
            vm.CatalogoModulos = ObtenerModulosSimulados();
            vm.CatalogoCoberturas = ObtenerCoberturasSimuladas();
            vm.CatalogoDocumentos = ObtenerDocumentosSimulados();
        }

        private static List<ModuloCatalogoItem> ObtenerModulosSimulados() => new()
        {
            new ModuloCatalogoItem { Id = 1, Nombre = "Carga de Documentos" },
            new ModuloCatalogoItem { Id = 2, Nombre = "Dictamen Administrativo" },
            new ModuloCatalogoItem { Id = 3, Nombre = "Dictamen Medico" },
            new ModuloCatalogoItem { Id = 4, Nombre = "Pagos" },
            new ModuloCatalogoItem { Id = 5, Nombre = "Cuentas Bancarias" }
        };

        private static List<CoberturaCatalogoItem> ObtenerCoberturasSimuladas() => new()
        {
            new CoberturaCatalogoItem { Id = 1, Nombre = "Consultas" },
            new CoberturaCatalogoItem { Id = 2, Nombre = "Medicamentos" },
            new CoberturaCatalogoItem { Id = 3, Nombre = "Vacunas" },
            new CoberturaCatalogoItem { Id = 4, Nombre = "Laboratorio y Gabinete" },
            new CoberturaCatalogoItem { Id = 5, Nombre = "Cuidados Preventivos" },
            new CoberturaCatalogoItem { Id = 6, Nombre = "Exámenes de Audición" },
            new CoberturaCatalogoItem { Id = 7, Nombre = "Lentes" },
            new CoberturaCatalogoItem { Id = 8, Nombre = "Gastos en el Extranjero" }
        };

        private static List<DocumentoCatalogoItem> ObtenerDocumentosSimulados() => new()
        {
            new DocumentoCatalogoItem { Id = 1, Nombre = "Receta Médica", CoberturaId = 1 },
            new DocumentoCatalogoItem { Id = 2, Nombre = "Orden Médica", CoberturaId = 1 },
            new DocumentoCatalogoItem { Id = 3, Nombre = "Factura XML / PDF", CoberturaId = 1 },
            new DocumentoCatalogoItem { Id = 4, Nombre = "Receta Médica", CoberturaId = 2 },
            new DocumentoCatalogoItem { Id = 5, Nombre = "Factura XML / PDF", CoberturaId = 2 },
            new DocumentoCatalogoItem { Id = 6, Nombre = "Receta Médica", CoberturaId = 3 },
            new DocumentoCatalogoItem { Id = 7, Nombre = "Orden Médica", CoberturaId = 3 },
            new DocumentoCatalogoItem { Id = 8, Nombre = "Factura XML / PDF", CoberturaId = 3 },
            new DocumentoCatalogoItem { Id = 9, Nombre = "Orden Médica", CoberturaId = 4 },
            new DocumentoCatalogoItem { Id = 10, Nombre = "Factura XML / PDF", CoberturaId = 4 },
            new DocumentoCatalogoItem { Id = 11, Nombre = "Orden Médica", CoberturaId = 5 },
            new DocumentoCatalogoItem { Id = 12, Nombre = "Factura XML / PDF", CoberturaId = 5 },
            new DocumentoCatalogoItem { Id = 13, Nombre = "Orden Médica", CoberturaId = 6 },
            new DocumentoCatalogoItem { Id = 14, Nombre = "Factura XML / PDF", CoberturaId = 6 },
            new DocumentoCatalogoItem { Id = 15, Nombre = "Receta Médica", CoberturaId = 7 },
            new DocumentoCatalogoItem { Id = 16, Nombre = "Factura XML / PDF", CoberturaId = 7 },
            new DocumentoCatalogoItem { Id = 17, Nombre = "Factura Hospital", CoberturaId = 8 },
            new DocumentoCatalogoItem { Id = 18, Nombre = "Factura XML / PDF", CoberturaId = 8 }
        };

    }
}

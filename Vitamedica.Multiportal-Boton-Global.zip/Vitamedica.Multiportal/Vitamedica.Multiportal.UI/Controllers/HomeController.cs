using System.Diagnostics;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
//using Vitamedica.Multiportal.Application.Interfaces;
using Vitamedica.Multiportal.UI.Models;
using Vitamedica.Multiportal.UI.Models.ActiveDirectory;
using Vitamedica.Multiportal.UI.Models.ViewModels;
using Vitamedica.Multiportal.UI.Services;

namespace Vitamedica.Multiportal.UI.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly MultiportalApiClient _multiportalApiClient;
        
        public HomeController(MultiportalApiClient multiportalApiClient)
        {
            _multiportalApiClient = multiportalApiClient;
        }
        
        public async Task<IActionResult> Index()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
            {
                try
                {
                    return View();

                    //string name = User.FindFirstValue(ClaimTypes.Name) ?? string.Empty;

                    //var _user = await _multiportalApiClient.GetUserProfile(name);
                    //if(_user != null)
                    //    return View(new UserProfile
                    //    {
                    //        ApellidoMaterno = _user.ApellidoMaterno,
                    //        ApellidoPaterno = _user.ApellidoPaterno,
                    //        Clave = _user.Clave,
                    //        CorreoElectronico = _user.CorreoElectronico,
                    //        GrgrCk = _user.GrgrCk,
                    //        MemeCk = _user.MemeCk,
                    //        Nombre = _user.Nombre,
                    //        NombreCompleto = _user.NombreCompleto,
                    //        NombreORazonSocial = _user.NombreORazonSocial,
                    //        NombreUsuario = _user.NombreUsuario,
                    //        NominaEmpleado = _user.NominaEmpleado,
                    //        PrprId = _user.PrprId,
                    //        RFC = _user.RFC,
                    //        TipoUsuario = _user.TipoUsuario,
                    //        TipoUsuarioDescripcion = _user.TipoUsuarioDescripcion
                    //    });

                    //var _user = _activeDirectoryApplication.GetUser(name);
                    //if (_user != null)
                    //    return View(new UserProfile
                    //    {
                    //        ApellidoMaterno = _user.ApellidoMaterno,
                    //        ApellidoPaterno = _user.ApellidoPaterno,
                    //        Clave = _user.Clave,
                    //        CorreoElectronico = _user.CorreoElectronico,
                    //        GrgrCk = _user.GrgrCk,
                    //        MemeCk = _user.MemeCk,
                    //        Nombre = _user.Nombre,
                    //        NombreCompleto = _user.NombreCompleto,
                    //        NombreORazonSocial = _user.NombreORazonSocial,
                    //        NombreUsuario = _user.NombreUsuario,
                    //        NominaEmpleado = _user.NominaEmpleado,
                    //        PrprId = _user.PrprId,
                    //        RFC = _user.RFC,
                    //        TipoUsuario = (ActiveDirectory.Model.ViewModels.TipoUsuario)_user.TipoUsuario,
                    //        TipoUsuarioDescripcion = _user.TipoUsuarioDescripcion
                    //    });
                }
                catch (Exception ex)
                {

                }
            }
            return View(new UserProfile());
        }

        public IActionResult Asegurado(int id)
        {
            var folio = ObtenerFoliosAseguradoSimulados().FirstOrDefault(f => f.Id == id);
            if (folio == null)
                return NotFound();

            var detalle = new AseguradoDetalleViewModel
            {
                Id = folio.Id,
                Folio = folio.Folio,
                Estaciones = TraducirAEstaciones(folio.EstacionActual),
            };

            return View(detalle);
        }

        private sealed class FolioAseguradoSimulado
        {
            public int Id { get; init; }
            public string Folio { get; init; } = string.Empty;
            public string EstacionActual { get; init; } = string.Empty;
        }

        private static List<FolioAseguradoSimulado> ObtenerFoliosAseguradoSimulados() => new()
        {
            new FolioAseguradoSimulado { Id = 1, Folio = "0000926100", EstacionActual = "Dictamen administrativo" },
        };

        private static IReadOnlyList<EstacionDetalleViewModel> TraducirAEstaciones(string estacionActual)
        {
            string[] nombres =
            {
                "Recepción de documentos",
                "Dictamen administrativo",
                "Autorización de pago",
                "Pago autorizado",
            };

            var indiceActual = ResolverIndiceEstacion(estacionActual);

            var estaciones = new List<EstacionDetalleViewModel>();
            for (var i = 0; i < nombres.Length; i++)
            {
                var numero = i + 1;
                estaciones.Add(new EstacionDetalleViewModel
                {
                    Nombre = nombres[i],
                    Estado = numero < indiceActual ? "hecho" : numero == indiceActual ? "actual" : "pendiente",
                });
            }

            return estaciones;
        }

        private static int ResolverIndiceEstacion(string estacionActual)
        {
            if (estacionActual.Contains("Recepción", StringComparison.OrdinalIgnoreCase))
                return 1;

            if (estacionActual.Contains("Autorización de pago", StringComparison.OrdinalIgnoreCase))
                return 3;

            if (estacionActual.Contains("Pago autorizado", StringComparison.OrdinalIgnoreCase))
                return 4;

            return 2;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Vitamedica.Multiportal.UI.Models.ViewModels;

namespace Vitamedica.Multiportal.UI.Controllers
{
    [Authorize]
    public class PagosController : Controller
    {
        private const int TamanioPaginaPorDefecto = 25;

        public IActionResult Index()
        {
            var resultado = Paginar(ObtenerPagosSimulados(), pagina: 1, tamanioPagina: TamanioPaginaPorDefecto);
            return View(resultado);
        }

        private const long TamanioMaximoArchivoRetroBytes = 5 * 1024 * 1024;
        private static readonly string[] ExtensionesPermitidasRetro = { ".txt", ".csv", ".xlsx" };

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SubirArchivoRetro(IFormFile archivo)
        {
            if (archivo == null || archivo.Length == 0)
                return BadRequest("No se recibió ningún archivo.");

            if (archivo.Length > TamanioMaximoArchivoRetroBytes)
                return BadRequest("El archivo excede el tamaño máximo permitido (5 MB).");

            var extension = Path.GetExtension(archivo.FileName);
            if (string.IsNullOrEmpty(extension) || !ExtensionesPermitidasRetro.Contains(extension, StringComparer.OrdinalIgnoreCase))
                return BadRequest("Formato de archivo no permitido. Usa .txt, .csv o .xlsx.");

            return Json(new { nombreArchivo = archivo.FileName, tamanioBytes = archivo.Length });
        }

        [HttpGet]
        public IActionResult Buscar(PagoFiltroViewModel filtro, int pagina = 1, int tamanioPagina = TamanioPaginaPorDefecto)
        {
            var filtrado = AplicarFiltro(ObtenerPagosSimulados(), filtro);
            var resultado = Paginar(filtrado, pagina, tamanioPagina);
            return PartialView("Partials/_ResultadosYPaginacionPagos", resultado);
        }

        [HttpGet]
        public IActionResult DescargarLayout(PagoFiltroViewModel filtro)
        {
            var pagos = AplicarFiltro(ObtenerPagosSimulados(), filtro);
            var csv = ConstruirCsvLayoutPagos(pagos);
            var nombreArchivo = $"layout_pagos_{DateTime.Now:yyyyMMdd_HHmmss}.csv";

            var bytes = new byte[] { 0xEF, 0xBB, 0xBF }.Concat(System.Text.Encoding.UTF8.GetBytes(csv)).ToArray();
            return File(bytes, "text/csv", nombreArchivo);
        }

        private static string ConstruirCsvLayoutPagos(List<PagoResumenViewModel> pagos)
        {
            var culturaInvariante = System.Globalization.CultureInfo.InvariantCulture;
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("Folio,Poliza,Titular,Motivo,Monto,Fecha,Complemento");

            foreach (var p in pagos)
            {
                sb.AppendLine(string.Join(",",
                    EscaparCsv(p.Folio),
                    EscaparCsv(p.Poliza),
                    EscaparCsv(p.Titular),
                    EscaparCsv(p.Motivo),
                    p.Monto.ToString("F2", culturaInvariante),
                    p.Fecha.ToString("yyyy-MM-dd"),
                    EscaparCsv(p.Complemento ?? "")));
            }

            return sb.ToString();
        }

        private static string EscaparCsv(string valor)
        {
            if (valor.Contains(',') || valor.Contains('"') || valor.Contains('\n'))
                return "\"" + valor.Replace("\"", "\"\"") + "\"";
            return valor;
        }

        private static List<PagoResumenViewModel> ObtenerPagosSimulados() => new()
        {
            new PagoResumenViewModel { Folio = "0000926100", Poliza = "38603787", Titular = "Carlos Moncayo Espinosa",     Motivo = "Medicamentos",            Monto = 1604.00m,  Fecha = new DateTime(2026, 4, 10), Complemento = "COMP-004471" },
            new PagoResumenViewModel { Folio = "0001126100", Poliza = "38603787", Titular = "Carlos Moncayo Espinosa",     Motivo = "Medicamentos",            Monto = 9913.62m,  Fecha = new DateTime(2026, 4, 10), Complemento = "COMP-004472" },
            new PagoResumenViewModel { Folio = "0001226100", Poliza = "32183470", Titular = "Jáder Medina",                 Motivo = "Laboratorio y Gabinete",  Monto = 4414.00m,  Fecha = new DateTime(2026, 4, 10), Complemento = "COMP-004480" },
            new PagoResumenViewModel { Folio = "0101326141", Poliza = "38602287", Titular = "Ésner Valencia Valencia",      Motivo = "Consultas",               Monto = 2000.00m,  Fecha = new DateTime(2026, 7, 9),  Complemento = null },
            new PagoResumenViewModel { Folio = "0106626184", Poliza = "38603787", Titular = "Carlos Moncayo Espinosa",     Motivo = "Gastos en el Extranjero", Monto = 4470.92m,  Fecha = new DateTime(2026, 7, 9),  Complemento = "COMP-005102" },
            new PagoResumenViewModel { Folio = "0106826184", Poliza = "32141088", Titular = "Alfredo Miguel Riera Losada", Motivo = "Gastos en el Extranjero", Monto = 26203.95m, Fecha = new DateTime(2026, 7, 9),  Complemento = null },
            new PagoResumenViewModel { Folio = "0106926184", Poliza = "32141088", Titular = "Alfredo Miguel Riera Losada", Motivo = "Gastos en el Extranjero", Monto = 17190.70m, Fecha = new DateTime(2026, 7, 9),  Complemento = null },
            new PagoResumenViewModel { Folio = "0107026184", Poliza = "32141088", Titular = "Alfredo Miguel Riera Losada", Motivo = "Lentes",                  Monto = 1500.00m,  Fecha = new DateTime(2026, 7, 9),  Complemento = "COMP-005110" },
            new PagoResumenViewModel { Folio = "0107226184", Poliza = "38603787", Titular = "Carlos Moncayo Espinosa",     Motivo = "Gastos en el Extranjero", Monto = 1773.68m,  Fecha = new DateTime(2026, 7, 9),  Complemento = "COMP-005118" },
            new PagoResumenViewModel { Folio = "0107526189", Poliza = "38603787", Titular = "Carlos Moncayo Espinosa",     Motivo = "Consultas",               Monto = 2500.00m,  Fecha = new DateTime(2026, 7, 9),  Complemento = "COMP-005125" },
            new PagoResumenViewModel { Folio = "0107726189", Poliza = "32195643", Titular = "Mariana Isabel Cordero Luna", Motivo = "Vacunas",                 Monto = 850.00m,   Fecha = new DateTime(2026, 7, 8),  Complemento = "COMP-005130" },
            new PagoResumenViewModel { Folio = "0107826189", Poliza = "32195643", Titular = "Mariana Isabel Cordero Luna", Motivo = "Consultas",               Monto = 1200.00m,  Fecha = new DateTime(2026, 7, 8),  Complemento = null },
            new PagoResumenViewModel { Folio = "0107926189", Poliza = "38612078", Titular = "Emilio Rodrigo Vargas Nuño",  Motivo = "Cuidados Preventivos",    Monto = 3400.00m,  Fecha = new DateTime(2026, 7, 7),  Complemento = "COMP-005134" },
            new PagoResumenViewModel { Folio = "0108026189", Poliza = "38612078", Titular = "Emilio Rodrigo Vargas Nuño",  Motivo = "Medicamentos",            Monto = 640.50m,   Fecha = new DateTime(2026, 7, 7),  Complemento = "COMP-005136" },
            new PagoResumenViewModel { Folio = "0108126189", Poliza = "32178904", Titular = "Ximena Alejandra Torres Campos", Motivo = "Exámenes de Audición", Monto = 980.00m,   Fecha = new DateTime(2026, 7, 6),  Complemento = null },
            new PagoResumenViewModel { Folio = "0108226189", Poliza = "32178904", Titular = "Ximena Alejandra Torres Campos", Motivo = "Lentes",               Monto = 2150.00m,  Fecha = new DateTime(2026, 7, 6),  Complemento = "COMP-005141" },
            new PagoResumenViewModel { Folio = "0108326189", Poliza = "38634512", Titular = "Iván Alberto Reséndiz Cano",  Motivo = "Gastos en el Extranjero", Monto = 8320.00m,  Fecha = new DateTime(2026, 7, 5),  Complemento = "COMP-005145" },
            new PagoResumenViewModel { Folio = "0108426189", Poliza = "38634512", Titular = "Iván Alberto Reséndiz Cano",  Motivo = "Consultas",               Monto = 1500.00m,  Fecha = new DateTime(2026, 7, 5),  Complemento = null },
            new PagoResumenViewModel { Folio = "0108526189", Poliza = "32167823", Titular = "Regina Montserrat Ochoa Lara", Motivo = "Medicamentos",           Monto = 460.00m,   Fecha = new DateTime(2026, 7, 4),  Complemento = "COMP-005150" },
            new PagoResumenViewModel { Folio = "0108626189", Poliza = "32167823", Titular = "Regina Montserrat Ochoa Lara", Motivo = "Laboratorio y Gabinete", Monto = 1980.00m,  Fecha = new DateTime(2026, 7, 4),  Complemento = "COMP-005153" },
            new PagoResumenViewModel { Folio = "0108726189", Poliza = "38645621", Titular = "Gerardo Iván Palacios Meza",  Motivo = "Gastos en el Extranjero", Monto = 14250.00m, Fecha = new DateTime(2026, 7, 3),  Complemento = null },
            new PagoResumenViewModel { Folio = "0108826189", Poliza = "38645621", Titular = "Gerardo Iván Palacios Meza",  Motivo = "Vacunas",                 Monto = 780.00m,   Fecha = new DateTime(2026, 7, 3),  Complemento = "COMP-005159" },
            new PagoResumenViewModel { Folio = "0108926189", Poliza = "32189045", Titular = "Alondra Sofía Miranda Vega",  Motivo = "Consultas",               Monto = 2000.00m,  Fecha = new DateTime(2026, 7, 2),  Complemento = "COMP-005162" },
            new PagoResumenViewModel { Folio = "0109026189", Poliza = "32189045", Titular = "Alondra Sofía Miranda Vega",  Motivo = "Cuidados Preventivos",    Monto = 690.00m,   Fecha = new DateTime(2026, 7, 2),  Complemento = null },
        };

        private static List<PagoResumenViewModel> AplicarFiltro(
            List<PagoResumenViewModel> pagos,
            PagoFiltroViewModel filtro)
        {
            IEnumerable<PagoResumenViewModel> query = pagos;

            if (!string.IsNullOrWhiteSpace(filtro.Folio))
                query = query.Where(p => p.Folio.Contains(filtro.Folio, StringComparison.OrdinalIgnoreCase));

            if (filtro.FechaDesde.HasValue)
                query = query.Where(p => p.Fecha.Date >= filtro.FechaDesde.Value.Date);

            if (filtro.FechaHasta.HasValue)
                query = query.Where(p => p.Fecha.Date <= filtro.FechaHasta.Value.Date);

            return query.ToList();
        }

        private static PagoResultadoViewModel Paginar(
            List<PagoResumenViewModel> pagos,
            int pagina,
            int tamanioPagina)
        {
            if (tamanioPagina <= 0)
                tamanioPagina = TamanioPaginaPorDefecto;

            var totalRegistros = pagos.Count;
            var totalPaginas = totalRegistros == 0
                ? 1
                : (int)Math.Ceiling(totalRegistros / (double)tamanioPagina);

            if (pagina < 1)
                pagina = 1;
            if (pagina > totalPaginas)
                pagina = totalPaginas;

            var pagosPagina = pagos
                .Skip((pagina - 1) * tamanioPagina)
                .Take(tamanioPagina)
                .ToList();

            return new PagoResultadoViewModel
            {
                Pagos = pagosPagina,
                Pagina = pagina,
                TamanioPagina = tamanioPagina,
                TotalRegistros = totalRegistros,
                TotalPaginas = totalPaginas,
            };
        }
    }
}

using MprGestionReclamos.Api.Extensiones;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddProblemDetails();
builder.Services.AddOpenApi();
builder.Services.AgregarServiciosMprGestionReclamos(builder.Configuration);

builder.Services.AddHttpLogging(_ => { });

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpLogging();
app.UseExceptionHandler();

app.MapearEndpointsReclamos();

app.MapGet("/health", () => Results.Ok(new { estado = "MprGestionReclamos operativo" }));

app.Run();

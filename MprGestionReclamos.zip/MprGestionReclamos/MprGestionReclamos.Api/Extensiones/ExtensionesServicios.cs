using MprGestionReclamos.Application.Casos;
using MprGestionReclamos.Application.Puertos;
using MprGestionReclamos.Infrastructure.Extensiones;
using MprGestionReclamos.Infrastructure.Integraciones;

namespace MprGestionReclamos.Api.Extensiones;

public static class ExtensionesServicios
{
    public static IServiceCollection AgregarServiciosMprGestionReclamos(
        this IServiceCollection servicios,
        IConfiguration configuracion)
    {
        servicios.AgregarInfrastructureMprGestionReclamos(configuracion);

        servicios.AddHttpClient<IValidadorDocumentosMprConfiguracionReglas, ValidadorDocumentosMprConfiguracionReglasHttp>(cliente =>
        {
            cliente.BaseAddress = new Uri(configuracion["Servicios:MprConfiguracionReglas:BaseUrl"]!);
        });

        servicios.AddHttpClient<IDocumentosAportadosMprDocumentos, DocumentosAportadosMprDocumentosHttp>(cliente =>
        {
            cliente.BaseAddress = new Uri(configuracion["Servicios:MprDocumentos:BaseUrl"]!);
        });

        servicios.AddScoped<CrearReclamoCasoDeUso>();
        servicios.AddScoped<ObtenerReclamoCasoDeUso>();
        servicios.AddScoped<EnviarReclamoCasoDeUso>();
        servicios.AddScoped<AprobarReclamoCasoDeUso>();
        servicios.AddScoped<RechazarReclamoCasoDeUso>();

        return servicios;
    }
}

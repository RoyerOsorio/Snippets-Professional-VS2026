using MprGestionReclamos.Api.Endpoints.Reclamos;

namespace MprGestionReclamos.Api.Extensiones;

public static class ExtensionesEndpoints
{
    public static void MapearEndpointsReclamos(this WebApplication app)
    {
        var grupo = app.MapGroup("/v1/reclamos").WithTags("Reclamos");

        CrearReclamoEndpoint.Mapear(grupo);
        ObtenerReclamoEndpoint.Mapear(grupo);
        EnviarReclamoEndpoint.Mapear(grupo);
        AprobarReclamoEndpoint.Mapear(grupo);
        RechazarReclamoEndpoint.Mapear(grupo);
    }
}

using MprGestionReclamos.Application.Casos;
using MprGestionReclamos.Contracts.Requests;
using MprGestionReclamos.Domain.Excepciones;

namespace MprGestionReclamos.Api.Endpoints.Reclamos;

public static class RechazarReclamoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapPost("/{reclamoId:int}/rechazar", RechazarAsync).WithName("RechazarReclamo");
    }

    private static async Task<IResult> RechazarAsync(
        int reclamoId,
        RechazarReclamoRequest request,
        RechazarReclamoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            var reclamo = await casoDeUso.EjecutarAsync(reclamoId, request.MotivoRechazo, DateTime.UtcNow, cancellationToken);
            return Results.Ok(CrearReclamoEndpoint.AResponse(reclamo));
        }
        catch (ReclamoNoEncontradoException ex)
        {
            return Results.Problem(title: "Reclamo no encontrado", detail: ex.Message, statusCode: StatusCodes.Status404NotFound);
        }
        catch (TransicionEstadoInvalidaException ex)
        {
            return Results.Problem(title: "Transición de estado inválida", detail: ex.Message, statusCode: StatusCodes.Status409Conflict);
        }
        catch (ArgumentException ex)
        {
            return Results.Problem(title: "Solicitud inválida", detail: ex.Message, statusCode: StatusCodes.Status400BadRequest);
        }
    }
}

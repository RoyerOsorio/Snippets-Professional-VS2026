using MprGestionReclamos.Application.Casos;
using MprGestionReclamos.Domain.Excepciones;

namespace MprGestionReclamos.Api.Endpoints.Reclamos;

public static class ObtenerReclamoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapGet("/{reclamoId:int}", ObtenerAsync).WithName("ObtenerReclamo");
    }

    private static async Task<IResult> ObtenerAsync(
        int reclamoId,
        ObtenerReclamoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            var reclamo = await casoDeUso.EjecutarAsync(reclamoId, cancellationToken);
            return Results.Ok(CrearReclamoEndpoint.AResponse(reclamo));
        }
        catch (ReclamoNoEncontradoException ex)
        {
            return Results.Problem(title: "Reclamo no encontrado", detail: ex.Message, statusCode: StatusCodes.Status404NotFound);
        }
    }
}

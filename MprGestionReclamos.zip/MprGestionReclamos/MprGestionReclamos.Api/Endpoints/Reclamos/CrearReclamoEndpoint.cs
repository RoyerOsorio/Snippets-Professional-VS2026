using MprGestionReclamos.Application.Casos;
using MprGestionReclamos.Contracts.Requests;
using MprGestionReclamos.Contracts.Responses;
using MprGestionReclamos.Domain.Entidades;

namespace MprGestionReclamos.Api.Endpoints.Reclamos;

/// <summary>
/// Consumido por Reimbursement.Orchestrator como tercer paso real de
/// POST /v1/reembolsos/iniciar.
/// </summary>
public static class CrearReclamoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapPost("/", CrearAsync).WithName("CrearReclamo");
    }

    private static async Task<IResult> CrearAsync(
        CrearReclamoRequest request,
        CrearReclamoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        var reclamo = await casoDeUso.EjecutarAsync(
            request.Poliza, request.AseguradoId, request.MotivoId, DateTime.UtcNow, cancellationToken);

        return Results.Created($"/v1/reclamos/{reclamo.Id}", AResponse(reclamo));
    }

    internal static ReclamoResponse AResponse(Application.Dtos.ReclamoDto reclamo) => new(
        reclamo.Id, reclamo.Poliza, reclamo.AseguradoId, reclamo.MotivoId, reclamo.Estado.ToString(),
        reclamo.FechaCreacion, reclamo.FechaEnvio, reclamo.FechaResolucion,
        reclamo.MontoAprobado, reclamo.MotivoRechazo);
}

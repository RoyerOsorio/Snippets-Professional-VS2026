using MprGestionReclamos.Application.Casos;
using MprGestionReclamos.Contracts.Responses;
using MprGestionReclamos.Domain.Excepciones;

namespace MprGestionReclamos.Api.Endpoints.Reclamos;

public static class EnviarReclamoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapPost("/{reclamoId:int}/enviar", EnviarAsync).WithName("EnviarReclamo");
    }

    private static async Task<IResult> EnviarAsync(
        int reclamoId,
        EnviarReclamoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            var resultado = await casoDeUso.EjecutarAsync(reclamoId, DateTime.UtcNow, cancellationToken);

            var respuesta = new EnviarReclamoResponse(
                resultado.Enviado, CrearReclamoEndpoint.AResponse(resultado.Reclamo), resultado.DocumentosFaltantes);

            return resultado.Enviado
                ? Results.Ok(respuesta)
                : Results.UnprocessableEntity(respuesta);
        }
        catch (ReclamoNoEncontradoException ex)
        {
            return Results.Problem(title: "Reclamo no encontrado", detail: ex.Message, statusCode: StatusCodes.Status404NotFound);
        }
        catch (TransicionEstadoInvalidaException ex)
        {
            return Results.Problem(title: "Transición de estado inválida", detail: ex.Message, statusCode: StatusCodes.Status409Conflict);
        }
    }
}

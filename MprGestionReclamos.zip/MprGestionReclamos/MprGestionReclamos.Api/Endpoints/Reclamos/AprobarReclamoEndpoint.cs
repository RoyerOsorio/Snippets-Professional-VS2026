using MprGestionReclamos.Application.Casos;
using MprGestionReclamos.Contracts.Requests;
using MprGestionReclamos.Domain.Excepciones;

namespace MprGestionReclamos.Api.Endpoints.Reclamos;

public static class AprobarReclamoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapPost("/{reclamoId:int}/aprobar", AprobarAsync).WithName("AprobarReclamo");
    }

    private static async Task<IResult> AprobarAsync(
        int reclamoId,
        AprobarReclamoRequest request,
        AprobarReclamoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            var reclamo = await casoDeUso.EjecutarAsync(reclamoId, request.MontoAprobado, DateTime.UtcNow, cancellationToken);
            return Results.Ok(CrearReclamoEndpoint.AResponse(reclamo));
        }
        catch (ReclamoNoEncontradoException ex)
        {
            return Results.Problem(title: "Reclamo no encontrado", detail: ex.Message, statusCode: StatusCodes.Status404NotFound);
        }
        catch (TransicionEstadoInvalidaException ex)
        {
            return Results.Problem(title: "Transición de estado inválida", detail: ex.Message, statusCode: StatusCodes.Status409Conflict);
        }
        catch (ArgumentOutOfRangeException ex)
        {
            return Results.Problem(title: "Monto aprobado inválido", detail: ex.Message, statusCode: StatusCodes.Status400BadRequest);
        }
    }
}

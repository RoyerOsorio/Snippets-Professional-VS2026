using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MprGestionReclamos.Infrastructure.Persistencia;
using RabbitMQ.Client;

namespace MprGestionReclamos.Infrastructure.Mensajeria;

/// <summary>
/// Segunda mitad del patrón Transactional Outbox: sondea periódicamente
/// dbo.MTP_OBOX_MENSAJE por filas no publicadas y las publica a RabbitMQ.
/// Marca cada fila como publicada DESPUÉS de que el broker confirma
/// recepción (publisher confirms) — si el proceso muere entre publicar y
/// marcar, la fila se vuelve a publicar en el siguiente ciclo. Por eso el
/// mensaje incluye OboxNid como MessageId: un consumidor idempotente lo usa
/// para descartar duplicados (ver docs/demo/README.md, sección Outbox/RabbitMQ).
///
/// No se implementa aquí ningún consumidor — MprPagos y MprAuditoria, que
/// serían los consumidores reales, todavía no existen en este repositorio
/// (roadmap). Este servicio solo publica; no se simula un consumidor que
/// no existe.
/// </summary>
public sealed class OutboxPublisherHostedService(
    IServiceScopeFactory scopeFactory,
    IOptions<OutboxPublisherOpciones> opciones,
    ILogger<OutboxPublisherHostedService> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var config = opciones.Value;

        var factory = new ConnectionFactory
        {
            HostName = config.HostName,
            Port = config.Port,
            UserName = config.UserName,
            Password = config.Password,
        };

        await using var conexion = await factory.CreateConnectionAsync(stoppingToken);
        await using var canal = await conexion.CreateChannelAsync(cancellationToken: stoppingToken);

        await canal.ExchangeDeclareAsync(config.Exchange, ExchangeType.Topic, durable: true, cancellationToken: stoppingToken);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await PublicarPendientesAsync(canal, config, stoppingToken);
            }
            catch (Exception ex)
            {
                // No se detiene el servicio por un fallo transitorio (ej. broker
                // caído momentáneamente) — se reintenta en el siguiente ciclo.
                logger.LogError(ex, "Fallo al publicar mensajes pendientes del Outbox.");
            }

            await Task.Delay(TimeSpan.FromSeconds(config.IntervaloPollingSegundos), stoppingToken);
        }
    }

    private async Task PublicarPendientesAsync(IChannel canal, OutboxPublisherOpciones config, CancellationToken cancellationToken)
    {
        using var scope = scopeFactory.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<MprGestionReclamosDbContext>();

        var pendientes = await dbContext.OutboxMensajes
            .Where(m => !m.OboxPublicado)
            .OrderBy(m => m.OboxNid)
            .Take(50)
            .ToListAsync(cancellationToken);

        foreach (var mensaje in pendientes)
        {
            var routingKey = mensaje.OboxTipoEvento switch
            {
                "ReclamoAprobadoParaPagoEvento" => config.RoutingKeyReclamoAprobadoParaPago,
                _ => mensaje.OboxTipoEvento,
            };

            var cuerpo = System.Text.Encoding.UTF8.GetBytes(mensaje.OboxPayloadJson);

            var propiedades = new BasicProperties
            {
                MessageId = mensaje.OboxNid.ToString(),
                ContentType = "application/json",
                Persistent = true,
            };

            await canal.BasicPublishAsync(
                config.Exchange, routingKey, mandatory: false, propiedades, cuerpo, cancellationToken);

            mensaje.OboxPublicado = true;
            mensaje.OboxFechaPublicacion = DateTime.UtcNow;

            logger.LogInformation(
                "Publicado {TipoEvento} (OboxNid={OboxNid}) en {Exchange}/{RoutingKey}.",
                mensaje.OboxTipoEvento, mensaje.OboxNid, config.Exchange, routingKey);
        }

        if (pendientes.Count > 0)
        {
            await dbContext.SaveChangesAsync(cancellationToken);
        }
    }
}

namespace MprGestionReclamos.Infrastructure.Mensajeria;

public sealed class OutboxPublisherOpciones
{
    public string HostName { get; set; } = "localhost";
    public int Port { get; set; } = 5672;
    public string UserName { get; set; } = "guest";
    public string Password { get; set; } = "guest";
    public string Exchange { get; set; } = "multiportal.reembolsos";
    public string RoutingKeyReclamoAprobadoParaPago { get; set; } = "reclamo.aprobado-para-pago";
    public int IntervaloPollingSegundos { get; set; } = 5;
}

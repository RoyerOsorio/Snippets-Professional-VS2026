using System.Net.Http.Json;
using MprGestionReclamos.Application.Puertos;

namespace MprGestionReclamos.Infrastructure.Integraciones;

/// <summary>
/// Adaptador HTTP del puerto IDocumentosAportadosMprDocumentos. Llama
/// directamente a MprDocumentos (comunicación servicio-a-servicio, no a
/// través del Gateway) — mismo criterio que
/// ValidadorDocumentosMprConfiguracionReglasHttp.
///
/// De la lista de documentos subidos para el Reclamo, solo interesan los
/// que tienen DocumentoRequeridoId asignado (referencia lógica hacia
/// MprConfiguracionReglas) — un documento subido sin esa referencia no
/// cuenta para satisfacer un requisito obligatorio.
/// </summary>
public sealed class DocumentosAportadosMprDocumentosHttp(HttpClient httpClient) : IDocumentosAportadosMprDocumentos
{
    public async Task<IReadOnlyList<int>> ObtenerDocumentosRequeridosAportadosAsync(
        int reclamoId,
        CancellationToken cancellationToken)
    {
        var documentos = await httpClient.GetFromJsonAsync<List<DocumentoRespuesta>>(
            $"/v1/documentos/reclamos/{reclamoId}", cancellationToken) ?? [];

        return documentos
            .Where(d => d.DocumentoRequeridoId.HasValue)
            .Select(d => d.DocumentoRequeridoId!.Value)
            .Distinct()
            .ToList();
    }

    private sealed record DocumentoRespuesta(
        int Id, int ReclamoId, int? DocumentoRequeridoId, string NombreOriginal,
        string TipoContenido, long TamanoBytes, DateTime FechaCarga);
}

using System.Net.Http.Json;
using MprGestionReclamos.Application.Puertos;

namespace MprGestionReclamos.Infrastructure.Integraciones;

/// <summary>
/// Adaptador HTTP del puerto IValidadorDocumentosMprConfiguracionReglas.
/// Llama directamente a MprConfiguracionReglas (comunicación
/// servicio-a-servicio, no a través del Gateway), igual criterio que usan
/// los adaptadores HTTP de Reimbursement.Orchestrator.
/// </summary>
public sealed class ValidadorDocumentosMprConfiguracionReglasHttp(HttpClient httpClient)
    : IValidadorDocumentosMprConfiguracionReglas
{
    public async Task<IReadOnlyList<string>> ObtenerDocumentosObligatoriosFaltantesAsync(
        int motivoId,
        IReadOnlyList<int> documentosAportadosIds,
        CancellationToken cancellationToken)
    {
        using var respuesta = await httpClient.PostAsJsonAsync(
            $"/v1/reglas/{motivoId}/validar-documentos",
            new { DocumentosAportadosIds = documentosAportadosIds },
            cancellationToken);

        respuesta.EnsureSuccessStatusCode();

        var faltantes = await respuesta.Content.ReadFromJsonAsync<List<DocumentoRequeridoRespuesta>>(
            cancellationToken: cancellationToken) ?? [];

        return faltantes.Select(d => d.Nombre).ToList();
    }

    private sealed record DocumentoRequeridoRespuesta(int Id, string Nombre, bool Obligatorio, bool EsFactura);
}

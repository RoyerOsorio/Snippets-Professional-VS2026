using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using MprGestionReclamos.Application.Eventos;
using MprGestionReclamos.Application.Puertos;
using MprGestionReclamos.Domain.Entidades;
using ReclamoGenerado = MprGestionReclamos.Infrastructure.Persistencia.ModelosGenerados.Reclamo;

namespace MprGestionReclamos.Infrastructure.Persistencia.Adaptadores;

/// <summary>
/// Adaptador escrito a mano. Implementa el puerto IRepositorioReclamos.
/// ActualizarYPublicarEventoAsync es donde vive el patrón Transactional
/// Outbox: el UPDATE del Reclamo y el INSERT en OutboxMensajes se agregan
/// al mismo DbContext y se guardan con un único SaveChangesAsync — EF Core
/// los envuelve en una sola transacción de base de datos, así que o se
/// confirman los dos, o ninguno. RabbitMQ NO se toca aquí — eso lo hace
/// OutboxPublisherHostedService leyendo esta misma tabla.
/// </summary>
public sealed class RepositorioReclamosEfCore(MprGestionReclamosDbContext dbContext) : IRepositorioReclamos
{
    private static readonly JsonSerializerOptions OpcionesJson = new(JsonSerializerDefaults.Web);

    public async Task<Reclamo?> ObtenerPorIdAsync(int reclamoId, CancellationToken cancellationToken)
    {
        var entidad = await dbContext.Reclamos.AsNoTracking()
            .FirstOrDefaultAsync(r => r.RcrcNid == reclamoId, cancellationToken);

        return entidad is null ? null : AEntidadDominio(entidad);
    }

    public async Task<Reclamo> CrearAsync(Reclamo reclamo, CancellationToken cancellationToken)
    {
        var entidad = new ReclamoGenerado
        {
            RcrcPoliza = reclamo.Poliza,
            RcrcAseguradoId = reclamo.AseguradoId,
            RcrcMotivoId = reclamo.MotivoId,
            RcrcEstado = (byte)reclamo.Estado,
            RcrcFechaCreacion = reclamo.FechaCreacion,
        };

        dbContext.Reclamos.Add(entidad);
        await dbContext.SaveChangesAsync(cancellationToken);

        return AEntidadDominio(entidad);
    }

    public async Task ActualizarAsync(Reclamo reclamo, CancellationToken cancellationToken)
    {
        var entidad = await dbContext.Reclamos.FirstAsync(r => r.RcrcNid == reclamo.Id, cancellationToken);
        AplicarCambios(entidad, reclamo);

        await dbContext.SaveChangesAsync(cancellationToken);
    }

    public async Task ActualizarYPublicarEventoAsync(
        Reclamo reclamo,
        ReclamoAprobadoParaPagoEvento evento,
        CancellationToken cancellationToken)
    {
        var entidad = await dbContext.Reclamos.FirstAsync(r => r.RcrcNid == reclamo.Id, cancellationToken);
        AplicarCambios(entidad, reclamo);

        dbContext.OutboxMensajes.Add(new ModelosGenerados.OutboxMensaje
        {
            OboxTipoEvento = nameof(ReclamoAprobadoParaPagoEvento),
            OboxPayloadJson = JsonSerializer.Serialize(evento, OpcionesJson),
            OboxFechaCreacion = evento.FechaResolucion,
            OboxPublicado = false,
        });

        // Un único SaveChangesAsync ⇒ una única transacción: el Reclamo
        // pasa a Aprobado y el mensaje queda en Outbox atómicamente.
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    private static void AplicarCambios(ReclamoGenerado entidad, Reclamo reclamo)
    {
        entidad.RcrcEstado = (byte)reclamo.Estado;
        entidad.RcrcFechaEnvio = reclamo.FechaEnvio;
        entidad.RcrcFechaResolucion = reclamo.FechaResolucion;
        entidad.RcrcMontoAprobado = reclamo.MontoAprobado;
        entidad.RcrcMotivoRechazo = reclamo.MotivoRechazo;
    }

    private static Reclamo AEntidadDominio(ReclamoGenerado entidad) => new(
        entidad.RcrcNid,
        entidad.RcrcPoliza,
        entidad.RcrcAseguradoId,
        entidad.RcrcMotivoId,
        (Domain.Entidades.EstadoReclamo)entidad.RcrcEstado,
        entidad.RcrcFechaCreacion,
        entidad.RcrcFechaEnvio,
        entidad.RcrcFechaResolucion,
        entidad.RcrcMontoAprobado,
        entidad.RcrcMotivoRechazo);
}

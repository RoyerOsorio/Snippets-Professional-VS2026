using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MprGestionReclamos.Application.Puertos;
using MprGestionReclamos.Infrastructure.Mensajeria;
using MprGestionReclamos.Infrastructure.Persistencia;
using MprGestionReclamos.Infrastructure.Persistencia.Adaptadores;

namespace MprGestionReclamos.Infrastructure.Extensiones;

public static class ExtensionesServiciosInfrastructure
{
    public static IServiceCollection AgregarInfrastructureMprGestionReclamos(
        this IServiceCollection servicios,
        IConfiguration configuracion)
    {
        servicios.AddDbContext<MprGestionReclamosDbContext>(opciones =>
            opciones.UseSqlServer(configuracion.GetConnectionString("MprGestionReclamosDb")));

        servicios.AddScoped<IRepositorioReclamos, RepositorioReclamosEfCore>();

        servicios.Configure<OutboxPublisherOpciones>(configuracion.GetSection("RabbitMq"));
        servicios.AddHostedService<OutboxPublisherHostedService>();

        // El validador HTTP hacia MprConfiguracionReglas (IValidadorDocumentosMprConfiguracionReglas)
        // se registra en Api/Program.cs vía AddHttpClient, porque necesita el BaseAddress leído de
        // configuración — mismo criterio que Reimbursement.Orchestrator con sus puertos HTTP.

        return servicios;
    }
}

namespace MprGestionReclamos.Contracts.Requests;

public sealed record RechazarReclamoRequest(string MotivoRechazo);

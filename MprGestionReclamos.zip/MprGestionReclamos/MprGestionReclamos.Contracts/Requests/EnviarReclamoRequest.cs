namespace MprGestionReclamos.Contracts.Requests;

public sealed record EnviarReclamoRequest(IReadOnlyList<int> DocumentosAportadosIds);

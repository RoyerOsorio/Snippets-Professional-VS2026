namespace MprGestionReclamos.Contracts.Requests;

public sealed record CrearReclamoRequest(string Poliza, int AseguradoId, int MotivoId);

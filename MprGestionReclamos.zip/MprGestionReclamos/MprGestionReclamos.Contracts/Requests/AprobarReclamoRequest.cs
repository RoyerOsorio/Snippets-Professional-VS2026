namespace MprGestionReclamos.Contracts.Requests;

public sealed record AprobarReclamoRequest(decimal MontoAprobado);

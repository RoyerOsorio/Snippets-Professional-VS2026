namespace MprGestionReclamos.Contracts.Responses;

/// <summary>
/// Estado como string (no el enum de Domain) — Contracts es la frontera
/// pública del microservicio y no debe exponer el tipo de Domain
/// directamente (ver UI_Architecture_Guide.md, distinción Domain/DTOs/Contracts).
/// </summary>
public sealed record ReclamoResponse(
    int Id,
    string Poliza,
    int AseguradoId,
    int MotivoId,
    string Estado,
    DateTime FechaCreacion,
    DateTime? FechaEnvio,
    DateTime? FechaResolucion,
    decimal? MontoAprobado,
    string? MotivoRechazo);

namespace MprGestionReclamos.Contracts.Responses;

public sealed record EnviarReclamoResponse(
    bool Enviado,
    ReclamoResponse Reclamo,
    IReadOnlyList<string> DocumentosFaltantes);

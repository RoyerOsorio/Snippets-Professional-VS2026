using MprGestionReclamos.Application.Dtos;
using MprGestionReclamos.Application.Puertos;
using MprGestionReclamos.Domain.Excepciones;

namespace MprGestionReclamos.Application.Casos;

public sealed class ObtenerReclamoCasoDeUso(IRepositorioReclamos repositorio)
{
    public async Task<ReclamoDto> EjecutarAsync(int reclamoId, CancellationToken cancellationToken)
    {
        var reclamo = await repositorio.ObtenerPorIdAsync(reclamoId, cancellationToken);

        if (reclamo is null)
        {
            throw new ReclamoNoEncontradoException($"No existe un Reclamo con Id {reclamoId}.");
        }

        return CrearReclamoCasoDeUso.AReclamoDto(reclamo);
    }
}

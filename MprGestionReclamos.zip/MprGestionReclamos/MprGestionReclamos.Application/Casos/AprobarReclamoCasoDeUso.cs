using MprGestionReclamos.Application.Dtos;
using MprGestionReclamos.Application.Eventos;
using MprGestionReclamos.Application.Puertos;
using MprGestionReclamos.Domain.Excepciones;

namespace MprGestionReclamos.Application.Casos;

/// <summary>
/// Paso "AprobarReclamo". Aplica la transición de dominio y, en la misma
/// operación de persistencia, escribe el evento ReclamoAprobadoParaPago en
/// la tabla Outbox (Transactional Outbox — ver IRepositorioReclamos). No
/// publica directamente a RabbitMQ: eso lo hace un BackgroundService
/// aparte que lee la tabla Outbox, para que la aprobación nunca falle ni
/// quede en estado inconsistente por una caída del broker.
/// </summary>
public sealed class AprobarReclamoCasoDeUso(IRepositorioReclamos repositorio)
{
    public async Task<ReclamoDto> EjecutarAsync(
        int reclamoId,
        decimal montoAprobado,
        DateTime fechaResolucion,
        CancellationToken cancellationToken)
    {
        var reclamo = await repositorio.ObtenerPorIdAsync(reclamoId, cancellationToken);

        if (reclamo is null)
        {
            throw new ReclamoNoEncontradoException($"No existe un Reclamo con Id {reclamoId}.");
        }

        reclamo.Aprobar(montoAprobado, fechaResolucion);

        var evento = new ReclamoAprobadoParaPagoEvento(
            reclamo.Id, reclamo.Poliza, reclamo.AseguradoId, montoAprobado, fechaResolucion);

        await repositorio.ActualizarYPublicarEventoAsync(reclamo, evento, cancellationToken);

        return CrearReclamoCasoDeUso.AReclamoDto(reclamo);
    }
}

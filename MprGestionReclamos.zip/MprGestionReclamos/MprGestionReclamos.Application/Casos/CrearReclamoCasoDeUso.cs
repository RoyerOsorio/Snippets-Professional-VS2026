using MprGestionReclamos.Application.Dtos;
using MprGestionReclamos.Application.Puertos;
using MprGestionReclamos.Domain.Entidades;

namespace MprGestionReclamos.Application.Casos;

/// <summary>
/// Consumido por Reimbursement.Orchestrator como tercer paso real de
/// POST /v1/reembolsos/iniciar (tras ValidarContextoCliente y
/// ObtenerReglaReembolso) y por la UI cuando exista la pantalla de
/// "Iniciar Reembolso" (roadmap, docs/demo/README.md).
/// </summary>
public sealed class CrearReclamoCasoDeUso(IRepositorioReclamos repositorio)
{
    public async Task<ReclamoDto> EjecutarAsync(
        string poliza,
        int aseguradoId,
        int motivoId,
        DateTime fechaCreacion,
        CancellationToken cancellationToken)
    {
        var reclamo = Reclamo.Crear(poliza, aseguradoId, motivoId, fechaCreacion);
        var creado = await repositorio.CrearAsync(reclamo, cancellationToken);

        return AReclamoDto(creado);
    }

    internal static ReclamoDto AReclamoDto(Reclamo reclamo) => new(
        reclamo.Id, reclamo.Poliza, reclamo.AseguradoId, reclamo.MotivoId, reclamo.Estado,
        reclamo.FechaCreacion, reclamo.FechaEnvio, reclamo.FechaResolucion,
        reclamo.MontoAprobado, reclamo.MotivoRechazo);
}

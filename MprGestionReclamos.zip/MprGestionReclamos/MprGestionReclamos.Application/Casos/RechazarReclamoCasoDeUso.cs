using MprGestionReclamos.Application.Dtos;
using MprGestionReclamos.Application.Puertos;
using MprGestionReclamos.Domain.Excepciones;

namespace MprGestionReclamos.Application.Casos;

public sealed class RechazarReclamoCasoDeUso(IRepositorioReclamos repositorio)
{
    public async Task<ReclamoDto> EjecutarAsync(
        int reclamoId,
        string motivoRechazo,
        DateTime fechaResolucion,
        CancellationToken cancellationToken)
    {
        var reclamo = await repositorio.ObtenerPorIdAsync(reclamoId, cancellationToken);

        if (reclamo is null)
        {
            throw new ReclamoNoEncontradoException($"No existe un Reclamo con Id {reclamoId}.");
        }

        reclamo.Rechazar(motivoRechazo, fechaResolucion);
        await repositorio.ActualizarAsync(reclamo, cancellationToken);

        return CrearReclamoCasoDeUso.AReclamoDto(reclamo);
    }
}

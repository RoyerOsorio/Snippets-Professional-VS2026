using MprGestionReclamos.Application.Dtos;
using MprGestionReclamos.Application.Puertos;
using MprGestionReclamos.Domain.Excepciones;

namespace MprGestionReclamos.Application.Casos;

/// <summary>
/// Paso "EnviarReclamo" del ejercicio original. Antes de aplicar la
/// transición de estado, consulta a MprDocumentos qué documentos
/// requeridos ya fueron aportados para este Reclamo, y valida contra
/// MprConfiguracionReglas que no falte ninguno obligatorio — si falta
/// alguno, el Reclamo NO se envía y se devuelven los documentos faltantes
/// para que la UI se lo muestre al usuario (Paso 5 del ejercicio original).
///
/// Antes (ver UI_Decision_Log.md DEC-003), el llamador enviaba los IDs de
/// documentos aportados directamente en el request — eso obligaba a la UI
/// (o al Orchestrator) a llevar la cuenta de qué se subió, duplicando una
/// responsabilidad que ya le pertenece a MprDocumentos. Con DEC-005, este
/// caso de uso consulta directamente a MprDocumentos.
/// </summary>
public sealed class EnviarReclamoCasoDeUso(
    IRepositorioReclamos repositorio,
    IDocumentosAportadosMprDocumentos documentosAportados,
    IValidadorDocumentosMprConfiguracionReglas validadorDocumentos)
{
    public async Task<ResultadoEnviarReclamo> EjecutarAsync(
        int reclamoId,
        DateTime fechaEnvio,
        CancellationToken cancellationToken)
    {
        var reclamo = await repositorio.ObtenerPorIdAsync(reclamoId, cancellationToken);

        if (reclamo is null)
        {
            throw new ReclamoNoEncontradoException($"No existe un Reclamo con Id {reclamoId}.");
        }

        var documentosAportadosIds = await documentosAportados.ObtenerDocumentosRequeridosAportadosAsync(
            reclamoId, cancellationToken);

        var faltantes = await validadorDocumentos.ObtenerDocumentosObligatoriosFaltantesAsync(
            reclamo.MotivoId, documentosAportadosIds, cancellationToken);

        if (faltantes.Count > 0)
        {
            return new ResultadoEnviarReclamo(Enviado: false, Reclamo: CrearReclamoCasoDeUso.AReclamoDto(reclamo), DocumentosFaltantes: faltantes);
        }

        reclamo.EnviarParaRevision(fechaEnvio);
        await repositorio.ActualizarAsync(reclamo, cancellationToken);

        return new ResultadoEnviarReclamo(Enviado: true, Reclamo: CrearReclamoCasoDeUso.AReclamoDto(reclamo), DocumentosFaltantes: []);
    }
}

public sealed record ResultadoEnviarReclamo(bool Enviado, ReclamoDto Reclamo, IReadOnlyList<string> DocumentosFaltantes);

namespace MprGestionReclamos.Application.Puertos;

/// <summary>
/// Puerto que EnviarReclamoCasoDeUso usa para preguntarle a MprDocumentos
/// (bounded context distinto) qué documentos requeridos ya fueron
/// aportados para el Reclamo. Reemplaza el criterio anterior, en el que
/// el llamador (UI/Orchestrator) enviaba los IDs directamente en el
/// request de EnviarReclamo — ver UI_Decision_Log.md DEC-005.
/// </summary>
public interface IDocumentosAportadosMprDocumentos
{
    Task<IReadOnlyList<int>> ObtenerDocumentosRequeridosAportadosAsync(
        int reclamoId,
        CancellationToken cancellationToken);
}

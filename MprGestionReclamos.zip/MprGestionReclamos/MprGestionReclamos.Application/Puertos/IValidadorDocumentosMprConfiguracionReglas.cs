namespace MprGestionReclamos.Application.Puertos;

/// <summary>
/// Puerto que EnviarReclamoCasoDeUso usa para preguntarle a
/// MprConfiguracionReglas (bounded context distinto) si la documentación
/// aportada satisface los requisitos obligatorios del Motivo del Reclamo.
/// MprGestionReclamos no reimplementa esa regla — solo la consulta, igual
/// criterio que usa Reimbursement.Orchestrator con sus propios puertos.
/// </summary>
public interface IValidadorDocumentosMprConfiguracionReglas
{
    Task<IReadOnlyList<string>> ObtenerDocumentosObligatoriosFaltantesAsync(
        int motivoId,
        IReadOnlyList<int> documentosAportadosIds,
        CancellationToken cancellationToken);
}

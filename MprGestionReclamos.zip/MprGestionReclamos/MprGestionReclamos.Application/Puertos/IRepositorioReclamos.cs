using MprGestionReclamos.Application.Eventos;
using MprGestionReclamos.Domain.Entidades;

namespace MprGestionReclamos.Application.Puertos;

public interface IRepositorioReclamos
{
    Task<Reclamo?> ObtenerPorIdAsync(int reclamoId, CancellationToken cancellationToken);

    Task<Reclamo> CrearAsync(Reclamo reclamo, CancellationToken cancellationToken);

    /// <summary>
    /// Persiste una transición de estado que NO publica ningún evento de
    /// integración (EnviarParaRevision, Rechazar).
    /// </summary>
    Task ActualizarAsync(Reclamo reclamo, CancellationToken cancellationToken);

    /// <summary>
    /// Persiste la transición a Aprobado y escribe la fila de
    /// OutboxMensajes correspondiente a ReclamoAprobadoParaPagoEvento
    /// dentro de la MISMA transacción (Transactional Outbox) — o se
    /// guardan los dos cambios, o ninguno. Un BackgroundService aparte
    /// (Infrastructure/Mensajeria) es quien efectivamente publica a
    /// RabbitMQ leyendo esta tabla — Application no conoce RabbitMQ.
    /// </summary>
    Task ActualizarYPublicarEventoAsync(
        Reclamo reclamo,
        ReclamoAprobadoParaPagoEvento evento,
        CancellationToken cancellationToken);
}

namespace MprGestionReclamos.Application.Eventos;

/// <summary>
/// Evento de integración publicado cuando AprobarReclamo se ejecuta con
/// éxito (ejercicio original: "Publicar ReclamoAprobadoParaPago en
/// RabbitMQ tras AprobarReclamo"). MprPagos lo consume para
/// ConfirmarPago; MprAuditoria lo consume para su bitácora/timeline —
/// ninguno de los dos existe todavía en este repositorio (ver roadmap,
/// docs/demo/README.md), por lo que hoy el evento se publica pero no
/// tiene consumidores reales.
/// </summary>
public sealed record ReclamoAprobadoParaPagoEvento(
    int ReclamoId,
    string Poliza,
    int AseguradoId,
    decimal MontoAprobado,
    DateTime FechaResolucion);

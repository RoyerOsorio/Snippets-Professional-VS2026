using MprGestionReclamos.Domain.Entidades;

namespace MprGestionReclamos.Application.Dtos;

public sealed record ReclamoDto(
    int Id,
    string Poliza,
    int AseguradoId,
    int MotivoId,
    EstadoReclamo Estado,
    DateTime FechaCreacion,
    DateTime? FechaEnvio,
    DateTime? FechaResolucion,
    decimal? MontoAprobado,
    string? MotivoRechazo);

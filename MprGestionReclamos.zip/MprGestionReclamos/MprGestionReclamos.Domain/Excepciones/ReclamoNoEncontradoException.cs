namespace MprGestionReclamos.Domain.Excepciones;

public sealed class ReclamoNoEncontradoException(string mensaje) : Exception(mensaje);

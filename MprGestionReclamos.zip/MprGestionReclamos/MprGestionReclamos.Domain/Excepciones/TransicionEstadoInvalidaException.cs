namespace MprGestionReclamos.Domain.Excepciones;

/// <summary>
/// Se lanza cuando se intenta una transición de estado que Reclamo no
/// permite desde su estado actual (ej. Aprobar un Reclamo que sigue en
/// Creado sin haber pasado por EnviarParaRevision).
/// </summary>
public sealed class TransicionEstadoInvalidaException(string mensaje) : Exception(mensaje);

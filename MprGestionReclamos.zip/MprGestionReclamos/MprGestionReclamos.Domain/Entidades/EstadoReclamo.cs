namespace MprGestionReclamos.Domain.Entidades;

/// <summary>
/// Ciclo de vida del Reclamo (ejercicio original: CrearReclamo, EnviarReclamo,
/// dictámenes, AprobarReclamo). Las transiciones válidas viven en
/// Reclamo.EnviarParaRevision/Aprobar/Rechazar — este enum es solo el estado,
/// no la regla.
/// </summary>
public enum EstadoReclamo
{
    Creado = 0,
    EnviadoParaRevision = 1,
    Aprobado = 2,
    Rechazado = 3,
}

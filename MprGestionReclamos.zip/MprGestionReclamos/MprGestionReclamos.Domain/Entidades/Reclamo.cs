using MprGestionReclamos.Domain.Excepciones;

namespace MprGestionReclamos.Domain.Entidades;

/// <summary>
/// Agregado de dominio: ciclo de vida del Reclamo. La máquina de estados es
/// la regla de negocio real que vive aquí (no en el Orchestrator ni en la
/// UI) — ver "El Orchestrator no ejecuta reglas internas" del ejercicio.
///
/// Transiciones permitidas:
///   Creado -> EnviadoParaRevision -> Aprobado
///                                 -> Rechazado
/// Cualquier otra transición lanza TransicionEstadoInvalidaException.
/// </summary>
public sealed class Reclamo
{
    public int Id { get; }
    public string Poliza { get; }
    public int AseguradoId { get; }
    public int MotivoId { get; }
    public EstadoReclamo Estado { get; private set; }
    public DateTime FechaCreacion { get; }
    public DateTime? FechaEnvio { get; private set; }
    public DateTime? FechaResolucion { get; private set; }
    public decimal? MontoAprobado { get; private set; }
    public string? MotivoRechazo { get; private set; }

    public Reclamo(
        int id,
        string poliza,
        int aseguradoId,
        int motivoId,
        EstadoReclamo estado,
        DateTime fechaCreacion,
        DateTime? fechaEnvio,
        DateTime? fechaResolucion,
        decimal? montoAprobado,
        string? motivoRechazo)
    {
        Id = id;
        Poliza = poliza;
        AseguradoId = aseguradoId;
        MotivoId = motivoId;
        Estado = estado;
        FechaCreacion = fechaCreacion;
        FechaEnvio = fechaEnvio;
        FechaResolucion = fechaResolucion;
        MontoAprobado = montoAprobado;
        MotivoRechazo = motivoRechazo;
    }

    /// <summary>
    /// Fábrica para CrearReclamo — siempre nace en estado Creado. El Id real
    /// lo asigna la base de datos (identity); aquí se usa 0 como marcador de
    /// "todavía no persistido", igual criterio que otras entidades de este
    /// ejercicio que no tienen fábrica de Id propia.
    /// </summary>
    public static Reclamo Crear(string poliza, int aseguradoId, int motivoId, DateTime fechaCreacion) =>
        new(0, poliza, aseguradoId, motivoId, EstadoReclamo.Creado, fechaCreacion, null, null, null, null);

    /// <summary>
    /// Paso "EnviarReclamo" del ejercicio original. Quien llama (el caso de
    /// uso de Application) es responsable de haber validado ya los
    /// documentos obligatorios contra MprConfiguracionReglas — esta entidad
    /// solo aplica la transición de estado, no conoce esa regla externa.
    /// </summary>
    public void EnviarParaRevision(DateTime fechaEnvio)
    {
        if (Estado != EstadoReclamo.Creado)
        {
            throw new TransicionEstadoInvalidaException(
                $"No se puede enviar para revisión un Reclamo en estado {Estado}. Solo es válido desde Creado.");
        }

        Estado = EstadoReclamo.EnviadoParaRevision;
        FechaEnvio = fechaEnvio;
    }

    /// <summary>
    /// Paso "AprobarReclamo". Quien llama es responsable de publicar el
    /// evento de integración ReclamoAprobadoParaPago (vía Transactional
    /// Outbox, en Infrastructure) — esta entidad no conoce mensajería.
    /// </summary>
    public void Aprobar(decimal montoAprobado, DateTime fechaResolucion)
    {
        if (Estado != EstadoReclamo.EnviadoParaRevision)
        {
            throw new TransicionEstadoInvalidaException(
                $"No se puede aprobar un Reclamo en estado {Estado}. Solo es válido desde EnviadoParaRevision.");
        }

        if (montoAprobado <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(montoAprobado), "El monto aprobado debe ser mayor a cero.");
        }

        Estado = EstadoReclamo.Aprobado;
        MontoAprobado = montoAprobado;
        FechaResolucion = fechaResolucion;
    }

    public void Rechazar(string motivoRechazo, DateTime fechaResolucion)
    {
        if (Estado != EstadoReclamo.EnviadoParaRevision)
        {
            throw new TransicionEstadoInvalidaException(
                $"No se puede rechazar un Reclamo en estado {Estado}. Solo es válido desde EnviadoParaRevision.");
        }

        if (string.IsNullOrWhiteSpace(motivoRechazo))
        {
            throw new ArgumentException("El motivo de rechazo es obligatorio.", nameof(motivoRechazo));
        }

        Estado = EstadoReclamo.Rechazado;
        MotivoRechazo = motivoRechazo;
        FechaResolucion = fechaResolucion;
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Vitamedica.Multiportal.UI.Models.ViewModels;

namespace Vitamedica.Multiportal.UI.Controllers
{
    [Authorize]
    public class ReembolsosController : Controller
    {
        private const int TamanioPaginaPorDefecto = 25;

        public IActionResult Index()
        {
            var resultado = Paginar(ObtenerSolicitudesSimuladas(), pagina: 1, tamanioPagina: TamanioPaginaPorDefecto);
            return View(resultado);
        }

        [HttpGet]
        public IActionResult Buscar(SolicitudReembolsoFiltroViewModel filtro, int pagina = 1, int tamanioPagina = TamanioPaginaPorDefecto)
        {
            var filtrado = AplicarFiltro(ObtenerSolicitudesSimuladas(), filtro);
            var resultado = Paginar(filtrado, pagina, tamanioPagina);
            return PartialView("Partials/_ResultadosYPaginacionSolicitudes", resultado);
        }

        private static readonly string[] EstatusFinales = { "Aprobado", "Rechazado" };

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Rechazar(int id, string? comentario)
        {
            var solicitud = ObtenerSolicitudesSimuladas().FirstOrDefault(s => s.Id == id);
            if (solicitud == null)
                return NotFound();

            if (EstatusFinales.Contains(solicitud.Estatus))
                return BadRequest("La solicitud ya se encuentra en un estado final y no puede rechazarse.");

            return Json(new { ok = true, nuevoEstatus = "Rechazado" });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Regresar(int id, string? comentario)
        {
            var solicitud = ObtenerSolicitudesSimuladas().FirstOrDefault(s => s.Id == id);
            if (solicitud == null)
                return NotFound();

            if (EstatusFinales.Contains(solicitud.Estatus))
                return BadRequest("La solicitud ya se encuentra en un estado final y no puede regresarse.");

            if (string.IsNullOrWhiteSpace(comentario))
                return BadRequest("Debe indicar un comentario para regresar el trámite.");

            // Simulado: no persiste (ver comentario de fase arriba).
            return Json(new { ok = true, nuevoEstatus = "En proceso", nuevaEstacion = "Dictamen médico" });
        }

        public IActionResult Crear()
        {
            return View(ObtenerCatalogosSimulados());
        }

        private static SolicitudReembolsoCatalogosViewModel ObtenerCatalogosSimulados() => new()
        {
            Categorias = new List<CategoriaReclamacionViewModel>
            {
                new()
                {
                    Key = "consultas", Nombre = "Consultas", Icono = "stethoscope",
                    TieneMotivo = true, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Receta", Requerido = false },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "medicamentos", Nombre = "Medicamentos", Icono = "pill",
                    TieneMotivo = false, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Receta", Requerido = false },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "vacunas", Nombre = "Vacunas", Icono = "syringe",
                    TieneMotivo = false, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Cartilla Nacional de Vacunación", Requerido = true },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "laboratorio", Nombre = "Laboratorio y Gabinete", Icono = "flask-conical",
                    TieneMotivo = false, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Orden Médica", Requerido = true },
                        new() { Nombre = "Estado de Cuenta", Requerido = false },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "cuidados", Nombre = "Cuidados Preventivos (Enfermería, Terapias)", Icono = "heart-pulse",
                    TieneMotivo = false, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Informe Médico", Requerido = false },
                        new() { Nombre = "Bitácora", Requerido = false },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "audicion", Nombre = "Exámenes de Audición", Icono = "ear",
                    TieneMotivo = false, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Orden Médica", Requerido = true },
                        new() { Nombre = "Estudios", Requerido = true },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "lentes", Nombre = "Lentes", Icono = "glasses",
                    TieneMotivo = false, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Orden Médica", Requerido = true },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "extranjero", Nombre = "Gastos en el Extranjero", Icono = "plane",
                    TieneMotivo = false, TipoFactura = "multimoneda",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Informe Médico", Requerido = true },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
            },
            MotivosConsulta = new List<string>
            {
                "Dolor de cabeza", "Chequeo general", "Dolor abdominal", "Control de enfermedad crónica", "Otro",
            },
            Monedas = new List<MonedaViewModel>
            {
                new() { Codigo = "USD", Nombre = "Dólar americano" },
                new() { Codigo = "EUR", Nombre = "Euro" },
                new() { Codigo = "MXN", Nombre = "Peso mexicano" },
            },
        };

        [HttpGet]
        public IActionResult BuscarDerechohabiente(string numeroEmpleado)
        {
            var derechohabiente = ObtenerDerechohabientesSimulados()
                .FirstOrDefault(d => d.NumeroEmpleado == (numeroEmpleado ?? string.Empty).Trim());

            if (derechohabiente == null)
                return NotFound();

            return Json(derechohabiente);
        }

        private static List<DerechohabienteViewModel> ObtenerDerechohabientesSimulados() => new()
        {
            new DerechohabienteViewModel
            {
                NumeroEmpleado = "38602287",
                Nombre = "ESNER VALENCIA VALENCIA",
                Grupo = "17000003",
                FechaInicioVigencia = "03/01/2026",
                FechaFinVigencia = "31/12/2199",
                MiembroDesde = "01/03/2026",
                Beneficiarios = new List<BeneficiarioViewModel>
                {
                    new() { Id = "titular", Nombre = "ESNER VALENCIA VALENCIA", Parentesco = "Titular" },
                    new() { Id = "conyuge", Nombre = "MARÍA JOSÉ PÉREZ DE VALENCIA", Parentesco = "Cónyuge" },
                    new() { Id = "hijo1", Nombre = "DIEGO VALENCIA PÉREZ", Parentesco = "Hijo(a)" },
                },
            },
        };

        // Requerimiento 2 (Fase 10, ver Fase10_...Analizar_Proponer.md sección
        // 6.B, Opción B2 confirmada por el usuario): la validación del cliente
        // (evaluarBotonRegistrar/registroGateCompleto en reembolso-solicitud.js)
        // es solo UX — el servidor revalida lo mismo antes de aceptar el
        // registro, sin confiar en el estado del formulario del cliente. Los
        // campos de captura de la Sección 1 (correo, teléfono, fecha de
        // padecimiento, código postal) no son parte del gate por la misma
        // decisión de alcance — no se validan aquí tampoco.
        private static bool SolicitudRegistroEsValida(SolicitudReembolsoRegistroViewModel modelo, out string mensajeError)
        {
            if (modelo == null || string.IsNullOrWhiteSpace(modelo.AseguradoTitular?.NumeroEmpleado))
            {
                mensajeError = "Debes buscar y seleccionar un asegurado titular antes de registrar la solicitud.";
                return false;
            }
            if (string.IsNullOrWhiteSpace(modelo.Paciente?.BeneficiarioId))
            {
                mensajeError = "Debes seleccionar un paciente/derechohabiente antes de registrar la solicitud.";
                return false;
            }
            if (modelo.Reclamacion?.Categorias == null || !modelo.Reclamacion.Categorias.Any(c => c.Solicitado))
            {
                mensajeError = "Debes solicitar al menos una categoría de la reclamación antes de registrar la solicitud.";
                return false;
            }

            mensajeError = string.Empty;
            return true;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Registrar([FromBody] SolicitudReembolsoRegistroViewModel modelo)
        {
            if (!SolicitudRegistroEsValida(modelo, out var mensajeError))
                return BadRequest(mensajeError);

            var folio = "REEMB-" + Guid.NewGuid().ToString("N")[..8].ToUpperInvariant();
            return Json(new { folio });
        }

        private const long TamanioMaximoArchivoBytes = 5 * 1024 * 1024;

        private static readonly Dictionary<string, string[]> ExtensionesPermitidasPorContexto = new()
        {
            ["factura"] = new[] { ".pdf", ".xml" },
            ["documento"] = new[] { ".png", ".jpg", ".jpeg", ".pdf" },
        };

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SubirArchivo(IFormFile archivo, string contexto)
        {
            if (archivo == null || archivo.Length == 0)
                return BadRequest("No se recibió ningún archivo.");

            if (archivo.Length > TamanioMaximoArchivoBytes)
                return BadRequest("El archivo excede el tamaño máximo permitido (5 MB).");

            if (!ExtensionesPermitidasPorContexto.TryGetValue(contexto ?? string.Empty, out var extensionesPermitidas))
                return BadRequest("Contexto de carga no reconocido.");

            var extension = Path.GetExtension(archivo.FileName);
            if (string.IsNullOrEmpty(extension) || !extensionesPermitidas.Contains(extension, StringComparer.OrdinalIgnoreCase))
                return BadRequest("Formato de archivo no permitido para este documento.");

            // Simulado: se descarta el contenido sin guardarlo.
            var montoDetectado = SimularLecturaMontoFactura(archivo.FileName, archivo.Length);
            return Json(new { nombreArchivo = archivo.FileName, tamanioBytes = archivo.Length, montoDetectado });
        }

        private static decimal SimularLecturaMontoFactura(string nombreArchivo, long tamanioBytes)
        {
            long semilla = tamanioBytes;
            foreach (var caracter in nombreArchivo)
                semilla += caracter;

            var generador = new Random((int)(semilla % int.MaxValue));
            var monto = 150m + (decimal)generador.NextDouble() * (8000m - 150m);
            return Math.Round(monto, 2);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AvanzarTramite(int id, string? comentario)
        {
            var solicitud = ObtenerSolicitudesSimuladas().FirstOrDefault(s => s.Id == id);
            if (solicitud == null)
                return NotFound();

            if (EstatusFinales.Contains(solicitud.Estatus))
                return BadRequest("La solicitud ya se encuentra en un estado final.");

            var indiceEstacion = ResolverIndiceEstacion(solicitud.EstacionActual);
            if (indiceEstacion >= 3)
                return Json(new { ok = true, nuevoEstatus = "Aprobado", nuevaEstacion = "Pago autorizado" });

            return Json(new { ok = true, nuevoEstatus = "En proceso", nuevaEstacion = "Autorización de pago" });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DevolverTramite(int id, string? motivo)
        {
            var solicitud = ObtenerSolicitudesSimuladas().FirstOrDefault(s => s.Id == id);
            if (solicitud == null)
                return NotFound();

            if (EstatusFinales.Contains(solicitud.Estatus))
                return BadRequest("La solicitud ya se encuentra en un estado final.");

            if (string.IsNullOrWhiteSpace(motivo))
                return BadRequest("Debe indicar el motivo de rechazo.");

            return Json(new { ok = true, nuevoEstatus = "Corregido", nuevaEstacion = "Recepción de documentos" });
        }

        // Ciclo 6 (Fase9_MejorasUI_RetrocederTramite, ver DEC-...): "Retroceder
        // trámite" — funcionalidad recuperada de Legacy (Vitamedica.ReembolsoGModelo,
        // ValidaTramite en ReembolsoController), adaptada a Current. En Legacy la
        // elegibilidad exacta es IdFlujo==1 (Recepción de documentos) &&
        // IdEstatus==4 (Devuelto al usuario) — aquí el equivalente verificado en
        // código es Estatus=="Corregido" && EstacionActual=="Recepción de
        // documentos" (único combo que produce DevolverTramite). Legacy no
        // permite elegir la estación destino ni capturar un motivo: el destino
        // lo calcula el servidor (en Legacy, IdFlujoAnterior; aquí, siempre
        // "Dictamen administrativo", la única estación de dictamen que existe
        // en el modelo de 4 estaciones de Current — ver TraducirAEstaciones).
        // Se dispara desde la card "Retroceder trámite" de Reembolsos/Index
        // (antes href="#"), buscando por folio en vez de por fila — igual que
        // en Legacy, no todo trámite elegible está necesariamente visible en
        // la tabla ya renderizada/filtrada.
        private static bool EsElegibleParaRetroceso(SolicitudReembolsoResumenViewModel solicitud) =>
            solicitud.Estatus == "Corregido" && ResolverIndiceEstacion(solicitud.EstacionActual) == 1;

        [HttpGet]
        public IActionResult ValidarRetroceso(string? folio)
        {
            if (string.IsNullOrWhiteSpace(folio))
                return Json(new { ok = false, message = "Ingresa un folio." });

            var solicitud = ObtenerSolicitudesSimuladas().FirstOrDefault(s => s.Folio == folio.Trim());

            if (solicitud == null)
                return Json(new { ok = false, message = "No se encontró ninguna solicitud con ese folio." });

            if (!EsElegibleParaRetroceso(solicitud))
                return Json(new { ok = false, message = "La función solo está permitida en solicitudes devueltas al usuario (estatus Corregido, en Recepción de documentos)." });

            return Json(new { ok = true, id = solicitud.Id, folio = solicitud.Folio, nombreBeneficiario = solicitud.NombreBeneficiario, nuevaEstacion = "Dictamen administrativo" });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult RetrocederTramite(string? folio)
        {
            if (string.IsNullOrWhiteSpace(folio))
                return BadRequest("Ingresa un folio.");

            var solicitud = ObtenerSolicitudesSimuladas().FirstOrDefault(s => s.Folio == folio.Trim());

            if (solicitud == null)
                return BadRequest("No se encontró ninguna solicitud con ese folio.");

            if (!EsElegibleParaRetroceso(solicitud))
                return BadRequest("La función solo está permitida en solicitudes devueltas al usuario (estatus Corregido, en Recepción de documentos).");

            // Simulado: no persiste (mismo criterio que el resto del proyecto —
            // ver comentarios de fase en Rechazar/Regresar/DevolverTramite).
            return Json(new { ok = true, id = solicitud.Id, folio = solicitud.Folio, nuevoEstatus = "En proceso", nuevaEstacion = "Dictamen administrativo" });
        }

        public IActionResult Detalle(int id)
        {
            var solicitud = ObtenerSolicitudesSimuladas().FirstOrDefault(s => s.Id == id);
            if (solicitud == null)
                return NotFound();

            var detalle = new SolicitudReembolsoDetalleViewModel
            {
                Id = solicitud.Id,
                Folio = solicitud.Folio,
                Poliza = solicitud.Poliza,
                NombreBeneficiario = solicitud.NombreBeneficiario,
                Parentesco = solicitud.Parentesco,
                Fecha = solicitud.Fecha,
                Estatus = solicitud.Estatus,
                EstacionActual = solicitud.EstacionActual,
                Estaciones = TraducirAEstaciones(solicitud.EstacionActual),
                Monto = solicitud.Monto,
                Cobertura = solicitud.Cobertura,
                SaldoCoberturas = ObtenerSaldoCoberturasSimulado(solicitud),
                Titular = ObtenerTitularSimulado(solicitud),
            };

            (detalle.EdadPaciente, detalle.EstadoPaciente, detalle.MunicipioPaciente) = ObtenerDatosPacienteSimulados(solicitud);

            return View(detalle);
        }

        private static readonly string[] NombresTitularSimulados =
        {
            "Héctor Ceballos Pérez", "Norma Angélica Reyes Domínguez", "Fernando Iván Cárdenas Ruiz",
            "Leticia Guadalupe Solís Manríquez", "Arturo Bernal Chávez", "Yolanda Patricia Estrada Nava",
        };

        private static readonly (string Estado, string Municipio)[] EstadoMunicipioSimulados =
        {
            ("Puebla", "Chapulco"), ("Jalisco", "Guadalajara"), ("Nuevo León", "San Pedro Garza García"),
            ("Estado de México", "Naucalpan"), ("Querétaro", "El Marqués"), ("Guanajuato", "Irapuato"),
        };

        private static TitularSimuladoViewModel ObtenerTitularSimulado(SolicitudReembolsoResumenViewModel solicitud)
        {
            var generador = new Random(solicitud.Id);
            var esTitular = solicitud.Parentesco == "Titular";
            var nombreTitular = esTitular
                ? solicitud.NombreBeneficiario
                : NombresTitularSimulados[solicitud.Id % NombresTitularSimulados.Length];

            var inicioVigencia = new DateTime(2026, 1, 3).AddYears(-generador.Next(0, 5));

            return new TitularSimuladoViewModel
            {
                NumeroEmpleado = solicitud.Poliza,
                NombreCompleto = nombreTitular,
                Grupo = (17000000 + solicitud.Id).ToString(),
                Correo = nombreTitular.Split(' ')[0].ToLowerInvariant() + "." + nombreTitular.Split(' ')[^1].ToLowerInvariant() + "@empresa.com.mx",
                Telefono = $"{generador.Next(10, 99)} {generador.Next(1000, 9999)} {generador.Next(1000, 9999)}",
                FechaInicioVigencia = inicioVigencia,
                FechaFinVigencia = new DateTime(2199, 12, 31),
                MiembroDesde = inicioVigencia,
            };
        }

        private static (int Edad, string Estado, string Municipio) ObtenerDatosPacienteSimulados(SolicitudReembolsoResumenViewModel solicitud)
        {
            var generador = new Random(solicitud.Id + 1000);
            var edad = solicitud.Parentesco switch
            {
                "Hijo(a)" => generador.Next(1, 18),
                _ => generador.Next(25, 65),
            };
            var (estado, municipio) = EstadoMunicipioSimulados[solicitud.Id % EstadoMunicipioSimulados.Length];
            return (edad, estado, municipio);
        }

        private static readonly Dictionary<string, (decimal Asegurada, decimal Pagada, decimal Coaseguro)> LimitesCoberturaSimulados = new()
        {
            ["GMM Mayor"] = (60000m, 0m, 0m),
            ["GMM Menor"] = (10000m, 0m, 0m),
            ["Dental"] = (5000m, 0m, 0m),
            ["Maternidad"] = (30000m, 0m, 0m),
        };

        private static List<SaldoCoberturaViewModel> ObtenerSaldoCoberturasSimulado(SolicitudReembolsoResumenViewModel solicitud) =>
            LimitesCoberturaSimulados.Select(par => new SaldoCoberturaViewModel
            {
                Cobertura = par.Key,
                SumaAsegurada = par.Value.Asegurada,
                SumaPagada = par.Value.Pagada,
                Coaseguro = par.Value.Coaseguro,
                SumaReclamada = par.Key == solicitud.Cobertura ? solicitud.Monto : 0m,
            }).ToList();

        private static List<SolicitudReembolsoResumenViewModel> ObtenerSolicitudesSimuladas() => new()
        {
            new SolicitudReembolsoResumenViewModel { Id = 1,  Folio = "0104271661", Poliza = "34521098", NombreBeneficiario = "Marisol Hernández Duarte",     Parentesco = "Titular",  Monto = 12480.00m, Fecha = new DateTime(2026, 7, 3),  EstacionActual = "Dictamen médico",         Estatus = "En proceso", Cobertura = "GMM Mayor",  Flujo = "Ordinario", FolioFiscal = "3F2A9B7C-D1E4" },
            new SolicitudReembolsoResumenViewModel { Id = 2,  Folio = "0104271662", Poliza = "34558820", NombreBeneficiario = "Roberto Carlos Nieto Salas",    Parentesco = "Titular",  Monto = 3260.50m,  Fecha = new DateTime(2026, 7, 2),  EstacionActual = "Recepción de documentos", Estatus = "Corregido",  Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "8C4D2E1F-A9B3", Nota = "Falta comprobante fiscal (factura CFDI) del gasto reportado.", AutorNota = "Ana López", FechaNota = new DateTime(2026, 7, 2, 11, 20, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 3,  Folio = "0104271663", Poliza = "34509912", NombreBeneficiario = "Fernanda Paola Ríos Castillo",  Parentesco = "Cónyuge", Monto = 850.00m,   Fecha = new DateTime(2026, 7, 1),  EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "Maternidad", Flujo = "Maternidad", FolioFiscal = "1A2B3C4D-5E6F" },
            new SolicitudReembolsoResumenViewModel { Id = 4,  Folio = "0104271664", Poliza = "34577345", NombreBeneficiario = "Alejandro Gómez Treviño",       Parentesco = "Titular",  Monto = 32800.00m, Fecha = new DateTime(2026, 6, 30), EstacionActual = "Autorización de pago",    Estatus = "Aprobado",   Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "7D8E9F0A-B1C2" },
            new SolicitudReembolsoResumenViewModel { Id = 5,  Folio = "0104271665", Poliza = "34512276", NombreBeneficiario = "Itzel Guadalupe Montes Vera",   Parentesco = "Hijo(a)", Monto = 1420.00m,  Fecha = new DateTime(2026, 6, 29), EstacionActual = "Dictamen médico",         Estatus = "En proceso", Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "4B5C6D7E-8F9A" },
            new SolicitudReembolsoResumenViewModel { Id = 6,  Folio = "0104271666", Poliza = "34598010", NombreBeneficiario = "Sergio Iván Delgado Rosales",   Parentesco = "Titular",  Monto = 620.00m,   Fecha = new DateTime(2026, 6, 28), EstacionActual = "Revisión de póliza",      Estatus = "Rechazado",  Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "2E3F4A5B-6C7D", Nota = "El diagnóstico reportado no corresponde a la cobertura seleccionada.", AutorNota = "Marco Villegas", FechaNota = new DateTime(2026, 6, 28, 16, 45, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 7,  Folio = "0104271667", Poliza = "34533187", NombreBeneficiario = "Daniela Contreras Barajas",     Parentesco = "Titular",  Monto = 5140.00m,  Fecha = new DateTime(2026, 6, 27), EstacionActual = "Recepción de documentos", Estatus = "Corregido",  Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "9A0B1C2D-3E4F", Nota = "La factura no coincide con el monto solicitado. Favor de corregir.", AutorNota = "Ana López", FechaNota = new DateTime(2026, 6, 27, 9, 10, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 8,  Folio = "0104271668", Poliza = "34561429", NombreBeneficiario = "Luis Fernando Aguilar Peña",    Parentesco = "Cónyuge",  Monto = 9930.00m,  Fecha = new DateTime(2026, 6, 26), EstacionActual = "Pago autorizado",         Estatus = "En proceso", Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "5C6D7E8F-9A0B" },
            new SolicitudReembolsoResumenViewModel { Id = 9,  Folio = "0104271669", Poliza = "34544567", NombreBeneficiario = "Karla Jimena Suárez Ponce",     Parentesco = "Titular",  Monto = 2150.00m,  Fecha = new DateTime(2026, 6, 25), EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "6A7B8C9D-0E1F" },
            new SolicitudReembolsoResumenViewModel { Id = 10, Folio = "0104271670", Poliza = "34590233", NombreBeneficiario = "Óscar Iván Beltrán Solís",      Parentesco = "Hijo(a)",  Monto = 780.00m,   Fecha = new DateTime(2026, 6, 24), EstacionActual = "Dictamen médico",         Estatus = "Aprobado",   Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "0F1E2D3C-4B5A" },
            new SolicitudReembolsoResumenViewModel { Id = 11, Folio = "0104271671", Poliza = "34567891", NombreBeneficiario = "Paulina Isabel Cordero Luna",   Parentesco = "Titular",  Monto = 15600.00m, Fecha = new DateTime(2026, 6, 23), EstacionActual = "Autorización de pago",    Estatus = "Aprobado",   Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "1B2C3D4E-5F6A" },
            new SolicitudReembolsoResumenViewModel { Id = 12, Folio = "0104271672", Poliza = "34523456", NombreBeneficiario = "Emilio Rodrigo Vargas Nuño",    Parentesco = "Cónyuge",  Monto = 430.00m,   Fecha = new DateTime(2026, 6, 22), EstacionActual = "Revisión de póliza",      Estatus = "Rechazado",  Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "2C3D4E5F-6A7B", Nota = "Documentación incompleta: falta receta médica original.", AutorNota = "Marco Villegas", FechaNota = new DateTime(2026, 6, 22, 14, 5, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 13, Folio = "0104271673", Poliza = "34578901", NombreBeneficiario = "Ximena Alejandra Torres Campos",Parentesco = "Titular",  Monto = 890.00m,   Fecha = new DateTime(2026, 6, 21), EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "Maternidad", Flujo = "Maternidad", FolioFiscal = "3D4E5F6A-7B8C" },
            new SolicitudReembolsoResumenViewModel { Id = 14, Folio = "0104271674", Poliza = "34534567", NombreBeneficiario = "Iván Alberto Reséndiz Cano",     Parentesco = "Titular",  Monto = 7230.00m,  Fecha = new DateTime(2026, 6, 20), EstacionActual = "Recepción de documentos", Estatus = "Corregido",  Cobertura = "GMM Mayor",  Flujo = "Ordinario", FolioFiscal = "4E5F6A7B-8C9D", Nota = "Se solicita la carátula de la póliza vigente para continuar.", AutorNota = "Ana López", FechaNota = new DateTime(2026, 6, 20, 10, 30, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 15, Folio = "0104271675", Poliza = "34589012", NombreBeneficiario = "Regina Montserrat Ochoa Lara",  Parentesco = "Hijo(a)",  Monto = 310.00m,   Fecha = new DateTime(2026, 6, 19), EstacionActual = "Dictamen médico",         Estatus = "En proceso", Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "5F6A7B8C-9D0E" },
            new SolicitudReembolsoResumenViewModel { Id = 16, Folio = "0104271676", Poliza = "34545678", NombreBeneficiario = "Gerardo Iván Palacios Meza",    Parentesco = "Titular",  Monto = 21400.00m, Fecha = new DateTime(2026, 6, 18), EstacionActual = "Pago autorizado",         Estatus = "Aprobado",   Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "6A7B8C9D-0E1F" },
            new SolicitudReembolsoResumenViewModel { Id = 17, Folio = "0104271677", Poliza = "34590123", NombreBeneficiario = "Alondra Sofía Miranda Vega",    Parentesco = "Cónyuge",  Monto = 1980.00m,  Fecha = new DateTime(2026, 6, 17), EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "7B8C9D0E-1F2A" },
            new SolicitudReembolsoResumenViewModel { Id = 18, Folio = "0104271678", Poliza = "34556789", NombreBeneficiario = "Tomás Eduardo Salinas Rocha",   Parentesco = "Titular",  Monto = 540.00m,   Fecha = new DateTime(2026, 6, 16), EstacionActual = "Revisión de póliza",      Estatus = "Rechazado",  Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "8C9D0E1F-2A3B", Nota = "El padecimiento reportado está fuera del periodo de cobertura.", AutorNota = "Marco Villegas", FechaNota = new DateTime(2026, 6, 16, 12, 0, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 19, Folio = "0104271679", Poliza = "34501234", NombreBeneficiario = "Valeria Guadalupe Espinoza Ríos",Parentesco = "Titular", Monto = 3720.00m,  Fecha = new DateTime(2026, 6, 15), EstacionActual = "Recepción de documentos", Estatus = "Corregido",  Cobertura = "GMM Mayor",  Flujo = "Ordinario", FolioFiscal = "9D0E1F2A-3B4C", Nota = "Falta identificación oficial del beneficiario para continuar el trámite.", AutorNota = "Ana López", FechaNota = new DateTime(2026, 6, 15, 8, 50, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 20, Folio = "0104271680", Poliza = "34567345", NombreBeneficiario = "Rodrigo Emiliano Castañeda Ibarra", Parentesco = "Hijo(a)", Monto = 6100.00m, Fecha = new DateTime(2026, 6, 14), EstacionActual = "Dictamen médico",         Estatus = "En proceso", Cobertura = "Maternidad", Flujo = "Maternidad", FolioFiscal = "0E1F2A3B-4C5D" },
            new SolicitudReembolsoResumenViewModel { Id = 21, Folio = "0104271681", Poliza = "34512890", NombreBeneficiario = "Melissa Andrea Guerrero Payán", Parentesco = "Titular",  Monto = 980.00m,   Fecha = new DateTime(2026, 6, 13), EstacionActual = "Autorización de pago",    Estatus = "Aprobado",   Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "1F2A3B4C-5D6E" },
            new SolicitudReembolsoResumenViewModel { Id = 22, Folio = "0104271682", Poliza = "34578456", NombreBeneficiario = "Diego Armando Cervantes Uribe", Parentesco = "Cónyuge",  Monto = 14250.00m, Fecha = new DateTime(2026, 6, 12), EstacionActual = "Pago autorizado",         Estatus = "Aprobado",   Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "2A3B4C5D-6E7F" },
            new SolicitudReembolsoResumenViewModel { Id = 23, Folio = "0104271683", Poliza = "34523901", NombreBeneficiario = "Natalia Fernanda Bravo Solano", Parentesco = "Titular",  Monto = 460.00m,   Fecha = new DateTime(2026, 6, 11), EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "3B4C5D6E-7F8A" },
            new SolicitudReembolsoResumenViewModel { Id = 24, Folio = "0104271684", Poliza = "34589567", NombreBeneficiario = "Jorge Luis Montoya Zepeda",     Parentesco = "Titular",  Monto = 2870.00m,  Fecha = new DateTime(2026, 6, 10), EstacionActual = "Revisión de póliza",      Estatus = "Rechazado",  Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "4C5D6E7F-8A9B", Nota = "Trámite duplicado: ya existe una solicitud registrada para este mismo evento.", AutorNota = "Marco Villegas", FechaNota = new DateTime(2026, 6, 10, 17, 15, 0) },
        };

        private static List<SolicitudReembolsoResumenViewModel> AplicarFiltro(
            List<SolicitudReembolsoResumenViewModel> solicitudes,
            SolicitudReembolsoFiltroViewModel filtro)
        {
            IEnumerable<SolicitudReembolsoResumenViewModel> query = solicitudes;

            if (!string.IsNullOrWhiteSpace(filtro.Folio))
                query = query.Where(s => s.Folio.Contains(filtro.Folio, StringComparison.OrdinalIgnoreCase));

            if (filtro.FechaDesde.HasValue)
                query = query.Where(s => s.Fecha.Date >= filtro.FechaDesde.Value.Date);

            if (filtro.FechaHasta.HasValue)
                query = query.Where(s => s.Fecha.Date <= filtro.FechaHasta.Value.Date);

            if (!string.IsNullOrWhiteSpace(filtro.Estatus) && filtro.Estatus != "Todos")
                query = query.Where(s => string.Equals(s.Estatus, filtro.Estatus, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.Poliza))
                query = query.Where(s => s.Poliza.Contains(filtro.Poliza, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.Cobertura) && filtro.Cobertura != "Todas")
                query = query.Where(s => string.Equals(s.Cobertura, filtro.Cobertura, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.Flujo) && filtro.Flujo != "Todos")
                query = query.Where(s => string.Equals(s.Flujo, filtro.Flujo, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.FolioFiscal))
                query = query.Where(s => s.FolioFiscal.Contains(filtro.FolioFiscal, StringComparison.OrdinalIgnoreCase));

            return query.ToList();
        }

        private static SolicitudReembolsoResultadoViewModel Paginar(
            List<SolicitudReembolsoResumenViewModel> solicitudes,
            int pagina,
            int tamanioPagina)
        {
            if (tamanioPagina <= 0)
                tamanioPagina = TamanioPaginaPorDefecto;

            var totalRegistros = solicitudes.Count;
            var totalPaginas = totalRegistros == 0
                ? 1
                : (int)Math.Ceiling(totalRegistros / (double)tamanioPagina);

            if (pagina < 1)
                pagina = 1;
            if (pagina > totalPaginas)
                pagina = totalPaginas;

            var solicitudesPagina = solicitudes
                .Skip((pagina - 1) * tamanioPagina)
                .Take(tamanioPagina)
                .ToList();

            return new SolicitudReembolsoResultadoViewModel
            {
                Solicitudes = solicitudesPagina,
                Pagina = pagina,
                TamanioPagina = tamanioPagina,
                TotalRegistros = totalRegistros,
                TotalPaginas = totalPaginas,
            };
        }

        private static IReadOnlyList<EstacionDetalleViewModel> TraducirAEstaciones(string estacionActual)
        {
            string[] nombres =
            {
                "Recepción de documentos",
                "Dictamen administrativo",
                "Autorización de pago",
                "Pago autorizado",
            };

            var indiceActual = ResolverIndiceEstacion(estacionActual);

            var estaciones = new List<EstacionDetalleViewModel>();
            for (var i = 0; i < nombres.Length; i++)
            {
                var numero = i + 1;
                estaciones.Add(new EstacionDetalleViewModel
                {
                    Nombre = nombres[i],
                    Estado = numero < indiceActual ? "hecho" : numero == indiceActual ? "actual" : "pendiente",
                });
            }

            return estaciones;
        }

        private static int ResolverIndiceEstacion(string estacionActual)
        {
            if (estacionActual.Contains("Recepción", StringComparison.OrdinalIgnoreCase))
                return 1;

            if (estacionActual.Contains("Autorización de pago", StringComparison.OrdinalIgnoreCase))
                return 3;

            if (estacionActual.Contains("Pago autorizado", StringComparison.OrdinalIgnoreCase))
                return 4;

            return 2;
        }
    }
}

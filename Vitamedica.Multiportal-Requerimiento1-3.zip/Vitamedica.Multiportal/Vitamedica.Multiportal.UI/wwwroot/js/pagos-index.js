/* ============================================================================
   pagos-index.js — Interacciones exclusivas de Views/Pagos/Index.cshtml.

   Fase F2 (ver UI_Decision_Log.md): filtros conectados vía fetch a
   PagosController.Buscar, mismo patrón ya validado en reembolsos-index.js
   (Reembolsos Fase 2/3): core/http.js (getHtml), PartialView (no JSON),
   DOMParser + replaceWith (nunca innerHTML + concatenación). Este archivo
   pasa de script clásico (IIFE) a módulo ES porque necesita `import` de
   core/http.js — al tener scope aislado por especificación del lenguaje, ya
   no necesita la IIFE.

   Fase F3: se agrega paginación real + selector "Mostrar" (tamaño de
   página), mismo mecanismo ya implementado en reembolsos-index.js:
   - buscar(pagina) ahora envía "pagina" y "tamanioPagina" en la query.
   - PagosController.Buscar ahora devuelve _ResultadosYPaginacionPagos
     (tbody + pie concatenados), por lo que reemplazarResultados localiza y
     reemplaza DOS fragmentos: #cuerpoTablaPagos y #pieTablaPagos, ambos
     recalculados por Razor en el servidor — ya no se actualizan
     "tableCount"/"tableRange" a mano desde JS.
   - El cambio de "Mostrar" reinicia siempre a la página 1.
   - Los clics de paginación se delegan sobre .table-panel porque el <nav>
     completo se reemplaza en cada búsqueda (los listeners puestos
     directamente sobre los <a> se perderían).

   Fase F4: se implementa el contrato de estados de carga/vacío/error
   (UI_Coding_Standards.md sección 4, JavaScript_Architecture_Guide.md
   sección 5) — reemplaza el window.alert() genérico que usaba Fase F2/F3
   como solución mínima. "Vacío" lo decide Razor con datos (ver
   _ResultadosPagos.cshtml); este archivo solo alterna cuál de los 3
   <tbody> hermanos (contenido/vacío ya resuelto por el servidor, cargando,
   error) queda visible en cada etapa de la búsqueda — mismo mecanismo que
   reembolsos-index.js.

   Ciclo 7 (ver claude/DEC-Pagos-Layout-Ciclo7-DescargarLayout.md): el botón
   "Layout Pagos" (antes href="#", prototipo sin backend) ahora mantiene su
   href sincronizado con el mismo filtro que ya usa buscar() — se
   actualiza en cada búsqueda (mismos parámetros, mismo query string) y se
   deshabilita si el resultado filtrado no tiene registros, sin necesitar
   un fetch propio: es una navegación de descarga real, no una llamada JSON.
   ============================================================================ */
import { getHtml, postForm, HttpError } from "./core/http.js";
import { refreshIcons } from "./core/icons.js";

const ID_TBODY_CARGANDO = "tbodyCargandoPagos";
const ID_TBODY_ERROR = "tbodyErrorPagos";
const ID_TBODY_RESULTADOS = "cuerpoTablaPagos";

document.addEventListener("DOMContentLoaded", function () {
    initModalRetro();
    initFiltros();
});

// ---- Modal "Retro" — carga real del archivo (Fase Pagos-G1, ver
// UI_Decision_Log.md) — antes solo mostraba el nombre y cerraba el modal,
// sin ningún POST. Mismo patrón que subirArchivoDocumento en
// reembolso-solicitud.js: sube al elegir el archivo (no al "Confirmar"),
// que ahora solo cierra el modal si ya hubo una carga exitosa. ----
function initModalRetro() {
    var input = document.getElementById("inputRetroArchivo");
    var nombre = document.getElementById("retroArchivoNombre");
    var confirmBtn = document.getElementById("btnConfirmarRetro");
    var modalEl = document.getElementById("modalRetro");
    if (!input || !nombre || !confirmBtn || !modalEl) return;

    var archivoCargado = false;

    function reiniciar() {
        archivoCargado = false;
        confirmBtn.disabled = true;
        nombre.textContent = "Ningún archivo seleccionado";
        input.value = "";
    }

    confirmBtn.disabled = true;
    modalEl.addEventListener("hidden.bs.modal", reiniciar);

    input.addEventListener("change", function () {
        var archivo = input.files && input.files[0];
        if (!archivo) { reiniciar(); return; }

        nombre.textContent = "Cargando " + archivo.name + "...";
        confirmBtn.disabled = true;

        subirArchivoRetro(archivo)
            .then(function (data) {
                archivoCargado = true;
                nombre.textContent = data.nombreArchivo;
                confirmBtn.disabled = false;
            })
            .catch(function (error) {
                console.error("[pagos-index]", error);
                window.alert(mensajeErrorCargaRetro(error));
                reiniciar();
            });
    });

    confirmBtn.addEventListener("click", function () {
        if (!archivoCargado) return;
        bootstrap.Modal.getOrCreateInstance(modalEl).hide();
    });
}

function subirArchivoRetro(archivo) {
    var form = document.getElementById("formPagos");
    var tokenInput = form ? form.querySelector("input[name='__RequestVerificationToken']") : null;
    var token = tokenInput ? tokenInput.value : "";
    var datos = new FormData();
    datos.append("archivo", archivo);
    return postForm("/Pagos/SubirArchivoRetro", datos, token);
}

function mensajeErrorCargaRetro(error) {
    if (error instanceof HttpError && error.body) return error.body;
    return "No se pudo cargar el archivo. Intenta de nuevo.";
}

// ---- Filtros + paginación — búsqueda vía fetch, sin recargar la página ----
function initFiltros() {
    var form = document.querySelector(".filters-form");
    var tablePanel = document.querySelector(".table-panel");
    var pageSize = document.getElementById("pageSize");
    if (!form) return;

    var btnBuscar = form.querySelector("button[type=submit]");

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        buscar(1);
    });

    form.addEventListener("reset", function () {
        // El reset nativo del formulario ocurre antes de este evento; se
        // difiere un turno para leer los campos ya restablecidos (mismo
        // patrón ya usado en reembolsos-index.js/clientes-index.js).
        setTimeout(function () { buscar(1); }, 0);
    });

    if (pageSize) {
        pageSize.addEventListener("change", function () {
            buscar(1);
        });
    }

    // Delegación de eventos: el <nav> de paginación se reemplaza por
    // completo en cada búsqueda (viene dentro de #pieTablaPagos), así que
    // el listener se pone sobre .table-panel (que nunca se reemplaza) en
    // lugar de sobre cada <a> individual.
    if (tablePanel) {
        tablePanel.addEventListener("click", function (e) {
            var link = e.target.closest(".pagination-vm .page-link[data-pagina]");
            if (!link) return;

            e.preventDefault();

            var item = link.closest(".page-item");
            if (item && item.classList.contains("disabled")) return;

            var pagina = parseInt(link.getAttribute("data-pagina"), 10);
            if (!isNaN(pagina)) buscar(pagina);
        });
    }

    function buscar(pagina) {
        // Ciclo 7: los filtros de "Descargar Layout" son exactamente los
        // mismos que Buscar (Folio/Fecha desde/Fecha hasta), SIN pagina ni
        // tamanioPagina — el layout exportado no está paginado (ver
        // PagosController.DescargarLayout). Se arma una sola vez y se
        // reutiliza para ambos destinos.
        var paramsFiltro = new URLSearchParams();
        agregarSiTieneValor(paramsFiltro, "folio", "fFolio");
        agregarSiTieneValor(paramsFiltro, "fechaDesde", "fFechaDesde", convertirFecha);
        agregarSiTieneValor(paramsFiltro, "fechaHasta", "fFechaHasta", convertirFecha);

        var params = new URLSearchParams(paramsFiltro);
        params.set("pagina", pagina || 1);
        params.set("tamanioPagina", pageSize ? pageSize.value : "25");

        if (btnBuscar) btnBuscar.disabled = true;
        mostrarEstadoTabla(ID_TBODY_CARGANDO);

        getHtml("/Pagos/Buscar?" + params.toString())
            .then(function (html) {
                reemplazarResultados(html, paramsFiltro);
            })
            .catch(function (error) {
                console.error("[pagos-index]", error);
                // Se oculta el resultado de la búsqueda anterior en vez de
                // dejarlo visible junto al mensaje de error — mismo criterio
                // ya aprobado explícitamente para Reembolsos (Fase E).
                mostrarEstadoTabla(ID_TBODY_ERROR);
            })
            .finally(function () {
                if (btnBuscar) btnBuscar.disabled = false;
            });
    }
}

// ---- "Descargar Layout" (Ciclo 7) — mantiene el enlace sincronizado con
// el filtro vigente, deshabilitado si no hay resultados. No usa fetch: es
// una navegación de descarga real, el propio <a href> hace el trabajo. ----
function actualizarEnlaceLayout(paramsFiltro, totalRegistros) {
    var enlace = document.getElementById("btnDescargarLayout");
    if (!enlace) return;

    var query = paramsFiltro.toString();
    enlace.href = "/Pagos/DescargarLayout" + (query ? "?" + query : "");
    enlace.setAttribute("aria-disabled", totalRegistros > 0 ? "false" : "true");
}

// ---- Estados de carga/vacío/error (Fase F4) ----
// Alterna cuál de los <tbody> hermanos de la tabla queda visible. "Vacío" no
// se maneja aquí: ya llega decidido por el servidor como parte del <tbody>
// de "contenido" (ver _ResultadosPagos.cshtml) — solo "cargando" y "error"
// son estados que este archivo controla, porque ocurren antes de que el
// servidor responda o cuando nunca llega a responder.
function mostrarEstadoTabla(idTbodyVisible) {
    [ID_TBODY_RESULTADOS, ID_TBODY_CARGANDO, ID_TBODY_ERROR].forEach(function (id) {
        var tbody = document.getElementById(id);
        if (tbody) tbody.hidden = (id !== idTbodyVisible);
    });
}

function agregarSiTieneValor(params, nombreParametro, idCampo, transformar) {
    var campo = document.getElementById(idCampo);
    if (!campo) return;

    var valor = campo.value;
    if (transformar) valor = transformar(valor);
    if (valor) params.set(nombreParametro, valor);
}

// El Date Picker entrega dd/mm/aaaa; se convierte a aaaa-mm-dd (ISO 8601)
// antes de enviarlo, mismo criterio ya usado en reembolsos-index.js.
function convertirFecha(valor) {
    var partes = (valor || "").split("/");
    if (partes.length !== 3) return "";
    return partes[2] + "-" + partes[1] + "-" + partes[0];
}

function reemplazarResultados(html, paramsFiltro) {
    // Ciclo 9-bis: se usa <template> en vez de DOMParser porque el fragmento
    // que llega del servidor inicia con un <tbody> suelto (sin <table> que lo
    // envuelva) — el parser HTML de DOMParser.parseFromString descarta <tbody>/
    // <tr>/<td> fuera de contexto de tabla (reglas de construcción del árbol HTML5),
    // por lo que doc.getElementById(ID_TBODY_RESULTADOS) siempre devolvía null y el
    // <tbody> nunca se reemplazaba. El contexto de fragmento de <template> no aplica
    // esa restricción de tabla, así que preserva el <tbody> y su <div> hermano tal
    // cual — ver DEC-Reembolsos-Index-Ciclo9bis-DefectoMostrar.md.
    var template = document.createElement("template");
    template.innerHTML = html;
    var doc = template.content;

    var nuevoCuerpo = doc.getElementById(ID_TBODY_RESULTADOS);
    var cuerpoActual = document.getElementById(ID_TBODY_RESULTADOS);
    if (nuevoCuerpo && cuerpoActual) {
        cuerpoActual.replaceWith(nuevoCuerpo);
    }

    // El nuevo <tbody> (contenido o vacío, ya decidido por el servidor) queda
    // visible; cargando/error se ocultan — cubre tanto el camino normal como
    // una búsqueda exitosa que llega después de un error previo.
    mostrarEstadoTabla(ID_TBODY_RESULTADOS);

    var nuevoPie = doc.getElementById("pieTablaPagos");
    var pieActual = document.getElementById("pieTablaPagos");
    if (nuevoPie && pieActual) {
        pieActual.replaceWith(nuevoPie);
    }

    // Ciclo 7: el nuevo <tbody> ya trae data-total (mismo dato que decide
    // el estado "vacio"/"contenido") — se reutiliza para habilitar o
    // deshabilitar "Descargar Layout" sin una consulta adicional.
    if (nuevoCuerpo && paramsFiltro) {
        var total = parseInt(nuevoCuerpo.getAttribute("data-total"), 10);
        actualizarEnlaceLayout(paramsFiltro, isNaN(total) ? 0 : total);
    }

    // Refresco de íconos Lucide vía core/icons.js — ver DEC-Limpieza-WindowVM.md.
    refreshIcons();
}

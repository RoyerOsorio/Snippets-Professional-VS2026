/* ============================================================================
   reembolsos-index.js — Interacciones exclusivas de Views/Reembolsos/Index.cshtml.

   Fase 2: filtros conectados vía fetch a ReembolsosController.Buscar (ver
   UI_Decision_Log.md) — primera vez que un archivo {pagina}.js de este
   proyecto necesita importar un módulo de core/, por lo que este archivo se
   carga como <script type="module"> (ver @section Scripts en Index.cshtml) en
   vez del <script> clásico no-módulo que usan las demás páginas. Al ser un
   módulo ES ya tiene su propio scope aislado (JavaScript_Architecture_Guide.md,
   sección 6), por lo que ya no necesita la IIFE que sí usan los archivos de
   página clásicos del proyecto.

   Fase 3: se agrega paginación real — el selector "Mostrar" (#pageSize) y los
   controles de navegación (Primera/Anterior/números/Siguiente/Última) ahora
   viajan como pagina/tamanioPagina en la misma búsqueda por fetch. El pie de
   la tabla (contador + rango + nav, id="pieTablaSolicitudes") se reemplaza
   igual que el <tbody> — mismo mecanismo DOMParser + replaceWith, extendido a
   dos fragmentos en vez de uno.

   Fase E: se implementa el contrato de estados de carga/vacío/error
   (UI_Coding_Standards.md sección 4, JavaScript_Architecture_Guide.md
   sección 5) — reemplaza el window.alert() genérico que usaba Fase 2 como
   solución mínima. "Vacío" lo decide Razor con datos (ver
   _ResultadosSolicitudes.cshtml); este archivo solo alterna cuál de los 3
   <tbody> hermanos (contenido/vacío ya resuelto por el servidor, cargando,
   error) queda visible en cada etapa de la búsqueda.

   Sin datos hardcodeados aquí: tanto la carga inicial (Razor, en Index.cshtml)
   como cada búsqueda (fetch + PartialView) traen los datos ya resueltos por
   el Controller — este archivo solo orquesta la interacción.
   ============================================================================ */
import { getJson, getHtml, postJson, HttpError } from "./core/http.js";
import { refreshIcons } from "./core/icons.js";

const TAMANIO_PAGINA_POR_DEFECTO = 25;
const ID_TBODY_CARGANDO = "tbodyCargandoSolicitudes";
const ID_TBODY_ERROR = "tbodyErrorSolicitudes";
const ID_TBODY_RESULTADOS = "cuerpoTablaSolicitudes";

document.addEventListener("DOMContentLoaded", function () {
    initModalNota();
    initFiltros();
    initAccionesTramite();
    initRetrocederTramite();
});

// ---- Modal de Notas — contenido real de la fila que lo abrió ----
// Fase Acciones-G1 (ver UI_Decision_Log.md): antes mostraba siempre la misma
// nota hardcodeada. Ahora lee data-nota/data-autor/data-fecha-nota del botón
// que abrió el modal (ya resueltos por Razor en _ResultadosSolicitudes.cshtml,
// sin fetch adicional) y decide entre el contenido real o el estado "sin
// notas registradas".
function initModalNota() {
    var modalNota = document.getElementById("modalNota");
    if (!modalNota) return;

    var timeline = document.getElementById("notaTimeline");
    var vacio = document.getElementById("notaVacia");
    var texto = document.getElementById("notaTexto");
    var meta = document.getElementById("notaMeta");

    modalNota.addEventListener("show.bs.modal", function (event) {
        var trigger = event.relatedTarget;
        if (!trigger) return;

        var nota = trigger.getAttribute("data-nota") || "";
        var autor = trigger.getAttribute("data-autor") || "";
        var fecha = trigger.getAttribute("data-fecha-nota") || "";

        var hayNota = nota.trim().length > 0;
        if (timeline) timeline.hidden = !hayNota;
        if (vacio) vacio.hidden = hayNota;

        if (hayNota) {
            if (texto) texto.textContent = nota;
            if (meta) meta.textContent = [autor, fecha].filter(Boolean).join(" · ");
        }
    });
}

// ---- Filtros + paginación — búsqueda vía fetch, sin recargar la página ----
function initFiltros() {
    var form = document.querySelector(".filters-form");
    if (!form) return;

    var btnBuscar = form.querySelector("button[type=submit]");
    var pageSize = document.getElementById("pageSize");
    var tablaPanel = document.querySelector(".table-panel");

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        // Cambiar de filtro siempre vuelve a página 1: la página actual
        // podría ya no existir con el nuevo criterio.
        buscar(1);
    });

    form.addEventListener("reset", function () {
        // El reset nativo del formulario ocurre antes de este evento; se
        // difiere un turno para leer los campos ya restablecidos (mismo
        // patrón ya usado en clientes-index.js). "Limpiar filtros" también
        // resetea página y tamaño de página a sus valores por defecto —
        // #pageSize vive fuera de <form>, así que el reset nativo no lo toca.
        setTimeout(function () {
            if (pageSize) pageSize.value = String(TAMANIO_PAGINA_POR_DEFECTO);
            buscar(1);
        }, 0);
    });

    if (pageSize) {
        pageSize.addEventListener("change", function () {
            // Cambiar el tamaño de página también vuelve a página 1.
            buscar(1);
        });
    }

    // Delegación de eventos: el <ul> de paginación se reemplaza por completo
    // en cada búsqueda (mismo mecanismo que el <tbody>), por lo que el
    // listener de clic se ata al contenedor de la tabla, que sí persiste —
    // nunca al <ul> ni a sus <a>, que no.
    if (tablaPanel) {
        tablaPanel.addEventListener("click", function (e) {
            var link = e.target.closest(".pagination-vm .page-link");
            if (!link) return;
            e.preventDefault();

            var item = link.closest(".page-item");
            if (item && item.classList.contains("disabled")) return;

            var pagina = parseInt(link.getAttribute("data-pagina"), 10);
            if (!pagina || pagina < 1) return;

            buscar(pagina);
        });
    }

    function buscar(pagina) {
        var params = new URLSearchParams();
        agregarSiTieneValor(params, "folio", "fFolio");
        agregarSiTieneValor(params, "fechaDesde", "fFechaDesde", convertirFecha);
        agregarSiTieneValor(params, "fechaHasta", "fFechaHasta", convertirFecha);
        agregarSiTieneValor(params, "estatus", "fEstatus", excluirValorTodos);
        agregarSiTieneValor(params, "poliza", "fPoliza");
        agregarSiTieneValor(params, "cobertura", "fCobertura", excluirValorTodos);
        agregarSiTieneValor(params, "flujo", "fFlujo", excluirValorTodos);
        agregarSiTieneValor(params, "folioFiscal", "fFolioFiscal");

        params.set("pagina", String(pagina || 1));
        params.set("tamanioPagina", String((pageSize && pageSize.value) || TAMANIO_PAGINA_POR_DEFECTO));

        if (btnBuscar) btnBuscar.disabled = true;
        mostrarEstadoTabla(ID_TBODY_CARGANDO);

        getHtml("/Reembolsos/Buscar?" + params.toString())
            .then(function (html) {
                reemplazarResultados(html);
            })
            .catch(function (error) {
                console.error("[reembolsos-index]", error);
                // Se oculta el resultado de la búsqueda anterior en vez de
                // dejarlo visible junto al mensaje de error — decisión
                // explícita del usuario (Fase E): evita mostrar datos
                // potencialmente obsoletos junto a un aviso de falla.
                mostrarEstadoTabla(ID_TBODY_ERROR);
            })
            .finally(function () {
                if (btnBuscar) btnBuscar.disabled = false;
            });
    }
}

// ---- Estados de carga/vacío/error (Fase E) ----
// Alterna cuál de los <tbody> hermanos de la tabla queda visible. "Vacío" no
// se maneja aquí: ya llega decidido por el servidor como parte del <tbody>
// de "contenido" (ver _ResultadosSolicitudes.cshtml) — solo "cargando" y
// "error" son estados que este archivo controla, porque ocurren antes de que
// el servidor responda o cuando nunca llega a responder.
function mostrarEstadoTabla(idTbodyVisible) {
    [ID_TBODY_RESULTADOS, ID_TBODY_CARGANDO, ID_TBODY_ERROR].forEach(function (id) {
        var tbody = document.getElementById(id);
        if (tbody) tbody.hidden = (id !== idTbodyVisible);
    });
}

function agregarSiTieneValor(params, nombreParametro, idCampo, transformar) {
    var campo = document.getElementById(idCampo);
    if (!campo) return;

    var valor = campo.value;
    if (transformar) valor = transformar(valor);
    if (valor) params.set(nombreParametro, valor);
}

function excluirValorTodos(valor) {
    return (valor === "Todos" || valor === "Todas") ? "" : valor;
}

// El Date Picker entrega dd/mm/aaaa; se convierte a aaaa-mm-dd (ISO 8601)
// antes de enviarlo, para que el model binder de ASP.NET Core lo interprete
// de forma confiable sin depender de la cultura configurada en el servidor.
// El propio componente Date Picker no se modifica.
function convertirFecha(valor) {
    var partes = (valor || "").split("/");
    if (partes.length !== 3) return "";
    return partes[2] + "-" + partes[1] + "-" + partes[0];
}

function reemplazarResultados(html) {
    // Ciclo 9-bis: se usa <template> en vez de DOMParser porque el fragmento
    // que llega del servidor inicia con un <tbody> suelto (sin <table> que lo
    // envuelva) — el parser HTML de DOMParser.parseFromString descarta <tbody>/
    // <tr>/<td> fuera de contexto de tabla (reglas de construcción del árbol HTML5),
    // por lo que doc.getElementById(ID_TBODY_RESULTADOS) siempre devolvía null y el
    // <tbody> nunca se reemplazaba. El contexto de fragmento de <template> no aplica
    // esa restricción de tabla, así que preserva el <tbody> y su <div> hermano tal
    // cual — ver DEC-Reembolsos-Index-Ciclo9bis-DefectoMostrar.md.
    var template = document.createElement("template");
    template.innerHTML = html;
    var doc = template.content;

    var nuevoCuerpo = doc.getElementById(ID_TBODY_RESULTADOS);
    var cuerpoActual = document.getElementById(ID_TBODY_RESULTADOS);
    if (nuevoCuerpo && cuerpoActual) {
        cuerpoActual.replaceWith(nuevoCuerpo);
    }

    // El nuevo <tbody> (contenido o vacío, ya decidido por el servidor) queda
    // visible; cargando/error se ocultan — cubre tanto el camino normal como
    // una búsqueda exitosa que llega después de un error previo.
    mostrarEstadoTabla(ID_TBODY_RESULTADOS);

    // Fase 3: el pie (contador + rango + nav) llega en el mismo HTML y se
    // reemplaza igual que el <tbody> — ya no se recalculan "N resultados" ni
    // "Mostrando X–Y de Z" en JavaScript (Fase 2 lo hacía y asumía siempre
    // página 1; en Fase 3 ese cálculo depende de la página real y vive solo
    // en _PaginacionSolicitudes.cshtml, sin duplicarlo aquí).
    var nuevoPie = doc.getElementById("pieTablaSolicitudes");
    var pieActual = document.getElementById("pieTablaSolicitudes");
    if (nuevoPie && pieActual) {
        pieActual.replaceWith(nuevoPie);
    }

    // Refresco de íconos Lucide vía core/icons.js — ver DEC-Limpieza-WindowVM.md
    // (cierra la discrepancia registrada en DEC-Reembolsos-Index-Filtros.md:
    // window.VM.refreshIcons() nunca estuvo definido en el proyecto).
    refreshIcons();
}

// ============================================================================
// Rechazar / Regresar trámite (Fase Acciones-G1, ver UI_Decision_Log.md y
// claude/GAP-Resync-2026-08-31.md sección 5). Mismo patrón ya usado en
// clientes-index.js (initEstado/confirmarCambioEstado/aplicarCambioEstado):
// el servidor valida (simulado, no persiste — ver ReembolsosController.
// Rechazar/Regresar) y el cliente actualiza su propia fila tras la
// respuesta exitosa. Un refetch de Buscar() no serviría aquí: el listado
// simulado se regenera sin memoria en cada request.
//
// Diferencia con Clientes: estas dos acciones piden un comentario (Legacy,
// ListaTablero.js) — opcional para Rechazar, obligatorio para Regresar,
// confirmado explícitamente por el usuario, no asumido.
// ============================================================================
var ESTATUS_BADGE = {
    "En proceso": { cls: "badge-status--warning", icon: "clock" },
    "Corregido": { cls: "badge-status--warning", icon: "edit-3" },
    "Aprobado": { cls: "badge-status--success", icon: "check-circle" },
    "Rechazado": { cls: "badge-status--error", icon: "x-circle" }
};

var filaTramiteEnContexto = null;
var accionTramiteEnContexto = null;

function initAccionesTramite() {
    var modalEl = document.getElementById("modalConfirmarAccionTramite");
    if (!modalEl) return;

    var tablaPanel = document.querySelector(".table-panel");
    var textoAccion = document.getElementById("textoAccionTramite");
    var textoDetalle = document.getElementById("textoDetalleTramite");
    var labelComentario = document.getElementById("labelComentarioTramite");
    var comentario = document.getElementById("comentarioAccionTramite");
    var errorComentario = document.getElementById("errorComentarioTramite");
    var btnConfirmar = document.getElementById("btnConfirmarAccionTramite");

    // Delegación de eventos: la fila (y su botón) puede reemplazarse en cada
    // búsqueda — mismo criterio que la paginación (ver initFiltros).
    if (tablaPanel) {
        tablaPanel.addEventListener("click", function (e) {
            var btn = e.target.closest("[data-accion-tramite]");
            if (!btn || btn.disabled) return;

            filaTramiteEnContexto = btn.closest("tr");
            accionTramiteEnContexto = btn.getAttribute("data-accion-tramite");
            var folio = btn.getAttribute("data-folio") || "";

            var esRegresar = accionTramiteEnContexto === "Regresar";
            textoAccion.textContent = esRegresar
                ? "¿Regresar el trámite " + folio + " a Dictamen médico?"
                : "¿Rechazar el trámite " + folio + "?";
            textoDetalle.textContent = esRegresar
                ? "El trámite volverá a la estación de Dictamen médico para su revisión."
                : "Se notificará al asegurado que su trámite fue rechazado.";
            labelComentario.textContent = "Comentario" + (esRegresar ? " (obligatorio)" : " (opcional)");
            comentario.value = "";
            comentario.required = esRegresar;
            errorComentario.hidden = true;

            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        });
    }

    if (btnConfirmar) {
        btnConfirmar.addEventListener("click", function () {
            if (!filaTramiteEnContexto || !accionTramiteEnContexto) {
                bootstrap.Modal.getOrCreateInstance(modalEl).hide();
                return;
            }

            var esRegresar = accionTramiteEnContexto === "Regresar";
            var textoComentario = comentario.value.trim();

            if (esRegresar && textoComentario === "") {
                errorComentario.hidden = false;
                comentario.focus();
                return;
            }
            errorComentario.hidden = true;

            var fila = filaTramiteEnContexto;
            var accion = accionTramiteEnContexto;
            btnConfirmar.disabled = true;

            confirmarAccionTramite(fila, accion, textoComentario)
                .then(function (resultado) {
                    aplicarAccionTramite(fila, resultado);
                })
                .catch(function (error) {
                    console.error("[reembolsos-index]", error);
                    window.alert(mensajeErrorAccionTramite(error));
                })
                .finally(function () {
                    btnConfirmar.disabled = false;
                    bootstrap.Modal.getOrCreateInstance(modalEl).hide();
                    filaTramiteEnContexto = null;
                    accionTramiteEnContexto = null;
                });
        });
    }
}

function confirmarAccionTramite(fila, accion, comentario) {
    var form = document.getElementById("formReembolsosIndex");
    var tokenInput = form ? form.querySelector("input[name='__RequestVerificationToken']") : null;
    var token = tokenInput ? tokenInput.value : "";
    var id = fila.getAttribute("data-id");
    var url = "/Reembolsos/" + accion + "?id=" + encodeURIComponent(id) + "&comentario=" + encodeURIComponent(comentario || "");
    return postJson(url, {}, token);
}

function mensajeErrorAccionTramite(error) {
    if (error instanceof HttpError && error.body) return error.body;
    return "No se pudo actualizar el trámite. Intenta de nuevo.";
}

function aplicarAccionTramite(fila, resultado) {
    if (!resultado || !fila) return;

    if (resultado.nuevoEstatus) {
        var badge = fila.querySelector("[data-badge-estatus]");
        var info = ESTATUS_BADGE[resultado.nuevoEstatus];
        if (badge && info) {
            badge.className = "badge-status " + info.cls;
            badge.innerHTML = '<i data-lucide="' + info.icon + '" aria-hidden="true"></i>' + resultado.nuevoEstatus;
        }
    }

    if (resultado.nuevaEstacion) {
        var textoEstacion = fila.querySelector("[data-badge-estacion-texto]");
        if (textoEstacion) textoEstacion.textContent = resultado.nuevaEstacion;
    }

    // Si el trámite quedó en un estado final (Rechazado), Rechazar/Regresar
    // dejan de tener sentido para esa fila — mismo criterio ya aplicado por
    // Razor al renderizar (_ResultadosSolicitudes.cshtml, "esEstadoFinal").
    var esFinal = resultado.nuevoEstatus === "Aprobado" || resultado.nuevoEstatus === "Rechazado";
    if (esFinal) {
        fila.querySelectorAll("[data-accion-tramite]").forEach(function (btn) {
            btn.disabled = true;
            btn.title = "No disponible: la solicitud ya está en un estado final";
        });
    }

    refreshIcons();
}


// ---- Retroceder trámite (Ciclo 6, ver DEC-...) — búsqueda por folio, no
// por fila (el trámite elegible no está necesariamente visible en la
// página/filtro actual de la tabla, igual que en Legacy). 3 pasos dentro
// del mismo modal: buscar → confirmar → resultado.
function initRetrocederTramite() {
    var modalEl = document.getElementById("modalRetrocederTramite");
    if (!modalEl) return;

    var pasoBuscar = modalEl.querySelector('[data-retroceso-paso="buscar"]');
    var pasoConfirmar = modalEl.querySelector('[data-retroceso-paso="confirmar"]');
    var pasoResultado = modalEl.querySelector('[data-retroceso-paso="resultado"]');
    var form = modalEl.querySelector("[data-retroceso-buscar-form]");
    var inputFolio = document.getElementById("inputFolioRetroceso");
    var errorFolio = document.getElementById("errorRetrocesoFolio");
    var textoConfirmar = document.getElementById("textoConfirmarRetroceso");
    var textoResultado = document.getElementById("textoResultadoRetroceso");
    var btnCancelar = document.getElementById("btnCancelarRetroceso");
    var btnConfirmar = document.getElementById("btnConfirmarRetroceso");
    var btnCerrar = document.getElementById("btnCerrarRetroceso");

    var folioEnContexto = null;
    var idEnContexto = null;

    function mostrarPaso(paso) {
        pasoBuscar.hidden = paso !== "buscar";
        pasoConfirmar.hidden = paso !== "confirmar";
        pasoResultado.hidden = paso !== "resultado";
        btnCancelar.hidden = paso === "resultado";
        btnConfirmar.hidden = paso !== "confirmar";
        btnCerrar.hidden = paso !== "resultado";
    }

    modalEl.addEventListener("show.bs.modal", function () {
        folioEnContexto = null;
        idEnContexto = null;
        if (inputFolio) inputFolio.value = "";
        if (errorFolio) errorFolio.hidden = true;
        mostrarPaso("buscar");
    });

    if (form) {
        form.addEventListener("submit", function (e) {
            e.preventDefault();
            var folio = (inputFolio.value || "").trim();
            if (folio === "") {
                errorFolio.textContent = "Ingresa un folio.";
                errorFolio.hidden = false;
                inputFolio.focus();
                return;
            }
            errorFolio.hidden = true;

            var submitBtn = form.querySelector("button[type=submit]");
            if (submitBtn) submitBtn.disabled = true;

            getJson("/Reembolsos/ValidarRetroceso?folio=" + encodeURIComponent(folio))
                .then(function (resultado) {
                    if (!resultado || !resultado.ok) {
                        errorFolio.textContent = (resultado && resultado.message) || "No se pudo validar el folio.";
                        errorFolio.hidden = false;
                        return;
                    }
                    folioEnContexto = resultado.folio;
                    idEnContexto = resultado.id;
                    textoConfirmar.textContent = "El trámite " + resultado.folio +
                        (resultado.nombreBeneficiario ? " (" + resultado.nombreBeneficiario + ")" : "") +
                        " será regresado a " + resultado.nuevaEstacion + ". ¿Deseas continuar?";
                    mostrarPaso("confirmar");
                })
                .catch(function (error) {
                    console.error("[reembolsos-index]", error);
                    errorFolio.textContent = mensajeErrorAccionTramite(error);
                    errorFolio.hidden = false;
                })
                .finally(function () {
                    if (submitBtn) submitBtn.disabled = false;
                });
        });
    }

    if (btnConfirmar) {
        btnConfirmar.addEventListener("click", function () {
            if (!folioEnContexto) return;

            var form2 = document.getElementById("formReembolsosIndex");
            var tokenInput = form2 ? form2.querySelector("input[name='__RequestVerificationToken']") : null;
            var token = tokenInput ? tokenInput.value : "";

            btnConfirmar.disabled = true;

            postJson("/Reembolsos/RetrocederTramite?folio=" + encodeURIComponent(folioEnContexto), {}, token)
                .then(function (resultado) {
                    aplicarResultadoRetroceso(idEnContexto, resultado);
                    textoResultado.textContent = "El trámite " + resultado.folio + " fue regresado a " + resultado.nuevaEstacion + ".";
                    mostrarPaso("resultado");
                })
                .catch(function (error) {
                    console.error("[reembolsos-index]", error);
                    window.alert(mensajeErrorAccionTramite(error));
                })
                .finally(function () {
                    btnConfirmar.disabled = false;
                });
        });
    }
}

// Actualiza la fila en pantalla solo si el trámite regresado ya está
// visible en la página/filtro actual de la tabla — mismo criterio de
// aplicarAccionTramite, reutilizado aquí porque es el mismo contrato de
// respuesta (nuevoEstatus/nuevaEstacion).
function aplicarResultadoRetroceso(id, resultado) {
    if (!id || !resultado) return;
    var fila = document.querySelector('tr[data-id="' + id + '"]');
    if (!fila) return;
    aplicarAccionTramite(fila, resultado);
}

using FluentAssertions;
using MprGestionReclamos.Domain.Entidades;
using MprGestionReclamos.Domain.Excepciones;
using Xunit;

namespace MprGestionReclamos.Application.Tests;

public class ReclamoTests
{
    private static readonly DateTime Ahora = new(2026, 8, 18, 12, 0, 0, DateTimeKind.Utc);

    [Fact]
    public void Crear_devuelve_un_Reclamo_en_estado_Creado()
    {
        var reclamo = Reclamo.Crear("POL-001", 1, 10, Ahora);

        reclamo.Estado.Should().Be(EstadoReclamo.Creado);
    }

    [Fact]
    public void EnviarParaRevision_transiciona_de_Creado_a_EnviadoParaRevision()
    {
        var reclamo = Reclamo.Crear("POL-001", 1, 10, Ahora);

        reclamo.EnviarParaRevision(Ahora.AddMinutes(5));

        reclamo.Estado.Should().Be(EstadoReclamo.EnviadoParaRevision);
        reclamo.FechaEnvio.Should().Be(Ahora.AddMinutes(5));
    }

    [Fact]
    public void EnviarParaRevision_lanza_excepcion_si_el_Reclamo_no_esta_en_Creado()
    {
        var reclamo = Reclamo.Crear("POL-001", 1, 10, Ahora);
        reclamo.EnviarParaRevision(Ahora);

        var accion = () => reclamo.EnviarParaRevision(Ahora);

        accion.Should().Throw<TransicionEstadoInvalidaException>();
    }

    [Fact]
    public void Aprobar_transiciona_de_EnviadoParaRevision_a_Aprobado_y_registra_el_monto()
    {
        var reclamo = Reclamo.Crear("POL-001", 1, 10, Ahora);
        reclamo.EnviarParaRevision(Ahora);

        reclamo.Aprobar(1500m, Ahora.AddDays(1));

        reclamo.Estado.Should().Be(EstadoReclamo.Aprobado);
        reclamo.MontoAprobado.Should().Be(1500m);
    }

    [Fact]
    public void Aprobar_lanza_excepcion_si_el_Reclamo_sigue_en_Creado()
    {
        var reclamo = Reclamo.Crear("POL-001", 1, 10, Ahora);

        var accion = () => reclamo.Aprobar(1500m, Ahora);

        accion.Should().Throw<TransicionEstadoInvalidaException>();
    }

    [Fact]
    public void Aprobar_lanza_excepcion_si_el_monto_no_es_positivo()
    {
        var reclamo = Reclamo.Crear("POL-001", 1, 10, Ahora);
        reclamo.EnviarParaRevision(Ahora);

        var accion = () => reclamo.Aprobar(0m, Ahora);

        accion.Should().Throw<ArgumentOutOfRangeException>();
    }

    [Fact]
    public void Rechazar_transiciona_de_EnviadoParaRevision_a_Rechazado_y_registra_el_motivo()
    {
        var reclamo = Reclamo.Crear("POL-001", 1, 10, Ahora);
        reclamo.EnviarParaRevision(Ahora);

        reclamo.Rechazar("Documentación insuficiente", Ahora.AddDays(1));

        reclamo.Estado.Should().Be(EstadoReclamo.Rechazado);
        reclamo.MotivoRechazo.Should().Be("Documentación insuficiente");
    }

    [Fact]
    public void Rechazar_lanza_excepcion_si_el_Reclamo_ya_esta_Aprobado()
    {
        var reclamo = Reclamo.Crear("POL-001", 1, 10, Ahora);
        reclamo.EnviarParaRevision(Ahora);
        reclamo.Aprobar(1500m, Ahora);

        var accion = () => reclamo.Rechazar("tarde", Ahora);

        accion.Should().Throw<TransicionEstadoInvalidaException>();
    }
}

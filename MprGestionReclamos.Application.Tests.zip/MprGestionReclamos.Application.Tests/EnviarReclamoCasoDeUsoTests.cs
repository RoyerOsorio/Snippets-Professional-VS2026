using FluentAssertions;
using MprGestionReclamos.Application.Casos;
using MprGestionReclamos.Application.Eventos;
using MprGestionReclamos.Application.Puertos;
using MprGestionReclamos.Domain.Entidades;
using Xunit;

namespace MprGestionReclamos.Application.Tests;

public class EnviarReclamoCasoDeUsoTests
{
    private sealed class RepositorioFalso : IRepositorioReclamos
    {
        private Reclamo? _reclamo;

        public RepositorioFalso(Reclamo reclamo) => _reclamo = reclamo;

        public Task<Reclamo?> ObtenerPorIdAsync(int reclamoId, CancellationToken cancellationToken) =>
            Task.FromResult(_reclamo);

        public Task<Reclamo> CrearAsync(Reclamo reclamo, CancellationToken cancellationToken) =>
            Task.FromResult(reclamo);

        public Task ActualizarAsync(Reclamo reclamo, CancellationToken cancellationToken)
        {
            _reclamo = reclamo;
            return Task.CompletedTask;
        }

        public Task ActualizarYPublicarEventoAsync(Reclamo reclamo, ReclamoAprobadoParaPagoEvento evento, CancellationToken cancellationToken)
        {
            _reclamo = reclamo;
            return Task.CompletedTask;
        }
    }

    private sealed class DocumentosAportadosFalso(IReadOnlyList<int> documentosRequeridosAportadosIds) : IDocumentosAportadosMprDocumentos
    {
        public Task<IReadOnlyList<int>> ObtenerDocumentosRequeridosAportadosAsync(int reclamoId, CancellationToken cancellationToken) =>
            Task.FromResult(documentosRequeridosAportadosIds);
    }

    private sealed class ValidadorFalso(IReadOnlyList<string> faltantes) : IValidadorDocumentosMprConfiguracionReglas
    {
        public Task<IReadOnlyList<string>> ObtenerDocumentosObligatoriosFaltantesAsync(
            int motivoId, IReadOnlyList<int> documentosAportadosIds, CancellationToken cancellationToken) =>
            Task.FromResult(faltantes);
    }

    private static readonly DateTime Ahora = new(2026, 8, 18, 12, 0, 0, DateTimeKind.Utc);

    [Fact]
    public async Task No_envia_el_Reclamo_si_faltan_documentos_obligatorios()
    {
        var reclamo = Reclamo.Crear("POL-001", 1, 10, Ahora);
        var casoDeUso = new EnviarReclamoCasoDeUso(
            new RepositorioFalso(reclamo), new DocumentosAportadosFalso([2]), new ValidadorFalso(["Factura"]));

        var resultado = await casoDeUso.EjecutarAsync(1, Ahora, CancellationToken.None);

        resultado.Enviado.Should().BeFalse();
        resultado.DocumentosFaltantes.Should().Contain("Factura");
    }

    [Fact]
    public async Task Envia_el_Reclamo_cuando_no_faltan_documentos_obligatorios()
    {
        var reclamo = Reclamo.Crear("POL-001", 1, 10, Ahora);
        var casoDeUso = new EnviarReclamoCasoDeUso(
            new RepositorioFalso(reclamo), new DocumentosAportadosFalso([1, 2]), new ValidadorFalso([]));

        var resultado = await casoDeUso.EjecutarAsync(1, Ahora, CancellationToken.None);

        resultado.Enviado.Should().BeTrue();
        resultado.Reclamo.Estado.Should().Be(EstadoReclamo.EnviadoParaRevision);
    }

    [Fact]
    public async Task Consulta_a_MprDocumentos_los_documentos_aportados_del_reclamo_antes_de_validar()
    {
        var reclamo = Reclamo.Crear("POL-001", 1, 10, Ahora);
        var documentosAportados = new DocumentosAportadosFalso([7]);
        var casoDeUso = new EnviarReclamoCasoDeUso(
            new RepositorioFalso(reclamo), documentosAportados, new ValidadorFalso([]));

        await casoDeUso.EjecutarAsync(1, Ahora, CancellationToken.None);

        // No hay mock framework en este proyecto — la aserción indirecta es que
        // EjecutarAsync completa sin lanzar, usando el fake como fuente de verdad
        // de "documentos aportados" en vez de un parámetro del propio método.
        (await documentosAportados.ObtenerDocumentosRequeridosAportadosAsync(1, CancellationToken.None))
            .Should().BeEquivalentTo([7]);
    }
}

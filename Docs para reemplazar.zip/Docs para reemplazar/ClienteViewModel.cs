namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Cliente (dbo.MTP_GRGR_GRUPO). Alimenta el único formulario compartido
/// Views/Shared/Partials/_ClienteForm.cshtml, usado tanto por CreacionCliente
/// (modelo vacío) como por DetalleCliente (modelo precargado).
///
/// Solo se exponen los campos de negocio de la imagen de referencia Grupo.
/// Se excluyen deliberadamente los campos técnicos/de auditoría de esa misma
/// tabla (usuario y fecha de alta/actualización, proceso de alta/actualización,
/// contraseñas de biometría, clave CNSF, ck, archivo de logo, catálogo/domicilio
/// fiscal por id): son datos que el sistema gestiona por sí mismo o que
/// pertenecen a un flujo de configuración distinto, no a la captura manual de
/// un Cliente. GRGR_ESTATUS tampoco es un campo del formulario: se gestiona
/// exclusivamente desde el Index (Desactivar/Reactivar), igual que dicta el
/// patrón CRUD oficial del proyecto.
///
/// Fase sin persistencia: no hay anotaciones de validación de framework ni
/// binding real a base de datos — la validación de campos requeridos y de
/// selección mínima ocurre en cliente-form.js, tal como ya ocurre en
/// ReembolsoSolicitud.
///
/// Módulos / Coberturas / Documentos: los tres catálogos son listas planas de
/// objetos relacionados por Id/ParentId (ModuloCatalogoItem / CoberturaCatalogoItem
/// / DocumentoCatalogoItem, definidos más abajo en este mismo archivo) — misma
/// forma que tendrían llegando de SQL Server/API en el futuro. El Controller es
/// responsable de obtenerlos (hoy simulados, después vía Service) y asignarlos a
/// estas propiedades de instancia; el ViewModel nunca los genera por sí mismo,
/// para no mezclar obtención de datos con la capa de presentación.
/// </summary>
public class ClienteViewModel
{
    public int? Id { get; set; } // GRGR_NID

    public string? NombreORazonSocial { get; set; } // GRGR_DESCASEGURADORA
    public string? Rfc { get; set; } // GRGR_RFC
    public string? Direccion { get; set; } // GRGR_DIRECCION
    public string? Telefono { get; set; } // GRGR_TELEFONO
    public string? NombreContacto { get; set; } // GRGR_NOMCONTACTO
    public string? TelefonoContacto { get; set; } // GRGR_TELCONTACTO
    public string? TelefonoInterior { get; set; } // GRGR_TEL_INTERIOR
    public string? TelefonoAtencion { get; set; } // GRGR_TELATENCION
    public string? DescripcionCorta { get; set; } // GRGR_DESCRIPCION_CORTA
    public string? FechaCorte { get; set; } // GRGR_FECHA_CORTE
    public string? FechaDiaHabil { get; set; } // GRGR_FECHA_DIA_HABIL
    public string? PrestadorServicio { get; set; } // GRGR_PRESTADOR_SERVICIO
    public bool ImprimeCredencial { get; set; } // GRGR_IMPRIME_CREDENCIAL

    /// <summary>Solo lectura fuera de este formulario. Activo por defecto al crear.</summary>
    public string Estatus { get; set; } = "Activo"; // GRGR_ESTATUS

    public List<FilialViewModel> Filiales { get; set; } = new();

    public List<int> ModulosSeleccionados { get; set; } = new();
    public List<int> CoberturasSeleccionadas { get; set; } = new();
    public List<int> DocumentosSeleccionados { get; set; } = new();

    // --------------------------------------------------------------------
    // Catálogos de Módulos/Coberturas/Documentos — propiedades de instancia,
    // pobladas por el Controller (hoy con datos simulados, después vía
    // Service/API/DB). Deliberadamente NO estáticas en el ViewModel: la
    // obtención de datos no pertenece a la capa de presentación.
    // --------------------------------------------------------------------
    public List<ModuloCatalogoItem> CatalogoModulos { get; set; } = new();
    public List<CoberturaCatalogoItem> CatalogoCoberturas { get; set; } = new();
    public List<DocumentoCatalogoItem> CatalogoDocumentos { get; set; } = new();
}

/// <summary>Catálogo simulado de Módulos. Ver <see cref="ClienteViewModel"/> para contexto.</summary>
public class ModuloCatalogoItem
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
}

/// <summary>Catálogo simulado de Coberturas, relacionado a su Módulo por <see cref="ModuloId"/>.</summary>
public class CoberturaCatalogoItem
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public int ModuloId { get; set; }
}

/// <summary>Catálogo simulado de Documentos requeridos, relacionado a su Cobertura por <see cref="CoberturaId"/>.</summary>
public class DocumentoCatalogoItem
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public int CoberturaId { get; set; }
}

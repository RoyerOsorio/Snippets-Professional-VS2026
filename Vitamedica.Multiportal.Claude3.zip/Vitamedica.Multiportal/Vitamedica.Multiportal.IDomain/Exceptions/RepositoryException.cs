﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Domain.Exceptions
{
    public class RepositoryException : Exception
    {
        public RepositoryException(string message, Exception innerException)
            : base(message, innerException) { }
    }
}

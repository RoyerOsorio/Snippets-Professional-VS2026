﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Domain.Entities.ActiveDirectory
{
    public class GroupResume
    {
        public string Nombre { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Domain.Entities.ActiveDirectory
{
    public class UserAuth
    {
        public string? Usuario { get; set; }
        public bool EsAutenticado { get; set; }
        public bool EsBloqueado { get; set; }
        public bool Existe { get; set; }
    }
}

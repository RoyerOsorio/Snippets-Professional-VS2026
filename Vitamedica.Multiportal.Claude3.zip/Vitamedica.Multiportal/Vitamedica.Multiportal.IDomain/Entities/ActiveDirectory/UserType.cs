﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Domain.Entities.ActiveDirectory
{
    public enum UserType
    {
        Generico = 0,

        EmpleadoVitamedica = 1,

        DerechohabienteSalud = 2,

        Membresia = 3,

        Medico = 4,

        HospitalAdmin = 5,

        Hospital = 6,

        FarmaciaAdmin = 7,

        Farmacia = 8,

        FarmaceuticaAdmin = 9,

        Farmaceutica = 10,

        AseguradoBBVA = 11
    }
}

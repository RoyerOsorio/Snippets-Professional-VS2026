﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Domain.Entities.Multiportal.Catalogo
{
    public class MotivoRechazo
    {
        public int MTMT_NID { get; set; }
        public string MTMT_DESCRIPCION { get; set; } = string.Empty;
        public int FRFR_NID { get; set; }
        public int TRTR_NID { get; set; }
        public string TRTR_DESCRIPCION { get; set; } = string.Empty;
        public int MNCR_NID { get; set; }
        public string MNCR_MENSAJE { get; set; } = string.Empty;
    }
}

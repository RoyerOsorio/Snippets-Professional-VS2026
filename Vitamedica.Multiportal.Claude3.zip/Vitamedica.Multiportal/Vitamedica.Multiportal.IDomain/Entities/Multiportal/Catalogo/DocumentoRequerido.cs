﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Domain.Entities.Multiportal.Catalogo
{
    public class DocumentoRequerido
    {
        public int DRDR_NID { get; set; }
        public string DRDR_DOCUMENTO { get; set; } = string.Empty;
        public string DRDR_OBSERVACIONES { get; set; } = string.Empty;
        public bool DRDR_ESFACTURA { get; set; }
        public int DRDR_MAXIMOPERMITIDO { get; set; }
        public int MRMR_NID { get; set; }
        public bool MRDR_OBLIGATORIO { get; set; }
    }
}

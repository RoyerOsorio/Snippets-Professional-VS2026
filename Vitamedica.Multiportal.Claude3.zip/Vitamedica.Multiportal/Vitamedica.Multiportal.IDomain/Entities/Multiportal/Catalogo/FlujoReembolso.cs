﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Domain.Entities.Multiportal.Catalogo
{
    public class FlujoReembolso
    {
        public int FRFR_NID { get; set; }
        public string FRFR_FLUJO { get; set; } = string.Empty;
    }
}

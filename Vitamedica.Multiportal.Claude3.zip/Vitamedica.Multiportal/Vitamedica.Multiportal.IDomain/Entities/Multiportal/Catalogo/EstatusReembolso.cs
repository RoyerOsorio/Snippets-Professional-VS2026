﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Domain.Entities.Multiportal.Catalogo
{
    public class EstatusReembolso
    {
        public int STST_NID { get; set; }
        public string STST_STATUS { get; set; } = string.Empty;
    }
}

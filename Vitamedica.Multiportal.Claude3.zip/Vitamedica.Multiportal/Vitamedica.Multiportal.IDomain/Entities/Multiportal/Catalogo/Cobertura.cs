﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Domain.Entities.Multiportal.Catalogo
{
    public class Cobertura
    {
        public int IdCobertura { get; set; }
        public string Descripcion { get; set; } = string.Empty;
        public bool Activa { get; set; }
        public bool Nacional { get; set; }
        public decimal Monto { get; set; }
        public decimal LimiteEvento { get; set; }
        public decimal Coaseguro { get; set; }
        public decimal Deducible { get; set; }
    }
}

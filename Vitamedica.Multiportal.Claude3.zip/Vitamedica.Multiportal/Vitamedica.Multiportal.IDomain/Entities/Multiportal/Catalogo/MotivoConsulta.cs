﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Domain.Entities.Multiportal.Catalogo
{
    public class MotivoConsulta
    {


        public int MTCN_NID { get; set; }
        public string MTCN_DESCRIPCION { get; set; } = string.Empty;
    }
}

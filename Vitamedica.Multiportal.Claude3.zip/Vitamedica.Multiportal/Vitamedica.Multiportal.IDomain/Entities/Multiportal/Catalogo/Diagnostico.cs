﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Domain.Entities.Multiportal.Catalogo
{
    public class Diagnostico
    {
        public string ICD { get; set; } = string.Empty;
        public string IDDIAG { get; set; } = string.Empty;

        public string DESCRIPCION { get; set; } = string.Empty;

        public string GRUPO { get; set; } = string.Empty;

    }
}

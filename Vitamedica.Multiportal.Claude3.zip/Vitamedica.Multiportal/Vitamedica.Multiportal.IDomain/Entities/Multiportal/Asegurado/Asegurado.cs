﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Domain.Entities.Multiportal.Asegurado
{
    public class Asegurado
    {
        //public required string Poliza { get; set; }
        //public required string Nombre { get; set; }
        //public string ApellidoPaterno { get; set; } = string.Empty;
        //public string ApellidoMaterno { get; set; } = string.Empty;
        //public DateTime FechaNacimiento { get; set; }
        //public DateTime FechaInicioVigencia { get; set; }
        //public DateTime FechaFinVigencia { get; set; }
        //public DateTime MiembroDesde { get; set; }

        public string GRGR_ID { get; set; } = string.Empty;
        public string SBGR_ID { get; set; } = string.Empty;
        public string PLPL_POLIZA { get; set; } = string.Empty;
        public DateTime PLVG_INICIO_VIGENCIA { get; set; }
        public DateTime PLVG_FIN_VIGENCIA { get; set; }
        public int RARA_NID { get; set; }
        public string RARA_NOMBRE_ROL_ASEGURADO { get; set; } = string.Empty;
        public int ASAS_NID { get; set; }
        public string ASAS_NOMBRE { get; set; } = string.Empty;
        public string ASAS_PRIMER_APELLIDO { get; set; } = string.Empty;
        public string ASAS_SEGUNDO_APELLIDO { get; set; } = string.Empty;
        public DateTime ASAS_FECHA_NACIMIENTO { get; set; }
        public int GEGE_NID { get; set; }
        public string GEGE_CLAVE { get; set; } = string.Empty;
        public string GEGE_DESCRIPCION { get; set; } = string.Empty;
    }
}

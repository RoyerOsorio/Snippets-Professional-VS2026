﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Domain.Entities.EndPoint
{
    public class EndPointSetting
    {
        public required string BaseUrl { get; set; } = string.Empty;
        public int TimeoutSeconds { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Vitamedica.Multiportal.Application.Exceptions;
using Vitamedica.Multiportal.Domain.Exceptions;

namespace Vitamedica.Multiportal.API.Middleware
{
    public class GlobalExceptionHandler : IExceptionHandler
    {
        private readonly ILogger<GlobalExceptionHandler> _logger;

        public GlobalExceptionHandler(ILogger<GlobalExceptionHandler> logger)
        {
            _logger = logger;
        }

        public async ValueTask<bool> TryHandleAsync(
            HttpContext httpContext,
            Exception exception,
            CancellationToken cancellationToken)
        {
            _logger.LogError(exception, "Excepción no controlada: {Message}", exception.Message);

            var (statusCode, title) = exception switch
            {
                NotFoundException => (StatusCodes.Status404NotFound, "Recurso no encontrado"),
                ValidationException => (StatusCodes.Status400BadRequest, "Error de validación"),
                DomainException => (StatusCodes.Status422UnprocessableEntity, "Error de negocio"),
                RepositoryException => (StatusCodes.Status503ServiceUnavailable, "Error de acceso a datos"),
                _ => (StatusCodes.Status500InternalServerError, "Error interno del servidor")
            };

            httpContext.Response.StatusCode = statusCode;

            await httpContext.Response.WriteAsJsonAsync(new ProblemDetails
            {
                Status = statusCode,
                Title = title,
                Detail = exception.Message,
                Instance = httpContext.Request.Path
            }, cancellationToken);

            return true;
        }
    }
}

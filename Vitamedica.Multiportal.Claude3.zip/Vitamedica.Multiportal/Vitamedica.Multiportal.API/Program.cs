using AutoMapper;
using System.Reflection;
using System.ServiceModel;
using Vitamedica.Multiportal.API.Middleware;
using Vitamedica.Multiportal.Application;
using Vitamedica.Multiportal.Application.Interfaces;
using Vitamedica.Multiportal.Application.InterfacesRepository;
using Vitamedica.Multiportal.Application.Mapping;
using Vitamedica.Multiportal.Domain.Entities.EndPoint;
using Vitamedica.Multiportal.Infrastructure;
using Vitamedica.Multiportal.Infrastructure.Data;

var builder = WebApplication.CreateBuilder(args);

// Manejo global de excepciones
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
builder.Services.AddProblemDetails();

//Factory
builder.Services.AddScoped<IDbConnectionFactory, DbConnectionFactory>();

//App
builder.Services.AddScoped<IActiveDirectoryApplication, ActiveDirectoryApplication>();
builder.Services.AddScoped<ICatalogoApplication, CatalogoApplication>();
builder.Services.AddScoped<IVigorApplication, VigorApplication>();

//Infra
var authSettings = builder.Configuration.GetSection("ExternalServices:ActiveDirectory").Get<EndPointSetting>();

if (authSettings != null)
{
    builder.Services.AddSingleton(authSettings);



    builder.Services.AddScoped<IActiveDirectoryService>(provider =>
    {
        var mode = authSettings.BaseUrl.StartsWith("https")
                   ? BasicHttpSecurityMode.Transport
                   : BasicHttpSecurityMode.None;

        var binding = new BasicHttpBinding(mode);
        var endPoint = new EndpointAddress(authSettings.BaseUrl);

        return new ActiveDirectoryServiceClient(binding, endPoint);
    });    
}

builder.Services.AddScoped<IActiveDirectoryRepository, ActiveDirectoryRepository>();
builder.Services.AddScoped<ICatalogoRepository, CatalogoRepository>();
builder.Services.AddScoped<IVigorRepository, VigorRepository>();

// Mapper
builder.Services.AddAutoMapper(cfg =>
{
    cfg.AddProfile<ActiveDirectoryProfile>();
    cfg.AddProfile<CatalogoProfile>();
});

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

var app = builder.Build();

app.UseExceptionHandler();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();

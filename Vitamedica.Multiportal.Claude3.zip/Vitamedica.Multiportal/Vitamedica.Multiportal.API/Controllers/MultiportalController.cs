﻿using System.Data;
using System.Diagnostics.Eventing.Reader;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Vitamedica.Multiportal.Application.Interfaces;

namespace Vitamedica.Multiportal.API.Controllers
{
    [ApiController]
    //[Route("api/multiportal")]
    [Route("")]


    public class MultiportalController : ControllerBase
    {
        IActiveDirectoryApplication _activeDirectoryApplication;
        public MultiportalController(IActiveDirectoryApplication activeDirectoryApplication)
        {
            _activeDirectoryApplication = activeDirectoryApplication;
        }

        [HttpGet]
        [Route("Index")]
        public IActionResult Index()
        {
            return Ok("ApiMultiportal");
        }

        [HttpGet]
        [Route("GetUser/{user}")]
        public IActionResult GetUserProfile(string user)
        {
            var result = _activeDirectoryApplication.GetUser(user);
            if (result == null)
                return BadRequest("");
            else
                return Ok(result);
        }

        
    }
}

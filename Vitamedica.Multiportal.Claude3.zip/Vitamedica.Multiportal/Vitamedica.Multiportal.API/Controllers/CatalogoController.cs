﻿using Microsoft.AspNetCore.Mvc;
using Vitamedica.Multiportal.Application;
using Vitamedica.Multiportal.Application.Interfaces;

namespace Vitamedica.Multiportal.API.Controllers
{
    [ApiController]
    //[Route("api/multiportal")]
    [Route("v1/catalogo")]
    public class CatalogoController : ControllerBase
    {
        ICatalogoApplication _catalogoApplication;
        public CatalogoController(ICatalogoApplication catalogoApplication)
        {
            _catalogoApplication = catalogoApplication;
        }

        [HttpGet]
        [Route("ServiceType")]
        public IActionResult GetServiceType()
        {
            var result = _catalogoApplication.ObtenerListaCoberturas();
            if (result == null)
                return BadRequest("");
            else
                return Ok(result);
        }

        [HttpGet]
        [Route("Modules")]
        public IActionResult GetModules()
        {
            var result = _catalogoApplication.ObtenerListaModulos();
            if (result == null)
                return BadRequest("");
            else
                return Ok(result);
        }


        [HttpGet]
        [Route("DocumentosRequeridos")]
        public async Task <IActionResult> GetRequiredDocuments([FromQuery] int? idMotivo)
        {
            var result = await _catalogoApplication.ObtenerListaDocumentosRequeridos(idMotivo);
            return Ok(result);
        }

        [HttpGet]
        [Route("FlujoReembolso")]
        public async Task<IActionResult> GetRefundFlow([FromQuery] bool? dictamenMedico,int? idFlujo)
        {
            var result = await _catalogoApplication.ObtenerFlujoReembolso(dictamenMedico, idFlujo);
            return Ok(result);
        }

        [HttpGet]
        [Route("Diagnosticos")]
        public async Task<IActionResult> GetDiagnostic ([FromQuery] string? idDiagnostico, string? descDiagnostico)
        {
            var result = await _catalogoApplication.ObtenerListaDiagnostico10(idDiagnostico, descDiagnostico);
            return Ok(result);
        }

        [HttpGet]
        [Route("MotivoConsulta")]
        public async Task<IActionResult> GetMotivoConsulta([FromQuery]int? idConsulta)
        {
            var result = await _catalogoApplication.ObtenerListaMotivoConsulta(idConsulta);
            return Ok(result);
        }
        [HttpGet]
        [Route("EstatusReembolso")]
        public async Task<IActionResult> GetEstatusReembolso([FromQuery] int? idStatus)
        {
            var result = await _catalogoApplication.ObtenerListaEstatusReembolso(idStatus);
            return Ok(result);
        }
        [HttpGet]
        [Route("MotivoRechazo")]
        public async Task<IActionResult> GetMotivoRechazo([FromQuery] string? descripcion, int? tipoRechazo, int? idMotivo)
        {
            var result = await _catalogoApplication.ObtenerListaMotivoRechazo(descripcion,tipoRechazo,idMotivo);
            return Ok(result);
        }
    }
}

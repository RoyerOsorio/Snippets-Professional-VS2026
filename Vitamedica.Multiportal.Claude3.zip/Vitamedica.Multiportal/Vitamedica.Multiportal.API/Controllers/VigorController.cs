﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Vitamedica.Multiportal.Application.Interfaces;

namespace Vitamedica.Multiportal.API.Controllers
{
    [ApiController]
    [Route("v1/vigor")]
    public class VigorController : ControllerBase
    {
        IVigorApplication _vigorApplication;
        public VigorController(IVigorApplication vigorApplication)
        {
            _vigorApplication = vigorApplication;
        }

        [HttpGet]
        [Route("Asegurado")]
        public async Task<IActionResult> GetMember(string poliza, string grupo)
        {
            try
            {
                var result = await _vigorApplication.ObtenerAsegurado(poliza, grupo);
                if (result == null)
                    return NotFound();

                return Ok(result);
            }
            catch (Exception ex)
            {

                return Problem();
            }
            
        }

        [HttpGet]
        [Route("Asegurados")]
        public async Task<IActionResult> GetMembers(string poliza, string grupo)
        {
            try
            {
                var result = await _vigorApplication.ObtenerListaAsegurado(poliza, grupo);
                if (result == null || result.Count() == 0)
                    return NotFound();

                return Ok(result);
            }
            catch (Exception ex)
            {

                return Problem();
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using Vitamedica.Multiportal.Application.DTOs.Multiportal.Vigor.Response;

namespace Vitamedica.Multiportal.Application.Interfaces
{
    public  interface IVigorApplication
    {
        Task<AseguradoDto?> ObtenerAsegurado(string poliza, string grupo);
        Task<List<AseguradoDto>> ObtenerListaAsegurado(string poliza, string grupo);
    }
}

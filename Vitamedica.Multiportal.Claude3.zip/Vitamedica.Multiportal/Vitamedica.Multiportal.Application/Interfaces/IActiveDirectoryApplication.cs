﻿using System;
using System.Collections.Generic;
using System.Text;
using Vitamedica.Multiportal.Application.DTOs.ActiveDirectory.Response;

namespace Vitamedica.Multiportal.Application.Interfaces
{
    public interface IActiveDirectoryApplication
    {
        UserAuthDto? AuthenticationUser(string user, string password);
        UserResumeDto? GetUser(string user);
    }
}

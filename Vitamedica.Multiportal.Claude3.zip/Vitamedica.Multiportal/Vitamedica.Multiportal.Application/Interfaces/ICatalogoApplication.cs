﻿using System;
using System.Collections.Generic;
using System.Text;
using Vitamedica.Multiportal.Application.DTOs.Multiportal.Catalogo.Response;
using Vitamedica.Multiportal.Domain.Entities.Multiportal.Catalogo;

namespace Vitamedica.Multiportal.Application.Interfaces
{
    public interface ICatalogoApplication
    {
        List<ModuloDto> ObtenerListaModulos();
        List<CoberturaDto> ObtenerListaCoberturas();
        Task<List<DocumentoRequeridoDto>> ObtenerListaDocumentosRequeridos(int? idMotivo);
        Task<List<FlujoReembolsoDto>> ObtenerFlujoReembolso(bool? dictamenMedico, int? idFlujo);
        Task<List<DiagnosticoDto>> ObtenerListaDiagnostico10(string? idDiagnostico, string? descDiagnostico);
        Task<List<MotivoConsultaDto>> ObtenerListaMotivoConsulta(int? idConsulta);
        Task<List<EstatusReembolsoDto>> ObtenerListaEstatusReembolso(int? idStatus);
        Task<List<MotivoRechazoDto>> ObtenerListaMotivoRechazo(string? descripcion, int? tipoRechazo, int? idMotivo);
        

    }
}

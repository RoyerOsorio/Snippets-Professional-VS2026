﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using System.Text;
using Vitamedica.Multiportal.Application.DTOs.Multiportal.Catalogo.Response;
using Vitamedica.Multiportal.Application.Interfaces;
using Vitamedica.Multiportal.Application.InterfacesRepository;
using Vitamedica.Multiportal.Domain.Exceptions;

namespace Vitamedica.Multiportal.Application
{
    public class CatalogoApplication : ICatalogoApplication
    {

        private readonly ICatalogoRepository _catalogoRepository;
        private readonly IMapper _mapper;

        public CatalogoApplication(ICatalogoRepository catalogoRepository
            , IMapper mapper)
        {
            _catalogoRepository = catalogoRepository;
            _mapper = mapper;
        }

        public List<CoberturaDto> ObtenerListaCoberturas()
        {
            return _mapper.Map<List<CoberturaDto>>(_catalogoRepository.ObtenerListaCoberturas());
        }

        public List<ModuloDto> ObtenerListaModulos()
        {
            return _mapper.Map<List<ModuloDto>>(_catalogoRepository.ObtenerListaCoberturas());
        }

        public async Task<List<DocumentoRequeridoDto>> ObtenerListaDocumentosRequeridos(int? idMotivo)
        {
            var result = await _catalogoRepository.ObtenerListaDocumentosRequeridos(idMotivo);
            if (idMotivo!=null && result.Count() == 0)
                throw new NotFoundException($"No existe documentos requeridos con idMotivo {idMotivo}.");
            return _mapper.Map<List<DocumentoRequeridoDto>>(result);
        }

        public async Task<List<FlujoReembolsoDto>> ObtenerFlujoReembolso(bool? dictamenMedico, int? idFlujo)
        {
            var result = await _catalogoRepository.ObtenerFlujoReembolso(dictamenMedico, idFlujo);
            if ((dictamenMedico != null||idFlujo!=null)  && result.Count() == 0)
                throw new NotFoundException($"No existe un flujo con dictameMedico {dictamenMedico} o idFlujo {idFlujo}.");
            return _mapper.Map<List<FlujoReembolsoDto>>(result);
        }

        public async Task<List<DiagnosticoDto>> ObtenerListaDiagnostico10(string? idDiagnostico, string? descDiagnostico)
        {
            var result = await _catalogoRepository.ObtenerListaDiagnostico10(idDiagnostico, descDiagnostico);
            if ((idDiagnostico!= null||descDiagnostico!=null) && result.Count() == 0)
                throw new NotFoundException($"No existe un diagnostico con id {idDiagnostico} o descripcion {descDiagnostico}.");

            return _mapper.Map<List<DiagnosticoDto>>(result);
        }

        public async Task<List<MotivoConsultaDto>> ObtenerListaMotivoConsulta(int? idConsulta)
        {
            var result = await _catalogoRepository.ObtenerListaMotivoConsulta(idConsulta);
            if (idConsulta!=null && result.Count() == 0)
               throw new NotFoundException($"No existe un motivo con id {idConsulta}.");
            
            return _mapper.Map<List<MotivoConsultaDto>>(result);
        }
        public async Task<List<EstatusReembolsoDto>> ObtenerListaEstatusReembolso(int? idStatus)
        {

            var result = await _catalogoRepository.ObtenerListaEstatusReembolso(idStatus);
            if (idStatus != null && result.Count() == 0)
                throw new NotFoundException($"No existe un estatus con id {idStatus}.");

            return _mapper.Map<List<EstatusReembolsoDto>>(result);
        }

        public async Task<List<MotivoRechazoDto>> ObtenerListaMotivoRechazo(string? descripcion, int? tipoRechazo, int? idMotivo)
        {

            var result = await _catalogoRepository.ObtenerListaMotivoRechazo(descripcion,tipoRechazo,idMotivo);
            if ((descripcion != null||tipoRechazo!=null||idMotivo!=null) && result.Count() == 0)
                throw new NotFoundException($"No existe un motivo de rechazo con descripcion: {descripcion}, tipoRechazo:{tipoRechazo}, idMotivo:{idMotivo}.");

            return _mapper.Map<List<MotivoRechazoDto>>(result);
        }
    }
}

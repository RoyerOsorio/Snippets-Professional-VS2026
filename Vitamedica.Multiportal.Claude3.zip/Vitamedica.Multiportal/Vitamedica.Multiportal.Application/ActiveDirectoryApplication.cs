﻿using Vitamedica.Multiportal.Application.InterfacesRepository;
using Vitamedica.Multiportal.Application.Interfaces;
using AutoMapper;
using Vitamedica.Multiportal.Application.DTOs.ActiveDirectory.Response;

namespace Vitamedica.Multiportal.Application
{
    public class ActiveDirectoryApplication : IActiveDirectoryApplication
    {
        private readonly IActiveDirectoryRepository _activeDirectoryRepository;
        private readonly IMapper _mapper;

        public ActiveDirectoryApplication(IActiveDirectoryRepository activeDirectoryRepository
            , IMapper mapper)
        {
            _activeDirectoryRepository = activeDirectoryRepository;
            _mapper = mapper;
        }

        public UserAuthDto? AuthenticationUser(string user, string password)
        {
            return _mapper.Map<UserAuthDto>(_activeDirectoryRepository.AuthenticationUser(user, password));
        }

        public UserResumeDto? GetUser(string user)
        {
            var userDto  = _mapper.Map<UserResumeDto>(_activeDirectoryRepository.GetUser(user));
            userDto.Grupo = _mapper.Map<List<GroupDto>>(_activeDirectoryRepository.GetGroupListByUser(user));
            return userDto;
        }
    }
}

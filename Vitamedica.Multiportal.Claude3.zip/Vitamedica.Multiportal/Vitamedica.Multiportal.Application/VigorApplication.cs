﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Vitamedica.Multiportal.Application.DTOs.Multiportal.Catalogo.Response;
using Vitamedica.Multiportal.Application.DTOs.Multiportal.Vigor.Response;
using Vitamedica.Multiportal.Application.Interfaces;
using Vitamedica.Multiportal.Application.InterfacesRepository;

namespace Vitamedica.Multiportal.Application
{
    public class VigorApplication : IVigorApplication
    {
        private readonly IVigorRepository _vigorRepository;
        private readonly IMapper _mapper;

        public VigorApplication(IVigorRepository vigorRepository
            , IMapper mapper)
        {
            _vigorRepository = vigorRepository;
            _mapper = mapper;
        }
        public async Task<AseguradoDto?> ObtenerAsegurado(string poliza, string grupo)
        {
            var result = await _vigorRepository.ObtenerAsegurado(poliza, grupo);
            if (result != null)
                return _mapper.Map<AseguradoDto>(result);
            return null;
        }

        public async Task<List<AseguradoDto>> ObtenerListaAsegurado(string poliza, string grupo)
        {
            var result = await _vigorRepository.ObtenerListaAsegurado(poliza, grupo);
            if (result != null)
                return _mapper.Map<List<AseguradoDto>>(result);
            return new List<AseguradoDto>();
        }
    }
}

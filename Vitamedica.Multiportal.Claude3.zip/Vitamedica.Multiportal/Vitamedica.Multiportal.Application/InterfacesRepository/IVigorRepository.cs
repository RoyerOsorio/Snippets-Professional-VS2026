﻿using Vitamedica.Multiportal.Domain.Entities.Multiportal.Asegurado;

namespace Vitamedica.Multiportal.Application.InterfacesRepository
{
    public interface IVigorRepository
    {
        Task<Asegurado?> ObtenerAsegurado(string poliza, string grupo);
        Task<IEnumerable<Asegurado>> ObtenerListaAsegurado(string poliza, string grupo);
    }
}

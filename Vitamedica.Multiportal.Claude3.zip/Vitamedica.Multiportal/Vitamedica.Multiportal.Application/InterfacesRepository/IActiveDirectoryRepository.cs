﻿using System;
using System.Collections.Generic;
using System.Text;
using Vitamedica.Multiportal.Domain.Entities.ActiveDirectory;

namespace Vitamedica.Multiportal.Application.InterfacesRepository
{
    public interface IActiveDirectoryRepository
    {
        UserAuth? AuthenticationUser(string user, string password);
        UserResume? GetUser(string user);
        List<GroupResume>? GetGroupListByUser(string user);
    }
}

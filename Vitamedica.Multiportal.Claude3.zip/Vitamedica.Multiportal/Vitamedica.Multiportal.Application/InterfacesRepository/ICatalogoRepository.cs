﻿using System;
using System.Collections.Generic;
using System.Text;
using Vitamedica.Multiportal.Application.DTOs.Multiportal.Catalogo.Response;
using Vitamedica.Multiportal.Domain.Entities.Multiportal.Asegurado;
using Vitamedica.Multiportal.Domain.Entities.Multiportal.Catalogo;

namespace Vitamedica.Multiportal.Application.InterfacesRepository
{
    public interface ICatalogoRepository
    {
        List<Modulo> ObtenerListaModulos();
        List<Cobertura> ObtenerListaCoberturas();
        Task<IEnumerable<DocumentoRequerido>> ObtenerListaDocumentosRequeridos(int? idMotivo);
        Task<IEnumerable<FlujoReembolso>> ObtenerFlujoReembolso(bool? dictamenMedico, int? idFlujo);
        Task<IEnumerable<Diagnostico>> ObtenerListaDiagnostico10(string? idDiagnostico, string? descDiagnostico);
        Task<IEnumerable<MotivoConsulta>> ObtenerListaMotivoConsulta(int? idConsulta);
        Task<IEnumerable<EstatusReembolso>> ObtenerListaEstatusReembolso(int? idStatus);
        Task<IEnumerable<MotivoRechazo>> ObtenerListaMotivoRechazo(string? descripcion, int? tipoRechazo, int? idMotivo);


    }
}

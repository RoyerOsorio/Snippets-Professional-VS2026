﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Application.DTOs.Multiportal.Catalogo.Response
{
    public class ModuloDto
    {
        public int idModulo { get; set; }
        public string descripcionModulo { get; set; } = string.Empty;
        public bool activo { get; set; }
    }
}

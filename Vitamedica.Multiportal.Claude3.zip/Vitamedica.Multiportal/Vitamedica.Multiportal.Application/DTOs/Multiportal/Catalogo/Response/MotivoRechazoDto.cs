﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Application.DTOs.Multiportal.Catalogo.Response
{
    public class MotivoRechazoDto
    {
        public int idMotivoRechazo { get; set; }
        public string descripcionMotivoRechazo { get; set; } = string.Empty;
        public int idFlujoReembolso { get; set; }
        public int idTipoRechazo { get; set; }
        public string descripcionTipoRechazo { get; set; } = string.Empty;
        public int idMensajeCorreo { get; set; }
        public string mensajeCorreo { get; set; } = string.Empty;
    }
}

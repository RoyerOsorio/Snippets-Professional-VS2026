﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Application.DTOs.Multiportal.Catalogo.Response
{
    public class CoberturaDto
    {
        public int idCobertura { get; set; }
        public string descripcionCobertura { get; set; } = string.Empty;
        public bool activa { get; set; }
        public bool nacional { get; set; }
        public decimal monto { get; set; }
        public decimal limiteEvento { get; set; }
        public decimal coaseguro { get; set; }
        public decimal deducible { get; set; }
    }
}

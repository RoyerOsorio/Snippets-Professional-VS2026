﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Application.DTOs.Multiportal.Catalogo.Response
{
    public class FlujoReembolsoDto
    {
        public int idFlujo { get; set; }
        public string flujo { get; set; } = string.Empty;

    }
}

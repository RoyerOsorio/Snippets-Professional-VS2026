﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Application.DTOs.Multiportal.Catalogo.Response
{
    public class EstatusReembolsoDto
    {
        public int idEstatus { get; set; }
        public string estatus { get; set; } = string.Empty;
    }
}

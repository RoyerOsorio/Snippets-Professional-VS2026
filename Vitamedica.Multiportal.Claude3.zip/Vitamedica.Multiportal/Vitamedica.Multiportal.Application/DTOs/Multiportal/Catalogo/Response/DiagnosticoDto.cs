﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Application.DTOs.Multiportal.Catalogo.Response
{
    public class DiagnosticoDto
    {
        public string icd { get; set; } = string.Empty;
        public string idDiagnostico { get; set; }= string.Empty;

        public string descripcionIcd { get; set; } = string.Empty;

        public string grupo { get; set; } = string.Empty;

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Application.DTOs.Multiportal.Catalogo.Response
{
    public class DocumentoRequeridoDto
    {
        public int idDocumento { get; set; }
        public string documento { get; set; } = string.Empty;
        public string observaciones { get; set; } = string.Empty;
        public bool esFactura { get; set; }
        public int maximoPermitido { get; set; }
        public int idMotivoDocumento { get; set; }
        public bool motivoDocumentoObligatorio { get; set; }
    }
    
}

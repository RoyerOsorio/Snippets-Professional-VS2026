﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Application.DTOs.Multiportal.Catalogo.Response
{
    public class MotivoConsultaDto
    {
        public int idMotivoConsulta { get; set; }
        public string descripcionMotivoConsulta{ get; set; } = string.Empty;
    }
}

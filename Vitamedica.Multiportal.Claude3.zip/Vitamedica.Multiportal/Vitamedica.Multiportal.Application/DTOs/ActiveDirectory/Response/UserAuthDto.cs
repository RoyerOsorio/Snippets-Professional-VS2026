﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Application.DTOs.ActiveDirectory.Response
{
    public class UserAuthDto
    {
        public string Usuario { get; set; } = string.Empty;
        public bool EsAutenticado { get; set; }
        public bool EsBloqueado { get; set; }
        public bool Existe { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vitamedica.Multiportal.Application.DTOs.ActiveDirectory.Response
{
    public class GroupDto
    {
        public string Nombre { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
    }
}

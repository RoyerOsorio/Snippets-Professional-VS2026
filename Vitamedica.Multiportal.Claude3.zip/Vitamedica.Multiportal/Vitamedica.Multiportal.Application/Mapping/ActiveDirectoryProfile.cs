﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Vitamedica.Multiportal.Application.DTOs.ActiveDirectory.Response;
using Vitamedica.Multiportal.Domain.Entities.ActiveDirectory;

namespace Vitamedica.Multiportal.Application.Mapping
{
    public class ActiveDirectoryProfile : Profile
    {
        public ActiveDirectoryProfile() 
        {
            CreateMap<UserAuth, UserAuthDto>();
            CreateMap<UserResume, UserResumeDto>();
            CreateMap<GroupResume, GroupDto>();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Vitamedica.Multiportal.Application.DTOs.Multiportal.Catalogo.Response;
using Vitamedica.Multiportal.Application.DTOs.Multiportal.Vigor.Response;
using Vitamedica.Multiportal.Domain.Entities.Multiportal.Asegurado;
using Vitamedica.Multiportal.Domain.Entities.Multiportal.Catalogo;

namespace Vitamedica.Multiportal.Application.Mapping
{
    public class CatalogoProfile : Profile
    {
        public CatalogoProfile()
        {
            CreateMap<Modulo, ModuloDto>();
            CreateMap<Cobertura, CoberturaDto>();
            CreateMap<Asegurado, AseguradoDto>();
            CreateMap<DocumentoRequerido, DocumentoRequeridoDto>()
                .ForMember(
                    dest => dest.idDocumento,
                    opt => opt.MapFrom(src => src.DRDR_NID)
                )
                .ForMember(
                    dest => dest.documento,
                    opt => opt.MapFrom(src => src.DRDR_DOCUMENTO)
                )
                .ForMember(
                    dest => dest.observaciones,
                    opt => opt.MapFrom(src => src.DRDR_OBSERVACIONES)
                )
                .ForMember(
                    dest => dest.esFactura,
                    opt => opt.MapFrom(src => src.DRDR_ESFACTURA)
                )
                .ForMember(
                    dest => dest.maximoPermitido,
                    opt => opt.MapFrom(src => src.DRDR_MAXIMOPERMITIDO)
                )
                .ForMember(
                    dest => dest.idMotivoDocumento,
                    opt => opt.MapFrom(src => src.MRMR_NID)
                )
                .ForMember(
                    dest => dest.motivoDocumentoObligatorio,
                    opt => opt.MapFrom(src => src.MRDR_OBLIGATORIO)
                );
            CreateMap<FlujoReembolso, FlujoReembolsoDto>()
                .ForMember(
                    dest => dest.idFlujo,
                    opt => opt.MapFrom(src => src.FRFR_NID)
                )
                .ForMember(
                    dest => dest.flujo,
                    opt => opt.MapFrom(src => src.FRFR_FLUJO)
                );
            CreateMap<Diagnostico, DiagnosticoDto>()
                .ForMember(
                    dest => dest.icd,
                    opt => opt.MapFrom(src => src.ICD)
                )
                .ForMember(
                    dest => dest.idDiagnostico,
                    opt => opt.MapFrom(src => src.IDDIAG)
                )
                .ForMember(
                    dest => dest.descripcionIcd,
                    opt => opt.MapFrom(src => src.DESCRIPCION)
                )
                .ForMember(
                    dest => dest.grupo,
                    opt => opt.MapFrom(src => src.GRUPO)
                );
            CreateMap<MotivoConsulta, MotivoConsultaDto>()
                .ForMember(
                    dest => dest.idMotivoConsulta,
                    opt => opt.MapFrom(src => src.MTCN_NID)
                )
                .ForMember(
                    dest => dest.descripcionMotivoConsulta,
                    opt => opt.MapFrom(src => src.MTCN_DESCRIPCION)
                );
            CreateMap<EstatusReembolso, EstatusReembolsoDto>()
                .ForMember(
                    dest => dest.idEstatus,
                    opt => opt.MapFrom(src => src.STST_NID)
                )
                .ForMember(
                    dest => dest.estatus,
                    opt => opt.MapFrom(src => src.STST_STATUS)
                );
            CreateMap<MotivoRechazo, MotivoRechazoDto>()
                .ForMember(
                    dest => dest.idMotivoRechazo,
                    opt => opt.MapFrom(src => src.MTMT_NID)
                )
                .ForMember(
                    dest => dest.descripcionMotivoRechazo,
                    opt => opt.MapFrom(src => src.MTMT_DESCRIPCION)
                )
                .ForMember(
                    dest => dest.idFlujoReembolso   ,
                    opt => opt.MapFrom(src => src.FRFR_NID)
                )
                .ForMember(
                    dest => dest.idTipoRechazo,
                    opt => opt.MapFrom(src => src.TRTR_NID)
                )
                .ForMember(
                    dest => dest.descripcionTipoRechazo,
                    opt => opt.MapFrom(src => src.TRTR_DESCRIPCION)
                )
                .ForMember(
                    dest => dest.idMensajeCorreo,
                    opt => opt.MapFrom(src => src.MNCR_NID)
                )
                .ForMember(
                    dest => dest.mensajeCorreo,
                    opt => opt.MapFrom(src => src.MNCR_MENSAJE)
                );
        }        
    }
}

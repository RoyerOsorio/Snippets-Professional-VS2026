﻿using Dapper;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net.NetworkInformation;
using System.Numerics;
using System.Text;
using Vitamedica.Multiportal.Application.InterfacesRepository;
using Vitamedica.Multiportal.Domain.Entities.Multiportal.Catalogo;
using Vitamedica.Multiportal.Infrastructure.Data;

namespace Vitamedica.Multiportal.Infrastructure
{
    public class CatalogoRepository : BaseRepository,ICatalogoRepository 
    {
       // public readonly IDbConnectionFactory _factory;
        private readonly ILogger<CatalogoRepository> _logger;

        public CatalogoRepository(IDbConnectionFactory dbConnectionFactory,ILogger<CatalogoRepository> logger):base(dbConnectionFactory) {
        
            //_factory = dbConnectionFactory;
            _logger = logger;
        }
        public List<Cobertura> ObtenerListaCoberturas()
        {
            throw new NotImplementedException();
        }

        public List<Modulo> ObtenerListaModulos()
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<DocumentoRequerido>> ObtenerListaDocumentosRequeridos(int? idMotivo)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@IdMotivo", idMotivo, DbType.Int32);

            return await EjecutarQueryAsync<DocumentoRequerido>(
                "SP_ObtenerDocumentosRequeridos",
                parameters,
                _logger,
                $"Error al consultar los documentos requeridos con idMotivo={idMotivo}");
        }

        public async Task<IEnumerable<FlujoReembolso>> ObtenerFlujoReembolso(bool? dictamenMedico, int? idFlujo)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@DictamenMedico", dictamenMedico, DbType.Boolean);
            parameters.Add("@IdFlujo", idFlujo, DbType.Boolean);

            return await EjecutarQueryAsync<FlujoReembolso>(
                "SP_ObtenerFlujoReembolso",
                parameters,
                _logger,
                $"Error al consultar el flujo de reembolso con dictamenMedico={dictamenMedico}, idFlujo={idFlujo}");
        }
        public async Task<IEnumerable<Diagnostico>> ObtenerListaDiagnostico10(string? idDiagnostico, string? descDiagnostico)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@IDDIAG", idDiagnostico, DbType.String);
            parameters.Add("@DIAGDESC", descDiagnostico, DbType.String);

            return await EjecutarQueryAsync<Diagnostico>(
                "SP_ObtenerListaDiagnostico10",
                parameters,
                _logger,
                $"Error al consultar el diagnostico con idDiagnostico={idDiagnostico}");
        }

        public async Task<IEnumerable<MotivoConsulta>> ObtenerListaMotivoConsulta(int? idConsulta)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@IdConsulta", idConsulta, DbType.Int32);

            return await EjecutarQueryAsync<MotivoConsulta>(
                "SP_ObtenerListaMotivoConsulta",
                parameters,
                _logger,
                $"Error al consultar el motivo de consulta con idConsulta={idConsulta}");
        }

        public async Task<IEnumerable<EstatusReembolso>> ObtenerListaEstatusReembolso(int? idStatus)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@IdStatus", idStatus, DbType.Int32);

            return await EjecutarQueryAsync<EstatusReembolso>(
                "SP_ObtenerStatusReembolso",
                parameters,
                _logger,
                $"Error al consultar el estatus de reembolso con idStatus={idStatus}");
        }

        public async Task<IEnumerable<MotivoRechazo>> ObtenerListaMotivoRechazo(string? descripcion, int? tipoRechazo, int? idMotivo)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Descripcion", descripcion, DbType.String);
            parameters.Add("@TipoRechazo", tipoRechazo, DbType.String);
            parameters.Add("@IdMotivo", idMotivo, DbType.Int32);

            return await EjecutarQueryAsync<MotivoRechazo>(
                "SP_ObtenerListaMotivoRechazo",
                parameters,
                _logger,
                $"Error al consultar el motivo de rechazo con descripcion={descripcion}, tipoRechazo={tipoRechazo}, idMotivo={idMotivo}");
        }
    }
}

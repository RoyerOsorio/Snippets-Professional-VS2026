﻿using System.Data;
using Dapper;
using Vitamedica.Multiportal.Application.InterfacesRepository;
using Vitamedica.Multiportal.Domain.Entities.Multiportal.Asegurado;
using Vitamedica.Multiportal.Infrastructure.Data;

namespace Vitamedica.Multiportal.Infrastructure
{
    public class VigorRepository : IVigorRepository
    {
        public readonly IDbConnectionFactory _factory;

        public VigorRepository(IDbConnectionFactory dbConnectionFactory)
        {
            _factory = dbConnectionFactory;
        }
        public async Task<Asegurado?> ObtenerAsegurado(string poliza, string grupo)
        {
            using var connection = _factory.CreateConnection();

            var parameters = new DynamicParameters();
            parameters.Add("@GRGR_ID", grupo, DbType.String);
            parameters.Add("@PLPL_POLIZA", poliza, DbType.String);



            return await connection.QueryFirstOrDefaultAsync<Asegurado>("SP_ObtenerBeneficiario"
            , parameters
            , commandType: CommandType.StoredProcedure);

        }

        public async Task<IEnumerable<Asegurado>> ObtenerListaAsegurado(string poliza, string grupo)
        {
            using var connection = _factory.CreateConnection();

            var parameters = new DynamicParameters();
            parameters.Add("@GRGR_ID", grupo, DbType.String);
            parameters.Add("@PLPL_POLIZA", poliza, DbType.String);

            return await connection.QueryAsync<Asegurado>("SP_ObtenerBeneficiario"
                , parameters
                , commandType: CommandType.StoredProcedure);
        }
    }
}

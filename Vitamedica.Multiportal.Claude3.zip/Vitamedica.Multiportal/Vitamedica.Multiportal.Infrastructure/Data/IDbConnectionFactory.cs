﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Vitamedica.Multiportal.Infrastructure.Data
{
    public interface IDbConnectionFactory
    {
        IDbConnection CreateConnection();
    }
}

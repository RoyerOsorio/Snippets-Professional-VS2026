﻿using Dapper;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Vitamedica.Multiportal.Domain.Exceptions;
using Vitamedica.Multiportal.Infrastructure.Data;

namespace Vitamedica.Multiportal.Infrastructure
{
    public abstract class BaseRepository
    {
        private readonly IDbConnectionFactory _factory;

        protected BaseRepository(IDbConnectionFactory factory)
        {
            _factory = factory;
        }

        protected async Task<IEnumerable<T>> EjecutarQueryAsync<T>(
            string storedProcedure,
            DynamicParameters parameters,
            ILogger logger,
            string mensajeError)
        {
            try
            {
                using var connection = _factory.CreateConnection();

                return await connection.QueryAsync<T>(
                    storedProcedure,
                    parameters,
                    commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "{Mensaje} | SP={StoredProcedure}", mensajeError, storedProcedure);
                throw new RepositoryException(mensajeError, ex);
            }
        }
    }
}

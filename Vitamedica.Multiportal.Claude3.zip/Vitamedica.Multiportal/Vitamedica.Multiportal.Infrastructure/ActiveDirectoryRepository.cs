﻿using Vitamedica.ActiveDirectory.Model.Service.Request.Usuario;
using Vitamedica.Multiportal.Application.InterfacesRepository;
using Vitamedica.Multiportal.Domain.Entities.ActiveDirectory;
using Microsoft.Extensions.Options;
using Vitamedica.Multiportal.Domain.Entities.EndPoint;
using Vitamedica.ActiveDirectory.Model.Service.Request.Grupo;

namespace Vitamedica.Multiportal.Infrastructure
{
    public class ActiveDirectoryRepository : IActiveDirectoryRepository
    {
        
        public readonly IActiveDirectoryService _activeDirectoryService;

        public ActiveDirectoryRepository(IActiveDirectoryService activeDirectoryService)
        {
            _activeDirectoryService = activeDirectoryService;            
        }

        public UserAuth? AuthenticationUser(string user, string password)
        {
            
            try
            {
                UsuarioAutenticacionOperationRequest request = new UsuarioAutenticacionOperationRequest
                {
                    Item = new ActiveDirectory.Model.ViewModels.UsuarioAutenticacionResume
                    {
                        NombreUsuario = user,
                        Password = password
                    }
                };
                var response = _activeDirectoryService.Autenticar(request);

                if (response != null && response.Item != null && response.Item.EsAutenticado)
                {
                    return new UserAuth
                    {
                        Usuario = response.Item.NombreUsuario,
                        EsAutenticado = response.Item.EsAutenticado,
                        EsBloqueado = response.Item.EsBloqueado,
                        Existe = response.Item.ExisteUsuario
                    };
                }
                return null;
            }
            catch (Exception ex)
            {
                
                throw new Exception("WCF Service Unavailable", ex);
            }
        }

        public UserResume? GetUser(string user)
        {
            
            try
            {
                UsuarioFilterRequest request = new UsuarioFilterRequest
                {
                    Item = new ActiveDirectory.Model.Filters.UsuarioFilter
                    {
                        NombreUsuario = user,
                        FilterType = ActiveDirectory.Model.Filters.UsuarioFilterType.NombreUsuario
                    }
                };
                var response = _activeDirectoryService.ObtenerPerfilUsuario(request);

                if (response != null && response.Item != null)
                {
                    return new UserResume
                    {
                        ApellidoMaterno = response.Item.ApellidoMaterno,
                        ApellidoPaterno = response.Item.ApellidoPaterno,
                        Clave = response.Item.Clave,
                        CorreoElectronico = response.Item.CorreoElectronico,
                        GrgrCk = response.Item.GrgrCk,
                        MemeCk = response.Item.MemeCk,
                        Nombre = response.Item.Nombre,
                        NombreCompleto = response.Item.NombreCompleto,
                        NombreORazonSocial = response.Item.NombreORazonSocial,
                        NombreUsuario = response.Item.NombreUsuario,
                        NominaEmpleado = response.Item.NominaEmpleado,
                        PrprId = response.Item.PrprId,
                        RFC = response.Item.RFC,
                        TipoUsuario = (UserType)response.Item.TipoUsuario,
                        TipoUsuarioDescripcion = response.Item.TipoUsuario.ToString()
                    };
                }
                return null;
            }
            catch (Exception ex)
            {
                
                throw new Exception("WCF Service Unavailable", ex);
            }
        }

        public List<GroupResume>? GetGroupListByUser(string user)
        {
            try
            {
                GrupoUsuarioFilterRequest request = new GrupoUsuarioFilterRequest
                {
                    Item = new ActiveDirectory.Model.Filters.GrupoUsuarioFilter
                    {
                        NombreUsuario = user, 
                        FilterType = ActiveDirectory.Model.Filters.GrupoUsurioFilterType.NombreUsuario
                    }
                };
                var response = _activeDirectoryService.ObtenerListaGruposUsuario(request);

                if (response != null && response.ValidExecution && response.List != null)
                {
                    List<GroupResume> list = new List<GroupResume>();
                    response.List.ForEach(x =>
                    {
                        list.Add(new GroupResume
                        {
                            Descripcion = x.Descripcion,
                            Nombre = x.Nombre
                        });
                    });
                    return list;
                }
                else
                {
                    throw new Exception("WCF Service Unavailable" + (response != null && response.ErrorList != null && response.ErrorList.Count > 0 ? response.ErrorList.FirstOrDefault().Description : ""));
                }                
            }
            catch (Exception ex)
            {

                throw new Exception("WCF Service Unavailable", ex);
            }
        }
    }
}

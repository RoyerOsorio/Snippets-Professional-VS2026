using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Vitamedica.Multiportal.UI.Services.Layout;

namespace Vitamedica.Multiportal.UI.Infrastructure.Filters;

/// <summary>
/// Filtro global que construye el <see cref="Models.ViewModels.LayoutViewModel"/> una
/// sola vez por petición y lo expone en <c>ViewData["Layout"]</c>, de modo que
/// _Layout y sus partials (Header, Sidebar, Footer) lo consuman sin que cada
/// controlador tenga que ensamblarlo (DRY + controladores limpios).
///
/// Solo actúa sobre controladores que renderizan vistas; ignora respuestas de API
/// puras (JSON/File/etc.), evitando trabajo innecesario.
/// </summary>
public sealed class LayoutActionFilter(ILayoutViewModelFactory factory) : IAsyncActionFilter
{
    public const string ViewDataKey = "Layout";

    private readonly ILayoutViewModelFactory _factory = factory;

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        if (context.Controller is Controller controller)
        {
            var routeValues = context.RouteData.Values;
            var controllerName = routeValues["controller"] as string;
            var actionName = routeValues["action"] as string;

            controller.ViewData[ViewDataKey] =
                _factory.Build(context.HttpContext, controllerName, actionName);
        }

        await next();
    }
}

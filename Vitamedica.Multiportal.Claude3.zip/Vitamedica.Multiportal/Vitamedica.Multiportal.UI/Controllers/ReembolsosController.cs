using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Vitamedica.Multiportal.UI.Models.ViewModels;
using Vitamedica.Multiportal.UI.Services;

namespace Vitamedica.Multiportal.UI.Controllers
{
    [Authorize]
    public class ReembolsosController : Controller
    {
        private const int TamanioPaginaPorDefecto = 25;

        public IActionResult Index()
        {
            var resultado = Paginar(ObtenerSolicitudesSimuladas(), pagina: 1, tamanioPagina: TamanioPaginaPorDefecto);
            return View(resultado);
        }

        // ====================================================================
        // Fase 2 — filtros conectados al listado simulado de Fase 1.
        // Fase 3 — se agrega paginación real (pagina/tamanioPagina) sobre el
        // resultado ya filtrado (ver UI_Decision_Log.md). Sigue devolviendo un
        // PartialView (no JSON): reutiliza exactamente el mismo marcado Razor
        // que ya usa Index() para la carga inicial, en vez de reconstruir la
        // fila en JavaScript.
        //
        // Fix (ver DEC-Pagos-Index-Paginacion.md, "Hallazgo: pie de tabla no
        // se actualiza en Reembolsos/Buscar"): antes devolvía solo
        // Partials/_ResultadosSolicitudes (el <tbody>), por lo que el pie
        // (#pieTablaSolicitudes) nunca llegaba a actualizarse tras un fetch,
        // aunque reembolsos-index.js ya intentaba reemplazarlo. Ahora
        // devuelve Partials/_ResultadosYPaginacionSolicitudes, que concatena
        // ambos fragmentos — mismo patrón ya usado en Pagos (Fase F3).
        // ====================================================================
        [HttpGet]
        public IActionResult Buscar(SolicitudReembolsoFiltroViewModel filtro, int pagina = 1, int tamanioPagina = TamanioPaginaPorDefecto)
        {
            var filtrado = AplicarFiltro(ObtenerSolicitudesSimuladas(), filtro);
            var resultado = Paginar(filtrado, pagina, tamanioPagina);
            return PartialView("Partials/_ResultadosYPaginacionSolicitudes", resultado);
        }

        // ====================================================================
        // Fase Acciones-G1 (ver UI_Decision_Log.md) — acciones por fila del
        // listado, ausentes hasta ahora (ver claude/GAP-Resync-2026-08-31.md,
        // sección 5). Mismo criterio de simulación que ClientesController.
        // CambiarEstado: el servidor valida (existencia del id, que la
        // solicitud no esté ya en un estado final) y responde; la fila se
        // actualiza en el DOM del lado del cliente tras una respuesta
        // exitosa (reembolsos-index.js) — un refetch de Buscar() no
        // reflejaría el cambio, ya que ObtenerSolicitudesSimuladas() se
        // regenera sin persistencia en cada llamada.
        //
        // Semántica confirmada contra Legacy (ListaTablero.js): "Rechazar"
        // pide un comentario opcional; "Regresar" lo exige y devuelve el
        // trámite a la estación "Dictamen médico" (valor que ya existe en
        // este mismo archivo, no se inventa uno nuevo) — se asume además que
        // el estatus vuelve a "En proceso" al regresar a dictamen, ya que el
        // trámite vuelve a estar en curso (supuesto explícito, no confirmado
        // contra una regla de negocio documentada).
        //
        // "Estado final" (no se puede Rechazar/Regresar) = Aprobado o
        // Rechazado, según confirmación explícita del usuario.
        // ====================================================================
        private static readonly string[] EstatusFinales = { "Aprobado", "Rechazado" };

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Rechazar(int id, string? comentario)
        {
            var solicitud = ObtenerSolicitudesSimuladas().FirstOrDefault(s => s.Id == id);
            if (solicitud == null)
                return NotFound();

            if (EstatusFinales.Contains(solicitud.Estatus))
                return BadRequest("La solicitud ya se encuentra en un estado final y no puede rechazarse.");

            // Simulado: no persiste (ver comentario de fase arriba).
            return Json(new { ok = true, nuevoEstatus = "Rechazado" });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Regresar(int id, string? comentario)
        {
            var solicitud = ObtenerSolicitudesSimuladas().FirstOrDefault(s => s.Id == id);
            if (solicitud == null)
                return NotFound();

            if (EstatusFinales.Contains(solicitud.Estatus))
                return BadRequest("La solicitud ya se encuentra en un estado final y no puede regresarse.");

            if (string.IsNullOrWhiteSpace(comentario))
                return BadRequest("Debe indicar un comentario para regresar el trámite.");

            // Simulado: no persiste (ver comentario de fase arriba).
            return Json(new { ok = true, nuevoEstatus = "En proceso", nuevaEstacion = "Dictamen médico" });
        }

        // ====================================================================
        // Fase G1 (ver UI_Decision_Log.md) — primer paso del roadmap de
        // Reembolsos/Crear: los 3 catálogos que la vista necesita (categorías
        // de reclamación, motivos de consulta, monedas) dejan de ser arreglos
        // anónimos hardcodeados dentro de Crear.cshtml y pasan a construirse
        // aquí, mismo patrón ya usado en Index()/ObtenerSolicitudesSimuladas().
        //
        // De paso se corrige el mismo anti-patrón ya señalado y corregido en
        // Reembolsos/Index Fase 1: catch vacío + fallback a
        // View(new UserProfile()) — código muerto, ya que [Authorize] de
        // clase garantiza autenticación antes de llegar aquí.
        // ====================================================================
        public IActionResult Crear()
        {
            return View(ObtenerCatalogosSimulados());
        }

        // ====================================================================
        // Catálogos simulados de Reembolsos/Crear (Fase G1) — antes vivían
        // como arreglos anónimos hardcodeados dentro de Crear.cshtml (ver
        // DEC-ReembolsosCrear-CatalogosSimulados.md). Mismos 8 valores/
        // estructura que ya existían, solo cambia dónde viven.
        // ====================================================================
        private static SolicitudReembolsoCatalogosViewModel ObtenerCatalogosSimulados() => new()
        {
            Categorias = new List<CategoriaReclamacionViewModel>
            {
                new()
                {
                    Key = "consultas", Nombre = "Consultas", Icono = "stethoscope",
                    TieneMotivo = true, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Receta", Requerido = false },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "medicamentos", Nombre = "Medicamentos", Icono = "pill",
                    TieneMotivo = false, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Receta", Requerido = false },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "vacunas", Nombre = "Vacunas", Icono = "syringe",
                    TieneMotivo = false, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Cartilla Nacional de Vacunación", Requerido = true },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "laboratorio", Nombre = "Laboratorio y Gabinete", Icono = "flask-conical",
                    TieneMotivo = false, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Orden Médica", Requerido = true },
                        new() { Nombre = "Estado de Cuenta", Requerido = false },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "cuidados", Nombre = "Cuidados Preventivos (Enfermería, Terapias)", Icono = "heart-pulse",
                    TieneMotivo = false, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Informe Médico", Requerido = false },
                        new() { Nombre = "Bitácora", Requerido = false },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "audicion", Nombre = "Exámenes de Audición", Icono = "ear",
                    TieneMotivo = false, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Orden Médica", Requerido = true },
                        new() { Nombre = "Estudios", Requerido = true },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "lentes", Nombre = "Lentes", Icono = "glasses",
                    TieneMotivo = false, TipoFactura = "estandar",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Orden Médica", Requerido = true },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
                new()
                {
                    Key = "extranjero", Nombre = "Gastos en el Extranjero", Icono = "plane",
                    TieneMotivo = false, TipoFactura = "multimoneda",
                    Documentos = new List<DocumentoReclamacionViewModel>
                    {
                        new() { Nombre = "Informe Médico", Requerido = true },
                        new() { Nombre = "Otro", Requerido = false },
                    },
                },
            },
            MotivosConsulta = new List<string>
            {
                "Dolor de cabeza", "Chequeo general", "Dolor abdominal", "Control de enfermedad crónica", "Otro",
            },
            Monedas = new List<MonedaViewModel>
            {
                new() { Codigo = "USD", Nombre = "Dólar americano" },
                new() { Codigo = "EUR", Nombre = "Euro" },
                new() { Codigo = "MXN", Nombre = "Peso mexicano" },
            },
        };

        // ====================================================================
        // Fase G2 (ver UI_Decision_Log.md) — búsqueda de Derechohabiente
        // conectada al servidor. Reemplaza el objeto DERECHOHABIENTE_DEMO
        // que antes vivía hardcodeado en reembolso-solicitud.js. Devuelve
        // JSON (no PartialView): a diferencia de Reembolsos/Index y
        // Pagos/Index, no existe un renderizado inicial de esta tabla que
        // reutilizar — los datos se distribuyen a mano en varios campos del
        // formulario (ver aplicarDerechohabiente en reembolso-solicitud.js).
        //
        // Si numeroEmpleado no corresponde a ningún derechohabiente
        // simulado: 404, mismo criterio ya usado en Detalle(int id).
        // ====================================================================
        [HttpGet]
        public IActionResult BuscarDerechohabiente(string numeroEmpleado)
        {
            var derechohabiente = ObtenerDerechohabientesSimulados()
                .FirstOrDefault(d => d.NumeroEmpleado == (numeroEmpleado ?? string.Empty).Trim());

            if (derechohabiente == null)
                return NotFound();

            return Json(derechohabiente);
        }

        // ====================================================================
        // "Base de datos" simulada de derechohabientes (Fase G2) — único
        // registro por ahora, mismo valor que antes vivía como
        // DERECHOHABIENTE_DEMO en reembolso-solicitud.js. Mismo patrón que
        // ObtenerSolicitudesSimuladas()/ObtenerCatalogosSimulados(): cuando
        // exista persistencia/API real, este método se sustituye sin que el
        // resto de la acción cambie de forma.
        // ====================================================================
        private static List<DerechohabienteViewModel> ObtenerDerechohabientesSimulados() => new()
        {
            new DerechohabienteViewModel
            {
                NumeroEmpleado = "38602287",
                Nombre = "ESNER VALENCIA VALENCIA",
                Grupo = "17000003",
                FechaInicioVigencia = "03/01/2026",
                FechaFinVigencia = "31/12/2199",
                MiembroDesde = "01/03/2026",
                Beneficiarios = new List<BeneficiarioViewModel>
                {
                    new() { Id = "titular", Nombre = "ESNER VALENCIA VALENCIA", Parentesco = "Titular" },
                    new() { Id = "conyuge", Nombre = "MARÍA JOSÉ PÉREZ DE VALENCIA", Parentesco = "Cónyuge" },
                    new() { Id = "hijo1", Nombre = "DIEGO VALENCIA PÉREZ", Parentesco = "Hijo(a)" },
                },
            },
        };

        // ====================================================================
        // Fase G3 (ver UI_Decision_Log.md) — POST simulado de "Registrar".
        // No persiste nada real (no hay Service/base de datos todavía) — se
        // limita a devolver un folio simulado, mismo criterio de
        // simulación que el resto del proyecto.
        //
        // Antiforgery: mismo patrón ya usado en SesionController/
        // Login.cshtml (@Html.AntiForgeryToken() + [ValidateAntiForgeryToken]).
        // Primer uso real de postJson (core/http.js) en el proyecto.
        //
        // El modelo recibido llega como JSON (no como formulario codificado):
        // reembolso-solicitud.js arma el payload a mano leyendo el DOM por
        // selector, no depende de los `name`/índice que declara Crear.cshtml
        // (esos quedaron como documentación de intención, ver Fase G4a/G4b en
        // DEC-ReembolsosCrear-G4a-IdentidadDerechohabiente.md y
        // DEC-ReembolsosCrear-G4b-LineasFactura.md). El binder de ASP.NET
        // Core mapea por nombre de propiedad JSON (camelCase por defecto),
        // no por esos atributos `name`.
        // ====================================================================
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Registrar([FromBody] SolicitudReembolsoRegistroViewModel modelo)
        {
            var folio = "REEMB-" + Guid.NewGuid().ToString("N")[..8].ToUpperInvariant();
            return Json(new { folio });
        }

        // ====================================================================
        // Fase G4c (ver UI_Decision_Log.md) — subida de archivos, primer
        // manejo real de archivos del proyecto. Sin persistencia real (no
        // hay Service/almacenamiento todavía, mismo criterio de simulación
        // que el resto del proyecto): el archivo se valida y se descarta,
        // nunca se guarda en disco — se devuelve la metadata como si hubiera
        // quedado almacenado.
        //
        // Validación server-side obligatoria (ver UI_Coding_Standards.md,
        // seguridad): las pistas de la UI ("PDF · máx. 5 MB", etc.) no son
        // suficientes por sí solas. "contexto" distingue las dos whitelists
        // de extensión que ya existían visualmente en Crear.cshtml:
        // "factura" (PDF/XML) y "documento" (PNG/JPEG/PDF).
        //
        // multipart/form-data (no JSON): requiere el mismo
        // [ValidateAntiForgeryToken] + header "RequestVerificationToken"
        // (ver postForm en core/http.js) que Registrar, ya corregido en
        // Program.cs (AddAntiforgery.HeaderName) como parte de esta fase.
        // ====================================================================
        private const long TamanioMaximoArchivoBytes = 5 * 1024 * 1024;

        private static readonly Dictionary<string, string[]> ExtensionesPermitidasPorContexto = new()
        {
            ["factura"] = new[] { ".pdf", ".xml" },
            ["documento"] = new[] { ".png", ".jpg", ".jpeg", ".pdf" },
        };

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SubirArchivo(IFormFile archivo, string contexto)
        {
            if (archivo == null || archivo.Length == 0)
                return BadRequest("No se recibió ningún archivo.");

            if (archivo.Length > TamanioMaximoArchivoBytes)
                return BadRequest("El archivo excede el tamaño máximo permitido (5 MB).");

            if (!ExtensionesPermitidasPorContexto.TryGetValue(contexto ?? string.Empty, out var extensionesPermitidas))
                return BadRequest("Contexto de carga no reconocido.");

            var extension = Path.GetExtension(archivo.FileName);
            if (string.IsNullOrEmpty(extension) || !extensionesPermitidas.Contains(extension, StringComparer.OrdinalIgnoreCase))
                return BadRequest("Formato de archivo no permitido para este documento.");

            // Simulado: se descarta el contenido sin guardarlo.
            var montoDetectado = SimularLecturaMontoFactura(archivo.FileName, archivo.Length);
            return Json(new { nombreArchivo = archivo.FileName, tamanioBytes = archivo.Length, montoDetectado });
        }

        // ====================================================================
        // Fase G5 (ver UI_Decision_Log.md) — simula "leer" el monto de la
        // factura cargada (contexto "factura"). Sin OCR/parseo real: es un
        // valor determinístico derivado del nombre y tamaño del archivo (el
        // mismo archivo subido dos veces da el mismo monto "detectado"), en
        // vez de un valor fijo — reemplaza el "$1,250.00" hardcodeado que
        // usaba reembolso-solicitud.js antes de esta fase. Se calcula
        // siempre (también para contexto "documento"), sin efecto: el JS
        // solo lo usa cuando contexto es "factura".
        // ====================================================================
        private static decimal SimularLecturaMontoFactura(string nombreArchivo, long tamanioBytes)
        {
            long semilla = tamanioBytes;
            foreach (var caracter in nombreArchivo)
                semilla += caracter;

            var generador = new Random((int)(semilla % int.MaxValue));
            var monto = 150m + (decimal)generador.NextDouble() * (8000m - 150m);
            return Math.Round(monto, 2);
        }

        // ====================================================================
        // Fase D — recibe el id de la fila seleccionada en Reembolsos/Index
        // (el enlace "Ver detalle" ya lo mandaba desde Fase 1, pero esta
        // acción lo ignoraba). Alcance acotado (ver UI_Decision_Log.md): solo
        // se conecta el encabezado (folio, estaciones, datos del paciente/
        // beneficiario) — el resto de Detalle.cshtml (titular, reclamación,
        // evidencias, notas, saldo) sigue hardcodeado, documentado como
        // pendiente de un modelo de dictamen que todavía no está definido.
        //
        // Si el id no corresponde a ninguna solicitud simulada: 404, no
        // redirección — decisión explícita del usuario.
        // ====================================================================
        // ====================================================================
        // Fase Dictamen-G1 (ver UI_Decision_Log.md y claude/Legacy_Dictamen_
        // Analysis.md sección 6) — "Registrar"/"Rechazar trámite" de
        // Detalle.cshtml. Antes: detalle-solicitud.js solo decidía qué modal
        // abrir (Finalizar trámite / Documentos a solicitar) y, al aceptar,
        // hacía window.location.href sin ningún POST — cero interacción con
        // el servidor.
        //
        // Mapeo de estados confirmado por el usuario, derivado del propio
        // modelo de 4 estaciones que ya tiene Current (TraducirAEstaciones/
        // ResolverIndiceEstacion) — esta pantalla representa la estación 2
        // ("Dictamen administrativo"):
        //   - Avanzar (sin rechazo, "Conceptos que se pagarán"): pasa a la
        //     estación 3 ("Autorización de pago"); Estatus queda "En
        //     proceso" (todavía no es el pago final).
        //   - Devolver (rechazo activo, "Documentos a solicitar"): regresa a
        //     la estación 1 ("Recepción de documentos"); Estatus pasa a
        //     "Corregido" (el asegurado debe volver a enviar documentos).
        //     Motivo obligatorio (ya es un campo requerido en la UI actual).
        //
        // Sin persistencia (mismo criterio que Rechazar/Regresar de esta
        // misma clase): el servidor valida y confirma; el cliente redirige
        // tras el éxito (detalle-solicitud.js) — no hay "base de datos"
        // simulada que mutar entre requests.
        // ====================================================================
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AvanzarTramite(int id, string? comentario)
        {
            var solicitud = ObtenerSolicitudesSimuladas().FirstOrDefault(s => s.Id == id);
            if (solicitud == null)
                return NotFound();

            if (EstatusFinales.Contains(solicitud.Estatus))
                return BadRequest("La solicitud ya se encuentra en un estado final.");

            // Fase FL-04 (cierre del motor de flujo, ver claude/Flujos_Funcionales_
            // Legacy_vs_Current.md, hallazgo de las secciones 1/6/14): antes este
            // método siempre fijaba la estación en "Autorización de pago" sin
            // importar en qué estación ya estuviera el trámite — no existía
            // ninguna acción que produjera el estado final "Aprobado". El mismo
            // botón "Registrar" de Detalle ahora se comporta distinto según la
            // estación actual (decisión confirmada explícitamente por el
            // usuario: un solo botón, un solo paso, sin estado intermedio
            // nuevo):
            //   - Si el trámite está en "Recepción de documentos" o en
            //     "Dictamen administrativo" (estaciones 1-2): avanza a
            //     "Autorización de pago" (comportamiento ya existente, sin
            //     cambios) — Estatus sigue "En proceso".
            //   - Si el trámite ya está en "Autorización de pago" o en
            //     "Pago autorizado" (estaciones 3-4): cierra el ciclo — pasa
            //     (o permanece) en "Pago autorizado" y Estatus pasa a
            //     "Aprobado", el único estado final positivo que existía en el
            //     modelo pero que ninguna acción de la UI producía hasta ahora.
            var indiceEstacion = ResolverIndiceEstacion(solicitud.EstacionActual);
            if (indiceEstacion >= 3)
                return Json(new { ok = true, nuevoEstatus = "Aprobado", nuevaEstacion = "Pago autorizado" });

            return Json(new { ok = true, nuevoEstatus = "En proceso", nuevaEstacion = "Autorización de pago" });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DevolverTramite(int id, string? motivo)
        {
            var solicitud = ObtenerSolicitudesSimuladas().FirstOrDefault(s => s.Id == id);
            if (solicitud == null)
                return NotFound();

            if (EstatusFinales.Contains(solicitud.Estatus))
                return BadRequest("La solicitud ya se encuentra en un estado final.");

            if (string.IsNullOrWhiteSpace(motivo))
                return BadRequest("Debe indicar el motivo de rechazo.");

            return Json(new { ok = true, nuevoEstatus = "Corregido", nuevaEstacion = "Recepción de documentos" });
        }

        public IActionResult Detalle(int id)
        {
            var solicitud = ObtenerSolicitudesSimuladas().FirstOrDefault(s => s.Id == id);
            if (solicitud == null)
                return NotFound();

            var detalle = new SolicitudReembolsoDetalleViewModel
            {
                Id = solicitud.Id,
                Folio = solicitud.Folio,
                Poliza = solicitud.Poliza,
                NombreBeneficiario = solicitud.NombreBeneficiario,
                Parentesco = solicitud.Parentesco,
                Fecha = solicitud.Fecha,
                Estatus = solicitud.Estatus,
                EstacionActual = solicitud.EstacionActual,
                Estaciones = TraducirAEstaciones(solicitud.EstacionActual),
                Monto = solicitud.Monto,
                Cobertura = solicitud.Cobertura,
                SaldoCoberturas = ObtenerSaldoCoberturasSimulado(solicitud),
                Titular = ObtenerTitularSimulado(solicitud),
            };

            (detalle.EdadPaciente, detalle.EstadoPaciente, detalle.MunicipioPaciente) = ObtenerDatosPacienteSimulados(solicitud);

            return View(detalle);
        }

        // ====================================================================
        // Fase Asegurado-G1 (ver UI_Decision_Log.md y claude/Legacy_Dictamen_
        // Analysis.md sección 1) — bloque "Datos del asegurado titular" y
        // Edad/Estado/Municipio del paciente en Detalle.cshtml. Antes: 10
        // campos 100% hardcodeados, idénticos para cualquier solicitud.
        //
        // Catálogo 100% simulado — confirmado explícitamente por el usuario:
        // no existe ninguna fuente real de asegurados/póliza en el proyecto,
        // a diferencia de Saldo-G1/Reclamacion-G1, que solo reutilizaron
        // datos ya existentes. Generación determinística por solicitud (con
        // Random sembrado por Id, mismo criterio que
        // SimularLecturaMontoFactura) — el mismo id siempre produce los
        // mismos datos simulados, no cambian entre cargas.
        //
        // "Número de Empleado" = Poliza: confirmado contra Legacy
        // (DetalleTramite.cshtml/VerCuenta.cshtml), no es un dato distinto.
        //
        // Cuando Parentesco != "Titular", el titular es una persona
        // simulada distinta al beneficiario (más fiel a una póliza
        // familiar real) — confirmado explícitamente por el usuario.
        // ====================================================================
        private static readonly string[] NombresTitularSimulados =
        {
            "Héctor Ceballos Pérez", "Norma Angélica Reyes Domínguez", "Fernando Iván Cárdenas Ruiz",
            "Leticia Guadalupe Solís Manríquez", "Arturo Bernal Chávez", "Yolanda Patricia Estrada Nava",
        };

        private static readonly (string Estado, string Municipio)[] EstadoMunicipioSimulados =
        {
            ("Puebla", "Chapulco"), ("Jalisco", "Guadalajara"), ("Nuevo León", "San Pedro Garza García"),
            ("Estado de México", "Naucalpan"), ("Querétaro", "El Marqués"), ("Guanajuato", "Irapuato"),
        };

        private static TitularSimuladoViewModel ObtenerTitularSimulado(SolicitudReembolsoResumenViewModel solicitud)
        {
            var generador = new Random(solicitud.Id);
            var esTitular = solicitud.Parentesco == "Titular";
            var nombreTitular = esTitular
                ? solicitud.NombreBeneficiario
                : NombresTitularSimulados[solicitud.Id % NombresTitularSimulados.Length];

            var inicioVigencia = new DateTime(2026, 1, 3).AddYears(-generador.Next(0, 5));

            return new TitularSimuladoViewModel
            {
                NumeroEmpleado = solicitud.Poliza,
                NombreCompleto = nombreTitular,
                Grupo = (17000000 + solicitud.Id).ToString(),
                Correo = nombreTitular.Split(' ')[0].ToLowerInvariant() + "." + nombreTitular.Split(' ')[^1].ToLowerInvariant() + "@empresa.com.mx",
                Telefono = $"{generador.Next(10, 99)} {generador.Next(1000, 9999)} {generador.Next(1000, 9999)}",
                FechaInicioVigencia = inicioVigencia,
                FechaFinVigencia = new DateTime(2199, 12, 31),
                MiembroDesde = inicioVigencia,
            };
        }

        private static (int Edad, string Estado, string Municipio) ObtenerDatosPacienteSimulados(SolicitudReembolsoResumenViewModel solicitud)
        {
            var generador = new Random(solicitud.Id + 1000);
            var edad = solicitud.Parentesco switch
            {
                "Hijo(a)" => generador.Next(1, 18),
                _ => generador.Next(25, 65),
            };
            var (estado, municipio) = EstadoMunicipioSimulados[solicitud.Id % EstadoMunicipioSimulados.Length];
            return (edad, estado, municipio);
        }

        // ====================================================================
        // Fase Saldo-G1 (ver UI_Decision_Log.md y claude/Legacy_Dictamen_
        // Analysis.md sección 4) — modal "Conoce tu saldo" de Detalle.cshtml.
        // Antes: 4 beneficiarios × 9 coberturas 100% hardcodeados en la vista.
        //
        // Catálogo de límites por cobertura simulado (mismo criterio que
        // ObtenerCatalogosSimulados/ObtenerModulosSimulados): valores fijos,
        // iguales para todas las solicitudes — no existe ningún catálogo real
        // de límites de póliza en el proyecto. La Suma Reclamada de la
        // cobertura de la solicitud abierta sí es un dato real (Monto, ya
        // existente); el resto de coberturas queda en $0.00 reclamado — no
        // hay un histórico de otros trámites por beneficiario que simular
        // sin inventarlo.
        //
        // Fórmula de Suma Remanente confirmada contra Legacy
        // (_Acumuladores.cshtml): Asegurada − (Pagada + Reclamada), nunca
        // negativa — implementada como propiedad calculada en
        // SaldoCoberturaViewModel, no aquí.
        // ====================================================================
        private static readonly Dictionary<string, (decimal Asegurada, decimal Pagada, decimal Coaseguro)> LimitesCoberturaSimulados = new()
        {
            ["GMM Mayor"] = (60000m, 0m, 0m),
            ["GMM Menor"] = (10000m, 0m, 0m),
            ["Dental"] = (5000m, 0m, 0m),
            ["Maternidad"] = (30000m, 0m, 0m),
        };

        private static List<SaldoCoberturaViewModel> ObtenerSaldoCoberturasSimulado(SolicitudReembolsoResumenViewModel solicitud) =>
            LimitesCoberturaSimulados.Select(par => new SaldoCoberturaViewModel
            {
                Cobertura = par.Key,
                SumaAsegurada = par.Value.Asegurada,
                SumaPagada = par.Value.Pagada,
                Coaseguro = par.Value.Coaseguro,
                SumaReclamada = par.Key == solicitud.Cobertura ? solicitud.Monto : 0m,
            }).ToList();

        // ====================================================================
        // Simulación temporal del listado del Tablero de Reembolsos — sin base
        // de datos ni Service todavía (ver Fase 1, UI_Decision_Log.md). Cuando
        // exista persistencia/API real, este método se sustituye por una
        // llamada a un Service/ApiClient inyectado (ej. await
        // _reembolsosService.ObtenerSolicitudesAsync()), sin que Index()/Buscar()
        // ni la vista necesiten cambiar de forma — todos ya consumen
        // List<SolicitudReembolsoResumenViewModel>, nunca este método.
        // Mismo patrón ya usado en ClientesController.ObtenerModulosSimulados().
        //
        // Fase 3: se amplía de 8 a 24 filas (mismo patrón/forma, sin campos
        // nuevos) para que la paginación sea demostrable con el tamaño de
        // página más chico del selector (10) — con 8 filas jamás habría una
        // segunda página. Cambio aprobado explícitamente por el usuario.
        // ====================================================================
        private static List<SolicitudReembolsoResumenViewModel> ObtenerSolicitudesSimuladas() => new()
        {
            new SolicitudReembolsoResumenViewModel { Id = 1,  Folio = "0104271661", Poliza = "34521098", NombreBeneficiario = "Marisol Hernández Duarte",     Parentesco = "Titular",  Monto = 12480.00m, Fecha = new DateTime(2026, 7, 3),  EstacionActual = "Dictamen médico",         Estatus = "En proceso", Cobertura = "GMM Mayor",  Flujo = "Ordinario", FolioFiscal = "3F2A9B7C-D1E4" },
            new SolicitudReembolsoResumenViewModel { Id = 2,  Folio = "0104271662", Poliza = "34558820", NombreBeneficiario = "Roberto Carlos Nieto Salas",    Parentesco = "Titular",  Monto = 3260.50m,  Fecha = new DateTime(2026, 7, 2),  EstacionActual = "Validación documental",   Estatus = "Corregido",  Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "8C4D2E1F-A9B3", Nota = "Falta comprobante fiscal (factura CFDI) del gasto reportado.", AutorNota = "Ana López", FechaNota = new DateTime(2026, 7, 2, 11, 20, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 3,  Folio = "0104271663", Poliza = "34509912", NombreBeneficiario = "Fernanda Paola Ríos Castillo",  Parentesco = "Cónyuge", Monto = 850.00m,   Fecha = new DateTime(2026, 7, 1),  EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "Maternidad", Flujo = "Maternidad", FolioFiscal = "1A2B3C4D-5E6F" },
            new SolicitudReembolsoResumenViewModel { Id = 4,  Folio = "0104271664", Poliza = "34577345", NombreBeneficiario = "Alejandro Gómez Treviño",       Parentesco = "Titular",  Monto = 32800.00m, Fecha = new DateTime(2026, 6, 30), EstacionActual = "Autorización de pago",    Estatus = "Aprobado",   Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "7D8E9F0A-B1C2" },
            new SolicitudReembolsoResumenViewModel { Id = 5,  Folio = "0104271665", Poliza = "34512276", NombreBeneficiario = "Itzel Guadalupe Montes Vera",   Parentesco = "Hijo(a)", Monto = 1420.00m,  Fecha = new DateTime(2026, 6, 29), EstacionActual = "Dictamen médico",         Estatus = "En proceso", Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "4B5C6D7E-8F9A" },
            new SolicitudReembolsoResumenViewModel { Id = 6,  Folio = "0104271666", Poliza = "34598010", NombreBeneficiario = "Sergio Iván Delgado Rosales",   Parentesco = "Titular",  Monto = 620.00m,   Fecha = new DateTime(2026, 6, 28), EstacionActual = "Revisión de póliza",      Estatus = "Rechazado",  Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "2E3F4A5B-6C7D", Nota = "El diagnóstico reportado no corresponde a la cobertura seleccionada.", AutorNota = "Marco Villegas", FechaNota = new DateTime(2026, 6, 28, 16, 45, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 7,  Folio = "0104271667", Poliza = "34533187", NombreBeneficiario = "Daniela Contreras Barajas",     Parentesco = "Titular",  Monto = 5140.00m,  Fecha = new DateTime(2026, 6, 27), EstacionActual = "Validación documental",   Estatus = "Corregido",  Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "9A0B1C2D-3E4F", Nota = "La factura no coincide con el monto solicitado. Favor de corregir.", AutorNota = "Ana López", FechaNota = new DateTime(2026, 6, 27, 9, 10, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 8,  Folio = "0104271668", Poliza = "34561429", NombreBeneficiario = "Luis Fernando Aguilar Peña",    Parentesco = "Cónyuge",  Monto = 9930.00m,  Fecha = new DateTime(2026, 6, 26), EstacionActual = "Pago autorizado",         Estatus = "En proceso", Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "5C6D7E8F-9A0B" },
            new SolicitudReembolsoResumenViewModel { Id = 9,  Folio = "0104271669", Poliza = "34544567", NombreBeneficiario = "Karla Jimena Suárez Ponce",     Parentesco = "Titular",  Monto = 2150.00m,  Fecha = new DateTime(2026, 6, 25), EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "6A7B8C9D-0E1F" },
            new SolicitudReembolsoResumenViewModel { Id = 10, Folio = "0104271670", Poliza = "34590233", NombreBeneficiario = "Óscar Iván Beltrán Solís",      Parentesco = "Hijo(a)",  Monto = 780.00m,   Fecha = new DateTime(2026, 6, 24), EstacionActual = "Dictamen médico",         Estatus = "Aprobado",   Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "0F1E2D3C-4B5A" },
            new SolicitudReembolsoResumenViewModel { Id = 11, Folio = "0104271671", Poliza = "34567891", NombreBeneficiario = "Paulina Isabel Cordero Luna",   Parentesco = "Titular",  Monto = 15600.00m, Fecha = new DateTime(2026, 6, 23), EstacionActual = "Autorización de pago",    Estatus = "Aprobado",   Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "1B2C3D4E-5F6A" },
            new SolicitudReembolsoResumenViewModel { Id = 12, Folio = "0104271672", Poliza = "34523456", NombreBeneficiario = "Emilio Rodrigo Vargas Nuño",    Parentesco = "Cónyuge",  Monto = 430.00m,   Fecha = new DateTime(2026, 6, 22), EstacionActual = "Revisión de póliza",      Estatus = "Rechazado",  Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "2C3D4E5F-6A7B", Nota = "Documentación incompleta: falta receta médica original.", AutorNota = "Marco Villegas", FechaNota = new DateTime(2026, 6, 22, 14, 5, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 13, Folio = "0104271673", Poliza = "34578901", NombreBeneficiario = "Ximena Alejandra Torres Campos",Parentesco = "Titular",  Monto = 890.00m,   Fecha = new DateTime(2026, 6, 21), EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "Maternidad", Flujo = "Maternidad", FolioFiscal = "3D4E5F6A-7B8C" },
            new SolicitudReembolsoResumenViewModel { Id = 14, Folio = "0104271674", Poliza = "34534567", NombreBeneficiario = "Iván Alberto Reséndiz Cano",     Parentesco = "Titular",  Monto = 7230.00m,  Fecha = new DateTime(2026, 6, 20), EstacionActual = "Validación documental",   Estatus = "Corregido",  Cobertura = "GMM Mayor",  Flujo = "Ordinario", FolioFiscal = "4E5F6A7B-8C9D", Nota = "Se solicita la carátula de la póliza vigente para continuar.", AutorNota = "Ana López", FechaNota = new DateTime(2026, 6, 20, 10, 30, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 15, Folio = "0104271675", Poliza = "34589012", NombreBeneficiario = "Regina Montserrat Ochoa Lara",  Parentesco = "Hijo(a)",  Monto = 310.00m,   Fecha = new DateTime(2026, 6, 19), EstacionActual = "Dictamen médico",         Estatus = "En proceso", Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "5F6A7B8C-9D0E" },
            new SolicitudReembolsoResumenViewModel { Id = 16, Folio = "0104271676", Poliza = "34545678", NombreBeneficiario = "Gerardo Iván Palacios Meza",    Parentesco = "Titular",  Monto = 21400.00m, Fecha = new DateTime(2026, 6, 18), EstacionActual = "Pago autorizado",         Estatus = "Aprobado",   Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "6A7B8C9D-0E1F" },
            new SolicitudReembolsoResumenViewModel { Id = 17, Folio = "0104271677", Poliza = "34590123", NombreBeneficiario = "Alondra Sofía Miranda Vega",    Parentesco = "Cónyuge",  Monto = 1980.00m,  Fecha = new DateTime(2026, 6, 17), EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "7B8C9D0E-1F2A" },
            new SolicitudReembolsoResumenViewModel { Id = 18, Folio = "0104271678", Poliza = "34556789", NombreBeneficiario = "Tomás Eduardo Salinas Rocha",   Parentesco = "Titular",  Monto = 540.00m,   Fecha = new DateTime(2026, 6, 16), EstacionActual = "Revisión de póliza",      Estatus = "Rechazado",  Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "8C9D0E1F-2A3B", Nota = "El padecimiento reportado está fuera del periodo de cobertura.", AutorNota = "Marco Villegas", FechaNota = new DateTime(2026, 6, 16, 12, 0, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 19, Folio = "0104271679", Poliza = "34501234", NombreBeneficiario = "Valeria Guadalupe Espinoza Ríos",Parentesco = "Titular", Monto = 3720.00m,  Fecha = new DateTime(2026, 6, 15), EstacionActual = "Validación documental",   Estatus = "Corregido",  Cobertura = "GMM Mayor",  Flujo = "Ordinario", FolioFiscal = "9D0E1F2A-3B4C", Nota = "Falta identificación oficial del beneficiario para continuar el trámite.", AutorNota = "Ana López", FechaNota = new DateTime(2026, 6, 15, 8, 50, 0) },
            new SolicitudReembolsoResumenViewModel { Id = 20, Folio = "0104271680", Poliza = "34567345", NombreBeneficiario = "Rodrigo Emiliano Castañeda Ibarra", Parentesco = "Hijo(a)", Monto = 6100.00m, Fecha = new DateTime(2026, 6, 14), EstacionActual = "Dictamen médico",         Estatus = "En proceso", Cobertura = "Maternidad", Flujo = "Maternidad", FolioFiscal = "0E1F2A3B-4C5D" },
            new SolicitudReembolsoResumenViewModel { Id = 21, Folio = "0104271681", Poliza = "34512890", NombreBeneficiario = "Melissa Andrea Guerrero Payán", Parentesco = "Titular",  Monto = 980.00m,   Fecha = new DateTime(2026, 6, 13), EstacionActual = "Autorización de pago",    Estatus = "Aprobado",   Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "1F2A3B4C-5D6E" },
            new SolicitudReembolsoResumenViewModel { Id = 22, Folio = "0104271682", Poliza = "34578456", NombreBeneficiario = "Diego Armando Cervantes Uribe", Parentesco = "Cónyuge",  Monto = 14250.00m, Fecha = new DateTime(2026, 6, 12), EstacionActual = "Pago autorizado",         Estatus = "Aprobado",   Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "2A3B4C5D-6E7F" },
            new SolicitudReembolsoResumenViewModel { Id = 23, Folio = "0104271683", Poliza = "34523901", NombreBeneficiario = "Natalia Fernanda Bravo Solano", Parentesco = "Titular",  Monto = 460.00m,   Fecha = new DateTime(2026, 6, 11), EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "3B4C5D6E-7F8A" },
            new SolicitudReembolsoResumenViewModel { Id = 24, Folio = "0104271684", Poliza = "34589567", NombreBeneficiario = "Jorge Luis Montoya Zepeda",     Parentesco = "Titular",  Monto = 2870.00m,  Fecha = new DateTime(2026, 6, 10), EstacionActual = "Revisión de póliza",      Estatus = "Rechazado",  Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "4C5D6E7F-8A9B", Nota = "Trámite duplicado: ya existe una solicitud registrada para este mismo evento.", AutorNota = "Marco Villegas", FechaNota = new DateTime(2026, 6, 10, 17, 15, 0) },
        };

        // ====================================================================
        // Filtro en memoria sobre la lista simulada — sustituye a la futura
        // llamada real (Service/ApiClient con filtro en el servidor de datos).
        // Cada campo nulo/"Todos"/"Todas" significa "sin restricción" (ver
        // SolicitudReembolsoFiltroViewModel). AND entre campos, no OR — mismo
        // criterio que el filtro combinado del Legacy (ver Legacy_Functional_
        // Gap_Analysis.md).
        // ====================================================================
        private static List<SolicitudReembolsoResumenViewModel> AplicarFiltro(
            List<SolicitudReembolsoResumenViewModel> solicitudes,
            SolicitudReembolsoFiltroViewModel filtro)
        {
            IEnumerable<SolicitudReembolsoResumenViewModel> query = solicitudes;

            if (!string.IsNullOrWhiteSpace(filtro.Folio))
                query = query.Where(s => s.Folio.Contains(filtro.Folio, StringComparison.OrdinalIgnoreCase));

            if (filtro.FechaDesde.HasValue)
                query = query.Where(s => s.Fecha.Date >= filtro.FechaDesde.Value.Date);

            if (filtro.FechaHasta.HasValue)
                query = query.Where(s => s.Fecha.Date <= filtro.FechaHasta.Value.Date);

            if (!string.IsNullOrWhiteSpace(filtro.Estatus) && filtro.Estatus != "Todos")
                query = query.Where(s => string.Equals(s.Estatus, filtro.Estatus, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.Poliza))
                query = query.Where(s => s.Poliza.Contains(filtro.Poliza, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.Cobertura) && filtro.Cobertura != "Todas")
                query = query.Where(s => string.Equals(s.Cobertura, filtro.Cobertura, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.Flujo) && filtro.Flujo != "Todos")
                query = query.Where(s => string.Equals(s.Flujo, filtro.Flujo, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.FolioFiscal))
                query = query.Where(s => s.FolioFiscal.Contains(filtro.FolioFiscal, StringComparison.OrdinalIgnoreCase));

            return query.ToList();
        }

        // ====================================================================
        // Paginación (Fase 3) — se aplica siempre después del filtro, nunca
        // antes. La página solicitada se ajusta (clamp) al rango válido
        // [1, TotalPaginas]: si el filtro deja menos páginas de las que
        // existían y la página pedida ya no existe, se regresa la última
        // página válida en vez de una lista vacía por error de rango — mismo
        // criterio (simplificado) que ListaTablero en el Legacy.
        // ====================================================================
        private static SolicitudReembolsoResultadoViewModel Paginar(
            List<SolicitudReembolsoResumenViewModel> solicitudes,
            int pagina,
            int tamanioPagina)
        {
            if (tamanioPagina <= 0)
                tamanioPagina = TamanioPaginaPorDefecto;

            var totalRegistros = solicitudes.Count;
            var totalPaginas = totalRegistros == 0
                ? 1
                : (int)Math.Ceiling(totalRegistros / (double)tamanioPagina);

            if (pagina < 1)
                pagina = 1;
            if (pagina > totalPaginas)
                pagina = totalPaginas;

            var solicitudesPagina = solicitudes
                .Skip((pagina - 1) * tamanioPagina)
                .Take(tamanioPagina)
                .ToList();

            return new SolicitudReembolsoResultadoViewModel
            {
                Solicitudes = solicitudesPagina,
                Pagina = pagina,
                TamanioPagina = tamanioPagina,
                TotalRegistros = totalRegistros,
                TotalPaginas = totalPaginas,
            };
        }

        // ====================================================================
        // Fase D — traduce EstacionActual (texto libre del listado, más
        // granular) a las 4 estaciones fijas de Reembolsos/Detalle. Es una
        // traducción de presentación, mismo criterio que el badge de Estatus
        // en _ResultadosSolicitudes.cshtml — no es una regla de negocio nueva.
        // No se introduce un quinto estado visual para "Rechazado": la
        // estación en la que se rechazó simplemente queda marcada "actual"
        // (decisión explícita del usuario — mantener las 4 estaciones tal
        // como existen hoy en la vista).
        // ====================================================================
        private static IReadOnlyList<EstacionDetalleViewModel> TraducirAEstaciones(string estacionActual)
        {
            string[] nombres =
            {
                "Recepción de documentos",
                "Dictamen administrativo",
                "Autorización de pago",
                "Pago autorizado",
            };

            var indiceActual = ResolverIndiceEstacion(estacionActual);

            var estaciones = new List<EstacionDetalleViewModel>();
            for (var i = 0; i < nombres.Length; i++)
            {
                var numero = i + 1;
                estaciones.Add(new EstacionDetalleViewModel
                {
                    Nombre = nombres[i],
                    Estado = numero < indiceActual ? "hecho" : numero == indiceActual ? "actual" : "pendiente",
                });
            }

            return estaciones;
        }

        private static int ResolverIndiceEstacion(string estacionActual)
        {
            if (estacionActual.Contains("Recepción", StringComparison.OrdinalIgnoreCase))
                return 1;

            if (estacionActual.Contains("Autorización de pago", StringComparison.OrdinalIgnoreCase))
                return 3;

            if (estacionActual.Contains("Pago autorizado", StringComparison.OrdinalIgnoreCase))
                return 4;

            // "Dictamen médico", "Validación documental", "Revisión de póliza"
            // — todas caen en "Dictamen administrativo", la única estación
            // intermedia de las 4 fijas.
            return 2;
        }
    }
}

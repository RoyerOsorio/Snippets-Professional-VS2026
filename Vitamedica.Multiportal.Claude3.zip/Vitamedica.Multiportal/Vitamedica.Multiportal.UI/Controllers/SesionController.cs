﻿using System.Reflection;
using System.Security.Claims;
using System.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Vitamedica.Multiportal.UI.Agents;

//using Vitamedica.Multiportal.Application;
//using Vitamedica.Multiportal.IApplication.Interfaces;
using Vitamedica.Multiportal.UI.Models.ActiveDirectory;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Vitamedica.Multiportal.UI.Controllers
{
    public class SesionController : Controller
    {
        private readonly AuthAgent _authAgent;
        public SesionController(AuthAgent authAgent)
        {
            _authAgent = authAgent;
        }
        // GET: Sesion
        public ActionResult Login()
        {
            return View();
        }


        // POST: Sesion/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(Login model)
        {

            if (!ModelState.IsValid) return View(model);

            var result = _authAgent.VerificaUsuario(model.User, model.Password);


            if (result.EsCorrecto && result.EsAutenticado)
            {
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, model.User),
                    //new Claim("TokenExterno", result.Token) // Guardamos el token si lo necesitamos después
                };

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);


                HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(claimsIdentity),
                    new AuthenticationProperties { IsPersistent = model.RememberMe });

                return RedirectToAction(nameof(Index), "Home");
            }

            return RedirectToAction(nameof(Login));

        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);


            // 3. Redirigir a la página principal o al login
            //return RedirectToAction("Login", "Sesion");
            Response.Redirect("http://dev-redvitamedica.bupa.com.mx/Portal/Sesion/Logout", true);
            return Redirect("http://dev-redvitamedica.bupa.com.mx/Portal/Sesion/Logout");
        }

        [HttpGet]
        public async Task<ActionResult> IniciarSesion()
        {
            try
            {
                
                string t0 = System.Web.HttpUtility.UrlEncode(Request.Query["t0"].ToString());
                string target = Request.Query["target"].ToString();



                if (string.IsNullOrEmpty(t0))
                {
                    //return await Task.FromResult(RedirectToAction("_Login", "Sesion"));
                    return await Task.FromResult(RedirectToAction("Logout", "Sesion"));
                }


                TokenValidoResume resToken;

                resToken = _authAgent.ValidaToken(t0);

                bool validaPass = true;
                string pass = string.Empty;
                try
                {
                    string Separador = "102512119090";
                    string[] separadorSplit = { Separador };


                    string resDesencripto = Utils.CryptoBBVA.Decrypt(HttpUtility.UrlDecode(t0));
                    string[] split = resDesencripto.Split(separadorSplit, StringSplitOptions.None);
                    pass = split[1].Trim();
                    validaPass = false;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }


                if (resToken != null && resToken.EsCorrecto && resToken.EsTokenValido)
                {
                    var result = _authAgent.VerificaUsuario(resToken.NombreUsuario, pass);


                    if (result.EsCorrecto && result.EsAutenticado)
                    {
                        var claims = new List<Claim>
                        {
                            new Claim(ClaimTypes.Name, resToken.NombreUsuario),
                            //new Claim("TokenExterno", result.Token) // Guardamos el token si lo necesitamos después
                        };

                        var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);


                        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                            new ClaimsPrincipal(claimsIdentity),
                            new AuthenticationProperties { IsPersistent = false });

                        return await Task.FromResult(RedirectToAction(nameof(Index), "Home"));
                    }

                    return await Task.FromResult(RedirectToAction(nameof(Login)));
                }

                ViewBag.ErrorMessage = resToken == null ? "" : resToken.Mensaje;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
                Console.WriteLine(ex.Message);
            }
            return View("Error");
        }
    }
}

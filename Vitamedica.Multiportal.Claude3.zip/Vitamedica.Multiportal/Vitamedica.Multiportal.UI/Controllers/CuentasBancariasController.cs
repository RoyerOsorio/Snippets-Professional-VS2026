using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Vitamedica.Multiportal.UI.Models.ViewModels;

namespace Vitamedica.Multiportal.UI.Controllers
{
    // ========================================================================
    // Ciclo 1 (ver claude/Fase_CuentasBancariasPagos_Analizar_Proponer.md,
    // sección 15) — estructura + listado con datos simulados.
    //
    // Ciclo 2 — filtros + paginación conectados al mismo listado simulado.
    // Mismo patrón ya validado en ReembolsosController/PagosController:
    // Buscar() devuelve un PartialView (no JSON) para reutilizar el mismo
    // marcado Razor que Index() ya usa en la carga inicial. Devuelve
    // Partials/_ResultadosYPaginacionCuentasBancarias (tbody + pie
    // concatenados), no solo el tbody — mismo criterio que PagosController
    // (ver DEC-Pagos-Index-Paginacion.md, "hallazgo: pie de tabla no se
    // actualiza en Reembolsos/Buscar" — Pagos y ahora Cuentas Bancarias no
    // repiten ese defecto).
    //
    // No se agrega entrada de menú todavía (deliberado, ver roadmap
    // aprobado, Ciclo 6) — se navega por URL directa mientras el módulo se
    // construye incrementalmente.
    // ========================================================================
    [Authorize]
    public class CuentasBancariasController : Controller
    {
        private const int TamanioPaginaPorDefecto = 25;

        public IActionResult Index()
        {
            var resultado = Paginar(ObtenerCuentasSimuladas(), pagina: 1, tamanioPagina: TamanioPaginaPorDefecto);
            return View(resultado);
        }

        [HttpGet]
        public IActionResult Buscar(CuentaBancariaFiltroViewModel filtro, int pagina = 1, int tamanioPagina = TamanioPaginaPorDefecto)
        {
            var filtrado = AplicarFiltro(ObtenerCuentasSimuladas(), filtro);
            var resultado = Paginar(filtrado, pagina, tamanioPagina);
            return PartialView("Partials/_ResultadosYPaginacionCuentasBancarias", resultado);
        }

        // ====================================================================
        // Ciclo 3 (ver claude/Fase_CuentasBancariasPagos_Analizar_Proponer.md,
        // sección 15) — alta de cuenta bancaria. Vista dedicada (confirmado
        // explícitamente por el usuario, no modal — sección 16, punto 1),
        // mismo patrón que ClientesController.Crear/Guardar.
        // ====================================================================
        public IActionResult Crear()
        {
            return View(new CuentaBancariaFormViewModel());
        }

        // ====================================================================
        // Ciclo 4 (ver claude/Fase_CuentasBancariasPagos_Analizar_Proponer.md,
        // sección 15) — edición, reutilizando el mismo formulario/partial que
        // Crear (_CuentaBancariaForm.cshtml), mismo patrón que
        // ClientesController.Detalle.
        //
        // A diferencia de ClientesController.Detalle (que siempre devuelve el
        // mismo registro demo fijo, sin importar "id" — Clientes/Index no
        // comparte lista con Detalle), aquí sí existe una lista simulada real
        // con ids propios (ObtenerCuentasSimuladas()), así que Detalle busca
        // en ella y devuelve NotFound() si no hay coincidencia — mismo
        // criterio que ReembolsosController.Detalle/HomeController.Asegurado.
        // ====================================================================
        public IActionResult Detalle(int id)
        {
            var cuenta = ObtenerCuentasSimuladas().FirstOrDefault(c => c.Id == id);
            if (cuenta == null)
                return NotFound();

            var modelo = new CuentaBancariaFormViewModel
            {
                Id = cuenta.Id,
                Poliza = cuenta.Poliza,
                Cliente = cuenta.Cliente,
                Banco = cuenta.Banco,
                Clabe = cuenta.Clabe,
                Titular = cuenta.Titular,
                EsPrincipal = cuenta.EsPrincipal,
            };

            return View(modelo);
        }

        // ====================================================================
        // Validación server-side real (no basta la pista de la UI) — mismo
        // principio ya aplicado en ClientesController.Guardar/
        // ReembolsosController.SubirArchivo (UI_Coding_Standards.md,
        // seguridad). Clabe: exactamente 18 dígitos, igual que Legacy
        // (CuentaBancariaResumeViewModel.Clabe) — sin dígito verificador,
        // PENDIENTE DE DEFINICIÓN DE NEGOCIO (ver sección 16, punto 5 del
        // análisis). Sirve tanto para alta (Ciclo 3) como para edición
        // (Ciclo 4) — no persiste en ninguno de los dos casos, mismo criterio
        // que el resto del proyecto.
        //
        // Nota (igual que ClientesController.Guardar): el formulario no envía
        // "id" en el payload (cuenta-bancaria-form.js/construirPayloadCuentaBancaria
        // no lo incluye) — mismo criterio ya establecido para Clientes, así
        // que en edición también se genera un id simulado nuevo en vez de
        // conservar el original. Es una simplificación ya aceptada del
        // proyecto (sin persistencia real, el id no tiene consecuencia
        // observable), no un defecto introducido aquí.
        // ====================================================================
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Guardar([FromBody] CuentaBancariaFormViewModel modelo)
        {
            if (modelo == null)
                return BadRequest("Cuerpo de la solicitud vacío o mal formado.");

            if (string.IsNullOrWhiteSpace(modelo.Poliza)
                || string.IsNullOrWhiteSpace(modelo.Cliente)
                || string.IsNullOrWhiteSpace(modelo.Banco)
                || string.IsNullOrWhiteSpace(modelo.Titular))
                return BadRequest("Faltan campos requeridos.");

            if (string.IsNullOrWhiteSpace(modelo.Clabe) || modelo.Clabe.Length != 18 || !modelo.Clabe.All(char.IsDigit))
                return BadRequest("La Clabe interbancaria debe tener exactamente 18 dígitos.");

            if (!ClavesBancoSimuladas.ContainsKey(modelo.Banco))
                return BadRequest("Banco no reconocido.");

            // Simulado: no persiste. Igual criterio que ClientesController.Guardar/
            // ReembolsosController.Registrar (id/folio simulado).
            var id = modelo.Id ?? new Random().Next(100, 999);
            return Json(new { ok = true, id });
        }

        // ====================================================================
        // Ciclo 5 (ver claude/Fase_CuentasBancariasPagos_Analizar_Proponer.md,
        // sección 15) — Desactivar/Reactivar, mismo patrón y misma limitación
        // ya documentada en ClientesController.CambiarEstado: no hay "base de
        // datos" simulada que mutar (ObtenerCuentasSimuladas() reconstruye la
        // misma lista en cada solicitud), así que el servidor solo valida y
        // confirma; la actualización visual ocurre en
        // cuentas-bancarias-index.js tras la respuesta exitosa.
        //
        // A diferencia de ClientesController.CambiarEstado, aquí sí existe una
        // lista simulada con ids reales, así que se valida que la cuenta
        // exista (NotFound si no) antes de confirmar — mismo criterio ya
        // aplicado en Detalle (Ciclo 4).
        // ====================================================================
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CambiarEstado(int id, string accion)
        {
            if (accion != "Desactivar" && accion != "Reactivar")
                return BadRequest("Acción no reconocida.");

            var cuenta = ObtenerCuentasSimuladas().FirstOrDefault(c => c.Id == id);
            if (cuenta == null)
                return NotFound();

            var nuevoEstado = accion == "Desactivar" ? "Inactiva" : "Activa";
            return Json(new { ok = true, nuevoEstado });
        }

        // ====================================================================
        // Ciclo 5 — Marcar cuenta principal. Regla de negocio explícita
        // (sección 4 del análisis: "una cuenta principal por póliza"): solo
        // una cuenta ACTIVA puede marcarse como principal; marcarla implica
        // desmarcar cualquier otra cuenta principal de la misma póliza.
        //
        // Sin persistencia real, el servidor no puede aplicar ese efecto
        // colateral sobre "las demás cuentas de la póliza" (no existe estado
        // compartido entre solicitudes) — únicamente valida la cuenta
        // solicitada y devuelve su póliza; cuentas-bancarias-index.js aplica
        // el efecto colateral sobre las filas de esa póliza ya visibles en el
        // DOM. Mismo reparto de responsabilidades (servidor valida, cliente
        // actualiza su propia vista) que el resto del proyecto.
        // ====================================================================
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult MarcarPrincipal(int id)
        {
            var cuenta = ObtenerCuentasSimuladas().FirstOrDefault(c => c.Id == id);
            if (cuenta == null)
                return NotFound();

            if (cuenta.Estatus != "Activa")
                return BadRequest("Solo una cuenta activa puede marcarse como principal.");

            return Json(new { ok = true, poliza = cuenta.Poliza });
        }

        // ====================================================================
        // Catálogo simulado de claves de banco — mismo criterio que
        // MonedaViewModel (Reembolsos/Crear Fase G1): el formulario captura
        // solo el nombre del banco; la clave es un detalle de
        // negocio/presentación que resuelve el servidor, no la vista ni el
        // JavaScript. Mismos 5 bancos ya usados en ObtenerCuentasSimuladas.
        // ====================================================================
        private static readonly Dictionary<string, string> ClavesBancoSimuladas = new()
        {
            ["BBVA"] = "012",
            ["Santander"] = "014",
            ["Banorte"] = "072",
            ["HSBC"] = "021",
            ["Banamex"] = "002",
        };

        // ====================================================================
        // Simulación temporal del listado — sin base de datos ni Service
        // todavía (ver Ciclo 1, claude/Fase_CuentasBancariasPagos_Analizar_
        // Proponer.md). Cuando exista persistencia/API real, este método se
        // sustituye por una llamada a un Service/ApiClient inyectado, sin que
        // Index()/Buscar() ni la vista necesiten cambiar de forma. Mismo
        // patrón ya usado en ReembolsosController.ObtenerSolicitudesSimuladas()/
        // PagosController.ObtenerPagosSimulados().
        //
        // Pólizas reutilizadas de los datasets simulados ya existentes en
        // Reembolsos/Pagos (mismos titulares) para que el catálogo se sienta
        // parte del mismo negocio simulado, no un dominio aislado.
        // ====================================================================
        private static List<CuentaBancariaViewModel> ObtenerCuentasSimuladas() => new()
        {
            new CuentaBancariaViewModel
            {
                Id = 1,
                Poliza = "38603787",
                Cliente = "Grupo Modelo",
                Banco = "BBVA",
                ClaveBanco = "012",
                Clabe = "012180001234567895",
                Titular = "Carlos Moncayo Espinosa",
                Estatus = "Activa",
                EsPrincipal = true,
                FechaAlta = new DateTime(2026, 3, 12),
                FechaModificacion = null
            },
            new CuentaBancariaViewModel
            {
                Id = 2,
                Poliza = "38603787",
                Cliente = "Grupo Modelo",
                Banco = "Santander",
                ClaveBanco = "014",
                Clabe = "014180009876543211",
                Titular = "Carlos Moncayo Espinosa",
                Estatus = "Inactiva",
                EsPrincipal = false,
                FechaAlta = new DateTime(2025, 11, 4),
                FechaModificacion = new DateTime(2026, 3, 12)
            },
            new CuentaBancariaViewModel
            {
                Id = 3,
                Poliza = "32183470",
                Cliente = "Grupo Modelo",
                Banco = "Banorte",
                ClaveBanco = "072",
                Clabe = "072180004455667783",
                Titular = "Jáder Medina",
                Estatus = "Activa",
                EsPrincipal = true,
                FechaAlta = new DateTime(2026, 1, 22),
                FechaModificacion = null
            },
            new CuentaBancariaViewModel
            {
                Id = 4,
                Poliza = "32195643",
                Cliente = "Smurfit",
                Banco = "BBVA",
                ClaveBanco = "012",
                Clabe = "012320011223344556",
                Titular = "Mariana Isabel Cordero Luna",
                Estatus = "Activa",
                EsPrincipal = true,
                FechaAlta = new DateTime(2026, 5, 2),
                FechaModificacion = null
            },
            new CuentaBancariaViewModel
            {
                Id = 5,
                Poliza = "38612078",
                Cliente = "Grupo Modelo",
                Banco = "HSBC",
                ClaveBanco = "021",
                Clabe = "021180002233445567",
                Titular = "Emilio Rodrigo Vargas Nuño",
                Estatus = "Activa",
                EsPrincipal = false,
                FechaAlta = new DateTime(2026, 6, 18),
                FechaModificacion = null
            },
            new CuentaBancariaViewModel
            {
                Id = 6,
                Poliza = "38634512",
                Cliente = "Grupo Modelo",
                Banco = "Banamex",
                ClaveBanco = "002",
                Clabe = "002180007766554432",
                Titular = "Iván Alberto Reséndiz Cano",
                Estatus = "Inactiva",
                EsPrincipal = false,
                FechaAlta = new DateTime(2025, 8, 30),
                FechaModificacion = new DateTime(2026, 2, 14)
            },
        };

        // ====================================================================
        // Filtro en memoria sobre la lista simulada — mismo criterio que
        // ReembolsosController.AplicarFiltro/PagosController.AplicarFiltro:
        // cada campo nulo/vacío significa "sin restricción", AND entre
        // campos, no OR.
        // ====================================================================
        private static List<CuentaBancariaViewModel> AplicarFiltro(
            List<CuentaBancariaViewModel> cuentas,
            CuentaBancariaFiltroViewModel filtro)
        {
            IEnumerable<CuentaBancariaViewModel> query = cuentas;

            if (!string.IsNullOrWhiteSpace(filtro.Poliza))
                query = query.Where(c => c.Poliza.Contains(filtro.Poliza, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.Banco) && filtro.Banco != "Todos")
                query = query.Where(c => string.Equals(c.Banco, filtro.Banco, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.Estatus) && filtro.Estatus != "Todos")
                query = query.Where(c => string.Equals(c.Estatus, filtro.Estatus, StringComparison.OrdinalIgnoreCase));

            return query.ToList();
        }

        // ====================================================================
        // Paginación — mismo patrón que ReembolsosController.Paginar/
        // PagosController.Paginar: se aplica siempre después del filtro; la
        // página solicitada se ajusta (clamp) al rango válido [1, TotalPaginas].
        // ====================================================================
        private static CuentaBancariaResultadoViewModel Paginar(
            List<CuentaBancariaViewModel> cuentas,
            int pagina,
            int tamanioPagina)
        {
            if (tamanioPagina <= 0)
                tamanioPagina = TamanioPaginaPorDefecto;

            var totalRegistros = cuentas.Count;
            var totalPaginas = totalRegistros == 0
                ? 1
                : (int)Math.Ceiling(totalRegistros / (double)tamanioPagina);

            if (pagina < 1)
                pagina = 1;
            if (pagina > totalPaginas)
                pagina = totalPaginas;

            var cuentasPagina = cuentas
                .Skip((pagina - 1) * tamanioPagina)
                .Take(tamanioPagina)
                .ToList();

            return new CuentaBancariaResultadoViewModel
            {
                Cuentas = cuentasPagina,
                Pagina = pagina,
                TamanioPagina = tamanioPagina,
                TotalRegistros = totalRegistros,
                TotalPaginas = totalPaginas,
            };
        }
    }
}

using System.Diagnostics;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
//using Vitamedica.Multiportal.Application.Interfaces;
using Vitamedica.Multiportal.UI.Models;
using Vitamedica.Multiportal.UI.Models.ActiveDirectory;
using Vitamedica.Multiportal.UI.Models.ViewModels;
using Vitamedica.Multiportal.UI.Services;

namespace Vitamedica.Multiportal.UI.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly MultiportalApiClient _multiportalApiClient;
        
        public HomeController(MultiportalApiClient multiportalApiClient)
        {
            _multiportalApiClient = multiportalApiClient;
        }
        
        public async Task<IActionResult> Index()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
            {
                try
                {
                    return View();

                    //string name = User.FindFirstValue(ClaimTypes.Name) ?? string.Empty;

                    //var _user = await _multiportalApiClient.GetUserProfile(name);
                    //if(_user != null)
                    //    return View(new UserProfile
                    //    {
                    //        ApellidoMaterno = _user.ApellidoMaterno,
                    //        ApellidoPaterno = _user.ApellidoPaterno,
                    //        Clave = _user.Clave,
                    //        CorreoElectronico = _user.CorreoElectronico,
                    //        GrgrCk = _user.GrgrCk,
                    //        MemeCk = _user.MemeCk,
                    //        Nombre = _user.Nombre,
                    //        NombreCompleto = _user.NombreCompleto,
                    //        NombreORazonSocial = _user.NombreORazonSocial,
                    //        NombreUsuario = _user.NombreUsuario,
                    //        NominaEmpleado = _user.NominaEmpleado,
                    //        PrprId = _user.PrprId,
                    //        RFC = _user.RFC,
                    //        TipoUsuario = _user.TipoUsuario,
                    //        TipoUsuarioDescripcion = _user.TipoUsuarioDescripcion
                    //    });

                    //var _user = _activeDirectoryApplication.GetUser(name);
                    //if (_user != null)
                    //    return View(new UserProfile
                    //    {
                    //        ApellidoMaterno = _user.ApellidoMaterno,
                    //        ApellidoPaterno = _user.ApellidoPaterno,
                    //        Clave = _user.Clave,
                    //        CorreoElectronico = _user.CorreoElectronico,
                    //        GrgrCk = _user.GrgrCk,
                    //        MemeCk = _user.MemeCk,
                    //        Nombre = _user.Nombre,
                    //        NombreCompleto = _user.NombreCompleto,
                    //        NombreORazonSocial = _user.NombreORazonSocial,
                    //        NombreUsuario = _user.NombreUsuario,
                    //        NominaEmpleado = _user.NominaEmpleado,
                    //        PrprId = _user.PrprId,
                    //        RFC = _user.RFC,
                    //        TipoUsuario = (ActiveDirectory.Model.ViewModels.TipoUsuario)_user.TipoUsuario,
                    //        TipoUsuarioDescripcion = _user.TipoUsuarioDescripcion
                    //    });
                }
                catch (Exception ex)
                {

                }
            }
            return View(new UserProfile());
        }

        // ====================================================================
        // Fase Asegurado-D (ver UI_Decision_Log.md) — mismo tratamiento que
        // ReembolsosController.Detalle(int id) (Fase D): recibe id, folio y
        // estaciones dejan de estar hardcodeados en Razor. El resto de
        // Asegurado.cshtml (titular, derechohabiente, reclamación,
        // evidencias, notas, saldo) sigue hardcodeado, pendiente de un
        // modelo de dictamen que todavía no está definido.
        //
        // Si el id no corresponde a ningún folio simulado: 404, no
        // redirección — mismo criterio ya decidido para Reembolsos/Detalle.
        //
        // Nota de duplicación (deliberada, no silenciosa): TraducirAEstaciones/
        // ResolverIndiceEstacion replican exactamente la lógica ya existente
        // en ReembolsosController. Es la 2a ocurrencia del mismo algoritmo —
        // se documenta aquí en vez de extraerse a un helper compartido
        // (Regla 21/40: evitar abstraer prematuramente; se reconsiderará si
        // aparece una 3a pantalla con la misma necesidad).
        // ====================================================================
        public IActionResult Asegurado(int id)
        {
            var folio = ObtenerFoliosAseguradoSimulados().FirstOrDefault(f => f.Id == id);
            if (folio == null)
                return NotFound();

            var detalle = new AseguradoDetalleViewModel
            {
                Id = folio.Id,
                Folio = folio.Folio,
                Estaciones = TraducirAEstaciones(folio.EstacionActual),
            };

            return View(detalle);
        }

        // ====================================================================
        // "Base de datos" simulada del portal del Asegurado — único folio por
        // ahora (mismo valor que antes vivía hardcodeado en Asegurado.cshtml).
        // Mismo patrón que ReembolsosController.ObtenerSolicitudesSimuladas()
        // (clase, no tupla — así FirstOrDefault() puede compararse con null
        // igual que en ese método, sin la trampa de que ValueTuple no admite
        // comparación directa contra null).
        // ====================================================================
        private sealed class FolioAseguradoSimulado
        {
            public int Id { get; init; }
            public string Folio { get; init; } = string.Empty;
            public string EstacionActual { get; init; } = string.Empty;
        }

        private static List<FolioAseguradoSimulado> ObtenerFoliosAseguradoSimulados() => new()
        {
            new FolioAseguradoSimulado { Id = 1, Folio = "0000926100", EstacionActual = "Dictamen administrativo" },
        };

        private static IReadOnlyList<EstacionDetalleViewModel> TraducirAEstaciones(string estacionActual)
        {
            string[] nombres =
            {
                "Recepción de documentos",
                "Dictamen administrativo",
                "Autorización de pago",
                "Pago autorizado",
            };

            var indiceActual = ResolverIndiceEstacion(estacionActual);

            var estaciones = new List<EstacionDetalleViewModel>();
            for (var i = 0; i < nombres.Length; i++)
            {
                var numero = i + 1;
                estaciones.Add(new EstacionDetalleViewModel
                {
                    Nombre = nombres[i],
                    Estado = numero < indiceActual ? "hecho" : numero == indiceActual ? "actual" : "pendiente",
                });
            }

            return estaciones;
        }

        private static int ResolverIndiceEstacion(string estacionActual)
        {
            if (estacionActual.Contains("Recepción", StringComparison.OrdinalIgnoreCase))
                return 1;

            if (estacionActual.Contains("Autorización de pago", StringComparison.OrdinalIgnoreCase))
                return 3;

            if (estacionActual.Contains("Pago autorizado", StringComparison.OrdinalIgnoreCase))
                return 4;

            return 2;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

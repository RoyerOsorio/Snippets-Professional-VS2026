﻿using Vitamedica.Multiportal.UI.Models.Multiportal;

namespace Vitamedica.Multiportal.UI.Services
{
    public class MultiportalApiClient
    {
        private readonly HttpClient _client;

        public MultiportalApiClient(HttpClient client)
        {
            _client = client;
        }

        public async Task<UserResumeDto?> GetUserProfile(string user)
        {
            string _uri = $"GetUser/{user}";
            return await _client.GetFromJsonAsync<UserResumeDto?>(_uri);
        }
    }
}

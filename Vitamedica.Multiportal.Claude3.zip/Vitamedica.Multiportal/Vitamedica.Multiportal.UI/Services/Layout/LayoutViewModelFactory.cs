using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Vitamedica.Multiportal.UI.Models.ViewModels;
using Vitamedica.Multiportal.UI.Services.Branding;
using Vitamedica.Multiportal.UI.Services.Navigation;

namespace Vitamedica.Multiportal.UI.Services.Layout;

/// <summary>Ensambla el <see cref="LayoutViewModel"/> (branding + usuario + sidebar) por petición.</summary>
public interface ILayoutViewModelFactory
{
    LayoutViewModel Build(HttpContext httpContext, string? controller, string? action);
}

public sealed class LayoutViewModelFactory(
    IBrandingService brandingService,
    INavigationService navigationService,
    IOptions<BrandingOptions> options) : ILayoutViewModelFactory
{
    private readonly IBrandingService _branding = brandingService;
    private readonly INavigationService _navigation = navigationService;
    private readonly BrandingOptions _options = options.Value;

    public LayoutViewModel Build(HttpContext httpContext, string? controller, string? action)
    {
        return new LayoutViewModel
        {
            Branding = _branding.GetBranding(httpContext),
            CurrentUser = BuildUser(httpContext.User),
            Sidebar = _navigation.BuildSidebar(controller, action)
        };
    }

    private CurrentUserViewModel BuildUser(ClaimsPrincipal principal)
    {
        var isAuth = principal.Identity?.IsAuthenticated ?? false;
        if (!isAuth)
        {
            return new CurrentUserViewModel { IsAuthenticated = false };
        }

        var displayName =
            principal.FindFirst(ClaimTypes.GivenName)?.Value
            ?? principal.FindFirst("name")?.Value
            ?? principal.Identity?.Name
            ?? "Usuario";

        return new CurrentUserViewModel
        {
            IsAuthenticated = true,
            DisplayName = displayName,
            Initials = BuildInitials(displayName),
            Role = principal.FindFirst(ClaimTypes.Role)?.Value ?? principal.FindFirst("role")?.Value,
            CanChangePassword = _options.ShowChangePassword
        };
    }

    /// <summary>Toma las iniciales de las dos primeras palabras del nombre.</summary>
    private static string BuildInitials(string name)
    {
        var parts = name.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        return parts.Length switch
        {
            0 => "?",
            1 => parts[0][..1].ToUpperInvariant(),
            _ => (parts[0][..1] + parts[1][..1]).ToUpperInvariant()
        };
    }
}

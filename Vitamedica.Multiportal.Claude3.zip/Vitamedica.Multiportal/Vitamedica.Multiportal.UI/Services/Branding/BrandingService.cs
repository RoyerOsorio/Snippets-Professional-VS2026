using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Vitamedica.Multiportal.UI.Models.ViewModels;

namespace Vitamedica.Multiportal.UI.Services.Branding;

/// <summary>
/// Configuración de identidad institucional, enlazada desde appsettings
/// (sección "Branding"). El nombre del sistema es el valor por defecto;
/// puede resolverse dinámicamente por cliente en <see cref="BrandingService"/>.
/// </summary>
public sealed class BrandingOptions
{
    public const string SectionName = "Branding";

    /// <summary>Nombre del sistema por defecto (fallback si no se resuelve por cliente).</summary>
    public string SystemName { get; set; } = "Multiportal";
    public string CompanyName { get; set; } = "Vitamédica";
    public string LegalName { get; set; } = "Vitamédica — Administradora de Servicios de Salud";
    public string AddressLine { get; set; } = string.Empty;
    public string Version { get; set; } = "1.0.0";

    /// <summary>Controla si el menú de usuario muestra "Cambiar contraseña" (pendiente R2 — depende del SSO).</summary>
    public bool ShowChangePassword { get; set; }

    /// <summary>Mapa opcional cliente → nombre del sistema, para resolución multi-cliente por host o claim.</summary>
    public IDictionary<string, string> SystemNameByClient { get; set; } = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
}

/// <summary>Resuelve la identidad institucional de la petición actual.</summary>
public interface IBrandingService
{
    BrandingViewModel GetBranding(HttpContext httpContext);
}

/// <summary>
/// Implementación por defecto. Resuelve el nombre del sistema con la siguiente
/// prioridad: (1) claim "system_name" del usuario, (2) mapa por cliente según
/// host, (3) valor por defecto de <see cref="BrandingOptions"/>. Este es el
/// único punto que hay que tocar para lógicas multi-cliente más ricas.
/// </summary>
public sealed class BrandingService(IOptions<BrandingOptions> options) : IBrandingService
{
    private readonly BrandingOptions _options = options.Value;

    public BrandingViewModel GetBranding(HttpContext httpContext)
    {
        return new BrandingViewModel
        {
            SystemName = ResolveSystemName(httpContext),
            CompanyName = _options.CompanyName,
            LegalName = _options.LegalName,
            AddressLine = _options.AddressLine,
            Version = _options.Version,
            Year = DateTime.Now.Year
        };
    }

    private string ResolveSystemName(HttpContext httpContext)
    {
        var fromClaim = httpContext.User.FindFirst("system_name")?.Value;
        if (!string.IsNullOrWhiteSpace(fromClaim))
        {
            return fromClaim;
        }

        var host = httpContext.Request.Host.Host;
        if (!string.IsNullOrEmpty(host) &&
            _options.SystemNameByClient.TryGetValue(host, out var byClient) &&
            !string.IsNullOrWhiteSpace(byClient))
        {
            return byClient;
        }

        return _options.SystemName;
    }
}

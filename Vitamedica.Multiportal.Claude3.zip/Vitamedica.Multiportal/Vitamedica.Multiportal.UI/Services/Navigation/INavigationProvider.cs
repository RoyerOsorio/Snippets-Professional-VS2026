using Vitamedica.Multiportal.UI.Models.ViewModels;

namespace Vitamedica.Multiportal.UI.Services.Navigation;

/// <summary>
/// Fuente de la definición del menú. Se abstrae para poder sustituir el origen
/// (hoy estático en código; mañana base de datos, archivo de configuración o
/// permisos por rol) sin tocar el resto del sistema (DIP).
/// </summary>
public interface INavigationProvider
{
    /// <summary>Devuelve el árbol de navegación SIN estado activo. Debe devolver una
    /// instancia nueva en cada llamada para que el marcado por petición sea seguro.</summary>
    IReadOnlyList<MenuItemViewModel> GetMenu();
}

/// <summary>
/// Proveedor de menú estático. Contiene únicamente los módulos con evidencia
/// funcional vigente en la referencia de producción (Tablero + flujo de
/// Reembolsos). Los módulos aún sin pantallas (Proveedores, Tabuladores, Pagos
/// como módulo propio, Situación Fiscal) NO se listan todavía: se agregan aquí
/// en cuanto exista pantalla real, sin ningún otro cambio en el sistema (I3).
///
/// Para añadir un módulo nuevo: agrega un MenuItemViewModel al arreglo raíz o,
/// si tiene submódulos, define sus Children. La navegación multinivel es recursiva
/// y no requiere cambios en la vista ni en el servicio.
///
/// Ciclo 6 de Cuentas Bancarias (ver claude/DEC-CuentasBancarias-Ciclo6-Menu.md):
/// ítem propio de nivel raíz, confirmado explícitamente por el usuario
/// (AskUserQuestion) en vez de anidarlo dentro de "Configuración" — ese ítem
/// hoy es un enlace directo a Clientes/Index (sin Children), convertirlo en
/// desplegable habría sido un cambio estructural sobre navegación ya
/// existente, no solo agregar un ítem nuevo.
/// </summary>
public sealed class StaticNavigationProvider : INavigationProvider
{
    public IReadOnlyList<MenuItemViewModel> GetMenu() =>
    [
        new MenuItemViewModel
        {
            Key = "tablero",
            Text = "Tablero",
            Icon = "layout-dashboard",
            Controller = "Reembolsos",
            Action = "Index"
        },
        new MenuItemViewModel
        {
            Key = "clientes",
            Text = "Clientes",
            Icon = "users",
            Children =
            [
                new MenuItemViewModel
                {
                    Key = "cliente-gm",
                    Text = "Grupo Modelo",
                    Icon = "user",
                    Controller = "Home",
                    Action = "ReembolsoSolicitud"
                },
                new MenuItemViewModel
                {
                    Key = "cliente-aon",
                    Text = "Smurfit",
                    Icon = "user",
                    Controller = "Home",
                    Action = "PagoSolicitud"
                }
            ]
        },
        new MenuItemViewModel
        {
            Key = "configuracion",
            Text = "Configuración",
            Icon = "cog",
            Controller = "Clientes",
            Action = "Index"
        },
        new MenuItemViewModel
        {
            Key = "cuentas-bancarias",
            Text = "Cuentas Bancarias",
            Icon = "landmark",
            Controller = "CuentasBancarias",
            Action = "Index"
        },
        new MenuItemViewModel
        {
            Key = "asegurado",
            Text = "Asegurado",
            Icon = "shield-user",
            Controller = "Home",
            Action = "Asegurado"
        }
        //new MenuItemViewModel
        //{
        //    Key = "reembolsos",
        //    Text = "Reembolsos",
        //    Icon = "receipt",
        //    Children =
        //    [
        //        new MenuItemViewModel
        //        {
        //            Key = "reembolsos-nueva",
        //            Text = "Nueva solicitud",
        //            Icon = "file-plus",
        //            Controller = "Home",
        //            Action = "ReembolsoSolicitud"
        //        },
        //        new MenuItemViewModel
        //        {
        //            Key = "reembolsos-retroceder",
        //            Text = "Retroceder trámite",
        //            Icon = "undo-2",
        //            Controller = "Home",
        //            Action = "Retroceder"
        //        },
        //        new MenuItemViewModel
        //        {
        //            Key = "reembolsos-pagos",
        //            Text = "Pagos",
        //            Icon = "wallet",
        //            Controller = "Home",
        //            Action = "Pagos"
        //        },
        //        new MenuItemViewModel
        //        {
        //            Key = "reembolsos-consultar",
        //            Text = "Consultar solicitudes",
        //            Icon = "search",
        //            Controller = "Home",
        //            Action = "Consultar"
        //        }
        //    ]
        //}
    ];
}

using Vitamedica.Multiportal.UI.Models.ViewModels;

namespace Vitamedica.Multiportal.UI.Services.Navigation;

/// <summary>
/// Construye el <see cref="SidebarViewModel"/> para la petición actual,
/// resolviendo qué ítem está activo y qué ramas deben abrirse.
/// </summary>
public interface INavigationService
{
    SidebarViewModel BuildSidebar(string? currentController, string? currentAction);
}

/// <summary>
/// Implementación por defecto. Toma la definición del <see cref="INavigationProvider"/>
/// y marca el estado activo comparando Controller/Action de cada hoja con la ruta
/// actual (comparación insensible a mayúsculas). Propaga <c>HasActiveDescendant</c>
/// hacia arriba para auto-abrir la rama que contiene la pantalla activa.
/// </summary>
public sealed class NavigationService(INavigationProvider provider) : INavigationService
{
    private readonly INavigationProvider _provider = provider;

    public SidebarViewModel BuildSidebar(string? currentController, string? currentAction)
    {
        var items = _provider.GetMenu();
        foreach (var item in items)
        {
            MarkActive(item, currentController, currentAction);
        }
        return new SidebarViewModel { Items = items };
    }

    /// <summary>Marca recursivamente el árbol. Devuelve true si el ítem o alguno
    /// de sus descendientes está activo.</summary>
    private static bool MarkActive(MenuItemViewModel item, string? controller, string? action)
    {
        var anyChildActive = false;
        foreach (var child in item.Children)
        {
            anyChildActive |= MarkActive(child, controller, action);
        }

        item.HasActiveDescendant = anyChildActive;

        if (!item.IsGroup)
        {
            item.IsActive =
                !string.IsNullOrEmpty(item.Controller) &&
                string.Equals(item.Controller, controller, StringComparison.OrdinalIgnoreCase) &&
                string.Equals(item.Action, action, StringComparison.OrdinalIgnoreCase);
        }

        return item.IsActive || anyChildActive;
    }
}

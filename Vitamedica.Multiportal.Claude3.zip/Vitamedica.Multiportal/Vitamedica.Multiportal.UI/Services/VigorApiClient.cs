﻿using Vitamedica.Multiportal.UI.Models.Multiportal;

namespace Vitamedica.Multiportal.UI.Services
{
    public class VigorApiClient
    {
        private readonly HttpClient _client;

        public VigorApiClient(HttpClient client)
        {
            _client = client;
        }

        public async Task<UserResumeDto?> GetInsured(string poliza, string grupo)
        {
            string _uri = $"Asegurado?poliza={poliza}&grupo={grupo}";
            return await _client.GetFromJsonAsync<UserResumeDto?>(_uri);
        }
        public async Task<UserResumeDto?> GetInsuredList(string poliza, string grupo)
        {
            string _uri = $"Asegurados?poliza={poliza}&grupo={grupo}";
            return await _client.GetFromJsonAsync<UserResumeDto?>(_uri);
        }
    }
}

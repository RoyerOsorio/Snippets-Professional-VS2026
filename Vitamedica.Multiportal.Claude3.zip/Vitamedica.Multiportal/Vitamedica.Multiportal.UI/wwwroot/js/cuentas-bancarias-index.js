/* ============================================================================
   cuentas-bancarias-index.js — Interacciones exclusivas de
   Views/CuentasBancarias/Index.cshtml.

   Ciclo 2 (ver claude/Fase_CuentasBancariasPagos_Analizar_Proponer.md,
   sección 15): filtros (Póliza/Banco/Estado) + paginación real conectados
   vía fetch a CuentasBancariasController.Buscar — mismo patrón ya validado
   en pagos-index.js/reembolsos-index.js: core/http.js (getHtml), PartialView
   (no JSON), DOMParser + replaceWith (nunca innerHTML + concatenación).

   CuentasBancariasController.Buscar devuelve
   _ResultadosYPaginacionCuentasBancarias (tbody + pie concatenados), por lo
   que reemplazarResultados localiza y reemplaza DOS fragmentos:
   #cuerpoTablaCuentasBancarias y #pieTablaCuentasBancarias, ambos
   recalculados por Razor en el servidor.

   Implementa el contrato de estados de carga/vacío/error
   (UI_Coding_Standards.md sección 4, JavaScript_Architecture_Guide.md
   sección 5) desde este mismo ciclo (a diferencia de Pagos/Reembolsos, que
   lo agregaron en una fase posterior) — mismo mecanismo: alterna cuál de
   los 3 <tbody> hermanos (contenido/vacío ya resuelto por el servidor,
   cargando, error) queda visible en cada etapa de la búsqueda.

   Ciclo 5 (ver claude/DEC-CuentasBancarias-Ciclo5-EstadoPrincipal.md):
   Activar/Desactivar + Marcar principal. Como el <tbody> se reemplaza
   entero en cada búsqueda (reemplazarResultados), estas acciones NO pueden
   usar listeners por fila (se perderían tras cada fetch) — se manejan por
   delegación sobre .table-panel, mismo elemento ya usado para la
   paginación. Sin persistencia real (mismo criterio que
   ClientesController.CambiarEstado): el servidor solo valida, el cliente
   actualiza su propio DOM tras la respuesta exitosa — incluido el efecto
   colateral de "Marcar principal" (desmarcar las demás cuentas de la misma
   póliza), que el servidor no puede aplicar porque no mantiene estado
   entre solicitudes.
   ============================================================================ */
import { getHtml, postJson, HttpError } from "./core/http.js";
import { refreshIcons } from "./core/icons.js";

const ID_TBODY_CARGANDO = "tbodyCargandoCuentasBancarias";
const ID_TBODY_ERROR = "tbodyErrorCuentasBancarias";
const ID_TBODY_RESULTADOS = "cuerpoTablaCuentasBancarias";

document.addEventListener("DOMContentLoaded", function () {
    initFiltros();
    initAcciones();
});

function initFiltros() {
    var form = document.querySelector(".filters-form");
    var tablePanel = document.querySelector(".table-panel");
    var pageSize = document.getElementById("pageSize");
    if (!form) return;

    var btnBuscar = form.querySelector("button[type=submit]");

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        buscar(1);
    });

    form.addEventListener("reset", function () {
        // El reset nativo del formulario ocurre antes de este evento; se
        // difiere un turno para leer los campos ya restablecidos (mismo
        // patrón ya usado en pagos-index.js/reembolsos-index.js/clientes-index.js).
        setTimeout(function () { buscar(1); }, 0);
    });

    if (pageSize) {
        pageSize.addEventListener("change", function () {
            buscar(1);
        });
    }

    // Delegación de eventos: el <nav> de paginación se reemplaza por
    // completo en cada búsqueda (viene dentro de #pieTablaCuentasBancarias),
    // así que el listener se pone sobre .table-panel (que nunca se
    // reemplaza) en lugar de sobre cada <a> individual.
    if (tablePanel) {
        tablePanel.addEventListener("click", function (e) {
            var link = e.target.closest(".pagination-vm .page-link[data-pagina]");
            if (!link) return;

            e.preventDefault();

            var item = link.closest(".page-item");
            if (item && item.classList.contains("disabled")) return;

            var pagina = parseInt(link.getAttribute("data-pagina"), 10);
            if (!isNaN(pagina)) buscar(pagina);
        });
    }

    function buscar(pagina) {
        var params = new URLSearchParams();
        agregarSiTieneValor(params, "poliza", "fPoliza");
        agregarSiTieneValorDistintoDe(params, "banco", "fBanco", "Todos");
        agregarSiTieneValorDistintoDe(params, "estatus", "fEstatus", "Todos");
        params.set("pagina", pagina || 1);
        params.set("tamanioPagina", pageSize ? pageSize.value : "25");

        if (btnBuscar) btnBuscar.disabled = true;
        mostrarEstadoTabla(ID_TBODY_CARGANDO);

        getHtml("/CuentasBancarias/Buscar?" + params.toString())
            .then(function (html) {
                reemplazarResultados(html);
            })
            .catch(function (error) {
                console.error("[cuentas-bancarias-index]", error);
                // Se oculta el resultado de la búsqueda anterior en vez de
                // dejarlo visible junto al mensaje de error — mismo criterio
                // ya aprobado explícitamente para Reembolsos/Pagos.
                mostrarEstadoTabla(ID_TBODY_ERROR);
            })
            .finally(function () {
                if (btnBuscar) btnBuscar.disabled = false;
            });
    }
}

// ---- Estados de carga/vacío/error ----
// Alterna cuál de los <tbody> hermanos de la tabla queda visible. "Vacío" no
// se maneja aquí: ya llega decidido por el servidor como parte del <tbody>
// de "contenido" (ver _ResultadosCuentasBancarias.cshtml) — solo "cargando"
// y "error" son estados que este archivo controla.
function mostrarEstadoTabla(idTbodyVisible) {
    [ID_TBODY_RESULTADOS, ID_TBODY_CARGANDO, ID_TBODY_ERROR].forEach(function (id) {
        var tbody = document.getElementById(id);
        if (tbody) tbody.hidden = (id !== idTbodyVisible);
    });
}

function agregarSiTieneValor(params, nombreParametro, idCampo) {
    var campo = document.getElementById(idCampo);
    if (!campo) return;
    var valor = campo.value;
    if (valor) params.set(nombreParametro, valor);
}

function agregarSiTieneValorDistintoDe(params, nombreParametro, idCampo, valorNeutro) {
    var campo = document.getElementById(idCampo);
    if (!campo) return;
    var valor = campo.value;
    if (valor && valor !== valorNeutro) params.set(nombreParametro, valor);
}

// ---- Desactivar / Reactivar / Marcar principal (Ciclo 5) ----
// filaEnContexto/accionEnContexto: el mismo par de variables módulo-globales
// ya usado en clientes-index.js, aquí generalizado para cubrir 2 tipos de
// acción con un único modal de confirmación.
var filaEnContexto = null;
var accionEnContexto = null; // { tipo: "estado" | "principal", valor }

function initAcciones() {
    var tablePanel = document.querySelector(".table-panel");
    var modalEl = document.getElementById("modalConfirmarAccionCuentaBancaria");
    if (!tablePanel || !modalEl) return;

    // Delegación de eventos: igual que la paginación, los botones de acción
    // viven dentro del <tbody> que reemplazarResultados sustituye por
    // completo en cada búsqueda — un listener puesto directamente sobre
    // cada botón se perdería tras el primer fetch.
    tablePanel.addEventListener("click", function (e) {
        var btnEstado = e.target.closest("[data-accion-estado]");
        var btnPrincipal = !btnEstado && e.target.closest("[data-accion-principal]");

        if (btnEstado) {
            filaEnContexto = btnEstado.closest("tr");
            accionEnContexto = { tipo: "estado", valor: btnEstado.getAttribute("data-accion-estado") };

            var titular = filaEnContexto ? filaEnContexto.children[4].textContent.trim() : "esta cuenta";
            document.getElementById("textoAccionCuentaBancaria").textContent =
                "¿" + accionEnContexto.valor + " la cuenta de " + titular + "?";
            document.getElementById("textoDetalleAccionCuentaBancaria").textContent =
                accionEnContexto.valor === "Desactivar"
                    ? "Podrás reactivarla cuando lo necesites."
                    : "La cuenta volverá a aparecer como Activa en el listado.";

            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        } else if (btnPrincipal) {
            filaEnContexto = btnPrincipal.closest("tr");
            accionEnContexto = { tipo: "principal", valor: "MarcarPrincipal" };

            var poliza = filaEnContexto ? filaEnContexto.getAttribute("data-poliza") : "";
            document.getElementById("textoAccionCuentaBancaria").textContent =
                "¿Marcar esta cuenta como principal de la póliza " + poliza + "?";
            document.getElementById("textoDetalleAccionCuentaBancaria").textContent =
                "Se desmarcará cualquier otra cuenta principal de la misma póliza.";

            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        }
    });

    var btnConfirmar = document.getElementById("btnConfirmarAccionCuentaBancaria");
    if (!btnConfirmar) return;

    btnConfirmar.addEventListener("click", function () {
        if (!filaEnContexto || !accionEnContexto) {
            bootstrap.Modal.getOrCreateInstance(modalEl).hide();
            return;
        }

        var fila = filaEnContexto;
        var accion = accionEnContexto;
        btnConfirmar.disabled = true;

        var promesa = accion.tipo === "estado"
            ? confirmarCambioEstado(fila, accion.valor)
            : confirmarMarcarPrincipal(fila);

        promesa
            .then(function () {
                if (accion.tipo === "estado") {
                    aplicarCambioEstado(fila, accion.valor);
                } else {
                    aplicarMarcarPrincipal(fila);
                }
            })
            .catch(function (error) {
                console.error("[cuentas-bancarias-index]", error);
                window.alert(mensajeErrorAccion(error));
            })
            .finally(function () {
                btnConfirmar.disabled = false;
                bootstrap.Modal.getOrCreateInstance(modalEl).hide();
                filaEnContexto = null;
                accionEnContexto = null;
            });
    });
}

function obtenerTokenAntiForgery() {
    var form = document.getElementById("formCuentasBancariasIndex");
    var tokenInput = form ? form.querySelector("input[name='__RequestVerificationToken']") : null;
    return tokenInput ? tokenInput.value : "";
}

// Fase Ciclo 5 (ver DEC-CuentasBancarias-Ciclo5-EstadoPrincipal.md): valida
// en servidor (simulado, no persiste) antes de actualizar el DOM — mismo
// criterio que confirmarCambioEstado en clientes-index.js.
function confirmarCambioEstado(fila, accion) {
    var id = fila.getAttribute("data-id");
    return postJson(
        "/CuentasBancarias/CambiarEstado?id=" + encodeURIComponent(id) + "&accion=" + encodeURIComponent(accion),
        {},
        obtenerTokenAntiForgery()
    );
}

function confirmarMarcarPrincipal(fila) {
    var id = fila.getAttribute("data-id");
    return postJson(
        "/CuentasBancarias/MarcarPrincipal?id=" + encodeURIComponent(id),
        {},
        obtenerTokenAntiForgery()
    );
}

function mensajeErrorAccion(error) {
    if (error instanceof HttpError && error.body) return error.body;
    return "No se pudo actualizar la cuenta bancaria. Intenta de nuevo.";
}

function aplicarCambioEstado(fila, accion) {
    var nuevoEstado = accion === "Desactivar" ? "Inactiva" : "Activa";
    fila.setAttribute("data-estado", nuevoEstado);

    var badge = fila.querySelector("[data-badge-estado]");
    if (badge) {
        if (nuevoEstado === "Activa") {
            badge.className = "badge-status badge-status--success";
            badge.innerHTML = '<i data-lucide="check-circle" aria-hidden="true"></i> Activa';
        } else {
            badge.className = "badge-status badge-status--neutral";
            badge.innerHTML = '<i data-lucide="circle-slash" aria-hidden="true"></i> Inactiva';
        }
    }

    // Regla de negocio (sección 4 del análisis): solo una cuenta ACTIVA
    // puede estar marcada como principal. Al desactivar una cuenta que lo
    // era, se retira el badge aquí mismo — no queda una cuenta "Inactiva +
    // Principal" en el listado sin esperar a un refresco del servidor.
    var esPrincipal = fila.querySelector("[data-badge-principal]") !== null;
    if (nuevoEstado !== "Activa" && esPrincipal) {
        actualizarBadgePrincipal(fila, false);
        esPrincipal = false;
    }

    actualizarAccionesEstado(fila, nuevoEstado, esPrincipal);
    refreshIcons();
}

function aplicarMarcarPrincipal(fila) {
    var poliza = fila.getAttribute("data-poliza");

    // Efecto colateral (sección 4 del análisis: "una cuenta principal por
    // póliza") aplicado en cliente sobre las filas de la misma póliza ya
    // visibles en el DOM — ver comentario en
    // CuentasBancariasController.MarcarPrincipal sobre por qué el servidor
    // no puede aplicarlo (sin persistencia, sin estado entre solicitudes).
    document.querySelectorAll('#tablaCuentasBancarias tbody tr[data-poliza="' + poliza + '"]').forEach(function (otraFila) {
        if (otraFila === fila) return;
        actualizarBadgePrincipal(otraFila, false);
        actualizarAccionesEstado(otraFila, otraFila.getAttribute("data-estado"), false);
    });

    actualizarBadgePrincipal(fila, true);
    actualizarAccionesEstado(fila, fila.getAttribute("data-estado"), true);
    refreshIcons();
}

function actualizarBadgePrincipal(fila, esPrincipal) {
    var celda = fila.querySelector("[data-badge-principal-cell]");
    if (!celda) return;
    celda.innerHTML = esPrincipal
        ? '<span class="badge-status badge-status--warning" data-badge-principal><i data-lucide="star" aria-hidden="true"></i> Principal</span>'
        : "";
}

function actualizarAccionesEstado(fila, estado, esPrincipal) {
    var contenedor = fila.querySelector("[data-acciones-estado]");
    if (!contenedor) return;

    var botones = "";
    if (estado === "Activa" && !esPrincipal) {
        botones += '<button type="button" class="btn doc-gen-btn doc-gen-btn--secondary" data-accion-principal="MarcarPrincipal" title="Marcar como principal" aria-label="Marcar cuenta como principal"><i data-lucide="star" aria-hidden="true"></i></button>';
    }
    if (estado === "Activa") {
        botones += '<button type="button" class="btn doc-gen-btn doc-gen-btn--danger" data-accion-estado="Desactivar" title="Desactivar" aria-label="Desactivar cuenta bancaria"><i data-lucide="ban" aria-hidden="true"></i></button>';
    } else {
        botones += '<button type="button" class="btn doc-gen-btn doc-gen-btn--secondary" data-accion-estado="Reactivar" title="Reactivar" aria-label="Reactivar cuenta bancaria"><i data-lucide="rotate-ccw" aria-hidden="true"></i></button>';
    }
    contenedor.innerHTML = botones;
}

function reemplazarResultados(html) {
    var doc = new DOMParser().parseFromString(html, "text/html");

    var nuevoCuerpo = doc.getElementById(ID_TBODY_RESULTADOS);
    var cuerpoActual = document.getElementById(ID_TBODY_RESULTADOS);
    if (nuevoCuerpo && cuerpoActual) {
        cuerpoActual.replaceWith(nuevoCuerpo);
    }

    // El nuevo <tbody> (contenido o vacío, ya decidido por el servidor) queda
    // visible; cargando/error se ocultan — cubre tanto el camino normal como
    // una búsqueda exitosa que llega después de un error previo.
    mostrarEstadoTabla(ID_TBODY_RESULTADOS);

    var nuevoPie = doc.getElementById("pieTablaCuentasBancarias");
    var pieActual = document.getElementById("pieTablaCuentasBancarias");
    if (nuevoPie && pieActual) {
        pieActual.replaceWith(nuevoPie);
    }

    // Refresco de íconos Lucide vía core/icons.js.
    refreshIcons();
}

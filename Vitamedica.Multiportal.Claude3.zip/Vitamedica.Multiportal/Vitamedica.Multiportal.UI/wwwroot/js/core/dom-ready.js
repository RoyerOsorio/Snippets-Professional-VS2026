/* ============================================================================
   core/dom-ready.js

   Responsabilidad: punto único de inicialización tras DOMContentLoaded,
   con comprobación idempotente de document.readyState — relevante porque
   los scripts `type="module"` se ejecutan de forma diferida y pueden correr
   después de que DOMContentLoaded ya se disparó.

   Depende de: nada.
   Consumido por: site.js
   ============================================================================ */

export function onReady(callback) {
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", callback, { once: true });
    } else {
        callback();
    }
}

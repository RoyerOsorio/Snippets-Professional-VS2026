/* ============================================================================
   core/density-preference.js
   
   Responsabilidad: lectura y escritura de la preferencia de densidad — "density-preference.js:
   Lectura/escritura de la preferencia de densidad").

   Depende de: core/storage.js
   Consumido por: site.js
   ============================================================================ */

import { get, set, STORAGE_KEYS } from './storage.js';

function applyDensityClass(value) {
    document.body.classList.toggle("density-compact", value === "compacta");
}

function syncToggleUI(densityToggle, value) {
    if (!densityToggle) return;
    densityToggle.querySelectorAll(".density-option").forEach((btn) => {
        const active = btn.getAttribute("data-density") === value;
        btn.classList.toggle("is-active", active);
        btn.setAttribute("aria-pressed", String(active));
    });
}

function applyDensitySelection(value, densityToggle) {
    applyDensityClass(value);
    set(STORAGE_KEYS.density, value);
    syncToggleUI(densityToggle, value);
}

export function initDensityPreference() {
    const current = get(STORAGE_KEYS.density) || "comoda";

    // Restaura la densidad persistida (equivalente a applyDensity() de layout.js legado).
    applyDensityClass(current);

    const densityToggle = document.querySelector("[data-density-toggle]");
    if (!densityToggle) return;

    // Sincroniza el control visual con la preferencia ya aplicada
    // (equivalente al bloque de sincronización de header.js legado).
    syncToggleUI(densityToggle, current);

    densityToggle.addEventListener("click", (e) => {
        const btn = e.target.closest(".density-option");
        if (!btn) return;
        applyDensitySelection(btn.getAttribute("data-density"), densityToggle);
    });
}

/* ============================================================================
   core/icons.js

   Responsabilidad: refrescar los íconos Lucide (window.lucide.createIcons())
   tras insertar o modificar marcado con atributos data-lucide.

   Historia: se evaluó y se descartó en la Fase 3-B.2 (ver UI_Component_Guide.md
   sección 4, entrada revisada) porque en ese momento sus dos únicos puntos de
   uso vivían dentro de site.js mismo, no en dos archivos de página distintos
   — no cumplía el criterio de promoción (JavaScript_Architecture_Guide.md
   sección 1). Esa circunstancia cambió: reembolsos-index.js y pagos-index.js
   ya duplicaban el mismo fragmento cada uno por su cuenta, y una limpieza
   posterior (ver DEC-Limpieza-WindowVM.md) corrigió 5 archivos adicionales
   que llamaban a un window.VM.refreshIcons() nunca definido — con eso el
   criterio de promoción sí se cumple, y esos 7 archivos de página pasan a
   consumir este módulo en vez de duplicar el mismo `if`.

   Depende de: nada (vendor global window.lucide, cargado como <script>
   clásico antes de site.js — ver JavaScript_Architecture_Guide.md sección 6).
   Consumido por: site.js, reembolsos-index.js, pagos-index.js,
   cliente-form.js, clientes-index.js, detalle-asegurado.js,
   detalle-solicitud.js, reembolso-solicitud.js.
   ============================================================================ */

export function refreshIcons() {
    if (window.lucide && typeof window.lucide.createIcons === "function") {
        window.lucide.createIcons();
    }
}

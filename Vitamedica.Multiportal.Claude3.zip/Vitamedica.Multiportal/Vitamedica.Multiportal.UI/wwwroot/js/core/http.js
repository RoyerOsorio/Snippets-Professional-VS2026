/* ============================================================================
   core/http.js — capa única de comunicación con el backend (fetch).
   Contrato acordado en JavaScript_Architecture_Guide.md, sección 5. Primera
   implementación real en el proyecto (Fase 2 — filtros de Reembolsos/Index;
   ver UI_Decision_Log.md). Toda llamada de red nueva pasa por las funciones
   de este módulo — nunca fetch directo disperso en un archivo de página.
   ============================================================================ */

const JSON_HEADERS = { "Accept": "application/json" };
const HTML_HEADERS = { "Accept": "text/html" };

export async function getJson(url) {
    const response = await fetch(url, { headers: JSON_HEADERS });
    if (!response.ok) throw new HttpError(response.status, await safeText(response));
    return response.json();
}

/* Equivalente a getJson para acciones que devuelven un PartialView (HTML ya
   renderizado por Razor) en vez de JSON — ver Fase 2 (Reembolsos/Index) para
   el porqué de preferir PartialView sobre JSON en ese caso. */
export async function getHtml(url) {
    const response = await fetch(url, { headers: HTML_HEADERS });
    if (!response.ok) throw new HttpError(response.status, await safeText(response));
    return response.text();
}

export async function postJson(url, body, antiforgeryToken) {
    const response = await fetch(url, {
        method: "POST",
        headers: { ...JSON_HEADERS, "Content-Type": "application/json", "RequestVerificationToken": antiforgeryToken },
        body: JSON.stringify(body),
    });
    if (!response.ok) throw new HttpError(response.status, await safeText(response));
    return response.json();
}

/* Fase G4c (ver UI_Decision_Log.md) — equivalente a postJson para cuando
   el body debe viajar como multipart/form-data (subida de archivos, ver
   Reembolsos/SubirArchivo). No se fija "Content-Type" a mano: el navegador
   debe generar el boundary del multipart, cosa que no puede hacer si el
   header ya viene fijado desde JS. */
export async function postForm(url, formData, antiforgeryToken) {
    const response = await fetch(url, {
        method: "POST",
        headers: { "RequestVerificationToken": antiforgeryToken },
        body: formData,
    });
    if (!response.ok) throw new HttpError(response.status, await safeText(response));
    return response.json();
}

export class HttpError extends Error {
    constructor(status, body) {
        super(`HTTP ${status}`);
        this.status = status;
        this.body = body;
    }
}

async function safeText(response) {
    try { return await response.text(); } catch { return ""; }
}

/* ============================================================================
   cuenta-bancaria-form.js — Interacciones exclusivas del formulario
   compartido de Cuenta Bancaria (Views/CuentasBancarias/Partials/
   _CuentaBancariaForm.cshtml), usado por Crear (Ciclo 3) y, en el futuro
   Ciclo 4, por Detalle (edición). Sin lógica de negocio ni llamadas a datos
   reales: fase de interfaz sin persistencia — mismo patrón ya usado en
   cliente-form.js.

   Gate de Guardar: todos los campos marcados data-campo-requerido deben
   tener valor (Póliza, Cliente, Banco, Clabe de 18 dígitos, Titular). No hay
   secciones progresivas como en Cliente (un único bloque de campos) ni
   catálogos jerárquicos — formulario mucho más simple.
   ============================================================================ */
import { refreshIcons } from "./core/icons.js";
import { postJson, HttpError } from "./core/http.js";

document.addEventListener("DOMContentLoaded", function () {
    initValidacion();
    initGuardado();
    refreshIcons();
});

var CAMPOS_REQUERIDOS = ["inputPoliza", "selectCliente", "selectBanco", "inputClabe", "inputTitular"];

function campoValido(id) {
    var el = document.getElementById(id);
    if (!el) return false;
    if (id === "inputClabe") return /^[0-9]{18}$/.test(el.value || "");
    return (el.value || "").trim().length > 0;
}

function formularioValido() {
    return CAMPOS_REQUERIDOS.every(campoValido);
}

function evaluarGuardar() {
    var btn = document.getElementById("btnGuardarCuentaBancaria");
    if (btn) btn.disabled = !formularioValido();
}

function initValidacion() {
    CAMPOS_REQUERIDOS.forEach(function (id) {
        var el = document.getElementById(id);
        if (!el) return;
        el.addEventListener("input", evaluarGuardar);
        el.addEventListener("change", evaluarGuardar);
    });
    evaluarGuardar(); // estado inicial (relevante en modo Edición precargada)
}

function construirPayloadCuentaBancaria() {
    function valor(id) {
        var el = document.getElementById(id);
        return el ? el.value : null;
    }
    var esPrincipal = document.getElementById("inputEsPrincipal");

    return {
        poliza: valor("inputPoliza"),
        cliente: valor("selectCliente"),
        banco: valor("selectBanco"),
        clabe: valor("inputClabe"),
        titular: valor("inputTitular"),
        esPrincipal: esPrincipal ? esPrincipal.checked : false,
    };
}

function mensajeErrorGuardado(error) {
    if (error instanceof HttpError && error.body) return error.body;
    return "No se pudo guardar la cuenta bancaria. Intenta de nuevo.";
}

function initGuardado() {
    var form = document.getElementById("formCuentaBancaria");
    var modalEl = document.getElementById("modalCuentaBancariaGuardada");
    if (!form || !modalEl) return;

    var tokenInput = form.querySelector("input[name='__RequestVerificationToken']");
    var token = tokenInput ? tokenInput.value : "";

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        var btn = document.getElementById("btnGuardarCuentaBancaria");
        if (btn && btn.disabled) return;

        if (btn) btn.disabled = true;

        postJson("/CuentasBancarias/Guardar", construirPayloadCuentaBancaria(), token)
            .then(function () {
                bootstrap.Modal.getOrCreateInstance(modalEl).show();
            })
            .catch(function (error) {
                console.error("[cuenta-bancaria-form]", error);
                window.alert(mensajeErrorGuardado(error));
                if (btn) btn.disabled = false;
            });
    });

    var btnCerrar = document.getElementById("btnCerrarModalCuentaBancariaGuardada");
    if (btnCerrar) {
        btnCerrar.addEventListener("click", function () {
            window.location.href = btnCerrar.getAttribute("data-href") || "/";
        });
    }
}

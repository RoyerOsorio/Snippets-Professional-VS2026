/* ============================================================================
   detalle-solicitud.js — Interacciones exclusivas de Views/Reembolsos/Detalle.
   Los comportamientos genéricos (abrir/cerrar doc-block, agregar/quitar filas
   de evidencia) ya viven en reembolso-solicitud.js y se reutilizan tal cual
   desde esta vista (ver @section Scripts). Aquí solo se resuelve lo propio de
   Detalle: modal ICD/CPT, modal Histórico ICD, el switch "Procedente", y
   (Fase Dictamen-G1, ver UI_Decision_Log.md) Registrar/Rechazar trámite,
   ahora con POST real a ReembolsosController.AvanzarTramite/DevolverTramite
   — antes solo hacía window.location.href sin tocar el servidor.
   ============================================================================ */
import { refreshIcons } from "./core/icons.js";
import { postJson, HttpError } from "./core/http.js";

var HISTORICO_ICD_DEMO = [
    { folio: "0100326135", motivo: "Consulta médica", concepto: "GASTOS EN EL EXTRANJERO", dx: "Z71.9" },
    { folio: "0098214410", motivo: "Revisión anual", concepto: "CONSULTAS", dx: "Z00.0" }
];

document.addEventListener("DOMContentLoaded", function () {
    initIcdModal();
    initHistoricoIcdModal();
    initProcedenteSwitches();
    initAgregarNota();
    initRechazarTramite();
    initSiguienteDetalle();
    refreshIcons();
});

// ---- Modal ICD/CPT (botón de cabecera y badge por partida) ----
function initIcdModal() {
    var modalEl = document.getElementById("modalIcd");
    if (!modalEl) return;

    var icdInput = modalEl.querySelector("#icdCodigo");
    var icdDesc = modalEl.querySelector("#icdDescripcion");
    var cptInput = modalEl.querySelector("#cptCodigo");
    var cptDesc = modalEl.querySelector("#cptDescripcion");

    document.querySelectorAll("[data-icd-open]").forEach(function (trigger) {
        trigger.addEventListener("click", function () {
            var prefill = trigger.getAttribute("data-icd-prefill") === "true";
            if (prefill) {
                icdInput.value = "Z719";
                icdDesc.value = "CONSULTA, NO ESPECIFICADA";
                cptInput.value = "L7999FE";
                cptDesc.value = "Alergenos a Medicamentos";
            } else {
                [icdInput, icdDesc, cptInput, cptDesc].forEach(function (el) { el.value = ""; });
            }
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        });
    });

    var limpiarBtn = modalEl.querySelector("[data-icd-limpiar]");
    if (limpiarBtn) {
        limpiarBtn.addEventListener("click", function () {
            [icdInput, icdDesc, cptInput, cptDesc].forEach(function (el) { el.value = ""; });
        });
    }
}

// ---- Modal Histórico ICD ----
function initHistoricoIcdModal() {
    var modalEl = document.getElementById("modalHistoricoIcd");
    if (!modalEl) return;
    var tbody = modalEl.querySelector("[data-historico-body]");

    var trigger = document.querySelector("[data-historico-icd-open]");
    if (trigger) {
        trigger.addEventListener("click", function () {
            tbody.innerHTML = HISTORICO_ICD_DEMO.map(function (r) {
                return "<tr><td>" + r.folio + "</td><td>" + r.motivo + "</td><td>" + r.concepto + "</td><td>" + r.dx + "</td></tr>";
            }).join("");
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        });
    }
}

// ---- Switch "Procedente": habilita Observaciones solo cuando NO procede ----
function initProcedenteSwitches() {
    document.querySelectorAll("[data-procedente-switch]").forEach(function (sw) {
        var obsId = sw.getAttribute("data-procedente-switch");
        var obs = document.getElementById(obsId);
        if (!obs) return;

        function sync() { obs.disabled = sw.checked; if (sw.checked) obs.value = ""; }
        sw.addEventListener("change", sync);
        sync();

        // Fase Reclamacion-G1 (ver UI_Decision_Log.md y claude/Legacy_
        // Dictamen_Analysis.md sección 2): regla real de Legacy
        // (ActualizarConcepto/ActualizarDocumento: "Aprobado =
        // string.IsNullOrEmpty(nota)") replicada del lado del cliente — sin
        // backend de partidas que persista nada, es la única forma honesta
        // de reflejarla aquí. Escribir cualquier observación desmarca
        // "Procedente" solo; vaciarla vuelve a marcarlo.
        obs.addEventListener("input", function () {
            var hayObservacion = obs.value.trim() !== "";
            if (hayObservacion === sw.checked) {
                sw.checked = !hayObservacion;
                sync();
            }
        });
    });
}

// ---- Aside Notas del trámite: alta de nota nueva (front-end únicamente, sin backend) ----
// Inserta la nota al inicio del note-timeline ya existente y refleja el
// conteo en notes-panel-badge. Reutiliza las clases .note-item/.note-icon/
// .note-body/.note-text/.note-meta ya definidas para las notas estáticas.
// El panel ya no es un modal: está siempre visible junto al contenido.
function initAgregarNota() {
    var panelEl = document.getElementById("panelNotasDetalle");
    if (!panelEl) return;

    var input = panelEl.querySelector("#notaNuevoTexto");
    var btn = panelEl.querySelector("#btnAgregarNotaDetalle");
    var timeline = panelEl.querySelector("[data-note-timeline]");
    var badge = panelEl.querySelector(".notes-panel-badge");
    if (!input || !btn || !timeline) return;

    function agregarNota() {
        var texto = (input.value || "").trim();
        if (!texto) { input.focus(); return; }

        var li = document.createElement("li");
        li.className = "note-item";
        li.innerHTML =
            '<span class="note-icon"><i data-lucide="message-square" aria-hidden="true"></i></span>' +
            '<div class="note-body">' +
            '<p class="note-text"></p>' +
            '<span class="note-meta"></span>' +
            '<hr class="border border-secondary opacity-75">' +
            '</div>';
        li.querySelector(".note-text").textContent = texto;
        li.querySelector(".note-meta").textContent = "Dictamen administrativo · jmjimenez · " + fechaHoyCorta();
        timeline.insertBefore(li, timeline.firstChild);

        input.value = "";
        if (badge) badge.textContent = String((parseInt(badge.textContent, 10) || 0) + 1);
        refreshIcons();
    }

    btn.addEventListener("click", agregarNota);
    input.addEventListener("keydown", function (e) {
        if (e.key === "Enter") { e.preventDefault(); agregarNota(); }
    });
}

function fechaHoyCorta() {
    var d = new Date();
    return d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear();
}

// ---- Rechazar trámite: revela el campo "Motivo rechazo" en la propia
// página (sin modal todavía) — el modal aparece hasta pulsar "Siguiente". ----
function initRechazarTramite() {
    var btnRechazar = document.getElementById("btnRechazarTramite");
    var wrapper = document.getElementById("motivoRechazoWrapper");
    var input = document.getElementById("inputMotivoRechazo");
    var btnLimpiar = document.getElementById("btnLimpiarMotivoRechazo");
    if (!btnRechazar || !wrapper) return;

    btnRechazar.addEventListener("click", function () {
        wrapper.hidden = false;
        if (input) input.focus();
    });

    if (btnLimpiar && input) {
        btnLimpiar.addEventListener("click", function () {
            input.value = "";
            input.focus();
        });
    }
}

// ---- Siguiente: si "Rechazar trámite" ya se activó (campo visible),
// continúa el flujo de rechazo (Documentos a solicitar); si no, continúa
// el flujo normal de finalización (Conceptos que se pagarán). Fase
// Dictamen-G1: al aceptar cualquiera de los dos modales, ahora se hace un
// POST real (AvanzarTramite/DevolverTramite) antes de redirigir — antes
// redirigía sin tocar el servidor. Mismo criterio de simulación que
// Reembolsos/Index (Rechazar/Regresar): sin persistencia, el servidor solo
// valida; la redirección ocurre tras una respuesta exitosa. ----
function initSiguienteDetalle() {
    var btn = document.getElementById("btnRegistrarDetalle");
    var wrapperRechazo = document.getElementById("motivoRechazoWrapper");
    var inputMotivo = document.getElementById("inputMotivoRechazo");
    var modalFinalizar = document.getElementById("modalFinalizarTramite");
    var modalDocumentos = document.getElementById("modalDocumentosSolicitar");
    var vista = document.querySelector(".solicitud-view");
    var id = vista ? vista.getAttribute("data-id") : null;

    if (!btn) return;

    btn.addEventListener("click", function () {
        var rechazoActivo = !!(wrapperRechazo && !wrapperRechazo.hidden);
        var modalEl = rechazoActivo ? modalDocumentos : modalFinalizar;
        if (modalEl) bootstrap.Modal.getOrCreateInstance(modalEl).show();
    });

    ["btnAceptarFinalizarTramite", "btnAceptarDocumentosSolicitar"].forEach(function (idBoton) {
        var aceptarBtn = document.getElementById(idBoton);
        if (!aceptarBtn) return;

        aceptarBtn.addEventListener("click", function () {
            var accion = aceptarBtn.getAttribute("data-accion-dictamen"); // "Avanzar" | "Devolver"
            var href = aceptarBtn.getAttribute("data-href") || "/";
            var motivo = inputMotivo ? inputMotivo.value.trim() : "";

            if (accion === "Devolver" && motivo === "") {
                if (inputMotivo) inputMotivo.focus();
                bootstrap.Modal.getOrCreateInstance(modalDocumentos).hide();
                if (wrapperRechazo) wrapperRechazo.hidden = false;
                return;
            }

            aceptarBtn.disabled = true;
            confirmarAccionDictamen(id, accion, motivo)
                .then(function () {
                    window.location.href = href;
                })
                .catch(function (error) {
                    console.error("[detalle-solicitud]", error);
                    window.alert(mensajeErrorAccionDictamen(error));
                })
                .finally(function () {
                    aceptarBtn.disabled = false;
                });
        });
    });
}

function confirmarAccionDictamen(id, accion, motivo) {
    var form = document.getElementById("formSolicitudReembolso");
    var tokenInput = form ? form.querySelector("input[name='__RequestVerificationToken']") : null;
    var token = tokenInput ? tokenInput.value : "";
    var parametro = accion === "Devolver" ? "motivo" : "comentario";
    var url = "/Reembolsos/" + accion + "Tramite?id=" + encodeURIComponent(id) + "&" + parametro + "=" + encodeURIComponent(motivo || "");
    return postJson(url, {}, token);
}

function mensajeErrorAccionDictamen(error) {
    if (error instanceof HttpError && error.body) return error.body;
    return "No se pudo actualizar el trámite. Intenta de nuevo.";
}

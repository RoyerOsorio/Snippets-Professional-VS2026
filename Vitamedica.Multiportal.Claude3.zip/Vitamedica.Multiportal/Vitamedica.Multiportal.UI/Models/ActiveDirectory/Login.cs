﻿using System.ComponentModel.DataAnnotations;

namespace Vitamedica.Multiportal.UI.Models.ActiveDirectory
{
    public class Login
    {
        [Required(ErrorMessage = "El correo es obligatorio")]
        public string User { get; set; } = string.Empty;

        [Required(ErrorMessage = "La contraseña es obligatoria")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;

        public bool RememberMe { get; set; }
    }
}

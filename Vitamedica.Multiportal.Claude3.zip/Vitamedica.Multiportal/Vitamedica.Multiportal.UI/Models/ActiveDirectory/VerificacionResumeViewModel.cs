﻿using Vitamedica.Multiportal.UI.Models.Shared;

namespace Vitamedica.Multiportal.UI.Models.ActiveDirectory
{
    public class VerificacionResumeViewModel: MensajeViewModel
    {
        public string NombreUsuario { get; set; } = string.Empty;

        public bool EsAutenticado { get; set; }

        public bool EsBloqueado { get; set; }

        public bool ExisteUsuario { get; set; }
    }
}

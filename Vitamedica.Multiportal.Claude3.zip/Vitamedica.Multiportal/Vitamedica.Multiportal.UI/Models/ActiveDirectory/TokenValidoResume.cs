﻿namespace Vitamedica.Multiportal.UI.Models.ActiveDirectory
{
    public class TokenValidoResume : UserProfile
    {
        public bool EsTokenValido { get; set; }
    }
}

﻿//using Vitamedica.ActiveDirectory.Model.ViewModels;

using Vitamedica.Multiportal.UI.Models.Shared;

namespace Vitamedica.Multiportal.UI.Models.ActiveDirectory
{
    public class UserProfile : MensajeViewModel
    {
        public string NombreUsuario { get; set; } = string.Empty;

        public string NombreCompleto { get; set; } = string.Empty;

        public string Clave { get; set; } = string.Empty;

        public string CorreoElectronico { get; set; } = string.Empty;

        public string ApellidoPaterno { get; set; } = string.Empty;

        public string ApellidoMaterno { get; set; } = string.Empty;

        public string Nombre { get; set; } = string.Empty;

        public string MemeCk { get; set; } = string.Empty;

        public string NominaEmpleado { get; set; } = string.Empty;

        public string PrprId { get; set; } = string.Empty;

        public string RFC { get; set; } = string.Empty;

        public string GrgrCk { get; set; } = string.Empty;

        public string NombreORazonSocial { get; set; } = string.Empty;

        public int TipoUsuario { get; set; }

        public string TipoUsuarioDescripcion { get; set; } = string.Empty;
    }
}

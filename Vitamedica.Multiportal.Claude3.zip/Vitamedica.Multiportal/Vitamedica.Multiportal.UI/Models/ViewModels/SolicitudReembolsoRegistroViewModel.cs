﻿namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Fase G3 (ver UI_Decision_Log.md): payload del POST simulado de
/// ReembolsosController.Registrar. Mapea los campos con `name` que ya
/// existían en Views/Reembolsos/Crear.cshtml (AseguradoTitular.*,
/// Paciente.BeneficiarioId, Reclamacion.*).
///
/// Fase G4a: se agregó la identidad del derechohabiente seleccionado
/// (AseguradoTitular.NumeroEmpleado/Nombre/FechaInicioVigencia/
/// FechaFinVigencia/MiembroDesde) vía inputs ocultos — antes solo se
/// mostraba en <span> de solo lectura.
///
/// Explícitamente fuera de alcance (ver DEC-ReembolsosCrear-RegistrarPost.md
/// y DEC-ReembolsosCrear-G4-Roadmap.md): líneas de factura y
/// documentos/uploads — ninguno tiene hoy un campo de formulario nombrado
/// que capturar (pendiente de Fases G4b/G4c).
/// </summary>
public class SolicitudReembolsoRegistroViewModel
{
    public AseguradoTitularViewModel AseguradoTitular { get; set; } = new();
    public PacienteViewModel Paciente { get; set; } = new();
    public ReclamacionViewModel Reclamacion { get; set; } = new();
}

public class AseguradoTitularViewModel
{
    // Fase G4a (ver UI_Decision_Log.md): identidad del derechohabiente
    // seleccionado en el modal de búsqueda (antes solo se mostraba en
    // <span> de solo lectura, nunca se enviaba al servidor).
    public string? NumeroEmpleado { get; set; }
    public string? Nombre { get; set; }
    public string? FechaInicioVigencia { get; set; }
    public string? FechaFinVigencia { get; set; }
    public string? MiembroDesde { get; set; }

    public string? CorreoElectronico { get; set; }
    public string? Telefono { get; set; }
    public string? CodigoPostal { get; set; }
    public string? Estado { get; set; }
    public string? Municipio { get; set; }
    public string? FechaInicioPadecimiento { get; set; }
}

public class PacienteViewModel
{
    public string? BeneficiarioId { get; set; }
}

public class ReclamacionViewModel
{
    public IReadOnlyList<CategoriaSolicitadaViewModel> Categorias { get; set; } = new List<CategoriaSolicitadaViewModel>();
    public string? Comentarios { get; set; }
}

public class CategoriaSolicitadaViewModel
{
    public bool Solicitado { get; set; }
    public string? Motivo { get; set; }

    // Fase G4b (ver UI_Decision_Log.md): datos de factura de la categoría.
    // Cada categoría usa UNO de los dos grupos según su TipoFactura (ver
    // SolicitudReembolsoCatalogosViewModel, Fase G1) — nunca ambos:
    //
    // "estandar" (un único archivo, PDF/XML/Generar XML):
    public bool FacturaCargada { get; set; }
    public string? FacturaMetodo { get; set; }
    public string? FacturaArchivoNombre { get; set; }

    // "multimoneda" (N líneas con Moneda/Fecha, ver Gastos en el Extranjero):
    public IReadOnlyList<FacturaLineaViewModel> FacturaLineas { get; set; } = new List<FacturaLineaViewModel>();
}

public class FacturaLineaViewModel
{
    public string? ArchivoNombre { get; set; }
    public string? Moneda { get; set; }
    public string? FechaServicio { get; set; }
}

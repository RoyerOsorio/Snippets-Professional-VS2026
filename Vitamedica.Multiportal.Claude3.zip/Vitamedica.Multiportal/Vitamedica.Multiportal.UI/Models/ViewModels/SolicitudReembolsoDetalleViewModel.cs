namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Datos de encabezado de Reembolsos/Detalle para una solicitud específica
/// (Fase D, ver UI_Decision_Log.md). Alcance deliberadamente acotado: solo
/// incluye los campos que ya existían en SolicitudReembolsoResumenViewModel
/// (folio, estación/estatus, datos del paciente/beneficiario), más Monto
/// (Fase Detalle-G1, punto 4) y SaldoCoberturas (Fase Saldo-G1). El resto de
/// Detalle.cshtml (datos del asegurado titular, edad/estado/municipio,
/// reclamación/partidas, ICD/CPT, "Formato de instrucción de reembolso")
/// sigue hardcodeado — conectarlo requeriría modelar datos de dictamen que
/// no están definidos todavía (ver Fase4_Reembolsos_Detalle_Id_Analizar_
/// Proponer.md, sección 1, y claude/Legacy_Dictamen_Analysis.md).
///
/// Es exclusivo de esta vista: no reutiliza SolicitudReembolsoResumenViewModel
/// directamente, para no acoplar Detalle a cambios futuros del listado
/// (por ejemplo, si el listado agrega/quita columnas que Detalle no necesita).
/// </summary>
public class SolicitudReembolsoDetalleViewModel
{
    public int Id { get; set; }
    public string Folio { get; set; } = string.Empty;
    public string Poliza { get; set; } = string.Empty;
    public string NombreBeneficiario { get; set; } = string.Empty;
    public string Parentesco { get; set; } = string.Empty;
    public DateTime Fecha { get; set; }
    public string Estatus { get; set; } = string.Empty;
    public string EstacionActual { get; set; } = string.Empty;

    /// <summary>Monto reclamado de la solicitud (mismo dato ya visible en
    /// Reembolsos/Index — SolicitudReembolsoResumenViewModel.Monto). Fase
    /// Detalle-G1, "punto 4" (ver DEC-ReembolsosDetalle-G1-EvidenciasReales.md):
    /// único hardcode del bloque "Datos de la reclamación" resuelto en esa
    /// fase — el resto (Procedente, Observaciones, Autorizado, Conversión
    /// USD/MXN, ICD/CPT, "Conoce tu saldo") sigue bloqueado por la Regla 24
    /// (no inventar el modelo de dictamen sin definición de negocio).</summary>
    public decimal Monto { get; set; }

    /// <summary>Cobertura de la solicitud ("GMM Mayor" | "GMM Menor" | "Dental"
    /// | "Maternidad" — mismo dato ya real del listado). Fase Reclamacion-G1:
    /// reemplaza el category-chip hardcodeado ("Gastos en el extranjero", que
    /// ni siquiera es una categoría real del catálogo) en Detalle.cshtml.</summary>
    public string Cobertura { get; set; } = string.Empty;

    /// <summary>Las 4 estaciones fijas de la vista, ya traducidas a
    /// hecho/actual/pendiente a partir de EstacionActual — ver
    /// ReembolsosController.TraducirAEstaciones. Traducción de presentación,
    /// mismo criterio que el badge de Estatus en Reembolsos/Index.</summary>
    public IReadOnlyList<EstacionDetalleViewModel> Estaciones { get; set; } = new List<EstacionDetalleViewModel>();

    /// <summary>Saldo por cobertura del beneficiario de esta solicitud, para
    /// el modal "Conoce tu saldo" (Fase Saldo-G1, ver UI_Decision_Log.md y
    /// claude/Legacy_Dictamen_Analysis.md sección 4). Alcance acotado,
    /// confirmado explícitamente por el usuario: solo el beneficiario de
    /// esta solicitud (no se inventa una póliza/familia completa) y las 4
    /// categorías de Cobertura ya existentes en el proyecto (no las 9
    /// sub-coberturas granulares de Legacy).</summary>
    public IReadOnlyList<SaldoCoberturaViewModel> SaldoCoberturas { get; set; } = new List<SaldoCoberturaViewModel>();

    /// <summary>Datos del asegurado titular de la póliza (Fase Asegurado-G1,
    /// ver UI_Decision_Log.md y claude/Legacy_Dictamen_Analysis.md sección 1).
    /// Catálogo 100% simulado — confirmado explícitamente por el usuario,
    /// no existe ninguna fuente real de asegurados/póliza en el proyecto.
    /// Generado de forma determinística por ReembolsosController.
    /// ObtenerTitularSimulado — mismo criterio que otros datos simulados
    /// consistentes del proyecto (ej. SimularLecturaMontoFactura).</summary>
    public TitularSimuladoViewModel Titular { get; set; } = new();

    /// <summary>Edad del paciente/derechohabiente de esta solicitud (no del
    /// titular). Simulada, derivada de Parentesco (Fase Asegurado-G1).</summary>
    public int EdadPaciente { get; set; }

    /// <summary>Estado/Municipio del paciente. Simulados (Fase Asegurado-G1)
    /// — mismo criterio que EdadPaciente.</summary>
    public string EstadoPaciente { get; set; } = string.Empty;
    public string MunicipioPaciente { get; set; } = string.Empty;
}

/// <summary>Datos simulados del asegurado titular de la póliza, para el
/// bloque "Datos del asegurado titular" de Reembolsos/Detalle. Cuando el
/// Parentesco de la solicitud es "Titular", NombreCompleto coincide con el
/// beneficiario de la solicitud; en otro caso (Cónyuge/Hijo(a)) es una
/// persona simulada distinta — confirmado explícitamente por el usuario,
/// más fiel a una póliza familiar real que mostrar siempre a la misma
/// persona.</summary>
public class TitularSimuladoViewModel
{
    /// <summary>Igual a Poliza — en Legacy, "Número de Empleado" es
    /// literalmente el mismo valor que la póliza (confirmado por código,
    /// DetalleTramite.cshtml/VerCuenta.cshtml), no un dato distinto.</summary>
    public string NumeroEmpleado { get; set; } = string.Empty;

    public string NombreCompleto { get; set; } = string.Empty;
    public string Grupo { get; set; } = string.Empty;
    public string Correo { get; set; } = string.Empty;
    public string Telefono { get; set; } = string.Empty;
    public DateTime FechaInicioVigencia { get; set; }
    public DateTime FechaFinVigencia { get; set; }
    public DateTime MiembroDesde { get; set; }
}

/// <summary>Una fila de la tabla de saldo por cobertura (modal "Conoce tu
/// saldo"). Fórmula de Remanente confirmada contra Legacy
/// (_Acumuladores.cshtml): Asegurada − (Pagada + Reclamada), nunca negativo.</summary>
public class SaldoCoberturaViewModel
{
    public string Cobertura { get; set; } = string.Empty;
    public decimal SumaAsegurada { get; set; }
    public decimal SumaPagada { get; set; }
    public decimal SumaReclamada { get; set; }

    /// <summary>Porcentaje (ej. 0m, 10m, 20m) — mismo formato que Legacy ("0.00 %").</summary>
    public decimal Coaseguro { get; set; }

    public decimal SumaRemanente => Math.Max(0m, SumaAsegurada - (SumaPagada + SumaReclamada));
}

/// <summary>Una estación de la timeline de Reembolsos/Detalle.</summary>
public class EstacionDetalleViewModel
{
    public string Nombre { get; set; } = string.Empty;

    /// <summary>"hecho" | "actual" | "pendiente".</summary>
    public string Estado { get; set; } = string.Empty;
}

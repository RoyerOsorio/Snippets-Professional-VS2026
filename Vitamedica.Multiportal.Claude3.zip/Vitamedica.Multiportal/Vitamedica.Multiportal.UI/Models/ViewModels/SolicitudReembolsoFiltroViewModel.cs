namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Criterio de búsqueda de Reembolsos/Index (Fase 2 — filtros conectados al
/// listado simulado de Fase 1). Cada campo nulo/vacío significa "sin
/// restricción" para ese campo — mismo criterio que "Todos"/"Todas" en los
/// &lt;select&gt; de la vista, que el propio ReembolsosController traduce a
/// null antes de filtrar.
/// </summary>
public class SolicitudReembolsoFiltroViewModel
{
    // Filtros rápidos
    public string? Folio { get; set; }
    public DateTime? FechaDesde { get; set; }
    public DateTime? FechaHasta { get; set; }
    public string? Estatus { get; set; }

    // "Más filtros"
    public string? Poliza { get; set; }
    public string? Cobertura { get; set; }
    public string? Flujo { get; set; }
    public string? FolioFiscal { get; set; }
}

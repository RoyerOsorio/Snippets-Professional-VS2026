namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Catálogos simulados que necesita Reembolsos/Crear (Fase G1, ver
/// UI_Decision_Log.md): categorías de reclamación, motivos de consulta y
/// monedas. Antes vivían como arreglos anónimos hardcodeados directamente
/// en Crear.cshtml — este ViewModel es la primera vez que se materializa la
/// estructura que el propio comentario original de la vista ya anticipaba
/// ("Nombrados pensando en el futuro ViewModel").
/// </summary>
public class SolicitudReembolsoCatalogosViewModel
{
    public IReadOnlyList<CategoriaReclamacionViewModel> Categorias { get; set; } = new List<CategoriaReclamacionViewModel>();
    public IReadOnlyList<string> MotivosConsulta { get; set; } = new List<string>();
    public IReadOnlyList<MonedaViewModel> Monedas { get; set; } = new List<MonedaViewModel>();
}

/// <summary>
/// Una categoría de reclamación (Consultas, Medicamentos, Vacunas, etc.) y
/// los documentos que exige. Mismos nombres de propiedad que el tipo
/// anónimo que reemplaza, para que Crear.cshtml no necesite cambiar su
/// forma de acceso (`cat.Key`, `cat.Nombre`, `cat.Documentos`, etc.).
/// </summary>
public class CategoriaReclamacionViewModel
{
    public string Key { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public string Icono { get; set; } = string.Empty;
    public bool TieneMotivo { get; set; }

    /// <summary>"estandar" (carga de PDF/XML) o "multimoneda" (líneas de factura con Moneda/Fecha/Monto).</summary>
    public string TipoFactura { get; set; } = "estandar";

    public IReadOnlyList<DocumentoReclamacionViewModel> Documentos { get; set; } = new List<DocumentoReclamacionViewModel>();
}

public class DocumentoReclamacionViewModel
{
    public string Nombre { get; set; } = string.Empty;
    public bool Requerido { get; set; }
}

/// <summary>
/// Antes eran <option> literales sin catálogo (`USD - Dólar americano`,
/// etc.) dentro del bloque "multimoneda" de Crear.cshtml. Ningún JS del
/// proyecto lee el value de ese <select> — se preserva el mismo texto
/// visible exacto que ya existía, ahora generado desde datos.
/// </summary>
public class MonedaViewModel
{
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;

    public string Texto => $"{Codigo} - {Nombre}";
}

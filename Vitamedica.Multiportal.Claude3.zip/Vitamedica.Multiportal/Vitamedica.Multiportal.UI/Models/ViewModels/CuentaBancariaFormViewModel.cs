namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Modelo de captura del formulario de Cuenta Bancaria (Ciclo 3: alta;
/// Ciclo 4, pendiente: edición reutilizará el mismo formulario, mismo
/// criterio que ClienteViewModel/_ClienteForm.cshtml — un único partial para
/// Crear y Detalle).
///
/// Deliberadamente separado de CuentaBancariaViewModel (el modelo de fila
/// del listado): ese expone datos calculados de presentación
/// (ClabeEnmascarada) y campos de solo lectura (Cliente como texto,
/// FechaAlta/FechaModificacion) que no son parte de la captura — misma
/// distinción Resumen/Registro ya aplicada en Reembolsos
/// (SolicitudReembolsoResumenViewModel vs.
/// SolicitudReembolsoRegistroViewModel).
///
/// ClaveBanco NO se captura aquí: se resuelve en el Controller a partir del
/// nombre de Banco elegido (catálogo simulado, ver
/// CuentasBancariasController.ClavesBancoSimuladas) — el formulario no debe
/// conocer ese detalle de presentación/negocio.
/// </summary>
public class CuentaBancariaFormViewModel
{
    /// <summary>Null en alta; con valor en edición (Ciclo 4, no usado
    /// todavía) — mismo criterio que ClienteViewModel.Id.</summary>
    public int? Id { get; set; }

    public string? Poliza { get; set; }
    public string? Cliente { get; set; }
    public string? Banco { get; set; }
    public string? Clabe { get; set; }
    public string? Titular { get; set; }
    public bool EsPrincipal { get; set; }
}

namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Resultado paginado de una búsqueda en CuentasBancarias/Index (Ciclo 2).
/// Mismo patrón que PagoResultadoViewModel/SolicitudReembolsoResultadoViewModel.
/// Usado tanto por CuentasBancariasController.Index() (carga inicial, página
/// 1) como por CuentasBancariasController.Buscar() (fetch con filtros/página/
/// tamaño de página).
/// </summary>
public class CuentaBancariaResultadoViewModel
{
    /// <summary>Las cuentas de la página actual únicamente (ya paginadas), no el total.</summary>
    public IReadOnlyList<CuentaBancariaViewModel> Cuentas { get; set; } = new List<CuentaBancariaViewModel>();

    /// <summary>Página actual, 1-based. Siempre queda dentro de [1, TotalPaginas].</summary>
    public int Pagina { get; set; } = 1;

    /// <summary>Tamaño de página solicitado (10/25/50/100 en la UI actual).</summary>
    public int TamanioPagina { get; set; } = 25;

    /// <summary>Total de cuentas que cumplen el filtro aplicado (antes de paginar).</summary>
    public int TotalRegistros { get; set; }

    /// <summary>Total de páginas resultantes. Nunca menor a 1, incluso sin resultados.</summary>
    public int TotalPaginas { get; set; } = 1;
}

namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Resultado paginado de una búsqueda en Pagos/Index — la página actual de
/// pagos más los metadatos necesarios para dibujar el contador y la
/// navegación (Fase F3, ver UI_Decision_Log.md). Mismo patrón que
/// SolicitudReembolsoResultadoViewModel en Reembolsos. Usado tanto por
/// PagosController.Index() (carga inicial, página 1) como por
/// PagosController.Buscar() (fetch con filtros/página/tamaño de página).
/// </summary>
public class PagoResultadoViewModel
{
    /// <summary>Los pagos de la página actual únicamente (ya paginados), no el total.</summary>
    public IReadOnlyList<PagoResumenViewModel> Pagos { get; set; } = new List<PagoResumenViewModel>();

    /// <summary>Página actual, 1-based. Siempre queda dentro de [1, TotalPaginas].</summary>
    public int Pagina { get; set; } = 1;

    /// <summary>Tamaño de página solicitado (10/25/50/100 en la UI actual).</summary>
    public int TamanioPagina { get; set; } = 25;

    /// <summary>Total de pagos que cumplen el filtro aplicado (antes de paginar).</summary>
    public int TotalRegistros { get; set; }

    /// <summary>Total de páginas resultantes. Nunca menor a 1, incluso sin resultados.</summary>
    public int TotalPaginas { get; set; } = 1;
}

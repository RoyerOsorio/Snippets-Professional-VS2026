namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Una fila del listado de Pagos/Index.
///
/// Fase sin persistencia: los valores hoy los genera
/// PagosController.ObtenerPagosSimulados(); cuando exista un origen de datos
/// real, ese método se sustituye por un Service/ApiClient inyectado sin que
/// esta clase ni la vista necesiten cambiar. Mismo patrón ya usado en
/// SolicitudReembolsoResumenViewModel.
///
/// Fecha es DateTime (no string, como era el dato hardcodeado original) para
/// poder filtrar por rango de fechas en una fase posterior (Fase F2) — mismo
/// criterio ya aplicado a SolicitudReembolsoResumenViewModel.Fecha.
/// </summary>
public class PagoResumenViewModel
{
    public string Folio { get; set; } = string.Empty;
    public string Poliza { get; set; } = string.Empty;
    public string Titular { get; set; } = string.Empty;

    /// <summary>Categoría del gasto pagado (Consultas, Medicamentos, etc.) —
    /// determina el ícono en la vista (Views/Pagos/Index.cshtml, diccionario
    /// iconoPorMotivo, presentación pura, se queda en la vista).</summary>
    public string Motivo { get; set; } = string.Empty;

    public decimal Monto { get; set; }
    public DateTime Fecha { get; set; }

    /// <summary>Número de complemento de reembolso ya generado, o null si el
    /// pago sigue pendiente de complemento — la vista distingue ambos casos
    /// con un badge distinto.</summary>
    public string? Complemento { get; set; }
}

namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Una fila del listado de CuentasBancarias/Index.
///
/// Origen: análisis Legacy → Current (claude/Fase_CuentasBancariasPagos_
/// Analizar_Proponer.md, secciones 2 y 4). A diferencia de Legacy
/// (CuentaBancariaResumeViewModel, InicioController), este ViewModel NO
/// modela un flujo de validación por token — es un catálogo administrado
/// directamente, mismo criterio de "gestión configurable" ya confirmado por
/// el usuario. Por eso se excluyen deliberadamente: Correo (servía solo al
/// correo automático de rechazo, sin infraestructura de correo en Current),
/// RutaVoucher/IdMotivo/DescripcionRechazo (dependían del flujo de
/// aprobación por token), CargarINE/INE (módulo aparte, fuera de alcance).
///
/// Estatus simplificado a 2 valores ("Activa"/"Inactiva", mismo criterio de
/// string ya usado en ClienteViewModel.Estatus) en vez de los 4 de Legacy
/// (Aprobada/Pendiente/Rechazada/NoExiste) — esos 4 existían por el flujo de
/// validación por token que aquí no se replica.
///
/// Fase sin persistencia: los valores hoy los genera
/// CuentasBancariasController.ObtenerCuentasSimuladas(); cuando exista un
/// origen de datos real, ese método se sustituye por un Service/ApiClient
/// inyectado sin que esta clase ni la vista necesiten cambiar. Mismo patrón
/// ya usado en PagoResumenViewModel/SolicitudReembolsoResumenViewModel.
/// </summary>
public class CuentaBancariaViewModel
{
    public int Id { get; set; }

    /// <summary>Póliza del asegurado titular de la cuenta — mismo campo real
    /// que Legacy (CuentaBancariaResumeViewModel.Poliza), es la llave de
    /// relación, no un dato propio de la cuenta.</summary>
    public string Poliza { get; set; } = string.Empty;

    /// <summary>Nombre del cliente/grupo al que pertenece la póliza — dato
    /// de presentación (no viaja en Legacy, se agrega aquí porque el
    /// listado ya no está anidado bajo una sola póliza como en
    /// ValidacionCuentas.cshtml, sino que lista cuentas de varias pólizas a
    /// la vez).</summary>
    public string Cliente { get; set; } = string.Empty;

    public string Banco { get; set; } = string.Empty;
    public string ClaveBanco { get; set; } = string.Empty;

    /// <summary>18 dígitos, igual que Legacy (CuentaBancariaResumeViewModel.
    /// Clabe, [StringLength(18, MinimumLength = 18)]). No se valida dígito
    /// verificador — Legacy tampoco lo hace (PENDIENTE DE DEFINICIÓN DE
    /// NEGOCIO si se agrega, ver Fase_CuentasBancariasPagos_Analizar_
    /// Proponer.md, sección 16, punto 5).</summary>
    public string Clabe { get; set; } = string.Empty;

    /// <summary>Nombre completo del titular en un solo campo — Legacy lo
    /// captura como 3 (Nombre/ApellidoP/ApellidoM) porque los necesitaba por
    /// separado para su integración con un sistema externo de nómina, que
    /// aquí no existe (mejora justificada, ver sección 4 del análisis).</summary>
    public string Titular { get; set; } = string.Empty;

    public string Estatus { get; set; } = "Activa";

    /// <summary>Cuenta principal de esta póliza — no existe en Legacy.
    /// Justificado por Reembolsos_Contexto_Empresarial.md §18 (una póliza
    /// puede tener más de una cuenta activa; se necesita saber cuál usar por
    /// defecto). Regla de negocio: a lo más una cuenta principal por
    /// póliza — se aplica en el catálogo simulado del Controller, no aquí.</summary>
    public bool EsPrincipal { get; set; }

    public DateTime FechaAlta { get; set; }
    public DateTime? FechaModificacion { get; set; }

    /// <summary>CLABE enmascarada para presentación en listado (dato
    /// sensible) — solo se muestran los últimos 4 dígitos, mismo criterio
    /// que un número de tarjeta. Propiedad calculada, no persistida, mismo
    /// patrón que SaldoCoberturaViewModel.SumaRemanente (cálculo de
    /// presentación vive en el ViewModel, no en el Controller).</summary>
    public string ClabeEnmascarada =>
        Clabe.Length >= 4
            ? new string('•', Math.Max(0, Clabe.Length - 4)) + " " + Clabe[^4..]
            : Clabe;
}

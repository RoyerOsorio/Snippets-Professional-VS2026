namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>Árbol de navegación ya resuelto (con estado activo) para el Sidebar.</summary>
public sealed class SidebarViewModel
{
    public IReadOnlyList<MenuItemViewModel> Items { get; init; } = Array.Empty<MenuItemViewModel>();
}

/// <summary>Datos del usuario autenticado que consume el Header. La autenticación
/// la resuelve un mecanismo externo (SSO); aquí solo se proyecta lo que la UI necesita.</summary>
public sealed class CurrentUserViewModel
{
    public bool IsAuthenticated { get; init; }
    public string DisplayName { get; init; } = string.Empty;
    /// <summary>Iniciales para el avatar (1–2 caracteres).</summary>
    public string Initials { get; init; } = string.Empty;
    /// <summary>Rol/etiqueta mostrada bajo el nombre en el menú de usuario.</summary>
    public string? Role { get; init; }
    /// <summary>Muestra "Cambiar contraseña" (pendiente R2: dependerá del mecanismo SSO definitivo).</summary>
    public bool CanChangePassword { get; init; }
}

/// <summary>Identidad institucional resuelta para la petición actual. El nombre del
/// sistema es dinámico por cliente/portal; el resto alimenta el Footer.</summary>
public sealed class BrandingViewModel
{
    /// <summary>Nombre dinámico del sistema mostrado al centro del Header (ej. "Reembolsos Grupo Modelo").</summary>
    public string SystemName { get; init; } = string.Empty;
    /// <summary>Nombre corto de la empresa (marca).</summary>
    public string CompanyName { get; init; } = "Vitamédica";
    /// <summary>Razón social / nombre legal completo para el aviso de copyright.</summary>
    public string LegalName { get; init; } = string.Empty;
    /// <summary>Dirección fiscal mostrada en el Footer.</summary>
    public string AddressLine { get; init; } = string.Empty;
    /// <summary>Versión del sistema mostrada en el Footer.</summary>
    public string Version { get; init; } = string.Empty;
    /// <summary>Año para el copyright (se resuelve en tiempo de ejecución).</summary>
    public int Year { get; init; } = DateTime.UtcNow.Year;
}

/// <summary>Modelo raíz que alimenta el chrome del Layout (Header, Sidebar, Footer).
/// Se construye una sola vez por petición mediante un filtro global, de modo que
/// ningún controlador tenga que ensamblarlo manualmente.</summary>
public sealed class LayoutViewModel
{
    public BrandingViewModel Branding { get; init; } = new();
    public CurrentUserViewModel CurrentUser { get; init; } = new();
    public SidebarViewModel Sidebar { get; init; } = new();
}

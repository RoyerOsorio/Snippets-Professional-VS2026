namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Criterio de búsqueda para Pagos/Index (Fase F2, ver UI_Decision_Log.md).
/// Cada campo nulo significa "sin restricción" — mismo criterio que
/// SolicitudReembolsoFiltroViewModel. Exclusivo de esta vista, no se mezcla
/// con PagoResumenViewModel ni con PagoResultadoViewModel (paginación).
/// </summary>
public class PagoFiltroViewModel
{
    public string? Folio { get; set; }
    public DateTime? FechaDesde { get; set; }
    public DateTime? FechaHasta { get; set; }
}

namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Criterio de búsqueda para CuentasBancarias/Index (Ciclo 2, ver
/// claude/Fase_CuentasBancariasPagos_Analizar_Proponer.md, sección 4 —
/// "Filtros: Póliza/Cliente (texto), Banco (select, catálogo simulado),
/// Estado (select Activo/Inactivo)"). Cada campo nulo/vacío significa "sin
/// restricción" — mismo criterio que PagoFiltroViewModel/
/// SolicitudReembolsoFiltroViewModel.
/// </summary>
public class CuentaBancariaFiltroViewModel
{
    public string? Poliza { get; set; }
    public string? Banco { get; set; }
    public string? Estatus { get; set; }
}

namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Una fila del listado de Reembolsos/Index (Tablero de solicitudes).
///
/// Fase sin persistencia: los valores hoy los genera
/// ReembolsosController.ObtenerSolicitudesSimuladas(); cuando exista un origen
/// de datos real, ese método se sustituye por un Service/ApiClient inyectado
/// sin que esta clase ni la vista necesiten cambiar.
///
/// Cobertura/Flujo/FolioFiscal (Fase 2 — filtros): no se muestran como columna
/// en la tabla, solo alimentan los filtros de "Más filtros"; se agregaron a
/// esta fila (no a un ViewModel aparte) porque describen la misma solicitud,
/// igual criterio que el resto de campos de esta clase.
/// </summary>
public class SolicitudReembolsoResumenViewModel
{
    /// <summary>Identificador de la solicitud. Habilita el enlace a
    /// Reembolsos/Detalle/{id}; ReembolsosController.Detalle() todavía no lo
    /// consume (queda para una fase posterior).</summary>
    public int Id { get; set; }

    public string Folio { get; set; } = string.Empty;
    public string Poliza { get; set; } = string.Empty;
    public string NombreBeneficiario { get; set; } = string.Empty;
    public string Parentesco { get; set; } = string.Empty;
    public decimal Monto { get; set; }
    public DateTime Fecha { get; set; }
    public string EstacionActual { get; set; } = string.Empty;

    /// <summary>"En proceso" | "Corregido" | "Aprobado" | "Rechazado". El mapeo a
    /// clase CSS/ícono del badge es presentación pura y se resuelve en la vista.</summary>
    public string Estatus { get; set; } = string.Empty;

    /// <summary>"GMM Mayor" | "GMM Menor" | "Dental" | "Maternidad". Solo para el filtro "Cobertura".</summary>
    public string Cobertura { get; set; } = string.Empty;

    /// <summary>"Ordinario" | "Urgencia" | "Maternidad". Solo para el filtro "Flujo".</summary>
    public string Flujo { get; set; } = string.Empty;

    /// <summary>Folio fiscal (CFDI) simulado. Solo para el filtro "Folio fiscal".</summary>
    public string FolioFiscal { get; set; } = string.Empty;

    /// <summary>Nota/comentario más reciente registrado sobre la solicitud
    /// (Fase Acciones-G1, ver UI_Decision_Log.md). Cadena vacía = sin notas
    /// registradas — el modal de notas en Reembolsos/Index muestra un estado
    /// vacío en ese caso, en vez de texto hardcodeado.</summary>
    public string Nota { get; set; } = string.Empty;

    /// <summary>Autor de <see cref="Nota"/>. Vacío si Nota también lo está.</summary>
    public string AutorNota { get; set; } = string.Empty;

    /// <summary>Fecha/hora de <see cref="Nota"/>. Null si Nota está vacía.</summary>
    public DateTime? FechaNota { get; set; }
}

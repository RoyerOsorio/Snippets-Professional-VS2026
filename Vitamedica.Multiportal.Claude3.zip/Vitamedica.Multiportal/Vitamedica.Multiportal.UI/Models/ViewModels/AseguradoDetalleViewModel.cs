namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Datos de encabezado de Home/Asegurado para un folio específico (Fase
/// Asegurado-D, ver UI_Decision_Log.md) — mismo criterio que
/// SolicitudReembolsoDetalleViewModel (Fase D de Reembolsos/Detalle):
/// alcance deliberadamente acotado a folio + estaciones. El resto de
/// Asegurado.cshtml (datos del titular, derechohabiente, reclamación,
/// evidencias, notas, saldo) sigue hardcodeado en esta fase — conectarlo
/// requeriría modelar datos de dictamen que no están definidos todavía.
///
/// Es exclusivo de esta vista (no reutiliza SolicitudReembolsoDetalleViewModel
/// directamente) para no acoplar el portal del Asegurado a cambios futuros
/// del Detalle del analista — son dos audiencias distintas del mismo
/// concepto de negocio (Claim), con ciclos de evolución propios.
/// </summary>
public class AseguradoDetalleViewModel
{
    public int Id { get; set; }
    public string Folio { get; set; } = string.Empty;

    /// <summary>Reutiliza EstacionDetalleViewModel (Reembolsos/Detalle) — es
    /// la misma forma exacta de timeline de 4 estaciones, sin variación
    /// entre pantallas; no se justifica un tipo propio para esto.</summary>
    public IReadOnlyList<EstacionDetalleViewModel> Estaciones { get; set; } = new List<EstacionDetalleViewModel>();
}

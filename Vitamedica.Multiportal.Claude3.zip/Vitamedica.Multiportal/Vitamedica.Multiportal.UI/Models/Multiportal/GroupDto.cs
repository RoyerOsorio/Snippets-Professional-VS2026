﻿namespace Vitamedica.Multiportal.UI.Models.Multiportal
{
    public class GroupDto
    {
        public string Nombre { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
    }
}

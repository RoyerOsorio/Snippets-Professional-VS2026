﻿namespace Vitamedica.Multiportal.UI.Models.Shared
{
    public class MensajeViewModel
    {
        public bool EsCorrecto { get; set; }
        public string Mensaje { get; set; } = string.Empty;
        public virtual int Id { get; set; }
    }
}

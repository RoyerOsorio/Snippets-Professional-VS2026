﻿namespace Vitamedica.Multiportal.UI.Models.EndPoint
{
    public class EndPointSetting
    {
        public required string BaseUrl { get; set; } = string.Empty;
        public int TimeoutSeconds { get; set; }
    }
}

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Vitamedica.Multiportal.UI.Services.Branding;
using Vitamedica.Multiportal.UI.Services.Layout;
using Vitamedica.Multiportal.UI.Services.Navigation;

namespace Vitamedica.Multiportal.UI.Extensions;

/// <summary>
/// Registro centralizado de la infraestructura de UI (navegación, branding, layout).
/// Se invoca una sola vez desde Program.cs, manteniendo la composición de servicios
/// desacoplada y fácil de mantener.
/// </summary>
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddMultiportalUi(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<BrandingOptions>()
                .Bind(configuration.GetSection(BrandingOptions.SectionName))
                .ValidateOnStart();

        // La definición del menú no depende de la petición → singleton.
        services.AddSingleton<INavigationProvider, StaticNavigationProvider>();

        // El resto depende de HttpContext/petición → scoped.
        services.AddScoped<INavigationService, NavigationService>();
        services.AddScoped<IBrandingService, BrandingService>();
        services.AddScoped<ILayoutViewModelFactory, LayoutViewModelFactory>();

        return services;
    }
}

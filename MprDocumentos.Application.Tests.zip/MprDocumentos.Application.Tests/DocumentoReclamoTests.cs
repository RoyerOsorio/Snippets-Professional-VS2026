using FluentAssertions;
using MprDocumentos.Domain.Entidades;
using MprDocumentos.Domain.Excepciones;
using Xunit;

namespace MprDocumentos.Application.Tests;

public class DocumentoReclamoTests
{
    private static readonly DateTime Ahora = new(2026, 8, 18, 12, 0, 0, DateTimeKind.Utc);

    [Fact]
    public void Subir_devuelve_un_documento_valido_cuando_cumple_las_reglas()
    {
        var documento = DocumentoReclamo.Subir(1, 2, "factura.pdf", "application/pdf", 1024, "ruta", Ahora);

        documento.ReclamoId.Should().Be(1);
        documento.NombreOriginal.Should().Be("factura.pdf");
    }

    [Fact]
    public void Subir_lanza_excepcion_si_el_archivo_esta_vacio()
    {
        var accion = () => DocumentoReclamo.Subir(1, null, "factura.pdf", "application/pdf", 0, "ruta", Ahora);

        accion.Should().Throw<ArchivoInvalidoException>();
    }

    [Fact]
    public void Subir_lanza_excepcion_si_el_archivo_excede_el_tamano_maximo()
    {
        var accion = () => DocumentoReclamo.Subir(
            1, null, "factura.pdf", "application/pdf", (10 * 1024 * 1024) + 1, "ruta", Ahora);

        accion.Should().Throw<ArchivoInvalidoException>();
    }

    [Theory]
    [InlineData("application/pdf")]
    [InlineData("image/jpeg")]
    [InlineData("image/png")]
    public void Subir_acepta_los_tipos_de_contenido_permitidos(string tipoContenido)
    {
        var documento = DocumentoReclamo.Subir(1, null, "archivo", tipoContenido, 1024, "ruta", Ahora);

        documento.TipoContenido.Should().Be(tipoContenido);
    }

    [Fact]
    public void Subir_lanza_excepcion_si_el_tipo_de_contenido_no_esta_permitido()
    {
        var accion = () => DocumentoReclamo.Subir(1, null, "virus.exe", "application/x-msdownload", 1024, "ruta", Ahora);

        accion.Should().Throw<ArchivoInvalidoException>();
    }

    [Fact]
    public void Subir_lanza_excepcion_si_el_nombre_original_esta_vacio()
    {
        var accion = () => DocumentoReclamo.Subir(1, null, "  ", "application/pdf", 1024, "ruta", Ahora);

        accion.Should().Throw<ArchivoInvalidoException>();
    }
}

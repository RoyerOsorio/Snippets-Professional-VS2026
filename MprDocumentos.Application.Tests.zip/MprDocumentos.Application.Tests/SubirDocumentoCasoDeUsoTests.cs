using FluentAssertions;
using MprDocumentos.Application.Casos;
using MprDocumentos.Application.Puertos;
using MprDocumentos.Domain.Entidades;
using MprDocumentos.Domain.Excepciones;
using Xunit;

namespace MprDocumentos.Application.Tests;

public class SubirDocumentoCasoDeUsoTests
{
    private sealed class RepositorioFalso : IRepositorioDocumentos
    {
        private int siguienteId = 1;
        public List<DocumentoReclamo> Guardados { get; } = [];

        public Task<DocumentoReclamo?> ObtenerPorIdAsync(int documentoId, CancellationToken cancellationToken) =>
            Task.FromResult(Guardados.FirstOrDefault(d => d.Id == documentoId));

        public Task<IReadOnlyList<DocumentoReclamo>> ListarPorReclamoAsync(int reclamoId, CancellationToken cancellationToken) =>
            Task.FromResult<IReadOnlyList<DocumentoReclamo>>(Guardados.Where(d => d.ReclamoId == reclamoId).ToList());

        public Task<DocumentoReclamo> CrearAsync(DocumentoReclamo documento, CancellationToken cancellationToken)
        {
            var conId = new DocumentoReclamo(
                siguienteId++, documento.ReclamoId, documento.DocumentoRequeridoId, documento.NombreOriginal,
                documento.TipoContenido, documento.TamanoBytes, documento.RutaAlmacenamiento, documento.FechaCarga);
            Guardados.Add(conId);
            return Task.FromResult(conId);
        }

        public Task EliminarAsync(DocumentoReclamo documento, CancellationToken cancellationToken)
        {
            Guardados.RemoveAll(d => d.Id == documento.Id);
            return Task.CompletedTask;
        }
    }

    private sealed class AlmacenamientoFalso : IAlmacenamientoArchivos
    {
        public Task<string> GuardarAsync(int reclamoId, string nombreOriginal, Stream contenido, CancellationToken cancellationToken) =>
            Task.FromResult($"{reclamoId}/falso_{nombreOriginal}");

        public Task<Stream> ObtenerAsync(string ruta, CancellationToken cancellationToken) =>
            Task.FromResult<Stream>(new MemoryStream());

        public Task EliminarAsync(string ruta, CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private static readonly DateTime Ahora = new(2026, 8, 18, 12, 0, 0, DateTimeKind.Utc);

    [Fact]
    public async Task Sube_el_documento_y_persiste_su_metadata()
    {
        var casoDeUso = new SubirDocumentoCasoDeUso(new RepositorioFalso(), new AlmacenamientoFalso());

        var resultado = await casoDeUso.EjecutarAsync(
            1, null, "factura.pdf", "application/pdf", 1024, new MemoryStream(), Ahora, CancellationToken.None);

        resultado.Id.Should().BeGreaterThan(0);
        resultado.ReclamoId.Should().Be(1);
        resultado.NombreOriginal.Should().Be("factura.pdf");
    }

    [Fact]
    public async Task No_guarda_el_archivo_si_la_validacion_de_negocio_falla()
    {
        var almacenamiento = new AlmacenamientoFalso();
        var casoDeUso = new SubirDocumentoCasoDeUso(new RepositorioFalso(), almacenamiento);

        var accion = async () => await casoDeUso.EjecutarAsync(
            1, null, "virus.exe", "application/x-msdownload", 1024, new MemoryStream(), Ahora, CancellationToken.None);

        await accion.Should().ThrowAsync<ArchivoInvalidoException>();
    }
}

namespace MprDocumentos.Application.Dtos;

public sealed record DocumentoReclamoDto(
    int Id,
    int ReclamoId,
    int? DocumentoRequeridoId,
    string NombreOriginal,
    string TipoContenido,
    long TamanoBytes,
    DateTime FechaCarga);

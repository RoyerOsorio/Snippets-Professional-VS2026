using MprDocumentos.Domain.Entidades;

namespace MprDocumentos.Application.Puertos;

/// <summary>
/// Persistencia de la METADATA del documento (tabla MTP_DOC_MDOCUMENTO).
/// El contenido binario no pasa por este puerto — ver IAlmacenamientoArchivos.
/// </summary>
public interface IRepositorioDocumentos
{
    Task<DocumentoReclamo?> ObtenerPorIdAsync(int documentoId, CancellationToken cancellationToken);

    Task<IReadOnlyList<DocumentoReclamo>> ListarPorReclamoAsync(int reclamoId, CancellationToken cancellationToken);

    Task<DocumentoReclamo> CrearAsync(DocumentoReclamo documento, CancellationToken cancellationToken);

    Task EliminarAsync(DocumentoReclamo documento, CancellationToken cancellationToken);
}

namespace MprDocumentos.Application.Puertos;

/// <summary>
/// Abstracción del almacenamiento físico del contenido binario de un
/// documento. La implementación de Infrastructure para este ejercicio
/// guarda en disco local (DEMO-ONLY, PROPUESTO — ver
/// deploy/sql/MprDocumentos/README.md y UI_Decision_Log.md DEC-004);
/// la tecnología definitiva (Azure Blob Storage, S3, etc.) queda
/// PENDIENTE de decisión arquitectónica, sin asumirse aquí.
///
/// "ruta" es un identificador lógico opaco para Application — quien
/// decide su formato real es la implementación de Infrastructure.
/// </summary>
public interface IAlmacenamientoArchivos
{
    Task<string> GuardarAsync(
        int reclamoId,
        string nombreOriginal,
        Stream contenido,
        CancellationToken cancellationToken);

    Task<Stream> ObtenerAsync(string ruta, CancellationToken cancellationToken);

    Task EliminarAsync(string ruta, CancellationToken cancellationToken);
}

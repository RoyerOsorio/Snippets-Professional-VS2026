using MprDocumentos.Application.Puertos;
using MprDocumentos.Domain.Excepciones;

namespace MprDocumentos.Application.Casos;

/// <summary>
/// Elimina primero el contenido físico y luego la metadata. Si el borrado
/// del contenido falla, la metadata NO se elimina — evita quedar con un
/// registro que apunta a un archivo indeterminado. El caso inverso
/// (archivo borrado pero metadata persistida por falla posterior) es una
/// simplificación de demo aceptada (mismo criterio que SubirDocumentoCasoDeUso).
/// </summary>
public sealed class EliminarDocumentoCasoDeUso(
    IRepositorioDocumentos repositorio,
    IAlmacenamientoArchivos almacenamiento)
{
    public async Task EjecutarAsync(int documentoId, CancellationToken cancellationToken)
    {
        var documento = await repositorio.ObtenerPorIdAsync(documentoId, cancellationToken);

        if (documento is null)
        {
            throw new DocumentoNoEncontradoException($"No existe un Documento con Id {documentoId}.");
        }

        await almacenamiento.EliminarAsync(documento.RutaAlmacenamiento, cancellationToken);
        await repositorio.EliminarAsync(documento, cancellationToken);
    }
}

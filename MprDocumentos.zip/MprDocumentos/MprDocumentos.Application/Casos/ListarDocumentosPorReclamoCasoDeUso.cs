using MprDocumentos.Application.Dtos;
using MprDocumentos.Application.Puertos;

namespace MprDocumentos.Application.Casos;

public sealed class ListarDocumentosPorReclamoCasoDeUso(IRepositorioDocumentos repositorio)
{
    public async Task<IReadOnlyList<DocumentoReclamoDto>> EjecutarAsync(int reclamoId, CancellationToken cancellationToken)
    {
        var documentos = await repositorio.ListarPorReclamoAsync(reclamoId, cancellationToken);

        return documentos.Select(SubirDocumentoCasoDeUso.ADocumentoReclamoDto).ToList();
    }
}

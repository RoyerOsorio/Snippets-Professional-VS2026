using MprDocumentos.Application.Dtos;
using MprDocumentos.Application.Puertos;
using MprDocumentos.Domain.Excepciones;

namespace MprDocumentos.Application.Casos;

public sealed class ObtenerDocumentoCasoDeUso(IRepositorioDocumentos repositorio)
{
    public async Task<DocumentoReclamoDto> EjecutarAsync(int documentoId, CancellationToken cancellationToken)
    {
        var documento = await repositorio.ObtenerPorIdAsync(documentoId, cancellationToken);

        if (documento is null)
        {
            throw new DocumentoNoEncontradoException($"No existe un Documento con Id {documentoId}.");
        }

        return SubirDocumentoCasoDeUso.ADocumentoReclamoDto(documento);
    }
}

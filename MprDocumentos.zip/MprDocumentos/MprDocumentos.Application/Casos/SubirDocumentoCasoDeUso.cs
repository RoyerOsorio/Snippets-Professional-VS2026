using MprDocumentos.Application.Dtos;
using MprDocumentos.Application.Puertos;
using MprDocumentos.Domain.Entidades;

namespace MprDocumentos.Application.Casos;

/// <summary>
/// Sube un documento asociado a un Reclamo. Primero valida las reglas de
/// negocio del archivo vía DocumentoReclamo.Subir (Domain), luego guarda
/// el contenido físico (IAlmacenamientoArchivos) y por último persiste la
/// metadata (IRepositorioDocumentos) con la ruta devuelta por el
/// almacenamiento. Si falla la persistencia de metadata después de haber
/// guardado el archivo, el archivo queda huérfano — aceptado como
/// simplificación de demo (ver docs/demo/README.md sección 10;
/// idempotencia/compensación real es PENDIENTE).
/// </summary>
public sealed class SubirDocumentoCasoDeUso(
    IRepositorioDocumentos repositorio,
    IAlmacenamientoArchivos almacenamiento)
{
    public async Task<DocumentoReclamoDto> EjecutarAsync(
        int reclamoId,
        int? documentoRequeridoId,
        string nombreOriginal,
        string tipoContenido,
        long tamanoBytes,
        Stream contenido,
        DateTime fechaCarga,
        CancellationToken cancellationToken)
    {
        // Valida las reglas de negocio (tamaño, tipo, nombre) ANTES de
        // tocar el almacenamiento físico — falla rápido y sin efectos
        // secundarios cuando el archivo es inválido.
        DocumentoReclamo.Subir(
            reclamoId, documentoRequeridoId, nombreOriginal, tipoContenido, tamanoBytes,
            rutaAlmacenamiento: string.Empty, fechaCarga);

        var ruta = await almacenamiento.GuardarAsync(reclamoId, nombreOriginal, contenido, cancellationToken);

        var documento = DocumentoReclamo.Subir(
            reclamoId, documentoRequeridoId, nombreOriginal, tipoContenido, tamanoBytes, ruta, fechaCarga);

        var creado = await repositorio.CrearAsync(documento, cancellationToken);

        return ADocumentoReclamoDto(creado);
    }

    internal static DocumentoReclamoDto ADocumentoReclamoDto(DocumentoReclamo documento) => new(
        documento.Id, documento.ReclamoId, documento.DocumentoRequeridoId,
        documento.NombreOriginal, documento.TipoContenido, documento.TamanoBytes, documento.FechaCarga);
}

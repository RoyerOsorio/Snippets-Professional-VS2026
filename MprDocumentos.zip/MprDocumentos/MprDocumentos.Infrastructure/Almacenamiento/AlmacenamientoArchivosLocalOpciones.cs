namespace MprDocumentos.Infrastructure.Almacenamiento;

/// <summary>
/// Configuración del almacenamiento local de demo (sección "Almacenamiento"
/// de appsettings.json). DirectorioBase es una carpeta en el disco del
/// contenedor/host donde corre la Api — en Docker Compose se monta como
/// volumen para no perder los archivos al recrear el contenedor.
/// </summary>
public sealed class AlmacenamientoArchivosLocalOpciones
{
    public string DirectorioBase { get; set; } = "almacenamiento-documentos";
}

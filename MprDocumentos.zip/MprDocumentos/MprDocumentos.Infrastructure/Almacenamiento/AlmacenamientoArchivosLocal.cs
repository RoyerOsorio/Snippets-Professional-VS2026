using Microsoft.Extensions.Options;
using MprDocumentos.Application.Puertos;

namespace MprDocumentos.Infrastructure.Almacenamiento;

/// <summary>
/// Implementación DEMO-ONLY de IAlmacenamientoArchivos: guarda el
/// contenido en disco local, bajo DirectorioBase/{reclamoId}/{guid}_{nombre}.
///
/// PROPUESTO, no DECIDIDO: para un despliegue real con múltiples réplicas
/// del servicio, disco local no es apto (cada réplica vería un
/// subconjunto distinto de archivos) — la tecnología definitiva
/// (Azure Blob Storage, S3, un volumen compartido, etc.) es una decisión
/// de infraestructura que todavía no se ha tomado (ver sección 3 de las
/// instrucciones del proyecto y UI_Decision_Log.md DEC-004). Se eligió
/// disco local únicamente para que el ejercicio sea ejecutable de punta
/// a punta sin depender de una cuenta cloud.
///
/// El nombre de archivo original se sanea (Path.GetFileName +
/// prefijo Guid) antes de escribir a disco, para no confiar en el input
/// del cliente al construir una ruta física (ver sección 20 — seguridad
/// de manipulación de rutas / path traversal).
/// </summary>
public sealed class AlmacenamientoArchivosLocal(IOptions<AlmacenamientoArchivosLocalOpciones> opciones) : IAlmacenamientoArchivos
{
    private readonly AlmacenamientoArchivosLocalOpciones opciones = opciones.Value;

    public async Task<string> GuardarAsync(
        int reclamoId,
        string nombreOriginal,
        Stream contenido,
        CancellationToken cancellationToken)
    {
        var nombreSeguro = Path.GetFileName(nombreOriginal);
        var directorioReclamo = Path.Combine(this.opciones.DirectorioBase, reclamoId.ToString());
        Directory.CreateDirectory(directorioReclamo);

        var rutaRelativa = Path.Combine(reclamoId.ToString(), $"{Guid.NewGuid():N}_{nombreSeguro}");
        var rutaFisica = Path.Combine(this.opciones.DirectorioBase, rutaRelativa);

        await using (var destino = File.Create(rutaFisica))
        {
            await contenido.CopyToAsync(destino, cancellationToken);
        }

        // Se persiste la ruta RELATIVA (no la absoluta del host) — el
        // DirectorioBase puede diferir entre entornos (local vs contenedor).
        return rutaRelativa.Replace('\\', '/');
    }

    public Task<Stream> ObtenerAsync(string ruta, CancellationToken cancellationToken)
    {
        var rutaFisica = Path.Combine(this.opciones.DirectorioBase, ruta);
        Stream flujo = File.OpenRead(rutaFisica);

        return Task.FromResult(flujo);
    }

    public Task EliminarAsync(string ruta, CancellationToken cancellationToken)
    {
        var rutaFisica = Path.Combine(this.opciones.DirectorioBase, ruta);

        if (File.Exists(rutaFisica))
        {
            File.Delete(rutaFisica);
        }

        return Task.CompletedTask;
    }
}

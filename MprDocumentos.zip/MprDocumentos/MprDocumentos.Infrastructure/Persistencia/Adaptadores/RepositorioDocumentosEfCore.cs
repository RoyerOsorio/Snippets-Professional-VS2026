using Microsoft.EntityFrameworkCore;
using MprDocumentos.Application.Puertos;
using MprDocumentos.Domain.Entidades;
using DocumentoGenerado = MprDocumentos.Infrastructure.Persistencia.ModelosGenerados.Documento;

namespace MprDocumentos.Infrastructure.Persistencia.Adaptadores;

/// <summary>
/// Adaptador escrito a mano. Implementa el puerto IRepositorioDocumentos
/// (metadata únicamente — el contenido binario lo maneja
/// IAlmacenamientoArchivos, ver Almacenamiento/AlmacenamientoArchivosLocal).
/// </summary>
public sealed class RepositorioDocumentosEfCore(MprDocumentosDbContext dbContext) : IRepositorioDocumentos
{
    public async Task<DocumentoReclamo?> ObtenerPorIdAsync(int documentoId, CancellationToken cancellationToken)
    {
        var entidad = await dbContext.Documentos.AsNoTracking()
            .FirstOrDefaultAsync(d => d.DocuNid == documentoId, cancellationToken);

        return entidad is null ? null : AEntidadDominio(entidad);
    }

    public async Task<IReadOnlyList<DocumentoReclamo>> ListarPorReclamoAsync(int reclamoId, CancellationToken cancellationToken)
    {
        var entidades = await dbContext.Documentos.AsNoTracking()
            .Where(d => d.DocuReclamoId == reclamoId)
            .OrderBy(d => d.DocuFechaCarga)
            .ToListAsync(cancellationToken);

        return entidades.Select(AEntidadDominio).ToList();
    }

    public async Task<DocumentoReclamo> CrearAsync(DocumentoReclamo documento, CancellationToken cancellationToken)
    {
        var entidad = new DocumentoGenerado
        {
            DocuReclamoId = documento.ReclamoId,
            DocuDocumentoRequeridoId = documento.DocumentoRequeridoId,
            DocuNombreOriginal = documento.NombreOriginal,
            DocuTipoContenido = documento.TipoContenido,
            DocuTamanoBytes = documento.TamanoBytes,
            DocuRutaAlmacenamiento = documento.RutaAlmacenamiento,
            DocuFechaCarga = documento.FechaCarga,
        };

        dbContext.Documentos.Add(entidad);
        await dbContext.SaveChangesAsync(cancellationToken);

        return AEntidadDominio(entidad);
    }

    public async Task EliminarAsync(DocumentoReclamo documento, CancellationToken cancellationToken)
    {
        var entidad = await dbContext.Documentos.FirstAsync(d => d.DocuNid == documento.Id, cancellationToken);
        dbContext.Documentos.Remove(entidad);

        await dbContext.SaveChangesAsync(cancellationToken);
    }

    private static DocumentoReclamo AEntidadDominio(DocumentoGenerado entidad) => new(
        entidad.DocuNid,
        entidad.DocuReclamoId,
        entidad.DocuDocumentoRequeridoId,
        entidad.DocuNombreOriginal,
        entidad.DocuTipoContenido,
        entidad.DocuTamanoBytes,
        entidad.DocuRutaAlmacenamiento,
        entidad.DocuFechaCarga);
}

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MprDocumentos.Application.Puertos;
using MprDocumentos.Infrastructure.Almacenamiento;
using MprDocumentos.Infrastructure.Persistencia;
using MprDocumentos.Infrastructure.Persistencia.Adaptadores;

namespace MprDocumentos.Infrastructure.Extensiones;

public static class ExtensionesServiciosInfrastructure
{
    public static IServiceCollection AgregarInfrastructureMprDocumentos(
        this IServiceCollection servicios,
        IConfiguration configuracion)
    {
        servicios.AddDbContext<MprDocumentosDbContext>(opciones =>
            opciones.UseSqlServer(configuracion.GetConnectionString("MprDocumentosDb")));

        servicios.AddScoped<IRepositorioDocumentos, RepositorioDocumentosEfCore>();

        servicios.Configure<AlmacenamientoArchivosLocalOpciones>(configuracion.GetSection("Almacenamiento"));
        servicios.AddSingleton<IAlmacenamientoArchivos, AlmacenamientoArchivosLocal>();

        return servicios;
    }
}

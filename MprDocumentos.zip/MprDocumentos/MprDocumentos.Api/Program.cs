using MprDocumentos.Api.Extensiones;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddProblemDetails();
builder.Services.AddOpenApi();
builder.Services.AgregarServiciosMprDocumentos(builder.Configuration);

// Límite explícito de tamaño de subida a nivel de servidor Kestrel,
// consistente con DocumentoReclamo.TamanoMaximoBytes (Domain) — evita que
// una request muy grande consuma memoria/ancho de banda antes de llegar
// a la validación de negocio. 11 MB (10 MB + margen) para no rechazar en
// Kestrel un archivo de 10 MB exacto por overhead del multipart.
builder.Services.Configure<Microsoft.AspNetCore.Http.Features.FormOptions>(opciones =>
{
    opciones.MultipartBodyLengthLimit = 11 * 1024 * 1024;
});

builder.Services.AddHttpLogging(_ => { });

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpLogging();
app.UseExceptionHandler();

app.MapearEndpointsDocumentos();

app.MapGet("/health", () => Results.Ok(new { estado = "MprDocumentos operativo" }));

app.Run();

using MprDocumentos.Application.Casos;

namespace MprDocumentos.Api.Endpoints.Documentos;

public static class ListarDocumentosPorReclamoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapGet("/reclamos/{reclamoId:int}", ListarAsync).WithName("ListarDocumentosPorReclamo");
    }

    private static async Task<IResult> ListarAsync(
        int reclamoId,
        ListarDocumentosPorReclamoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        var documentos = await casoDeUso.EjecutarAsync(reclamoId, cancellationToken);

        return Results.Ok(documentos.Select(SubirDocumentoEndpoint.AResponse));
    }
}

using MprDocumentos.Application.Casos;
using MprDocumentos.Domain.Excepciones;

namespace MprDocumentos.Api.Endpoints.Documentos;

public static class ObtenerDocumentoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapGet("/{documentoId:int}", ObtenerAsync).WithName("ObtenerDocumento");
    }

    private static async Task<IResult> ObtenerAsync(
        int documentoId,
        ObtenerDocumentoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            var documento = await casoDeUso.EjecutarAsync(documentoId, cancellationToken);
            return Results.Ok(SubirDocumentoEndpoint.AResponse(documento));
        }
        catch (DocumentoNoEncontradoException ex)
        {
            return Results.Problem(title: "Documento no encontrado", detail: ex.Message, statusCode: StatusCodes.Status404NotFound);
        }
    }
}

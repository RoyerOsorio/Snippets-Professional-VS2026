using MprDocumentos.Application.Casos;
using MprDocumentos.Domain.Excepciones;

namespace MprDocumentos.Api.Endpoints.Documentos;

public static class EliminarDocumentoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapDelete("/{documentoId:int}", EliminarAsync).WithName("EliminarDocumento");
    }

    private static async Task<IResult> EliminarAsync(
        int documentoId,
        EliminarDocumentoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            await casoDeUso.EjecutarAsync(documentoId, cancellationToken);
            return Results.NoContent();
        }
        catch (DocumentoNoEncontradoException ex)
        {
            return Results.Problem(title: "Documento no encontrado", detail: ex.Message, statusCode: StatusCodes.Status404NotFound);
        }
    }
}

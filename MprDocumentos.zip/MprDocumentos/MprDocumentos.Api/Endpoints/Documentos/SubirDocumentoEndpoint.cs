using MprDocumentos.Application.Casos;
using MprDocumentos.Contracts.Responses;
using MprDocumentos.Domain.Excepciones;

namespace MprDocumentos.Api.Endpoints.Documentos;

/// <summary>
/// multipart/form-data — el archivo llega como IFormFile ("archivo"),
/// no como JSON. Consumido en el futuro por la UI (pantalla de carga de
/// documentos de un Reclamo, roadmap docs/demo/README.md) y potencialmente
/// por Reimbursement.Orchestrator si se agrega un paso de subida en el
/// flujo de iniciar reembolso (no incluido en el alcance actual).
/// </summary>
public static class SubirDocumentoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapPost("/reclamos/{reclamoId:int}", SubirAsync)
            .WithName("SubirDocumento")
            .DisableAntiforgery();
    }

    private static async Task<IResult> SubirAsync(
        int reclamoId,
        IFormFile archivo,
        int? documentoRequeridoId,
        SubirDocumentoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            await using var contenido = archivo.OpenReadStream();

            var documento = await casoDeUso.EjecutarAsync(
                reclamoId, documentoRequeridoId, archivo.FileName, archivo.ContentType,
                archivo.Length, contenido, DateTime.UtcNow, cancellationToken);

            return Results.Created($"/v1/documentos/{documento.Id}", AResponse(documento));
        }
        catch (ArchivoInvalidoException ex)
        {
            return Results.Problem(title: "Archivo inválido", detail: ex.Message, statusCode: StatusCodes.Status400BadRequest);
        }
    }

    internal static DocumentoResponse AResponse(Application.Dtos.DocumentoReclamoDto documento) => new(
        documento.Id, documento.ReclamoId, documento.DocumentoRequeridoId,
        documento.NombreOriginal, documento.TipoContenido, documento.TamanoBytes, documento.FechaCarga);
}

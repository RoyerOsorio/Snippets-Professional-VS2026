using MprDocumentos.Application.Casos;
using MprDocumentos.Infrastructure.Extensiones;

namespace MprDocumentos.Api.Extensiones;

public static class ExtensionesServicios
{
    public static IServiceCollection AgregarServiciosMprDocumentos(
        this IServiceCollection servicios,
        IConfiguration configuracion)
    {
        servicios.AgregarInfrastructureMprDocumentos(configuracion);

        servicios.AddScoped<SubirDocumentoCasoDeUso>();
        servicios.AddScoped<ListarDocumentosPorReclamoCasoDeUso>();
        servicios.AddScoped<ObtenerDocumentoCasoDeUso>();
        servicios.AddScoped<EliminarDocumentoCasoDeUso>();

        return servicios;
    }
}

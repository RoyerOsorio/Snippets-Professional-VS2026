using MprDocumentos.Api.Endpoints.Documentos;

namespace MprDocumentos.Api.Extensiones;

public static class ExtensionesEndpoints
{
    public static void MapearEndpointsDocumentos(this WebApplication app)
    {
        var grupo = app.MapGroup("/v1/documentos").WithTags("Documentos");

        SubirDocumentoEndpoint.Mapear(grupo);
        ListarDocumentosPorReclamoEndpoint.Mapear(grupo);
        ObtenerDocumentoEndpoint.Mapear(grupo);
        EliminarDocumentoEndpoint.Mapear(grupo);
    }
}

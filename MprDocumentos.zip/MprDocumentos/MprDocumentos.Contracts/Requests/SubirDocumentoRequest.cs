namespace MprDocumentos.Contracts.Requests;

/// <summary>
/// El binario del archivo NO viaja en este record — llega como
/// IFormFile en el propio endpoint (multipart/form-data), que es el
/// mecanismo estándar de ASP.NET Core para uploads y evita cargar el
/// archivo completo en memoria como base64 dentro de un JSON body.
/// Este record modela solo la metadata que acompaña al archivo.
/// </summary>
public sealed record SubirDocumentoRequest(int? DocumentoRequeridoId);

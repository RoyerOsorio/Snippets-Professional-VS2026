namespace MprDocumentos.Contracts.Responses;

public sealed record DocumentoResponse(
    int Id,
    int ReclamoId,
    int? DocumentoRequeridoId,
    string NombreOriginal,
    string TipoContenido,
    long TamanoBytes,
    DateTime FechaCarga);

using MprDocumentos.Domain.Excepciones;

namespace MprDocumentos.Domain.Entidades;

/// <summary>
/// Agregado de dominio: metadata de un archivo aportado para un Reclamo.
/// El contenido binario NO vive en esta entidad — vive en el almacenamiento
/// (Infrastructure, vía IAlmacenamientoArchivos); esta entidad solo conoce
/// la referencia lógica a dónde está guardado (RutaAlmacenamiento).
///
/// ReclamoId y DocumentoRequeridoId son identificadores lógicos hacia
/// MprGestionReclamos y MprConfiguracionReglas respectivamente — bounded
/// contexts distintos, sin FK física entre bases (ver UI_Decision_Log.md
/// y deploy/sql/MprDocumentos/README.md).
/// </summary>
public sealed class DocumentoReclamo
{
    private const long TamanoMaximoBytes = 10 * 1024 * 1024; // 10 MB — límite de demo, ver Domain/Excepciones/ArchivoInvalidoException.

    private static readonly HashSet<string> TiposContenidoPermitidos =
        new(StringComparer.OrdinalIgnoreCase) { "application/pdf", "image/jpeg", "image/png" };

    public int Id { get; }
    public int ReclamoId { get; }
    public int? DocumentoRequeridoId { get; }
    public string NombreOriginal { get; }
    public string TipoContenido { get; }
    public long TamanoBytes { get; }
    public string RutaAlmacenamiento { get; }
    public DateTime FechaCarga { get; }

    public DocumentoReclamo(
        int id,
        int reclamoId,
        int? documentoRequeridoId,
        string nombreOriginal,
        string tipoContenido,
        long tamanoBytes,
        string rutaAlmacenamiento,
        DateTime fechaCarga)
    {
        Id = id;
        ReclamoId = reclamoId;
        DocumentoRequeridoId = documentoRequeridoId;
        NombreOriginal = nombreOriginal;
        TipoContenido = tipoContenido;
        TamanoBytes = tamanoBytes;
        RutaAlmacenamiento = rutaAlmacenamiento;
        FechaCarga = fechaCarga;
    }

    /// <summary>
    /// Fábrica para SubirDocumento — valida las reglas de negocio del
    /// archivo (tamaño, tipo de contenido) antes de que Infrastructure
    /// intente guardarlo físicamente. El Id real lo asigna la base de
    /// datos; se usa 0 como marcador de "todavía no persistido".
    /// </summary>
    public static DocumentoReclamo Subir(
        int reclamoId,
        int? documentoRequeridoId,
        string nombreOriginal,
        string tipoContenido,
        long tamanoBytes,
        string rutaAlmacenamiento,
        DateTime fechaCarga)
    {
        if (tamanoBytes <= 0)
        {
            throw new ArchivoInvalidoException("El archivo está vacío.");
        }

        if (tamanoBytes > TamanoMaximoBytes)
        {
            throw new ArchivoInvalidoException(
                $"El archivo excede el tamaño máximo permitido de {TamanoMaximoBytes / 1024 / 1024} MB.");
        }

        if (!TiposContenidoPermitidos.Contains(tipoContenido))
        {
            throw new ArchivoInvalidoException(
                $"Tipo de contenido '{tipoContenido}' no permitido. Permitidos: {string.Join(", ", TiposContenidoPermitidos)}.");
        }

        if (string.IsNullOrWhiteSpace(nombreOriginal))
        {
            throw new ArchivoInvalidoException("El nombre del archivo es obligatorio.");
        }

        return new DocumentoReclamo(0, reclamoId, documentoRequeridoId, nombreOriginal, tipoContenido, tamanoBytes, rutaAlmacenamiento, fechaCarga);
    }
}

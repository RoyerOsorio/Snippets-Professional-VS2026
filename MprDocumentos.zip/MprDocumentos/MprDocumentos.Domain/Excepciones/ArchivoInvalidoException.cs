namespace MprDocumentos.Domain.Excepciones;

/// <summary>
/// Se lanza cuando un archivo aportado no cumple las validaciones mínimas
/// de este microservicio (tamaño máximo, tipo de contenido permitido).
/// No es una vulnerabilidad la que se valida aquí — es la regla de negocio
/// "qué se acepta como documento de un Reclamo"; la seguridad del upload
/// (nombre de archivo, ruta de almacenamiento) vive en Infrastructure.
/// </summary>
public sealed class ArchivoInvalidoException(string mensaje) : Exception(mensaje);

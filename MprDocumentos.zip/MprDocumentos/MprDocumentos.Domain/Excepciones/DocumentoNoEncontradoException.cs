namespace MprDocumentos.Domain.Excepciones;

public sealed class DocumentoNoEncontradoException(string mensaje) : Exception(mensaje);

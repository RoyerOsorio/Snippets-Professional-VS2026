using FluentAssertions;
using MprClientes.Domain.Entidades;
using Xunit;

namespace MprClientes.Application.Tests;

public class VigenciaTests
{
    [Fact]
    public void EstaVigenteEn_devuelve_true_cuando_la_fecha_esta_dentro_del_rango()
    {
        var vigencia = new Vigencia(new DateTime(2026, 1, 1), new DateTime(2026, 12, 31));

        vigencia.EstaVigenteEn(new DateTime(2026, 6, 15)).Should().BeTrue();
    }

    [Fact]
    public void EstaVigenteEn_devuelve_false_cuando_la_fecha_es_posterior_al_fin_de_vigencia()
    {
        var vigencia = new Vigencia(new DateTime(2025, 1, 1), new DateTime(2025, 12, 31));

        vigencia.EstaVigenteEn(new DateTime(2026, 1, 1)).Should().BeFalse();
    }

    [Fact]
    public void Constructor_lanza_excepcion_si_fin_es_anterior_a_inicio()
    {
        var accion = () => new Vigencia(new DateTime(2026, 12, 31), new DateTime(2026, 1, 1));

        accion.Should().Throw<ArgumentException>();
    }
}

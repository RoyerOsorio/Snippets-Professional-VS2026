using FluentAssertions;
using MprClientes.Application.Casos;
using MprClientes.Application.Puertos;
using MprClientes.Domain.Entidades;
using MprClientes.Domain.Excepciones;
using Xunit;

namespace MprClientes.Application.Tests;

public class ObtenerContextoClienteCasoDeUsoTests
{
    private sealed class RepositorioFalso(ContextoContractualCliente? resultado) : IRepositorioContextoContractual
    {
        public Task<ContextoContractualCliente?> ObtenerPorPolizaYAseguradoAsync(
            string poliza, int aseguradoId, CancellationToken cancellationToken) =>
            Task.FromResult(resultado);
    }

    [Fact]
    public async Task Lanza_ClienteNoEncontradoException_cuando_no_existe_contexto()
    {
        var casoDeUso = new ObtenerContextoClienteCasoDeUso(new RepositorioFalso(null));

        var accion = () => casoDeUso.EjecutarAsync("POL-999", 999, CancellationToken.None);

        await accion.Should().ThrowAsync<ClienteNoEncontradoException>();
    }

    [Fact]
    public async Task Devuelve_EsVigente_true_cuando_la_poliza_esta_dentro_de_vigencia()
    {
        var hoy = DateTime.UtcNow;
        var contexto = new ContextoContractualCliente(
            1, "Ana García López", "POL-001", "CERT-0001", "Titular",
            new Vigencia(hoy.AddDays(-1), hoy.AddDays(1)));

        var casoDeUso = new ObtenerContextoClienteCasoDeUso(new RepositorioFalso(contexto));

        var resultado = await casoDeUso.EjecutarAsync("POL-001", 1, CancellationToken.None);

        resultado.EsVigente.Should().BeTrue();
    }
}

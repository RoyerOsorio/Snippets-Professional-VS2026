using FluentAssertions;
using MprClientes.Domain.Entidades;
using Xunit;

namespace MprClientes.Application.Tests;

public class ContextoContractualClienteTests
{
    [Fact]
    public void EsValidoParaReembolso_es_false_si_la_poliza_no_esta_vigente()
    {
        var contexto = new ContextoContractualCliente(
            aseguradoId: 1,
            nombreCompleto: "Ana García López",
            poliza: "POL-001",
            certificado: "CERT-0001",
            rolAsegurado: "Titular",
            vigencia: new Vigencia(new DateTime(2020, 1, 1), new DateTime(2020, 12, 31)));

        contexto.EsValidoParaReembolso(DateTime.UtcNow).Should().BeFalse();
    }

    [Fact]
    public void EsValidoParaReembolso_es_true_si_la_poliza_esta_vigente()
    {
        var hoy = DateTime.UtcNow;
        var contexto = new ContextoContractualCliente(
            aseguradoId: 1,
            nombreCompleto: "Ana García López",
            poliza: "POL-001",
            certificado: "CERT-0001",
            rolAsegurado: "Titular",
            vigencia: new Vigencia(hoy.AddDays(-30), hoy.AddDays(30)));

        contexto.EsValidoParaReembolso(hoy).Should().BeTrue();
    }
}

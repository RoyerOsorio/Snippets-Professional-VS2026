using FluentAssertions;
using MprConfiguracionReglas.Domain.Entidades;
using Xunit;

namespace MprConfiguracionReglas.Application.Tests;

public class ReglaReembolsoTests
{
    private static ReglaReembolso CrearReglaConDosDocumentosObligatorios()
    {
        var documentos = new List<DocumentoRequerido>
        {
            new(1, "Factura", obligatorio: true, esFactura: true),
            new(2, "Identificación oficial", obligatorio: true, esFactura: false),
            new(3, "Comprobante de domicilio", obligatorio: false, esFactura: false),
        };

        return new ReglaReembolso(
            motivoId: 1,
            motivo: "Consulta médica ambulatoria",
            cobertura: 80m,
            coaseguro: 10m,
            deducible: 500m,
            limitePorEvento: 15000m,
            moneda: "MXN",
            esNacional: true,
            activo: true,
            documentos: documentos);
    }

    [Fact]
    public void DocumentosObligatoriosFaltantes_devuelve_vacio_cuando_se_aportan_todos_los_obligatorios()
    {
        var regla = CrearReglaConDosDocumentosObligatorios();

        var faltantes = regla.DocumentosObligatoriosFaltantes(new[] { 1, 2 });

        faltantes.Should().BeEmpty();
    }

    [Fact]
    public void DocumentosObligatoriosFaltantes_devuelve_solo_los_obligatorios_no_aportados()
    {
        var regla = CrearReglaConDosDocumentosObligatorios();

        var faltantes = regla.DocumentosObligatoriosFaltantes(new[] { 1 });

        faltantes.Should().ContainSingle(d => d.Id == 2);
    }

    [Fact]
    public void DocumentosObligatoriosFaltantes_ignora_documentos_opcionales_no_aportados()
    {
        var regla = CrearReglaConDosDocumentosObligatorios();

        var faltantes = regla.DocumentosObligatoriosFaltantes(new[] { 1, 2 });

        faltantes.Should().NotContain(d => d.Id == 3);
    }
}

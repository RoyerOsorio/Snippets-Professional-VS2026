namespace MprConfiguracionReglas.Contracts.Requests;

public sealed record ValidarDocumentosRequest(IReadOnlyList<int> DocumentosAportadosIds);

namespace MprConfiguracionReglas.Contracts.Responses;

public sealed record DocumentoRequeridoResponse(int Id, string Nombre, bool Obligatorio, bool EsFactura);

public sealed record ReglaReembolsoResponse(
    int MotivoId,
    string Motivo,
    decimal? Cobertura,
    decimal? Coaseguro,
    decimal? Deducible,
    decimal? LimitePorEvento,
    string? Moneda,
    bool EsNacional,
    bool Activo,
    IReadOnlyList<DocumentoRequeridoResponse> Documentos);

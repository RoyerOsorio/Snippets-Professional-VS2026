namespace MprConfiguracionReglas.Contracts.Responses;

public sealed record FlujoReembolsoResponse(int Id, string Nombre, bool RequiereDictamenMedico);

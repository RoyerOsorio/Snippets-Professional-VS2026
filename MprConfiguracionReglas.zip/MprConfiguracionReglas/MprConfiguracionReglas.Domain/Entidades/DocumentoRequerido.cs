namespace MprConfiguracionReglas.Domain.Entidades;

/// <summary>
/// Documento exigido por un Motivo de Reembolso, con su carácter
/// obligatorio/opcional. Corresponde a la relación MTP_MRDR_RMOTIVODOCUMENTO
/// del esquema legado.
/// </summary>
public sealed class DocumentoRequerido
{
    public int Id { get; }
    public string Nombre { get; }
    public bool Obligatorio { get; }
    public bool EsFactura { get; }

    public DocumentoRequerido(int id, string nombre, bool obligatorio, bool esFactura)
    {
        Id = id;
        Nombre = nombre;
        Obligatorio = obligatorio;
        EsFactura = esFactura;
    }
}

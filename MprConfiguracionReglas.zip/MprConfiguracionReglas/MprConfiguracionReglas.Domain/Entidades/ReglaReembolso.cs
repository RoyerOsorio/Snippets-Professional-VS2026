namespace MprConfiguracionReglas.Domain.Entidades;

/// <summary>
/// Agregado de dominio: reglas de reembolso asociadas a un Motivo
/// (cobertura, coaseguro, deducible, límite por evento) más los documentos
/// que exige. Responde la pregunta conceptual de MprConfiguracionReglas:
/// "¿con qué reglas debe procesarse el reembolso?".
///
/// La regla de negocio real que vive aquí (no en el Orchestrator ni en la
/// UI) es "¿la documentación aportada satisface los requisitos
/// obligatorios de este motivo?" — ver DocumentosObligatoriosFaltantes.
/// </summary>
public sealed class ReglaReembolso
{
    public int MotivoId { get; }
    public string Motivo { get; }
    public decimal? Cobertura { get; }
    public decimal? Coaseguro { get; }
    public decimal? Deducible { get; }
    public decimal? LimitePorEvento { get; }
    public string? Moneda { get; }
    public bool EsNacional { get; }
    public bool Activo { get; }
    public IReadOnlyList<DocumentoRequerido> Documentos { get; }

    public ReglaReembolso(
        int motivoId,
        string motivo,
        decimal? cobertura,
        decimal? coaseguro,
        decimal? deducible,
        decimal? limitePorEvento,
        string? moneda,
        bool esNacional,
        bool activo,
        IReadOnlyList<DocumentoRequerido> documentos)
    {
        MotivoId = motivoId;
        Motivo = motivo;
        Cobertura = cobertura;
        Coaseguro = coaseguro;
        Deducible = deducible;
        LimitePorEvento = limitePorEvento;
        Moneda = moneda;
        EsNacional = esNacional;
        Activo = activo;
        Documentos = documentos;
    }

    /// <summary>
    /// Determina qué documentos obligatorios de este motivo NO están
    /// cubiertos por los documentos ya aportados (identificados por su
    /// DocumentoRequerido.Id). Es la validación que MprDocumentos/UI deben
    /// consultar antes de permitir "EnviarReclamo" — la regla vive aquí
    /// porque pertenece al bounded context de configuración, no al de
    /// Documentos ni al de Reclamos.
    /// </summary>
    public IReadOnlyList<DocumentoRequerido> DocumentosObligatoriosFaltantes(IEnumerable<int> documentosAportadosIds)
    {
        var aportados = documentosAportadosIds.ToHashSet();

        return Documentos
            .Where(d => d.Obligatorio && !aportados.Contains(d.Id))
            .ToList();
    }
}

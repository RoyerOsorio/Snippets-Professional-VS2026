namespace MprConfiguracionReglas.Domain.Entidades;

/// <summary>
/// Configuración del flujo de reembolso, incluida la bandera
/// RequiereDictamenMedico (Paso 7 del ejercicio original: "Una regla de
/// MprConfiguracionReglas determina si es necesario [dictamen médico]").
///
/// Nota de alcance: el esquema entregado (MprConfiguracionReglas.txt) no
/// define una relación explícita Motivo → Flujo — MTP_FRFR_CFLUJOREEMBOLSO
/// no tiene FK hacia MTP_MRMR_CMOTIVOREEMBOLSO. Por eso este agregado se
/// consulta de forma independiente (por Id de flujo), no como parte de
/// ReglaReembolso. Si el negocio confirma que existe esa relación, se
/// agrega entonces — no se inventa aquí (ver sección 44 del gobierno del
/// proyecto: "si no tienes información, no inventes").
/// </summary>
public sealed class FlujoReembolso
{
    public int Id { get; }
    public string Nombre { get; }
    public bool RequiereDictamenMedico { get; }

    public FlujoReembolso(int id, string nombre, bool requiereDictamenMedico)
    {
        Id = id;
        Nombre = nombre;
        RequiereDictamenMedico = requiereDictamenMedico;
    }
}

namespace MprConfiguracionReglas.Domain.Excepciones;

public sealed class ReglaReembolsoNoEncontradaException(string mensaje) : Exception(mensaje);

using MprConfiguracionReglas.Application.Dtos;
using MprConfiguracionReglas.Application.Puertos;
using MprConfiguracionReglas.Domain.Excepciones;

namespace MprConfiguracionReglas.Application.Casos;

public sealed class ObtenerFlujoReembolsoCasoDeUso(IRepositorioFlujosReembolso repositorio)
{
    public async Task<FlujoReembolsoDto> EjecutarAsync(int? idFlujo, bool? dictamenMedico, CancellationToken cancellationToken)
    {
        var flujo = await repositorio.ObtenerAsync(idFlujo, dictamenMedico, cancellationToken);

        if (flujo is null)
        {
            throw new ReglaReembolsoNoEncontradaException(
                $"No existe un flujo con idFlujo={idFlujo} o dictamenMedico={dictamenMedico}.");
        }

        return new FlujoReembolsoDto(flujo.Id, flujo.Nombre, flujo.RequiereDictamenMedico);
    }
}

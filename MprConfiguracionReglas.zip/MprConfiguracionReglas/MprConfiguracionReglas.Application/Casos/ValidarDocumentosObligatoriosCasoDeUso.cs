using MprConfiguracionReglas.Application.Dtos;
using MprConfiguracionReglas.Application.Puertos;
using MprConfiguracionReglas.Domain.Excepciones;

namespace MprConfiguracionReglas.Application.Casos;

/// <summary>
/// Expone la regla de dominio ReglaReembolso.DocumentosObligatoriosFaltantes
/// como caso de uso — consumido antes de permitir "EnviarReclamo" (Paso 5
/// del ejercicio original).
/// </summary>
public sealed class ValidarDocumentosObligatoriosCasoDeUso(IRepositorioReglasReembolso repositorio)
{
    public async Task<IReadOnlyList<DocumentoRequeridoDto>> EjecutarAsync(
        int motivoId,
        IReadOnlyList<int> documentosAportadosIds,
        CancellationToken cancellationToken)
    {
        var regla = await repositorio.ObtenerPorMotivoAsync(motivoId, cancellationToken);

        if (regla is null)
        {
            throw new ReglaReembolsoNoEncontradaException($"No existe una regla de reembolso con motivo {motivoId}.");
        }

        return regla.DocumentosObligatoriosFaltantes(documentosAportadosIds)
            .Select(d => new DocumentoRequeridoDto(d.Id, d.Nombre, d.Obligatorio, d.EsFactura))
            .ToList();
    }
}

using MprConfiguracionReglas.Application.Dtos;
using MprConfiguracionReglas.Application.Puertos;
using MprConfiguracionReglas.Domain.Excepciones;

namespace MprConfiguracionReglas.Application.Casos;

/// <summary>
/// Consultado por Reimbursement.Orchestrator en el Paso 2 ("obtener reglas,
/// obtener documentos requeridos") y por la UI para mostrar qué documentos
/// pide un motivo de reembolso.
/// </summary>
public sealed class ObtenerReglaReembolsoCasoDeUso(IRepositorioReglasReembolso repositorio)
{
    public async Task<ReglaReembolsoDto> EjecutarAsync(int motivoId, CancellationToken cancellationToken)
    {
        var regla = await repositorio.ObtenerPorMotivoAsync(motivoId, cancellationToken);

        if (regla is null)
        {
            throw new ReglaReembolsoNoEncontradaException($"No existe una regla de reembolso con motivo {motivoId}.");
        }

        return new ReglaReembolsoDto(
            regla.MotivoId,
            regla.Motivo,
            regla.Cobertura,
            regla.Coaseguro,
            regla.Deducible,
            regla.LimitePorEvento,
            regla.Moneda,
            regla.EsNacional,
            regla.Activo,
            regla.Documentos.Select(d => new DocumentoRequeridoDto(d.Id, d.Nombre, d.Obligatorio, d.EsFactura)).ToList());
    }
}

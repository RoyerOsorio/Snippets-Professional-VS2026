namespace MprConfiguracionReglas.Application.Dtos;

public sealed record DocumentoRequeridoDto(int Id, string Nombre, bool Obligatorio, bool EsFactura);

public sealed record ReglaReembolsoDto(
    int MotivoId,
    string Motivo,
    decimal? Cobertura,
    decimal? Coaseguro,
    decimal? Deducible,
    decimal? LimitePorEvento,
    string? Moneda,
    bool EsNacional,
    bool Activo,
    IReadOnlyList<DocumentoRequeridoDto> Documentos);

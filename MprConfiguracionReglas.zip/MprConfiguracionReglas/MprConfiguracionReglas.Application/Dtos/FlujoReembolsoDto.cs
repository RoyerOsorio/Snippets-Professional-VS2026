namespace MprConfiguracionReglas.Application.Dtos;

public sealed record FlujoReembolsoDto(int Id, string Nombre, bool RequiereDictamenMedico);

using MprConfiguracionReglas.Domain.Entidades;

namespace MprConfiguracionReglas.Application.Puertos;

public interface IRepositorioReglasReembolso
{
    Task<ReglaReembolso?> ObtenerPorMotivoAsync(int motivoId, CancellationToken cancellationToken);
}

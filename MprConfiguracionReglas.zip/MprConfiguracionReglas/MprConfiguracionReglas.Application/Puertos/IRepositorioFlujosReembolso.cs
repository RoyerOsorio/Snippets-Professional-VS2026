using MprConfiguracionReglas.Domain.Entidades;

namespace MprConfiguracionReglas.Application.Puertos;

public interface IRepositorioFlujosReembolso
{
    Task<FlujoReembolso?> ObtenerAsync(int? idFlujo, bool? dictamenMedico, CancellationToken cancellationToken);
}

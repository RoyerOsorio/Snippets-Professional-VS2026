using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MprConfiguracionReglas.Application.Puertos;
using MprConfiguracionReglas.Infrastructure.Persistencia;
using MprConfiguracionReglas.Infrastructure.Persistencia.Adaptadores;

namespace MprConfiguracionReglas.Infrastructure.Extensiones;

/// <summary>
/// Único punto de registro de Infrastructure. Se invoca una sola vez desde
/// Program.cs, siguiendo el mismo patrón ya usado en MprClientes.Infrastructure.
/// </summary>
public static class ExtensionesServiciosInfrastructure
{
    public static IServiceCollection AgregarInfrastructureMprConfiguracionReglas(
        this IServiceCollection servicios,
        IConfiguration configuracion)
    {
        servicios.AddDbContext<MprConfiguracionReglasDbContext>(opciones =>
            opciones.UseSqlServer(configuracion.GetConnectionString("MprConfiguracionReglasDb")));

        servicios.AddScoped<IRepositorioReglasReembolso, RepositorioReglasReembolsoEfCore>();
        servicios.AddScoped<IRepositorioFlujosReembolso, RepositorioFlujosReembolsoEfCore>();

        return servicios;
    }
}

using Microsoft.EntityFrameworkCore;
using MprConfiguracionReglas.Application.Puertos;
using MprConfiguracionReglas.Domain.Entidades;

namespace MprConfiguracionReglas.Infrastructure.Persistencia.Adaptadores;

/// <summary>
/// Adaptador escrito a mano (no generado). Implementa el puerto
/// IRepositorioFlujosReembolso. Consulta MTP_FRFR_CFLUJOREEMBOLSO de forma
/// independiente (sin relación con MotivoReembolso) — ver nota de alcance
/// en MprConfiguracionReglas.Domain.Entidades.FlujoReembolso.
/// </summary>
public sealed class RepositorioFlujosReembolsoEfCore(MprConfiguracionReglasDbContext dbContext) : IRepositorioFlujosReembolso
{
    public async Task<FlujoReembolso?> ObtenerAsync(int? idFlujo, bool? dictamenMedico, CancellationToken cancellationToken)
    {
        var consulta = dbContext.FlujosReembolso.AsNoTracking().AsQueryable();

        if (idFlujo is not null)
        {
            consulta = consulta.Where(f => f.FrfrNid == idFlujo.Value);
        }

        if (dictamenMedico is not null)
        {
            consulta = consulta.Where(f => f.FrfrDicmedico == dictamenMedico.Value);
        }

        var flujo = await consulta.FirstOrDefaultAsync(cancellationToken);

        return flujo is null
            ? null
            : new FlujoReembolso(flujo.FrfrNid, flujo.FrfrFlujo, flujo.FrfrDicmedico);
    }
}

using Microsoft.EntityFrameworkCore;
using MprConfiguracionReglas.Application.Puertos;
using MprConfiguracionReglas.Domain.Entidades;

namespace MprConfiguracionReglas.Infrastructure.Persistencia.Adaptadores;

/// <summary>
/// Adaptador escrito a mano (no generado). Implementa el puerto
/// IRepositorioReglasReembolso reconstruyendo el agregado de dominio
/// ReglaReembolso a partir de los modelos generados por scaffold
/// (MotivoReembolso + su colección MotivoDocumento → DocumentoRequerido).
/// </summary>
public sealed class RepositorioReglasReembolsoEfCore(MprConfiguracionReglasDbContext dbContext) : IRepositorioReglasReembolso
{
    public async Task<ReglaReembolso?> ObtenerPorMotivoAsync(int motivoId, CancellationToken cancellationToken)
    {
        var motivo = await dbContext.MotivosReembolso
            .AsNoTracking()
            .Include(m => m.Documentos)
            .ThenInclude(md => md.Documento)
            .FirstOrDefaultAsync(m => m.MrmrNid == motivoId, cancellationToken);

        if (motivo is null)
        {
            return null;
        }

        var documentos = motivo.Documentos
            .Select(md => new DocumentoRequerido(
                md.Documento.DrdrNid,
                md.Documento.DrdrDocumento,
                md.MrdrObligatorio,
                md.Documento.DrdrEsfactura))
            .ToList();

        return new ReglaReembolso(
            motivo.MrmrNid,
            motivo.MrmrMotivo,
            motivo.MrmrCobertura,
            motivo.MrmrCoaseguro,
            motivo.MrmrDeducible,
            motivo.MrmrLimitexevento,
            motivo.MrmrMoneda,
            motivo.MrmrEsnacional ?? false,
            motivo.MrmrActivo ?? false,
            documentos);
    }
}

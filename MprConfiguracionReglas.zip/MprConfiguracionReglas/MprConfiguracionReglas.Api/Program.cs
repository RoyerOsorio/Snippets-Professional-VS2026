using MprConfiguracionReglas.Api.Extensiones;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddProblemDetails();
builder.Services.AddOpenApi();
builder.Services.AgregarServiciosMprConfiguracionReglas(builder.Configuration);

// Observabilidad mínima, igual criterio que MprClientes.Api: se deja el
// enganche de HttpLogging listo, sin acoplarse a un backend de tracing
// concreto (decisión de infraestructura todavía pendiente).
builder.Services.AddHttpLogging(_ => { });

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpLogging();
app.UseExceptionHandler();

app.MapearEndpointsReglas();

app.MapGet("/health", () => Results.Ok(new { estado = "MprConfiguracionReglas operativo" }));

app.Run();

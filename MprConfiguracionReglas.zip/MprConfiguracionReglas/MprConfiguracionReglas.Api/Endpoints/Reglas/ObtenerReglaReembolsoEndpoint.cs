using MprConfiguracionReglas.Application.Casos;
using MprConfiguracionReglas.Contracts.Responses;
using MprConfiguracionReglas.Domain.Excepciones;

namespace MprConfiguracionReglas.Api.Endpoints.Reglas;

/// <summary>
/// Endpoint consumido por Reimbursement.Orchestrator en el Paso 2
/// ("obtener reglas, obtener documentos requeridos") y por la UI para
/// mostrar qué documentos exige un motivo de reembolso.
/// </summary>
public static class ObtenerReglaReembolsoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapGet("/{motivoId:int}", ObtenerAsync).WithName("ObtenerReglaReembolso");
    }

    private static async Task<IResult> ObtenerAsync(
        int motivoId,
        ObtenerReglaReembolsoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            var regla = await casoDeUso.EjecutarAsync(motivoId, cancellationToken);

            return Results.Ok(new ReglaReembolsoResponse(
                regla.MotivoId, regla.Motivo, regla.Cobertura, regla.Coaseguro, regla.Deducible,
                regla.LimitePorEvento, regla.Moneda, regla.EsNacional, regla.Activo,
                regla.Documentos.Select(d => new DocumentoRequeridoResponse(d.Id, d.Nombre, d.Obligatorio, d.EsFactura)).ToList()));
        }
        catch (ReglaReembolsoNoEncontradaException ex)
        {
            return Results.Problem(
                title: "Regla de reembolso no encontrada",
                detail: ex.Message,
                statusCode: StatusCodes.Status404NotFound);
        }
    }
}

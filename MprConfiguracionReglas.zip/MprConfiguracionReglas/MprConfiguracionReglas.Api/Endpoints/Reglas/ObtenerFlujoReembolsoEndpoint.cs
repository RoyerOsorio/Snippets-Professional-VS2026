using MprConfiguracionReglas.Application.Casos;
using MprConfiguracionReglas.Contracts.Responses;
using MprConfiguracionReglas.Domain.Excepciones;

namespace MprConfiguracionReglas.Api.Endpoints.Reglas;

/// <summary>
/// Endpoint consumido por Reimbursement.Orchestrator para el Paso 7
/// ("Una regla de MprConfiguracionReglas determina si es necesario
/// [dictamen médico]"). Acepta idFlujo y/o dictamenMedico como filtros —
/// ver nota de alcance sobre la ausencia de relación Motivo→Flujo en el
/// esquema entregado.
/// </summary>
public static class ObtenerFlujoReembolsoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapGet("/", ObtenerAsync).WithName("ObtenerFlujoReembolso");
    }

    private static async Task<IResult> ObtenerAsync(
        int? idFlujo,
        bool? dictamenMedico,
        ObtenerFlujoReembolsoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            var flujo = await casoDeUso.EjecutarAsync(idFlujo, dictamenMedico, cancellationToken);

            return Results.Ok(new FlujoReembolsoResponse(flujo.Id, flujo.Nombre, flujo.RequiereDictamenMedico));
        }
        catch (ReglaReembolsoNoEncontradaException ex)
        {
            return Results.Problem(
                title: "Flujo de reembolso no encontrado",
                detail: ex.Message,
                statusCode: StatusCodes.Status404NotFound);
        }
    }
}

using MprConfiguracionReglas.Application.Casos;
using MprConfiguracionReglas.Contracts.Requests;
using MprConfiguracionReglas.Contracts.Responses;
using MprConfiguracionReglas.Domain.Excepciones;

namespace MprConfiguracionReglas.Api.Endpoints.Reglas;

/// <summary>
/// Expone ReglaReembolso.DocumentosObligatoriosFaltantes — consumido antes
/// de permitir "EnviarReclamo" (Paso 5 del ejercicio original). Devuelve la
/// lista de documentos obligatorios que todavía faltan; una lista vacía
/// significa que la documentación aportada satisface la regla.
/// </summary>
public static class ValidarDocumentosEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapPost("/{motivoId:int}/validar-documentos", ValidarAsync).WithName("ValidarDocumentosObligatorios");
    }

    private static async Task<IResult> ValidarAsync(
        int motivoId,
        ValidarDocumentosRequest request,
        ValidarDocumentosObligatoriosCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            var faltantes = await casoDeUso.EjecutarAsync(motivoId, request.DocumentosAportadosIds, cancellationToken);

            return Results.Ok(faltantes.Select(d => new DocumentoRequeridoResponse(d.Id, d.Nombre, d.Obligatorio, d.EsFactura)));
        }
        catch (ReglaReembolsoNoEncontradaException ex)
        {
            return Results.Problem(
                title: "Regla de reembolso no encontrada",
                detail: ex.Message,
                statusCode: StatusCodes.Status404NotFound);
        }
    }
}

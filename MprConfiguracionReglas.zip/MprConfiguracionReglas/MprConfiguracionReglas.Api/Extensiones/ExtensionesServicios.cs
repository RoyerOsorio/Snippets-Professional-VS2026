using MprConfiguracionReglas.Application.Casos;
using MprConfiguracionReglas.Infrastructure.Extensiones;

namespace MprConfiguracionReglas.Api.Extensiones;

public static class ExtensionesServicios
{
    public static IServiceCollection AgregarServiciosMprConfiguracionReglas(
        this IServiceCollection servicios,
        IConfiguration configuracion)
    {
        servicios.AgregarInfrastructureMprConfiguracionReglas(configuracion);

        servicios.AddScoped<ObtenerReglaReembolsoCasoDeUso>();
        servicios.AddScoped<ObtenerFlujoReembolsoCasoDeUso>();
        servicios.AddScoped<ValidarDocumentosObligatoriosCasoDeUso>();

        return servicios;
    }
}

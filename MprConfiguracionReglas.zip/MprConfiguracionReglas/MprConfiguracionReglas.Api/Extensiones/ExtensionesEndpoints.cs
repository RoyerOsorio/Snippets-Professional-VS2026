using MprConfiguracionReglas.Api.Endpoints.Reglas;

namespace MprConfiguracionReglas.Api.Extensiones;

public static class ExtensionesEndpoints
{
    public static void MapearEndpointsReglas(this WebApplication app)
    {
        var grupoReglas = app.MapGroup("/v1/reglas").WithTags("Reglas");
        ObtenerReglaReembolsoEndpoint.Mapear(grupoReglas);
        ValidarDocumentosEndpoint.Mapear(grupoReglas);

        var grupoFlujos = app.MapGroup("/v1/flujos").WithTags("Flujos");
        ObtenerFlujoReembolsoEndpoint.Mapear(grupoFlujos);
    }
}

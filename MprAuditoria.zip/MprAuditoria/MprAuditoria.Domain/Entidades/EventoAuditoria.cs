namespace MprAuditoria.Domain.Entidades;

/// <summary>
/// Registro inmutable de un evento de integración consumido por MprAuditoria.
/// A diferencia de Pago o Reclamo, EventoAuditoria no tiene ciclo de vida:
/// se crea una única vez (Registrar) y nunca cambia de estado — es un log
/// append-only, no un agregado con transiciones (ver UI_Decision_Log.md
/// DEC-007).
///
/// MensajeIdOrigen es el MessageId del mensaje RabbitMQ que originó este
/// registro (el OboxNid asignado por el microservicio publicador) —
/// persistido con restricción de unicidad para idempotencia ante
/// redelivery de RabbitMQ, mismo criterio que MprPagos (ver DEC-006).
///
/// ReclamoId se extrae del payload de cada tipo de evento porque el
/// timeline se consulta por Reclamo — es el eje central de la bitácora.
/// </summary>
public sealed class EventoAuditoria
{
    public long Id { get; }
    public long MensajeIdOrigen { get; }
    public string TipoEvento { get; }
    public int ReclamoId { get; }
    public string PayloadJson { get; }
    public DateTime FechaOcurrencia { get; }
    public DateTime FechaRegistro { get; }

    public EventoAuditoria(
        long id,
        long mensajeIdOrigen,
        string tipoEvento,
        int reclamoId,
        string payloadJson,
        DateTime fechaOcurrencia,
        DateTime fechaRegistro)
    {
        Id = id;
        MensajeIdOrigen = mensajeIdOrigen;
        TipoEvento = tipoEvento;
        ReclamoId = reclamoId;
        PayloadJson = payloadJson;
        FechaOcurrencia = fechaOcurrencia;
        FechaRegistro = fechaRegistro;
    }

    /// <summary>
    /// Fábrica invocada por los consumidores de RabbitMQ. El Id real lo
    /// asigna la base de datos; aquí se usa 0 como marcador de "todavía no
    /// persistido", mismo criterio que las demás entidades del ejercicio.
    /// </summary>
    public static EventoAuditoria Registrar(
        long mensajeIdOrigen,
        string tipoEvento,
        int reclamoId,
        string payloadJson,
        DateTime fechaOcurrencia,
        DateTime fechaRegistro)
    {
        if (string.IsNullOrWhiteSpace(tipoEvento))
        {
            throw new ArgumentException("El tipo de evento no puede estar vacío.", nameof(tipoEvento));
        }

        if (string.IsNullOrWhiteSpace(payloadJson))
        {
            throw new ArgumentException("El payload del evento no puede estar vacío.", nameof(payloadJson));
        }

        return new EventoAuditoria(0, mensajeIdOrigen, tipoEvento, reclamoId, payloadJson, fechaOcurrencia, fechaRegistro);
    }
}

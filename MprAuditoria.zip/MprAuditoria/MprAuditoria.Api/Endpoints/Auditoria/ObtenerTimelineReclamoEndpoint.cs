using MprAuditoria.Application.Casos;
using MprAuditoria.Contracts.Responses;

namespace MprAuditoria.Api.Endpoints.Auditoria;

/// <summary>
/// Bitácora/timeline de un Reclamo — alimenta la pantalla de resultado
/// final del ejercicio original ("Reembolso #R-00001 ... Timeline"). Sin
/// body ni parámetros de filtro adicionales: se devuelve todo el historial
/// disponible, ordenado cronológicamente.
/// </summary>
public static class ObtenerTimelineReclamoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapGet("/reclamos/{reclamoId:int}", ObtenerAsync).WithName("ObtenerTimelineReclamo");
    }

    private static async Task<IResult> ObtenerAsync(
        int reclamoId,
        ObtenerTimelineReclamoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        var eventos = await casoDeUso.EjecutarAsync(reclamoId, cancellationToken);

        var response = eventos
            .Select(e => new EventoAuditoriaResponse(e.Id, e.TipoEvento, e.ReclamoId, e.PayloadJson, e.FechaOcurrencia, e.FechaRegistro))
            .ToList();

        return Results.Ok(response);
    }
}

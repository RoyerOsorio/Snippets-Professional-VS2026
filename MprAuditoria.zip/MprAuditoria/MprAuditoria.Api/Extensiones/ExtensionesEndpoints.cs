using MprAuditoria.Api.Endpoints.Auditoria;

namespace MprAuditoria.Api.Extensiones;

public static class ExtensionesEndpoints
{
    public static void MapearEndpointsAuditoria(this WebApplication app)
    {
        var grupo = app.MapGroup("/v1/auditoria").WithTags("Auditoria");

        ObtenerTimelineReclamoEndpoint.Mapear(grupo);
    }
}

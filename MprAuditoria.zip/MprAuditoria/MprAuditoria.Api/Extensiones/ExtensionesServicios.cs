using MprAuditoria.Application.Casos;
using MprAuditoria.Infrastructure.Extensiones;

namespace MprAuditoria.Api.Extensiones;

public static class ExtensionesServicios
{
    public static IServiceCollection AgregarServiciosMprAuditoria(
        this IServiceCollection servicios,
        IConfiguration configuracion)
    {
        servicios.AgregarInfrastructureMprAuditoria(configuracion);

        servicios.AddScoped<RegistrarEventoAuditoriaCasoDeUso>();
        servicios.AddScoped<ObtenerTimelineReclamoCasoDeUso>();

        return servicios;
    }
}

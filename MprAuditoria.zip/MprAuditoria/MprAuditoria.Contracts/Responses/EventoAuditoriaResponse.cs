namespace MprAuditoria.Contracts.Responses;

public sealed record EventoAuditoriaResponse(
    long Id,
    string TipoEvento,
    int ReclamoId,
    string PayloadJson,
    DateTime FechaOcurrencia,
    DateTime FechaRegistro);

using MprAuditoria.Application.Dtos;
using MprAuditoria.Application.Puertos;
using MprAuditoria.Domain.Entidades;

namespace MprAuditoria.Application.Casos;

/// <summary>
/// Consumido por ambos BackgroundServices de Infrastructure/Mensajeria (uno
/// por cada tipo de evento consumido: ReclamoAprobadoParaPago y
/// PagoCompletado — ver DEC-007). Idempotente por MensajeIdOrigen, mismo
/// criterio que ProcesarReclamoAprobadoParaPagoCasoDeUso en MprPagos
/// (DEC-006): protege contra redelivery de RabbitMQ (at-least-once
/// delivery), no solo contra el reintento de publicación que ya maneja el
/// Outbox de origen.
/// </summary>
public sealed class RegistrarEventoAuditoriaCasoDeUso(IRepositorioEventosAuditoria repositorio)
{
    public async Task<EventoAuditoriaDto> EjecutarAsync(
        long mensajeIdOrigen,
        string tipoEvento,
        int reclamoId,
        string payloadJson,
        DateTime fechaOcurrencia,
        DateTime fechaRegistro,
        CancellationToken cancellationToken)
    {
        var existente = await repositorio.ObtenerPorMensajeIdOrigenAsync(mensajeIdOrigen, cancellationToken);

        if (existente is not null)
        {
            return ADto(existente);
        }

        var evento = EventoAuditoria.Registrar(mensajeIdOrigen, tipoEvento, reclamoId, payloadJson, fechaOcurrencia, fechaRegistro);
        var registrado = await repositorio.RegistrarAsync(evento, cancellationToken);

        return ADto(registrado);
    }

    private static EventoAuditoriaDto ADto(EventoAuditoria evento) => new(
        evento.Id, evento.TipoEvento, evento.ReclamoId, evento.PayloadJson, evento.FechaOcurrencia, evento.FechaRegistro);
}

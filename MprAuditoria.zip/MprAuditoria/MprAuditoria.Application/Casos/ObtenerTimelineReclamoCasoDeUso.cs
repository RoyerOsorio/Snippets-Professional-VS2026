using MprAuditoria.Application.Dtos;
using MprAuditoria.Application.Puertos;

namespace MprAuditoria.Application.Casos;

/// <summary>
/// Devuelve la bitácora/timeline completa de un Reclamo, ordenada por fecha
/// de ocurrencia — es la pieza que alimenta la pantalla de resultado final
/// del ejercicio original ("Reembolso #R-00001 ... Timeline"). Lista vacía
/// si el Reclamo no tiene eventos registrados; no es un error — un Reclamo
/// que todavía no fue aprobado legítimamente no tiene eventos todavía.
/// </summary>
public sealed class ObtenerTimelineReclamoCasoDeUso(IRepositorioEventosAuditoria repositorio)
{
    public async Task<IReadOnlyList<EventoAuditoriaDto>> EjecutarAsync(int reclamoId, CancellationToken cancellationToken)
    {
        var eventos = await repositorio.ObtenerTimelinePorReclamoAsync(reclamoId, cancellationToken);

        return eventos
            .OrderBy(e => e.FechaOcurrencia)
            .Select(e => new EventoAuditoriaDto(e.Id, e.TipoEvento, e.ReclamoId, e.PayloadJson, e.FechaOcurrencia, e.FechaRegistro))
            .ToList();
    }
}

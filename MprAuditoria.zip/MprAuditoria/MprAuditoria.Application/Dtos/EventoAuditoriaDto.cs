namespace MprAuditoria.Application.Dtos;

public sealed record EventoAuditoriaDto(
    long Id,
    string TipoEvento,
    int ReclamoId,
    string PayloadJson,
    DateTime FechaOcurrencia,
    DateTime FechaRegistro);

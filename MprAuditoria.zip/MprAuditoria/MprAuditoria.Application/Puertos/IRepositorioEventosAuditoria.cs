using MprAuditoria.Domain.Entidades;

namespace MprAuditoria.Application.Puertos;

public interface IRepositorioEventosAuditoria
{
    /// <summary>
    /// Usado por RegistrarEventoAuditoriaCasoDeUso para la verificación de
    /// idempotencia a nivel de aplicación, antes de intentar el INSERT (que
    /// además tiene una restricción de unicidad en base de datos como
    /// segunda barrera — ver deploy/sql/MprAuditoria/README.md).
    /// </summary>
    Task<EventoAuditoria?> ObtenerPorMensajeIdOrigenAsync(long mensajeIdOrigen, CancellationToken cancellationToken);

    Task<EventoAuditoria> RegistrarAsync(EventoAuditoria evento, CancellationToken cancellationToken);

    /// <summary>Bitácora completa de un Reclamo — la consulta principal de este microservicio.</summary>
    Task<IReadOnlyList<EventoAuditoria>> ObtenerTimelinePorReclamoAsync(int reclamoId, CancellationToken cancellationToken);
}

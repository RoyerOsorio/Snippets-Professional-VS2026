using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MprAuditoria.Application.Puertos;
using MprAuditoria.Infrastructure.Mensajeria;
using MprAuditoria.Infrastructure.Persistencia;
using MprAuditoria.Infrastructure.Persistencia.Adaptadores;

namespace MprAuditoria.Infrastructure.Extensiones;

public static class ExtensionesServiciosInfrastructure
{
    public static IServiceCollection AgregarInfrastructureMprAuditoria(
        this IServiceCollection servicios,
        IConfiguration configuracion)
    {
        servicios.AddDbContext<MprAuditoriaDbContext>(opciones =>
            opciones.UseSqlServer(configuracion.GetConnectionString("MprAuditoriaDb")));

        servicios.AddScoped<IRepositorioEventosAuditoria, RepositorioEventosAuditoriaEfCore>();

        servicios.Configure<RabbitMqOpciones>(configuracion.GetSection("RabbitMq"));
        servicios.AddHostedService<ReclamoAprobadoParaPagoConsumerHostedService>();
        servicios.AddHostedService<PagoCompletadoConsumerHostedService>();

        return servicios;
    }
}

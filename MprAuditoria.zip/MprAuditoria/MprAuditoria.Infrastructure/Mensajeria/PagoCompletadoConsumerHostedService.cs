using System.Text;
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MprAuditoria.Application.Casos;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace MprAuditoria.Infrastructure.Mensajeria;

/// <summary>
/// Consume PagoCompletado (publicado por MprPagos, ver DEC-006) y lo
/// registra en la bitácora. Misma estructura y mismas simplificaciones
/// explícitas que ReclamoAprobadoParaPagoConsumerHostedService: sin
/// dead-letter queue ni límite de reintentos (ver docs/demo/README.md).
/// </summary>
public sealed class PagoCompletadoConsumerHostedService(
    IServiceScopeFactory scopeFactory,
    IOptions<RabbitMqOpciones> opciones,
    ILogger<PagoCompletadoConsumerHostedService> logger) : BackgroundService
{
    private static readonly JsonSerializerOptions OpcionesJson = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true,
    };

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var config = opciones.Value;

        var factory = new ConnectionFactory
        {
            HostName = config.HostName,
            Port = config.Port,
            UserName = config.UserName,
            Password = config.Password,
        };

        await using var conexion = await factory.CreateConnectionAsync(stoppingToken);
        await using var canal = await conexion.CreateChannelAsync(cancellationToken: stoppingToken);

        await canal.ExchangeDeclareAsync(config.Exchange, ExchangeType.Topic, durable: true, cancellationToken: stoppingToken);
        await canal.QueueDeclareAsync(
            config.ColaPagoCompletado, durable: true, exclusive: false, autoDelete: false,
            cancellationToken: stoppingToken);
        await canal.QueueBindAsync(
            config.ColaPagoCompletado, config.Exchange, config.RoutingKeyPagoCompletado,
            cancellationToken: stoppingToken);

        var consumidor = new AsyncEventingBasicConsumer(canal);
        consumidor.ReceivedAsync += async (_, entrega) =>
        {
            await ProcesarMensajeAsync(canal, entrega, stoppingToken);
        };

        await canal.BasicConsumeAsync(
            config.ColaPagoCompletado, autoAck: false, consumidor, cancellationToken: stoppingToken);

        logger.LogInformation(
            "Escuchando {Cola} (enlazada a {Exchange}/{RoutingKey}).",
            config.ColaPagoCompletado, config.Exchange, config.RoutingKeyPagoCompletado);

        await Task.Delay(Timeout.Infinite, stoppingToken).ContinueWith(_ => { }, TaskScheduler.Default);
    }

    private async Task ProcesarMensajeAsync(IChannel canal, BasicDeliverEventArgs entrega, CancellationToken cancellationToken)
    {
        try
        {
            var mensajeIdTexto = entrega.BasicProperties.MessageId;

            if (string.IsNullOrWhiteSpace(mensajeIdTexto) || !long.TryParse(mensajeIdTexto, out var mensajeIdOrigen))
            {
                logger.LogWarning("Mensaje descartado: MessageId ausente o inválido ({MessageId}).", mensajeIdTexto);
                await canal.BasicNackAsync(entrega.DeliveryTag, multiple: false, requeue: false, cancellationToken);
                return;
            }

            var cuerpoTexto = Encoding.UTF8.GetString(entrega.Body.ToArray());
            var payload = JsonSerializer.Deserialize<PagoCompletadoMensaje>(cuerpoTexto, OpcionesJson);

            if (payload is null)
            {
                logger.LogWarning("Mensaje descartado: payload no se pudo deserializar (MessageId={MessageId}).", mensajeIdOrigen);
                await canal.BasicNackAsync(entrega.DeliveryTag, multiple: false, requeue: false, cancellationToken);
                return;
            }

            using var scope = scopeFactory.CreateScope();
            var casoDeUso = scope.ServiceProvider.GetRequiredService<RegistrarEventoAuditoriaCasoDeUso>();

            await casoDeUso.EjecutarAsync(
                mensajeIdOrigen, "PagoCompletado", payload.ReclamoId, cuerpoTexto,
                payload.FechaConfirmacion, DateTime.UtcNow, cancellationToken);

            await canal.BasicAckAsync(entrega.DeliveryTag, multiple: false, cancellationToken);

            logger.LogInformation(
                "Registrado PagoCompletado en bitácora (MessageId={MessageId}, ReclamoId={ReclamoId}).",
                mensajeIdOrigen, payload.ReclamoId);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Fallo al procesar mensaje de {Cola} — se reencola.", opciones.Value.ColaPagoCompletado);
            await canal.BasicNackAsync(entrega.DeliveryTag, multiple: false, requeue: true, cancellationToken);
        }
    }

    /// <summary>
    /// Copia local del payload esperado — MprAuditoria NO referencia el
    /// ensamblado de MprPagos.Application, mismo criterio de bounded
    /// contexts separados aplicado al consumidor de ReclamoAprobadoParaPago.
    /// </summary>
    private sealed record PagoCompletadoMensaje(
        int PagoId, int ReclamoId, string Poliza, int AseguradoId, decimal MontoPagado, DateTime FechaConfirmacion);
}

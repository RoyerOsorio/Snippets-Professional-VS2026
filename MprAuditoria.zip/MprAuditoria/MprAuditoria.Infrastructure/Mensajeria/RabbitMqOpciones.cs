namespace MprAuditoria.Infrastructure.Mensajeria;

/// <summary>
/// MprAuditoria es un consumidor terminal (ver DEC-007): escucha dos
/// routing keys del mismo exchange `multiportal.reembolsos`
/// (ReclamoAprobadoParaPago desde MprGestionReclamos, PagoCompletado desde
/// MprPagos) y no publica ningún evento propio — no necesita
/// Outbox/publisher ni IntervaloPollingSegundos.
/// </summary>
public sealed class RabbitMqOpciones
{
    public string HostName { get; set; } = "localhost";
    public int Port { get; set; } = 5672;
    public string UserName { get; set; } = "guest";
    public string Password { get; set; } = "guest";
    public string Exchange { get; set; } = "multiportal.reembolsos";

    /// <summary>Routing key con la que MprGestionReclamos publica el evento (ver DEC-003).</summary>
    public string RoutingKeyReclamoAprobadoParaPago { get; set; } = "reclamo.aprobado-para-pago";

    /// <summary>Cola propia de MprAuditoria — nunca comparte cola con MprPagos, que también consume esta routing key desde su propia cola (fan-out por exchange topic).</summary>
    public string ColaReclamoAprobadoParaPago { get; set; } = "mprauditoria.reclamo-aprobado-para-pago";

    /// <summary>Routing key con la que MprPagos publica el evento (ver DEC-006).</summary>
    public string RoutingKeyPagoCompletado { get; set; } = "pago.completado";

    public string ColaPagoCompletado { get; set; } = "mprauditoria.pago-completado";
}

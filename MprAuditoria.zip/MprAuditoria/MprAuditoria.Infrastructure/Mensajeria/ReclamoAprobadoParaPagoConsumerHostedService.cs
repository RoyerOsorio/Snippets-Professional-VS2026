using System.Text;
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MprAuditoria.Application.Casos;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace MprAuditoria.Infrastructure.Mensajeria;

/// <summary>
/// Consume ReclamoAprobadoParaPago (publicado por MprGestionReclamos, ver
/// DEC-003) y lo registra en la bitácora. Misma estructura que
/// MprPagos.Infrastructure.Mensajeria.ReclamoAprobadoParaPagoConsumerHostedService
/// (DEC-006) — cada microservicio declara y usa su propia cola. MprPagos
/// también consume este mismo routing key desde una cola distinta:
/// RabbitMQ entrega una copia del mensaje a cada cola enlazada (fan-out por
/// routing key en un exchange topic), así que ambos consumidores coexisten
/// sin interferirse.
/// </summary>
public sealed class ReclamoAprobadoParaPagoConsumerHostedService(
    IServiceScopeFactory scopeFactory,
    IOptions<RabbitMqOpciones> opciones,
    ILogger<ReclamoAprobadoParaPagoConsumerHostedService> logger) : BackgroundService
{
    private static readonly JsonSerializerOptions OpcionesJson = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true,
    };

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var config = opciones.Value;

        var factory = new ConnectionFactory
        {
            HostName = config.HostName,
            Port = config.Port,
            UserName = config.UserName,
            Password = config.Password,
        };

        await using var conexion = await factory.CreateConnectionAsync(stoppingToken);
        await using var canal = await conexion.CreateChannelAsync(cancellationToken: stoppingToken);

        await canal.ExchangeDeclareAsync(config.Exchange, ExchangeType.Topic, durable: true, cancellationToken: stoppingToken);
        await canal.QueueDeclareAsync(
            config.ColaReclamoAprobadoParaPago, durable: true, exclusive: false, autoDelete: false,
            cancellationToken: stoppingToken);
        await canal.QueueBindAsync(
            config.ColaReclamoAprobadoParaPago, config.Exchange, config.RoutingKeyReclamoAprobadoParaPago,
            cancellationToken: stoppingToken);

        var consumidor = new AsyncEventingBasicConsumer(canal);
        consumidor.ReceivedAsync += async (_, entrega) =>
        {
            await ProcesarMensajeAsync(canal, entrega, stoppingToken);
        };

        await canal.BasicConsumeAsync(
            config.ColaReclamoAprobadoParaPago, autoAck: false, consumidor, cancellationToken: stoppingToken);

        logger.LogInformation(
            "Escuchando {Cola} (enlazada a {Exchange}/{RoutingKey}).",
            config.ColaReclamoAprobadoParaPago, config.Exchange, config.RoutingKeyReclamoAprobadoParaPago);

        // BasicConsumeAsync es asíncrono por evento — esta espera mantiene
        // vivo el BackgroundService hasta que se solicite el shutdown.
        await Task.Delay(Timeout.Infinite, stoppingToken).ContinueWith(_ => { }, TaskScheduler.Default);
    }

    private async Task ProcesarMensajeAsync(IChannel canal, BasicDeliverEventArgs entrega, CancellationToken cancellationToken)
    {
        try
        {
            var mensajeIdTexto = entrega.BasicProperties.MessageId;

            if (string.IsNullOrWhiteSpace(mensajeIdTexto) || !long.TryParse(mensajeIdTexto, out var mensajeIdOrigen))
            {
                logger.LogWarning("Mensaje descartado: MessageId ausente o inválido ({MessageId}).", mensajeIdTexto);
                await canal.BasicNackAsync(entrega.DeliveryTag, multiple: false, requeue: false, cancellationToken);
                return;
            }

            var cuerpoTexto = Encoding.UTF8.GetString(entrega.Body.ToArray());
            var payload = JsonSerializer.Deserialize<ReclamoAprobadoParaPagoMensaje>(cuerpoTexto, OpcionesJson);

            if (payload is null)
            {
                logger.LogWarning("Mensaje descartado: payload no se pudo deserializar (MessageId={MessageId}).", mensajeIdOrigen);
                await canal.BasicNackAsync(entrega.DeliveryTag, multiple: false, requeue: false, cancellationToken);
                return;
            }

            using var scope = scopeFactory.CreateScope();
            var casoDeUso = scope.ServiceProvider.GetRequiredService<RegistrarEventoAuditoriaCasoDeUso>();

            await casoDeUso.EjecutarAsync(
                mensajeIdOrigen, "ReclamoAprobadoParaPago", payload.ReclamoId, cuerpoTexto,
                payload.FechaResolucion, DateTime.UtcNow, cancellationToken);

            await canal.BasicAckAsync(entrega.DeliveryTag, multiple: false, cancellationToken);

            logger.LogInformation(
                "Registrado ReclamoAprobadoParaPago en bitácora (MessageId={MessageId}, ReclamoId={ReclamoId}).",
                mensajeIdOrigen, payload.ReclamoId);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Fallo al procesar mensaje de {Cola} — se reencola.", opciones.Value.ColaReclamoAprobadoParaPago);
            await canal.BasicNackAsync(entrega.DeliveryTag, multiple: false, requeue: true, cancellationToken);
        }
    }

    /// <summary>
    /// Copia local del payload esperado — MprAuditoria NO referencia el
    /// ensamblado de MprGestionReclamos.Application (bounded contexts
    /// separados); el contrato del mensaje es implícito (JSON), no un tipo
    /// compartido, mismo criterio ya aplicado en MprPagos.
    /// </summary>
    private sealed record ReclamoAprobadoParaPagoMensaje(
        int ReclamoId, string Poliza, int AseguradoId, decimal MontoAprobado, DateTime FechaResolucion);
}

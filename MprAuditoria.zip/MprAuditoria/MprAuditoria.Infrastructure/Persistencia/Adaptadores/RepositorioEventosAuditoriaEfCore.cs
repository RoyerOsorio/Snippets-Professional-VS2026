using Microsoft.EntityFrameworkCore;
using MprAuditoria.Application.Puertos;
using MprAuditoria.Domain.Entidades;
using EventoAuditoriaGenerado = MprAuditoria.Infrastructure.Persistencia.ModelosGenerados.EventoAuditoria;

namespace MprAuditoria.Infrastructure.Persistencia.Adaptadores;

/// <summary>
/// Adaptador escrito a mano. Implementa el puerto IRepositorioEventosAuditoria.
/// Sin patrón Outbox aquí: MprAuditoria es un consumidor terminal, no
/// publica ningún evento de integración propio (ver DEC-007).
/// </summary>
public sealed class RepositorioEventosAuditoriaEfCore(MprAuditoriaDbContext dbContext) : IRepositorioEventosAuditoria
{
    public async Task<EventoAuditoria?> ObtenerPorMensajeIdOrigenAsync(long mensajeIdOrigen, CancellationToken cancellationToken)
    {
        var entidad = await dbContext.EventosAuditoria.AsNoTracking()
            .FirstOrDefaultAsync(e => e.AudiMensajeIdOrigen == mensajeIdOrigen, cancellationToken);

        return entidad is null ? null : AEntidadDominio(entidad);
    }

    public async Task<EventoAuditoria> RegistrarAsync(EventoAuditoria evento, CancellationToken cancellationToken)
    {
        var entidad = new EventoAuditoriaGenerado
        {
            AudiMensajeIdOrigen = evento.MensajeIdOrigen,
            AudiTipoEvento = evento.TipoEvento,
            AudiReclamoId = evento.ReclamoId,
            AudiPayloadJson = evento.PayloadJson,
            AudiFechaOcurrencia = evento.FechaOcurrencia,
            AudiFechaRegistro = evento.FechaRegistro,
        };

        dbContext.EventosAuditoria.Add(entidad);
        await dbContext.SaveChangesAsync(cancellationToken);

        return AEntidadDominio(entidad);
    }

    public async Task<IReadOnlyList<EventoAuditoria>> ObtenerTimelinePorReclamoAsync(int reclamoId, CancellationToken cancellationToken)
    {
        var entidades = await dbContext.EventosAuditoria.AsNoTracking()
            .Where(e => e.AudiReclamoId == reclamoId)
            .OrderBy(e => e.AudiFechaOcurrencia)
            .ToListAsync(cancellationToken);

        return entidades.Select(AEntidadDominio).ToList();
    }

    private static EventoAuditoria AEntidadDominio(EventoAuditoriaGenerado entidad) => new(
        entidad.AudiNid,
        entidad.AudiMensajeIdOrigen,
        entidad.AudiTipoEvento,
        entidad.AudiReclamoId,
        entidad.AudiPayloadJson,
        entidad.AudiFechaOcurrencia,
        entidad.AudiFechaRegistro);
}

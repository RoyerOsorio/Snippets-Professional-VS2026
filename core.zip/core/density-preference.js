/* ============================================================================
   core/density-preference.js
   Fase: Fase 3-B.2 — Refactorización interna del JavaScript del Layout
   (Frontend_Refactoring_and_Migration_Plan_Addendum_v1.1.md).

   Responsabilidad: lectura y escritura de la preferencia de densidad
   (JavaScript_Architecture_Guide_v1.0.md §4 — "density-preference.js:
   Lectura/escritura de la preferencia de densidad, Guía de Diseño §12").
   Consolida en un único módulo lo que en el legado estaba disperso entre
   wwwroot/js/layout.js (restauración inicial, applyDensity()) y
   wwwroot/js/header.js (sincronización del control + escritura,
   applyDensitySelection() y su listener de clic).

   Depende de: core/storage.js
   Consumido por: site.js

   Mecanismo: ES Modules nativos (D-07, Migration_Technical_Decisions_Register).
   Migration Phase: Fase 3-B.2
   Estado: Nuevo — coexiste con el legado (layout.js, header.js) bajo M-01.
   Traslado literal de la lógica ya validada, sin reescritura de comportamiento
   (Migration Plan §5, principio 3).
   ============================================================================ */

import { get, set, STORAGE_KEYS } from './storage.js';

function applyDensityClass(value) {
    document.body.classList.toggle("density-compact", value === "compacta");
}

function syncToggleUI(densityToggle, value) {
    if (!densityToggle) return;
    densityToggle.querySelectorAll(".density-option").forEach((btn) => {
        const active = btn.getAttribute("data-density") === value;
        btn.classList.toggle("is-active", active);
        btn.setAttribute("aria-pressed", String(active));
    });
}

function applyDensitySelection(value, densityToggle) {
    applyDensityClass(value);
    set(STORAGE_KEYS.density, value);
    syncToggleUI(densityToggle, value);
}

export function initDensityPreference() {
    const current = get(STORAGE_KEYS.density) || "comoda";

    // Restaura la densidad persistida (equivalente a applyDensity() de layout.js legado).
    applyDensityClass(current);

    const densityToggle = document.querySelector("[data-density-toggle]");
    if (!densityToggle) return;

    // Sincroniza el control visual con la preferencia ya aplicada
    // (equivalente al bloque de sincronización de header.js legado).
    syncToggleUI(densityToggle, current);

    densityToggle.addEventListener("click", (e) => {
        const btn = e.target.closest(".density-option");
        if (!btn) return;
        applyDensitySelection(btn.getAttribute("data-density"), densityToggle);
    });
}

/* ============================================================================
   core/storage.js
   Fase: Fase 3-B.2 — Refactorización interna del JavaScript del Layout
   (Frontend_Refactoring_and_Migration_Plan_Addendum_v1.1.md).

   Responsabilidad: acceso seguro a localStorage (puede estar deshabilitado
   en algunos entornos) + helpers de serialización JSON. Utilidad transversal
   sin conocimiento de ningún componente ni módulo de negocio específico
   (JavaScript_Architecture_Guide_v1.0.md §5).

   Depende de: nada.
   Consumido por: core/density-preference.js, components/sidebar.js
   (extraído a core/ por repetirse en 2 módulos distintos — criterio de
   JavaScript_Architecture_Guide_v1.0.md §11.1).

   Mecanismo: ES Modules nativos (D-07, Migration_Technical_Decisions_Register).
   Migration Phase: Fase 3-B.2
   Estado: Nuevo — coexiste con el legado (layout.js) bajo M-01 mientras
   dure la transición. Traslado literal del wrapper `store`/`STORAGE` de
   wwwroot/js/layout.js legado (sin reescritura de lógica).
   ============================================================================ */

export function get(key) {
    try {
        return window.localStorage.getItem(key);
    } catch {
        return null;
    }
}

export function set(key, value) {
    try {
        window.localStorage.setItem(key, value);
    } catch {
        /* no-op: localStorage puede estar deshabilitado */
    }
}

export function getJSON(key, fallback) {
    const raw = get(key);
    if (!raw) return fallback;
    try {
        return JSON.parse(raw);
    } catch {
        return fallback;
    }
}

export function setJSON(key, value) {
    set(key, JSON.stringify(value));
}

export const STORAGE_KEYS = {
    collapsed: "vm.sidebar.collapsed",
    openGroups: "vm.sidebar.openGroups",
    density: "vm.density"
};

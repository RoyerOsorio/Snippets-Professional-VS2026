/* ============================================================================
   core/dom-ready.js
   Fase: Fase 3-B.2 — Refactorización interna del JavaScript del Layout
   (Frontend_Refactoring_and_Migration_Plan_Addendum_v1.1.md).

   Responsabilidad: punto único de inicialización tras DOMContentLoaded,
   con comprobación idempotente de document.readyState — relevante porque
   los scripts `type="module"` se ejecutan de forma diferida y pueden correr
   después de que DOMContentLoaded ya se disparó
   (JavaScript_Architecture_Guide_v1.0.md §4, §10.3).

   Depende de: nada.
   Consumido por: site.js

   Mecanismo: ES Modules nativos (D-07, Migration_Technical_Decisions_Register).
   Migration Phase: Fase 3-B.2
   Estado: Nuevo — coexiste con el legado bajo M-01.
   ============================================================================ */

export function onReady(callback) {
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", callback, { once: true });
    } else {
        callback();
    }
}

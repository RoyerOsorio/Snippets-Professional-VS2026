# Vitamedica.Microservicios

Repositorio destino de la migración incremental de `ReembolsoGModelo` (sistema
monolítico .NET Framework 4.8) hacia una **arquitectura de microservicios**,
donde cada microservicio implementa internamente **Clean Architecture** +
**SOLID**, con las reglas de negocio del dominio aisladas de frameworks,
bases de datos y protocolos de transporte.

Cada microservicio es una **solución .NET independiente** (su propio
`.slnx`, su propio ciclo de vida y despliegue), sin referencias de proyecto
cruzadas entre microservicios. La comunicación entre ellos, cuando exista,
será vía HTTP/gRPC o mensajería asíncrona — nunca referencias directas a
ensamblados de otro microservicio.

## Microservicios planeados

| Microservicio | Estado | Responsabilidad |
|---|---|---|
| **Clientes** | ✅ Demo inicial (este repo) | Consulta de datos del cliente/asegurado (hoy con datos de ejemplo; a futuro reemplaza la integración a Active Directory que hoy hace `UsuarioAgent`/`ActiveDirectoryServiceClient` en el monolito). |
| **Reembolso (Grupo Modelo G)** | Pendiente | Contiene las reglas de negocio reales de `ReembolsoGModelo`: captura de trámite, cálculo de cobertura/coaseguro/límite por evento, flujo de dictamen (Pendiente → EnRevisión → Devuelto/Rechazado/Aprobado → Pagado). Es el equivalente de dominio a `ReembolsoController` + `Vitamedica.Reembolso.GModelo.Business` del monolito, pero con el dominio puro (sin ADO.NET, sin MVC). |
| **Tesorería** | Pendiente | Validación de cuenta bancaria (CLABE), dispersión de pago vía BBVA, procesamiento del archivo de retorno del banco (`ArchivoRetro`). Hoy vive mezclado dentro de `ReembolsoController`/`InicioController` en el monolito. |
| **Autenticación** | Pendiente | Login (manual, token cifrado, id encriptado) contra Active Directory. Ver `Diagrama_Detalle_Autenticacion.drawio` en el repo `ReembolsoGModelo` para el detalle de las 3 rutas actuales. |
| **Notificaciones** | Pendiente | Envío de correos (bienvenida, resultado de trámite, rechazo de cuenta) — hoy disperso en `EnviaCorreoAgent` dentro del monolito. |

> Fuente de verdad del negocio legacy: skill `reembolso-gmodelo-overview`
> (`ReembolsoGModelo\.devin\skills\reembolso-gmodelo-overview\SKILL.md`) —
> consultar ahí antes de migrar reglas de negocio adicionales, para no
> perder matices ya verificados contra el código real.

## Por qué "Clientes" primero

El microservicio de Reembolso (el que contendrá las reglas de negocio de
"Grupo Modelo") **depende** de poder consultar al cliente/asegurado
(nómina, vigencia, grupo, datos de contacto) para poder capturar un trámite.
En una arquitectura de microservicios, esa consulta se hace vía HTTP a este
microservicio en vez de una consulta SQL directa o un `using (UsuarioAgent
agent = new UsuarioAgent())` como en el monolito.

**Alcance de esta primera entrega**: solo el microservicio `Clientes`,
devolviendo información de ejemplo (semilla en memoria), como base para que
el futuro microservicio de Reembolso lo consuma. La integración real con
Active Directory / el servicio `ActiveDirectoryServiceClient` del monolito
se implementará más adelante, en la capa `Infrastructure` de este mismo
microservicio (solo se reemplaza el repositorio, Domain/Application no
cambian).

## Estructura de cada microservicio (Clean Architecture)

```
<Microservicio>/
├── Vitamedica.Microservicios.<Microservicio>.slnx
├── src/
│   ├── Vitamedica.Microservicios.<Microservicio>.Domain          (sin dependencias externas)
│   ├── Vitamedica.Microservicios.<Microservicio>.Application     (depende solo de Domain)
│   ├── Vitamedica.Microservicios.<Microservicio>.Infrastructure  (depende de Domain + Application)
│   └── Vitamedica.Microservicios.<Microservicio>.Api             (depende de Application + Infrastructure)
└── tests/
    └── Vitamedica.Microservicios.<Microservicio>.Domain.Tests
```

Regla de dependencia (SOLID - Dependency Inversion): las flechas siempre
apuntan hacia `Domain`. `Api` no conoce `Infrastructure` en detalle, solo
llama `AddInfrastructure()`/`AddApplication()` (Inversión de Control vía
extensiones de `IServiceCollection`).

using Vitamedica.Microservicios.Clientes.Domain.Entities;
using Xunit;

namespace Vitamedica.Microservicios.Clientes.Domain.Tests;

/// <summary>
/// Cliente es hoy una proyección de solo lectura de la tabla real
/// MPR_ASAS_MASEGURADO (no tiene invariantes de negocio propias, ya que
/// este microservicio no es dueño de esos datos). Las pruebas se limitan
/// a validar el comportamiento propio de esta capa: el cálculo de
/// NombreCompleto.
/// </summary>
public class ClienteTests
{
    private static Cliente CrearCliente(
        string nombre = "Juan", string apPaterno = "Pérez", string apMaterno = "López") =>
        new(
            id: 1,
            nombre: nombre,
            apellidoPaterno: apPaterno,
            apellidoMaterno: apMaterno,
            fechaNacimiento: new DateTime(1990, 5, 20),
            generoId: 1,
            rfc: "PELJ900520ABC",
            curp: "PELJ900520HDFRPN01");

    [Fact]
    public void NombreCompleto_ConcatenaNombreYApellidos()
    {
        var cliente = CrearCliente();

        Assert.Equal("Juan Pérez López", cliente.NombreCompleto);
    }

    [Fact]
    public void NombreCompleto_ApellidoMaternoVacio_NoDejaEspaciosDeSobra()
    {
        var cliente = CrearCliente(apMaterno: "");

        Assert.Equal("Juan Pérez", cliente.NombreCompleto);
    }

    [Fact]
    public void Propiedades_SeAsignanCorrectamenteAlConstruir()
    {
        var cliente = CrearCliente();

        Assert.Equal(1, cliente.Id);
        Assert.Equal("PELJ900520ABC", cliente.Rfc);
        Assert.Equal("PELJ900520HDFRPN01", cliente.Curp);
        Assert.Equal(new DateTime(1990, 5, 20), cliente.FechaNacimiento);
    }
}

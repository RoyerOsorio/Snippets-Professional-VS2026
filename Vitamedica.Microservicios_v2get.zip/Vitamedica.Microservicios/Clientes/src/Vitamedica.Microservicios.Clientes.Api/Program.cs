using Vitamedica.Microservicios.Clientes.Application;
using Vitamedica.Microservicios.Clientes.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// La API de este microservicio solo conoce estos dos puntos de entrada.
builder.Services.AddApplication();
builder.Services.AddInfrastructure(builder.Configuration);

var app = builder.Build();

// Sin migraciones ni seed: este microservicio es de SOLO LECTURA contra
// una tabla real (MPR_ASAS_MASEGURADO) que ya existe y no le pertenece.

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();

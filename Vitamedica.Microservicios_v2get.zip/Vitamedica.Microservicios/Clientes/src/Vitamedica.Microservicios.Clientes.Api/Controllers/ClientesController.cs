using Microsoft.AspNetCore.Mvc;
using Vitamedica.Microservicios.Clientes.Application.Clientes.Queries;

namespace Vitamedica.Microservicios.Clientes.Api.Controllers;

/// <summary>
/// Demo de consulta de solo lectura contra el asegurado real
/// (tabla MPR_ASAS_MASEGURADO, base MprConfiguracion). El controlador es
/// delgado: arma la Query, llama al handler de Application y traduce el
/// resultado a un código HTTP. No contiene lógica de negocio.
/// </summary>
[ApiController]
[Route("api/[controller]")]
public class ClientesController : ControllerBase
{
    private readonly ObtenerClientePorIdQueryHandler _obtenerPorId;
    private readonly ListarClientesQueryHandler _listar;

    public ClientesController(
        ObtenerClientePorIdQueryHandler obtenerPorId,
        ListarClientesQueryHandler listar)
    {
        _obtenerPorId = obtenerPorId;
        _listar = listar;
    }

    /// <summary>GET /api/clientes — lista todos los registros existentes en la tabla real.</summary>
    [HttpGet]
    public async Task<IActionResult> Listar(CancellationToken ct)
    {
        var clientes = await _listar.HandleAsync(new ListarClientesQuery(), ct);
        return Ok(clientes);
    }

    /// <summary>GET /api/clientes/{id} — consulta por ASAS_NID (llave real de la tabla).</summary>
    [HttpGet("{id:int}")]
    public async Task<IActionResult> ObtenerPorId(int id, CancellationToken ct)
    {
        var resultado = await _obtenerPorId.HandleAsync(new ObtenerClientePorIdQuery(id), ct);
        return resultado.EsExitoso ? Ok(resultado.Valor) : NotFound(new { error = resultado.Error });
    }
}

using Microsoft.Extensions.DependencyInjection;
using Vitamedica.Microservicios.Clientes.Application.Clientes.Queries;

namespace Vitamedica.Microservicios.Clientes.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddScoped<ObtenerClientePorIdQueryHandler>();
        services.AddScoped<ListarClientesQueryHandler>();

        return services;
    }
}

using Vitamedica.Microservicios.Clientes.Application.Common.Abstractions;
using Vitamedica.Microservicios.Clientes.Application.Dtos;
using Vitamedica.Microservicios.Clientes.Domain.Repositories;

namespace Vitamedica.Microservicios.Clientes.Application.Clientes.Queries;

public class ListarClientesQueryHandler
    : IQueryHandler<ListarClientesQuery, IReadOnlyList<ClienteDto>>
{
    private readonly IClienteRepository _repository;

    public ListarClientesQueryHandler(IClienteRepository repository)
    {
        _repository = repository;
    }

    public async Task<IReadOnlyList<ClienteDto>> HandleAsync(
        ListarClientesQuery query, CancellationToken ct = default)
    {
        var clientes = await _repository.ObtenerTodosAsync(ct);
        return clientes.Select(c => c.ADto()).ToList();
    }
}

namespace Vitamedica.Microservicios.Clientes.Application.Clientes.Queries;

public record ObtenerClientePorIdQuery(int Id);

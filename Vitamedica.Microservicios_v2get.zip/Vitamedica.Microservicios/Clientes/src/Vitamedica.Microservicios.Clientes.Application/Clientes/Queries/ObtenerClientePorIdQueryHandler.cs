using Vitamedica.Microservicios.Clientes.Application.Common.Abstractions;
using Vitamedica.Microservicios.Clientes.Application.Dtos;
using Vitamedica.Microservicios.Clientes.Domain.Repositories;

namespace Vitamedica.Microservicios.Clientes.Application.Clientes.Queries;

public class ObtenerClientePorIdQueryHandler
    : IQueryHandler<ObtenerClientePorIdQuery, Result<ClienteDto>>
{
    private readonly IClienteRepository _repository;

    public ObtenerClientePorIdQueryHandler(IClienteRepository repository)
    {
        _repository = repository;
    }

    public async Task<Result<ClienteDto>> HandleAsync(
        ObtenerClientePorIdQuery query, CancellationToken ct = default)
    {
        var cliente = await _repository.ObtenerPorIdAsync(query.Id, ct);

        return cliente is null
            ? Result<ClienteDto>.Fallido($"No existe un cliente con id '{query.Id}'")
            : Result<ClienteDto>.Exitoso(cliente.ADto());
    }
}

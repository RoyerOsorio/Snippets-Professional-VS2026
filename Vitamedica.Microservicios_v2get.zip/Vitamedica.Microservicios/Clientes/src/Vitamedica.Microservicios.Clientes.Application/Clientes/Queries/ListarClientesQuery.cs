namespace Vitamedica.Microservicios.Clientes.Application.Clientes.Queries;

public record ListarClientesQuery;

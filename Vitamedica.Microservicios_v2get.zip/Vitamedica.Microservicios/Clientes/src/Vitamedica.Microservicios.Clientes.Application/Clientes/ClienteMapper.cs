using Vitamedica.Microservicios.Clientes.Application.Dtos;
using Vitamedica.Microservicios.Clientes.Domain.Entities;

namespace Vitamedica.Microservicios.Clientes.Application.Clientes;

internal static class ClienteMapper
{
    public static ClienteDto ADto(this Cliente cliente) => new(
        cliente.Id,
        cliente.NombreCompleto,
        cliente.FechaNacimiento,
        cliente.GeneroId,
        cliente.Rfc,
        cliente.Curp);
}

namespace Vitamedica.Microservicios.Clientes.Application.Dtos;

/// <summary>
/// Forma de datos expuesta hacia afuera. Refleja los campos que
/// realmente existen hoy en MPR_ASAS_MASEGURADO.
/// </summary>
public record ClienteDto(
    int Id,
    string NombreCompleto,
    DateTime FechaNacimiento,
    byte GeneroId,
    string? Rfc,
    string? Curp);

namespace Vitamedica.Microservicios.Clientes.Application.Common.Abstractions;

/// <summary>
/// Evita que la API tenga que capturar DomainException directamente: los
/// handlers las atrapan y las traducen a un Result.Fallido con el mensaje
/// de negocio.
/// </summary>
public class Result
{
    public bool EsExitoso { get; }
    public string? Error { get; }

    protected Result(bool esExitoso, string? error)
    {
        EsExitoso = esExitoso;
        Error = error;
    }

    public static Result Exitoso() => new(true, null);
    public static Result Fallido(string error) => new(false, error);
}

public class Result<T> : Result
{
    public T? Valor { get; }

    private Result(bool esExitoso, T? valor, string? error) : base(esExitoso, error)
    {
        Valor = valor;
    }

    public static Result<T> Exitoso(T valor) => new(true, valor, null);
    public static new Result<T> Fallido(string error) => new(false, default, error);
}

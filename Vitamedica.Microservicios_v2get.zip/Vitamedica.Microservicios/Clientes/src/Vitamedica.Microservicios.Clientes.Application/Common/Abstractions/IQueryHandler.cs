namespace Vitamedica.Microservicios.Clientes.Application.Common.Abstractions;

/// <summary>
/// Abstracción mínima de CQRS (sin dependencias externas tipo MediatR).
/// Este microservicio, al ser de solo consulta en esta primera entrega,
/// únicamente necesita IQueryHandler; ICommandHandler se agrega cuando se
/// implemente el alta/actualización real de Clientes.
/// </summary>
public interface IQueryHandler<in TQuery, TResult>
{
    Task<TResult> HandleAsync(TQuery query, CancellationToken ct = default);
}

using Vitamedica.Microservicios.Clientes.Domain.Entities;

namespace Vitamedica.Microservicios.Clientes.Domain.Repositories;

/// <summary>
/// Contrato de SOLO LECTURA (sin Agregar/Actualizar) porque este
/// microservicio consulta datos de un sistema externo del que no es
/// dueño (tabla MPR_ASAS_MASEGURADO). Hoy lo implementa Infrastructure
/// con EF Core apuntando directo a esa tabla real; a futuro podría
/// cambiar a un cliente HTTP hacia el sistema dueño de esos datos, sin
/// tocar Domain ni Application.
/// </summary>
public interface IClienteRepository
{
    Task<Cliente?> ObtenerPorIdAsync(int id, CancellationToken ct = default);
    Task<IReadOnlyList<Cliente>> ObtenerTodosAsync(CancellationToken ct = default);
}

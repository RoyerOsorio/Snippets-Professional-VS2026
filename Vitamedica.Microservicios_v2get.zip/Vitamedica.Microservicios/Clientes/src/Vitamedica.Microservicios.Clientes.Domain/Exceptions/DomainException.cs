namespace Vitamedica.Microservicios.Clientes.Domain.Exceptions;

/// <summary>
/// Excepción base para violaciones de reglas de negocio del dominio de
/// Clientes (ej. nómina inválida, Cliente no vigente).
/// </summary>
public class DomainException : Exception
{
    public DomainException(string message) : base(message)
    {
    }
}

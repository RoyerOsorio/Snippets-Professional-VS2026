namespace Vitamedica.Microservicios.Clientes.Domain.Entities;

/// <summary>
/// Proyección de SOLO LECTURA del asegurado real (tabla
/// MPR_ASAS_MASEGURADO de la base MprConfiguracion). Este microservicio
/// NO es dueño de estos datos — son propiedad de otro sistema — por eso
/// no expone métodos que muten estado (a diferencia de un Aggregate Root
/// clásico con reglas de negocio propias).
///
/// Campos disponibles hoy en la tabla real: nombre/apellidos, fecha de
/// nacimiento, género, RFC y CURP. NO incluye email, número de
/// nómina/certificado ni "vigencia" — esos viven en tablas relacionadas
/// (MPR_ASCR_RASEGURADO_CERTIFICADO, MPR_PLCR_3POLIZA_CERTIFICADO,
/// MPR_GRGR_CGRUPO) que se pueden incorporar en una siguiente iteración
/// vía join, una vez validado este flujo de lectura básico.
/// </summary>
public class Cliente
{
    public int Id { get; private set; }
    public string Nombre { get; private set; } = null!;
    public string ApellidoPaterno { get; private set; } = null!;
    public string ApellidoMaterno { get; private set; } = null!;
    public DateTime FechaNacimiento { get; private set; }
    public byte GeneroId { get; private set; }
    public string? Rfc { get; private set; }
    public string? Curp { get; private set; }

    private Cliente() { } // requerido por EF Core para materializar desde la tabla real

    /// <summary>
    /// Constructor interno solo para pruebas unitarias (ver
    /// InternalsVisibleTo en el .csproj) — en producción, la única forma
    /// de obtener un Cliente es a través de IClienteRepository.
    /// </summary>
    internal Cliente(int id, string nombre, string apellidoPaterno, string apellidoMaterno,
        DateTime fechaNacimiento, byte generoId, string? rfc, string? curp)
    {
        Id = id;
        Nombre = nombre;
        ApellidoPaterno = apellidoPaterno;
        ApellidoMaterno = apellidoMaterno;
        FechaNacimiento = fechaNacimiento;
        GeneroId = generoId;
        Rfc = rfc;
        Curp = curp;
    }

    public string NombreCompleto => $"{Nombre} {ApellidoPaterno} {ApellidoMaterno}".Trim();
}

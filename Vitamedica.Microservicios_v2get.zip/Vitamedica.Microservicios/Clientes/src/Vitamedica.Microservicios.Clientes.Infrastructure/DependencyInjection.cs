using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Vitamedica.Microservicios.Clientes.Domain.Repositories;
using Vitamedica.Microservicios.Clientes.Infrastructure.Persistence;
using Vitamedica.Microservicios.Clientes.Infrastructure.Persistence.Repositories;

namespace Vitamedica.Microservicios.Clientes.Infrastructure;

public static class DependencyInjection
{
    /// <summary>
    /// Recibe IConfiguration porque la cadena de conexión es un detalle de
    /// configuración del entorno (appsettings.json / variables de entorno /
    /// User Secrets), nunca un valor hardcodeado en Infrastructure.
    ///
    /// No se registran migraciones ni seed: la tabla MPR_ASAS_MASEGURADO ya
    /// existe en la base real y este microservicio solo la lee.
    /// </summary>
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("ClientesDb")
            ?? throw new InvalidOperationException("Falta configurar la cadena de conexión 'ClientesDb'");

        services.AddDbContext<AppDbContext>(options =>
            options.UseSqlServer(connectionString));

        services.AddScoped<IClienteRepository, ClienteRepository>();

        return services;
    }
}

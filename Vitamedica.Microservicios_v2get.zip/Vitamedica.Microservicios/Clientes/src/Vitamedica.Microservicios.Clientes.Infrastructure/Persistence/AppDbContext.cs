using Microsoft.EntityFrameworkCore;
using Vitamedica.Microservicios.Clientes.Domain.Entities;

namespace Vitamedica.Microservicios.Clientes.Infrastructure.Persistence;

/// <summary>
/// Único punto donde este microservicio sabe que hoy persiste con EF Core
/// contra SQL Server (base MprConfiguracion, tabla real
/// MPR_ASAS_MASEGURADO). Domain y Application no tienen ninguna
/// referencia a Microsoft.EntityFrameworkCore.
///
/// Este DbContext es de SOLO LECTURA: no se generan migraciones para él
/// (la tabla ya existe y es de otro sistema) y las consultas usan
/// AsNoTracking por defecto para evitar el overhead de change tracking
/// que no se necesita en un escenario que nunca escribe.
/// </summary>
public class AppDbContext : DbContext
{
    public DbSet<Cliente> Clientes => Set<Cliente>();

    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
    }
}

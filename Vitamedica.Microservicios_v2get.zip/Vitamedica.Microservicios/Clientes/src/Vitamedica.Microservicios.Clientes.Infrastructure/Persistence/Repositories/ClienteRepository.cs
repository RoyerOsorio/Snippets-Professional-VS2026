using Microsoft.EntityFrameworkCore;
using Vitamedica.Microservicios.Clientes.Domain.Entities;
using Vitamedica.Microservicios.Clientes.Domain.Repositories;

namespace Vitamedica.Microservicios.Clientes.Infrastructure.Persistence.Repositories;

/// <summary>
/// Implementación de SOLO LECTURA contra la tabla real MPR_ASAS_MASEGURADO
/// (base MprConfiguracion). No expone Agregar/Actualizar porque este
/// microservicio no es dueño de esos datos. Si en el futuro cambia la
/// fuente (ej. a un cliente HTTP hacia el sistema dueño), solo se
/// reemplaza esta clase — Domain y Application quedan intactos.
/// </summary>
public class ClienteRepository : IClienteRepository
{
    private readonly AppDbContext _context;

    public ClienteRepository(AppDbContext context)
    {
        _context = context;
    }

    public Task<Cliente?> ObtenerPorIdAsync(int id, CancellationToken ct = default)
        => _context.Clientes.FirstOrDefaultAsync(c => c.Id == id, ct);

    public async Task<IReadOnlyList<Cliente>> ObtenerTodosAsync(CancellationToken ct = default)
        => await _context.Clientes.ToListAsync(ct);
}

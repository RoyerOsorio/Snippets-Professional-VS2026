using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vitamedica.Microservicios.Clientes.Domain.Entities;

namespace Vitamedica.Microservicios.Clientes.Infrastructure.Persistence.Configurations;

/// <summary>
/// Mapea Cliente directamente a la tabla real MPR_ASAS_MASEGURADO
/// (base MprConfiguracion). NO se generan migraciones para esta entidad
/// — la tabla ya existe y es propiedad de otro sistema; este
/// microservicio solo lee. Ver README de la solución para el detalle de
/// por qué se optó por esta integración de solo lectura.
/// </summary>
public class ClienteConfiguration : IEntityTypeConfiguration<Cliente>
{
    public void Configure(EntityTypeBuilder<Cliente> builder)
    {
        builder.ToTable("MPR_ASAS_MASEGURADO");

        builder.HasKey(c => c.Id);
        builder.Property(c => c.Id).HasColumnName("ASAS_NID");

        builder.Property(c => c.Nombre).HasColumnName("ASAS_NOMBRE").HasMaxLength(50).IsRequired();
        builder.Property(c => c.ApellidoPaterno).HasColumnName("ASAS_APPATERNO").HasMaxLength(50).IsRequired();
        builder.Property(c => c.ApellidoMaterno).HasColumnName("ASAS_APMATERNO").HasMaxLength(50).IsRequired();
        builder.Property(c => c.FechaNacimiento).HasColumnName("ASAS_FECHA_NACIMIENTO").IsRequired();
        builder.Property(c => c.GeneroId).HasColumnName("GEGE_NID").IsRequired();
        builder.Property(c => c.Rfc).HasColumnName("ASAS_RFC").HasMaxLength(20);
        builder.Property(c => c.Curp).HasColumnName("ASAS_CURP").HasMaxLength(20);

        // La propiedad calculada NombreCompleto no existe como columna.
        builder.Ignore(c => c.NombreCompleto);
    }
}

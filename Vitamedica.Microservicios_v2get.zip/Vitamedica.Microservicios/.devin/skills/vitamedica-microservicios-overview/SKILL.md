---
name: vitamedica-microservicios-overview
description: Contexto de arquitectura del repositorio Vitamedica.Microservicios (migración incremental de ReembolsoGModelo a microservicios con Clean Architecture + SOLID)
triggers:
  - user
  - model
---

Este skill resume el análisis y las decisiones tomadas sobre el repositorio
`Vitamedica.Microservicios`. Úsalo como contexto rápido antes de explorar el
código o de responder preguntas sobre la arquitectura, en lugar de
re-explorar todo desde cero.

## Convención al dar referencias de código (archivo-clase-método)

Igual que en el skill `reembolso-gmodelo-overview` del repo `ReembolsoGModelo`:
cuando se pida ubicar una funcionalidad, responde con **ruta de archivo
completa** (incluyendo el proyecto), **clase**, **método/línea aproximada**,
y aclara si hay ambigüedad con nombres repetidos entre microservicios.

## Qué es este repositorio

`Vitamedica.Microservicios` es el repositorio destino de la migración
incremental de `ReembolsoGModelo` (sistema monolítico .NET Framework 4.8,
ver skill `reembolso-gmodelo-overview` en ese repo) hacia una **arquitectura
de microservicios**. Cada microservicio implementa internamente **Clean
Architecture** (Domain → Application → Infrastructure → Api, las
dependencias siempre apuntan hacia Domain) + **SOLID**, y es una **solución
.NET independiente** (su propio `.slnx`, sin referencias de proyecto
cruzadas con otros microservicios — la comunicación futura entre ellos será
vía HTTP/gRPC o mensajería, nunca referencias directas de ensamblado).

Ver `README.md` en la raíz de este repo para la tabla completa de
microservicios planeados (Clientes ✅, Reembolso/Grupo Modelo G, Tesorería,
Autenticación, Notificaciones).

## Microservicio `Clientes` (único implementado hasta ahora)

Ruta: `C:\source\Vitamedica.Microservicios\Clientes\`
Solución: `Vitamedica.Microservicios.Clientes.slnx`

### Qué hace

Consulta de **solo lectura** contra la tabla real `MPR_ASAS_MASEGURADO`
("maestro de asegurado") de la base **`MprConfiguracion`** en el servidor
`10.34.62.102` (SQL Server). **Este microservicio NO es dueño de esos
datos** — son de otro sistema — por eso:
- No se generaron migraciones EF Core para esta tabla (ya existe).
- El repositorio (`IClienteRepository`) solo expone `ObtenerPorIdAsync` /
  `ObtenerTodosAsync`, sin `Agregar`/`Actualizar`.
- El usuario de conexión (`uf_mprconfiguracion`) de hecho **no tiene permiso
  `CREATE TABLE`** en esa base — se confirmó al intentar aplicar una
  migración (Error 262 de SQL Server), lo cual es consistente con ser un
  usuario de aplicación de solo lectura/escritura sobre tablas existentes,
  no un usuario de DDL.

### Campos reales disponibles (verificado contra `INFORMATION_SCHEMA.COLUMNS`)

`MPR_ASAS_MASEGURADO` tiene: `ASAS_NID` (PK, int), `ASAS_NOMBRE`,
`ASAS_APPATERNO`, `ASAS_APMATERNO`, `ASAS_FECHA_NACIMIENTO`, `GEGE_NID`
(género, catálogo en `MPR_GEGE_CGENERO`), `ASAS_RFC`, `ASAS_CURP`.

**No tiene** email, ni número de nómina/certificado directo, ni bandera de
"vigente". El número de certificado vive en `MPR_ASCR_RASEGURADO_CERTIFICADO`
→ `MPR_PLCR_3POLIZA_CERTIFICADO` (columna `PLCR_CERTIFICADO`), y el grupo en
`MPR_GRGR_CGRUPO`, ambas relacionadas por cadenas de FKs — **pendientes de
incorporar** en una siguiente iteración (requieren joins, no están en el
Domain actual). No inventes estos campos si te piden extender el modelo:
verifica primero contra el catálogo real (`INFORMATION_SCHEMA`) como se hizo
aquí, en vez de asumir que existen como en el primer borrador (que sí
inventó Email/Nomina/GrupoModelo/Vigente con datos de ejemplo — ese enfoque
se descartó a favor de leer la tabla real).

### Estructura de capas

```
Clientes/
├── Vitamedica.Microservicios.Clientes.slnx
├── src/
│   ├── ...Domain          — Entities/Cliente.cs (proyección de solo lectura,
│   │                        constructor internal solo para tests vía
│   │                        InternalsVisibleTo), Repositories/IClienteRepository.cs
│   ├── ...Application     — Dtos/ClienteDto.cs, Clientes/Queries/
│   │                        (ObtenerClientePorIdQuery, ListarClientesQuery + handlers),
│   │                        Common/Abstractions/ (Result, IQueryHandler)
│   ├── ...Infrastructure  — Persistence/AppDbContext.cs (EF Core + SQL Server,
│   │                        QueryTrackingBehavior.NoTracking), Persistence/Configurations/
│   │                        ClienteConfiguration.cs (mapea a MPR_ASAS_MASEGURADO
│   │                        vía Fluent API con nombres de columna reales),
│   │                        Persistence/Repositories/ClienteRepository.cs
│   └── ...Api             — Controllers/ClientesController.cs, Program.cs
└── tests/...Domain.Tests  — ClienteTests.cs (3 pruebas, solo valida
                             NombreCompleto y asignación de propiedades —
                             no hay invariantes de negocio propias porque
                             Domain no es dueño de estos datos)
```

### Configuración / credenciales (IMPORTANTE — no repetir la contraseña aquí)

La cadena de conexión real vive en
`src\Vitamedica.Microservicios.Clientes.Api\appsettings.Development.json`
bajo `ConnectionStrings:ClientesDb`. **No copies la contraseña en este
archivo de skill ni en ningún otro documento que pueda compartirse** — si
necesitas la cadena de conexión, lee directamente ese `appsettings.Development.json`.
Si este repo se llega a compartir o subir a un control de versiones
compartido, esa credencial debe rotarse (mismo criterio que ya se documentó
para el monolito `ReembolsoGModelo` en su propio skill).

### Punto de entrada / cómo depurar paso a paso

1. **Proyecto de inicio**: `Vitamedica.Microservicios.Clientes.Api` (el único
   ejecutable de los 5 proyectos de la solución).
2. **`Program.cs`** (`src\Vitamedica.Microservicios.Clientes.Api\Program.cs`)
   es el punto de entrada real (top-level statements). Ahí se registran
   `AddApplication()` y `AddInfrastructure(builder.Configuration)`. No hay
   `Database.Migrate()` ni seed — se quitaron a propósito (ver sección de
   arriba, es de solo lectura contra una tabla que ya existe).
3. **Para depurar un request específico**, el mejor primer breakpoint está
   en el controlador, no en `Program.cs`:
   `Controllers\ClientesController.cs` → método `Listar()` (línea ~31) o
   `ObtenerPorId()` (línea ~39).
4. **Cadena a recorrer con Step Into (F11)** desde ese breakpoint:
   ```
   ClientesController.Listar()/ObtenerPorId()
      └─ ListarClientesQueryHandler / ObtenerClientePorIdQueryHandler .HandleAsync()   (Application)
           └─ IClienteRepository.ObtenerTodosAsync()/ObtenerPorIdAsync()
                └─ ClienteRepository (Infrastructure) — aquí se ejecuta el SELECT real contra SQL Server
           └─ ClienteMapper.ADto()                                                     (mapeo Entity → DTO)
   ```

### Endpoints disponibles

- `GET /api/clientes` — lista todos los registros (hoy 7 filas reales).
- `GET /api/clientes/{id}` — consulta por `ASAS_NID`. 404 si no existe.

## Historial relevante de decisiones (para no repetir errores ya resueltos)

- **Owned types de EF Core no deben compartirse por referencia entre
  distintos dueños**: en una versión anterior del seed (con datos de
  ejemplo, ya descartada), reutilizar la misma instancia de un Value Object
  (`GrupoModelo`) para varios agregados corrompía el tracking y causaba
  `NullReferenceException` intermitente. Si en el futuro se vuelve a usar
  owned types (ej. para modelar `CuentaBancaria` en el microservicio de
  Reembolso), crear siempre una instancia nueva por cada dueño.
- **El usuario de conexión de `Clientes` no tiene permiso `CREATE TABLE`**
  en `MprConfiguracion` — cualquier intento de agregar/aplicar migraciones
  fallará con Error 262 de SQL Server. Este microservicio es y debe seguir
  siendo de solo lectura sobre esa base.
- **`dotnet-ef` requiere el paquete `Microsoft.EntityFrameworkCore.Design`
  tanto en el proyecto con el DbContext (Infrastructure) como en el
  proyecto de arranque (Api)** — si solo se agrega en uno, el comando
  `dotnet ef` falla pidiendo la referencia en el proyecto de inicio.

/* ============================================================================
   detalle-asegurado.js — Interacciones EXCLUSIVAS de Views/Home/DetalleAsegurado.
   Lo genérico (acordeón de doc-block, modal ICD/CPT, modal Histórico ICD) ya
   vive en reembolso-solicitud.js y detalle-solicitud.js y se reutiliza tal
   cual desde la vista (ver @section Scripts) — no se duplica aquí. Este
   archivo solo resuelve lo que es propio de esta pantalla:
     1) Tabs de estatus del trámite (visual, sin cambio de contenido).
     2) Fila agrupadora/fila hija dentro de la tabla de Factura.
   Sin lógica de negocio ni llamadas a datos reales.
   ============================================================================ */
(function () {
    "use strict";

    document.addEventListener("DOMContentLoaded", function () {
        initStatusTabs();
        initClaimTableGroups();
        if (window.VM && typeof window.VM.refreshIcons === "function") {
            window.VM.refreshIcons();
        }
    });

    // ---- 1. Tabs de estatus del trámite ----
    function initStatusTabs() {
        var tabs = document.querySelectorAll(".status-tabs .status-tab");
        if (!tabs.length) return;

        tabs.forEach(function (tab) {
            tab.addEventListener("click", function () {
                tabs.forEach(function (t) {
                    var selected = t === tab;
                    t.classList.toggle("is-active", selected);
                    t.setAttribute("aria-selected", String(selected));
                });
            });
        });
    }

    // ---- 2. Fila agrupadora + fila hija dentro de claim-table (Factura) ----
    function initClaimTableGroups() {
        document.querySelectorAll("[data-claim-row-toggle]").forEach(function (toggle) {
            var childRow = document.getElementById(toggle.getAttribute("aria-controls"));
            if (!childRow) return;

            toggle.addEventListener("click", function () {
                var expanded = toggle.getAttribute("aria-expanded") === "true";
                toggle.setAttribute("aria-expanded", String(!expanded));
                childRow.hidden = expanded;
            });
        });
    }
})();

using FluentAssertions;
using MprAuditoria.Application.Casos;
using MprAuditoria.Application.Puertos;
using MprAuditoria.Domain.Entidades;
using Xunit;

namespace MprAuditoria.Application.Tests;

public class ObtenerTimelineReclamoCasoDeUsoTests
{
    private sealed class RepositorioFalso(IReadOnlyList<EventoAuditoria> eventos) : IRepositorioEventosAuditoria
    {
        public Task<EventoAuditoria?> ObtenerPorMensajeIdOrigenAsync(long mensajeIdOrigen, CancellationToken cancellationToken) =>
            Task.FromResult<EventoAuditoria?>(null);

        public Task<EventoAuditoria> RegistrarAsync(EventoAuditoria evento, CancellationToken cancellationToken) =>
            throw new NotSupportedException();

        public Task<IReadOnlyList<EventoAuditoria>> ObtenerTimelinePorReclamoAsync(int reclamoId, CancellationToken cancellationToken) =>
            Task.FromResult(eventos.Where(e => e.ReclamoId == reclamoId).ToList() as IReadOnlyList<EventoAuditoria>);
    }

    private static readonly DateTime Ahora = new(2026, 8, 18, 12, 0, 0, DateTimeKind.Utc);

    [Fact]
    public async Task Devuelve_los_eventos_de_un_Reclamo_ordenados_por_fecha_de_ocurrencia()
    {
        var segundo = new EventoAuditoria(2, 100, "PagoCompletado", 1, "{}", Ahora.AddHours(1), Ahora.AddHours(1));
        var primero = new EventoAuditoria(1, 99, "ReclamoAprobadoParaPago", 1, "{}", Ahora, Ahora);
        var repositorio = new RepositorioFalso([segundo, primero]);
        var casoDeUso = new ObtenerTimelineReclamoCasoDeUso(repositorio);

        var resultado = await casoDeUso.EjecutarAsync(1, CancellationToken.None);

        resultado.Should().HaveCount(2);
        resultado[0].TipoEvento.Should().Be("ReclamoAprobadoParaPago");
        resultado[1].TipoEvento.Should().Be("PagoCompletado");
    }

    [Fact]
    public async Task Devuelve_lista_vacia_si_el_Reclamo_no_tiene_eventos()
    {
        var repositorio = new RepositorioFalso([]);
        var casoDeUso = new ObtenerTimelineReclamoCasoDeUso(repositorio);

        var resultado = await casoDeUso.EjecutarAsync(1, CancellationToken.None);

        resultado.Should().BeEmpty();
    }
}

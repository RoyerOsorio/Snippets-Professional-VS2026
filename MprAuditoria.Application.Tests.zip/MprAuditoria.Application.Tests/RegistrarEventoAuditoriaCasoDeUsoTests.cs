using FluentAssertions;
using MprAuditoria.Application.Casos;
using MprAuditoria.Application.Puertos;
using MprAuditoria.Domain.Entidades;
using Xunit;

namespace MprAuditoria.Application.Tests;

public class RegistrarEventoAuditoriaCasoDeUsoTests
{
    private sealed class RepositorioFalso : IRepositorioEventosAuditoria
    {
        private long siguienteId = 1;
        public List<EventoAuditoria> Registrados { get; } = [];

        public Task<EventoAuditoria?> ObtenerPorMensajeIdOrigenAsync(long mensajeIdOrigen, CancellationToken cancellationToken) =>
            Task.FromResult(Registrados.FirstOrDefault(e => e.MensajeIdOrigen == mensajeIdOrigen));

        public Task<EventoAuditoria> RegistrarAsync(EventoAuditoria evento, CancellationToken cancellationToken)
        {
            var conId = new EventoAuditoria(
                siguienteId++, evento.MensajeIdOrigen, evento.TipoEvento, evento.ReclamoId,
                evento.PayloadJson, evento.FechaOcurrencia, evento.FechaRegistro);
            Registrados.Add(conId);
            return Task.FromResult(conId);
        }

        public Task<IReadOnlyList<EventoAuditoria>> ObtenerTimelinePorReclamoAsync(int reclamoId, CancellationToken cancellationToken) =>
            Task.FromResult<IReadOnlyList<EventoAuditoria>>(Registrados.Where(e => e.ReclamoId == reclamoId).ToList());
    }

    private static readonly DateTime Ahora = new(2026, 8, 18, 12, 0, 0, DateTimeKind.Utc);

    [Fact]
    public async Task Registra_un_evento_nuevo_cuando_el_mensaje_no_se_habia_procesado()
    {
        var repositorio = new RepositorioFalso();
        var casoDeUso = new RegistrarEventoAuditoriaCasoDeUso(repositorio);

        var resultado = await casoDeUso.EjecutarAsync(99, "ReclamoAprobadoParaPago", 1, "{}", Ahora, Ahora, CancellationToken.None);

        resultado.Id.Should().BeGreaterThan(0);
        repositorio.Registrados.Should().HaveCount(1);
    }

    [Fact]
    public async Task Es_idempotente_ante_el_mismo_MensajeIdOrigen()
    {
        var repositorio = new RepositorioFalso();
        var casoDeUso = new RegistrarEventoAuditoriaCasoDeUso(repositorio);

        var primero = await casoDeUso.EjecutarAsync(99, "PagoCompletado", 1, "{}", Ahora, Ahora, CancellationToken.None);
        var segundo = await casoDeUso.EjecutarAsync(99, "PagoCompletado", 1, "{}", Ahora, Ahora, CancellationToken.None);

        segundo.Id.Should().Be(primero.Id);
        repositorio.Registrados.Should().HaveCount(1);
    }
}

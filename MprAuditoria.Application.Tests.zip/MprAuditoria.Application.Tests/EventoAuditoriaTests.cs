using FluentAssertions;
using MprAuditoria.Domain.Entidades;
using Xunit;

namespace MprAuditoria.Application.Tests;

public class EventoAuditoriaTests
{
    private static readonly DateTime Ahora = new(2026, 8, 18, 12, 0, 0, DateTimeKind.Utc);

    [Fact]
    public void Registrar_crea_un_evento_con_los_datos_provistos()
    {
        var evento = EventoAuditoria.Registrar(99, "ReclamoAprobadoParaPago", 1, "{\"ReclamoId\":1}", Ahora, Ahora.AddSeconds(1));

        evento.MensajeIdOrigen.Should().Be(99);
        evento.TipoEvento.Should().Be("ReclamoAprobadoParaPago");
        evento.ReclamoId.Should().Be(1);
        evento.FechaOcurrencia.Should().Be(Ahora);
        evento.FechaRegistro.Should().Be(Ahora.AddSeconds(1));
    }

    [Fact]
    public void Registrar_lanza_excepcion_si_el_tipo_de_evento_esta_vacio()
    {
        var accion = () => EventoAuditoria.Registrar(99, "  ", 1, "{}", Ahora, Ahora);

        accion.Should().Throw<ArgumentException>();
    }

    [Fact]
    public void Registrar_lanza_excepcion_si_el_payload_esta_vacio()
    {
        var accion = () => EventoAuditoria.Registrar(99, "PagoCompletado", 1, "", Ahora, Ahora);

        accion.Should().Throw<ArgumentException>();
    }
}

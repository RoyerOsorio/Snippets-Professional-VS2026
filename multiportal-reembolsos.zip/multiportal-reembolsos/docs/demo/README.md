# Ejercicio técnico: arquitectura de microservicios — Multiportal de Reembolsos

## 1. Propósito

Demo técnica ejecutable end-to-end del rumbo arquitectónico decidido por
gerencia: pasar de `Vitamedica.Multiportal` (monolito MVC + API + Application
+ Domain + Infrastructure) hacia microservicios. Este repositorio es un
**vertical slice incremental**, no el sistema completo — construye
microservicios reales uno a la vez (MprClientes, MprConfiguracionReglas,
MprGestionReclamos, MprDocumentos) con Gateway y Orchestrator reales, y
documenta explícitamente qué falta para los demás servicios en vez de
simularlo.

## 2. Alcance actual — qué es real y qué es próximo paso

| Pieza | Estado |
|---|---|
| MprClientes (Api/Application/Domain/Infrastructure/Contracts) | **Real**, con SQL Server, EF Core Database First, Clean Architecture híbrida + Hexagonal |
| MprConfiguracionReglas (Api/Application/Domain/Infrastructure/Contracts) | **Real**, mismo patrón que MprClientes — reglas de reembolso, documentos requeridos, flujo con `RequiereDictamenMedico` |
| MprGestionReclamos (Api/Application/Domain/Infrastructure/Contracts) | **Real** — ciclo de vida del Reclamo (`CrearReclamo`, `EnviarReclamo`, `AprobarReclamo`, `RechazarReclamo`) con Transactional Outbox y publicación a RabbitMQ |
| MprDocumentos (Api/Application/Domain/Infrastructure/Contracts) | **Real** — `SubirDocumento`/`ListarDocumentosPorReclamo`/`ObtenerDocumento`/`EliminarDocumento`; metadata en SQL Server, contenido físico en disco local (**DEMO-ONLY/PROPUESTO**, ver `deploy/sql/MprDocumentos/README.md`). **Conectado** a `EnviarReclamoCasoDeUso` de MprGestionReclamos (ver DEC-005) — todavía **no invocado** por el Orchestrator |
| RabbitMQ | **Real** (contenedor en docker-compose) — MprGestionReclamos publica `ReclamoAprobadoParaPago`; **sin consumidores reales todavía** (MprPagos/MprAuditoria no existen). MprDocumentos no publica eventos en el alcance actual (ver `MprDocumentos.Infrastructure.csproj`) |
| Multiportal.ApiGateway (YARP) | **Real**, enruta `/api/clientes/*` → MprClientes, `/api/reglas/*` + `/api/flujos/*` → MprConfiguracionReglas, `/api/reclamos/*` → MprGestionReclamos, `/api/documentos/*` → MprDocumentos |
| Reimbursement.Orchestrator | **Real** para tres pasos (`ValidarContextoCliente`, `ObtenerReglaReembolso`, `CrearReclamo`, los dos últimos cuando se envía `motivoId`); los demás pasos están documentados como pendientes, no simulados (ver `src/orchestration/Reimbursement.Orchestrator/README.md`) |
| Vitamedica.Multiportal.UI | **Integrada de verdad**: `HomeController.Clientes()` ahora consulta MprClientes vía Gateway en vez de datos hardcodeados |
| MprPagos, MprAuditoria | **Pendientes** — ver Roadmap (sección 9) |
| Idempotencia de consumidores, Saga/compensaciones | **Pendientes** — no hay todavía ningún consumidor real de `ReclamoAprobadoParaPago` contra el cual validar idempotencia; la Saga solo tiene sentido cuando exista más de un paso compensable entre MprGestionReclamos, MprPagos y MprDocumentos |

Se optó deliberadamente por esta secuencia (un microservicio a la vez, no los
6 a la vez) para validar el patrón arquitectónico completo — Browser →
Gateway → Orchestrator/Servicio → SQL Server propio — antes de replicarlo el
resto de las veces. Ver sección 39 del gobierno del Project ("Principio de
patrón antes que pantalla").

## 3. Arquitectura

```mermaid
graph TD
    Browser["Browser"] --> UI["Vitamedica.Multiportal.UI (MVC/Razor)"]
    UI --> GW["Multiportal.ApiGateway (YARP)"]
    GW --> MC["MprClientes.Api"]
    GW --> MCR["MprConfiguracionReglas.Api"]
    GW --> MGR["MprGestionReclamos.Api"]
    GW --> MD["MprDocumentos.Api"]
    GW -.->|"ruta declarada, servicio pendiente"| ORQ["Reimbursement.Orchestrator"]
    ORQ --> MC
    ORQ --> MCR
    ORQ --> MGR
    ORQ -.->|"pendiente: Orchestrator todavía no llama a MprDocumentos"| MD
    MGR --> MD
    MC --> SQLMC[("SQL Server\nMprClientesDb")]
    MCR --> SQLMCR[("SQL Server\nMprConfiguracionReglasDb")]
    MGR --> SQLMGR[("SQL Server\nMprGestionReclamosDb")]
    MD --> SQLMD[("SQL Server\nMprDocumentosDb")]
    MD -.->|"DEMO-ONLY / PROPUESTO"| DISCO[("Disco local\n(volumen Docker)")]
    MGR --> MQ{{"RabbitMQ\n(ReclamoAprobadoParaPago)"}}
    MQ -.->|pendiente, sin consumidor| MP["MprPagos"]
    MQ -.->|pendiente, sin consumidor| MA["MprAuditoria"]

    classDef pendiente stroke-dasharray: 5 5;
    class ORQ,MP,MA pendiente;
```

Líneas punteadas = declarado/documentado pero no implementado todavía (o,
en el caso de `MprDocumentos → Disco local`, una decisión explícitamente
marcada como PROPUESTO/no definitiva). `MprGestionReclamos → RabbitMQ` es
línea sólida porque el publisher es real (Transactional Outbox) aunque
todavía no exista ningún consumidor. `MprGestionReclamos → MprDocumentos`
es ahora línea sólida: `EnviarReclamoCasoDeUso` consulta directamente a
MprDocumentos (ver DEC-005). La única conexión que sigue punteada es
`Orchestrator → MprDocumentos` — el flujo de `iniciar reembolso` todavía
no invoca la subida de documentos.

## 4. Diagrama de secuencia — flujo real implementado

```mermaid
sequenceDiagram
    participant U as Usuario
    participant UI as Vitamedica.Multiportal.UI
    participant GW as Multiportal.ApiGateway
    participant MC as MprClientes.Api
    participant DB as SQL Server (MprClientesDb)

    U->>UI: Abre pantalla Clientes
    UI->>GW: GET /api/clientes
    GW->>MC: GET /v1/clientes
    MC->>DB: SELECT MTP_GRGR_GRUPO (EF Core)
    DB-->>MC: Filas
    MC-->>GW: 200 OK [ClienteResponse]
    GW-->>UI: 200 OK
    UI-->>U: Lista de Clientes (real, no hardcodeada)

    Note over UI,MC: Paso adicional expuesto (aún no consumido por una<br/>pantalla de UI): ValidarContextoCliente + ObtenerReglaReembolso + CrearReclamo
    participant ORQ as Reimbursement.Orchestrator
    participant MCR as MprConfiguracionReglas.Api
    participant DBR as SQL Server (MprConfiguracionReglasDb)
    participant MGR as MprGestionReclamos.Api
    participant DBG as SQL Server (MprGestionReclamosDb)
    participant MQ2 as RabbitMQ
    U->>ORQ: POST /v1/reembolsos/iniciar {poliza, aseguradoId, motivoId}
    ORQ->>MC: GET /v1/clientes/contexto?poliza=...&aseguradoId=...
    MC->>DB: SELECT (Póliza+Vigencia+Certificado+Rol)
    DB-->>MC: Fila
    MC-->>ORQ: ContextoClienteResponse (EsVigente calculado en Domain)
    alt contexto vigente y motivoId enviado
        ORQ->>MCR: GET /v1/reglas/{motivoId}
        MCR->>DBR: SELECT MotivoReembolso + Documentos (EF Core)
        DBR-->>MCR: Filas
        MCR-->>ORQ: ReglaReembolsoResponse
        ORQ->>MGR: POST /v1/reclamos {poliza, aseguradoId, motivoId}
        MGR->>DBG: INSERT MTP_RCRC_MRECLAMO (estado=Creado)
        DBG-->>MGR: Reclamo creado
        MGR-->>ORQ: ReclamoResponse (Id, Estado=Creado)
    end
    ORQ-->>U: IniciarReembolsoResponse + SiguientesPasosPendientes

    participant MD as MprDocumentos.Api
    participant DBD as SQL Server (MprDocumentosDb)
    Note over MGR,DBD: Ciclo posterior (fuera del flujo de "iniciar",<br/>disparado por acciones separadas de usuario/UI):
    U->>MD: POST /v1/documentos/reclamos/{reclamoId} (multipart/form-data)
    MD->>MD: DocumentoReclamo.Subir (valida tamaño/tipo/nombre)
    MD->>MD: IAlmacenamientoArchivos.GuardarAsync (disco local, DEMO-ONLY)
    MD->>DBD: INSERT MTP_DOC_MDOCUMENTO (metadata + ruta)
    DBD-->>MD: Documento creado
    MD-->>U: 201 Created DocumentoResponse
    U->>MGR: POST /v1/reclamos/{id}/enviar
    MGR->>MD: GET /v1/documentos/reclamos/{id}
    MD-->>MGR: Documentos aportados (con DocumentoRequeridoId)
    MGR->>MCR: POST /v1/reglas/{motivoId}/validar-documentos
    MCR-->>MGR: Documentos obligatorios faltantes (vacío si todo OK)
    MGR->>DBG: UPDATE estado=EnviadoParaRevision (si no faltan documentos)
    U->>MGR: POST /v1/reclamos/{id}/aprobar {montoAprobado}
    MGR->>DBG: UPDATE estado=Aprobado + INSERT MTP_OBOX_MENSAJE (misma transacción)
    Note over MGR: OutboxPublisherHostedService (BackgroundService) sondea<br/>MTP_OBOX_MENSAJE y publica a RabbitMQ de forma asíncrona
    MGR-->>MQ2: ReclamoAprobadoParaPago (exchange multiportal.reembolsos)
```

## 5. Estructura del repositorio

```text
multiportal-reembolsos/
├── Multiportal.All.slnx
├── Directory.Build.props
├── src/
│   ├── frontend/                    → cambios aplicados directamente sobre
│   │                                   Vitamedica.Multiportal.UI (repo existente),
│   │                                   NO una copia — ver sección 6.
│   ├── gateway/Multiportal.ApiGateway/
│   ├── orchestration/Reimbursement.Orchestrator/
│   ├── services/MprClientes/
│   │   ├── MprClientes.Api/         (Minimal APIs)
│   │   ├── MprClientes.Application/ (casos de uso + puertos)
│   │   ├── MprClientes.Domain/      (Vigencia, ContextoContractualCliente)
│   │   ├── MprClientes.Infrastructure/ (EF Core Database First)
│   │   └── MprClientes.Contracts/   (DTOs públicos)
│   ├── services/MprConfiguracionReglas/
│   │   ├── MprConfiguracionReglas.Api/         (Minimal APIs)
│   │   ├── MprConfiguracionReglas.Application/ (casos de uso + puertos)
│   │   ├── MprConfiguracionReglas.Domain/      (ReglaReembolso, FlujoReembolso)
│   │   ├── MprConfiguracionReglas.Infrastructure/ (EF Core Database First)
│   │   └── MprConfiguracionReglas.Contracts/   (DTOs públicos)
│   ├── services/MprGestionReclamos/
│   │   ├── MprGestionReclamos.Api/         (Minimal APIs)
│   │   ├── MprGestionReclamos.Application/ (casos de uso + puertos, incl. evento ReclamoAprobadoParaPago)
│   │   ├── MprGestionReclamos.Domain/      (Reclamo, EstadoReclamo — máquina de estados)
│   │   ├── MprGestionReclamos.Infrastructure/ (EF Core Database First + Transactional Outbox + publisher RabbitMQ)
│   │   └── MprGestionReclamos.Contracts/   (DTOs públicos)
│   └── services/MprDocumentos/
│       ├── MprDocumentos.Api/         (Minimal APIs, endpoint multipart/form-data)
│       ├── MprDocumentos.Application/ (casos de uso + puertos, incl. IAlmacenamientoArchivos)
│       ├── MprDocumentos.Domain/      (DocumentoReclamo — validación de tamaño/tipo/nombre)
│       ├── MprDocumentos.Infrastructure/ (EF Core Database First + almacenamiento local DEMO-ONLY)
│       └── MprDocumentos.Contracts/   (DTOs públicos)
├── tests/
│   ├── services/MprClientes.Application.Tests/
│   ├── services/MprConfiguracionReglas.Application.Tests/
│   ├── services/MprGestionReclamos.Application.Tests/
│   ├── services/MprDocumentos.Application.Tests/
│   └── architecture/Multiportal.ArchitectureTests/
├── deploy/
│   ├── docker/docker-compose.yml
│   ├── sql/MprClientes/
│   ├── sql/MprConfiguracionReglas/
│   ├── sql/MprGestionReclamos/
│   ├── sql/MprDocumentos/
│   └── apim/README.md
└── docs/demo/README.md   (este archivo)
```

## 6. Cambios aplicados sobre Vitamedica.Multiportal.UI

Estos archivos se escribieron directamente en tu carpeta local
`Vitamedica.Multiportal.UI` (no viven dentro de este repo nuevo, para no
duplicar el proyecto UI):

- **Nuevo:** `Models/Multiportal/ClienteDto.cs`, `Services/ClientesApiClient.cs`
- **Modificado:** `Controllers/HomeController.cs` (`Clientes()` ahora es
  async y consulta datos reales), `Program.cs` (registro de
  `ClientesApiClient`), `appsettings.json` / `appsettings.Development.json`
  (`Apis:apiGateway:BaseUrl`)

Todos siguen el patrón `Browser → Controller → ApiClient tipado → API` ya
documentado en `UI_Architecture_Guide.md` sección 4 — no se introdujo ningún
patrón nuevo de comunicación. `CreacionCliente`/`DetalleCliente` **no** se
tocaron: dependen de catálogos (Módulos/Coberturas/Documentos) que
pertenecen a MprConfiguracionReglas, todavía no construido.

## 7. Ejecución local

### Opción A — Docker Compose (SQL Server ×4 + RabbitMQ + los 4 microservicios + Gateway)

```bash
cd deploy/docker
docker compose up --build
```

Levanta, en orden: `sqlserver-mprclientes` → `mprclientes-init-db` →
`mprclientes-api` (puerto 5101); `sqlserver-mprconfiguracionreglas` →
`mprconfiguracionreglas-init-db` → `mprconfiguracionreglas-api` (puerto
5102); `rabbitmq` (puerto 5672, consola en http://localhost:15672);
`sqlserver-mprdocumentos` → `mprdocumentos-init-db` → `mprdocumentos-api`
(puerto 5104, con un volumen Docker dedicado para el almacenamiento local
de archivos); `sqlserver-mprgestionreclamos` → `mprgestionreclamos-init-db`
→ `mprgestionreclamos-api` (puerto 5103, espera a `rabbitmq` sano y a que
`mprconfiguracionreglas-api` **y** `mprdocumentos-api` hayan arrancado —
`EnviarReclamoCasoDeUso` consulta a ambos, ver DEC-005); finalmente
`gateway` (puerto 5000), que depende de los cuatro microservicios. El
Orchestrator no está en este `docker-compose.yml` todavía — se ejecuta con
`dotnet run` (Opción B).

### Opción B — Visual Studio / dotnet CLI

```bash
# 1) SQL Server local ya corriendo, luego:
sqlcmd -S localhost -U sa -P <password> -i deploy/sql/MprClientes/00_crear_base.sql
sqlcmd -S localhost -U sa -P <password> -i deploy/sql/MprClientes/01_crear_tablas.sql
sqlcmd -S localhost -U sa -P <password> -i deploy/sql/MprClientes/02_datos_demo.sql
sqlcmd -S localhost -U sa -P <password> -i deploy/sql/MprConfiguracionReglas/00_crear_base.sql
sqlcmd -S localhost -U sa -P <password> -i deploy/sql/MprConfiguracionReglas/01_crear_tablas.sql
sqlcmd -S localhost -U sa -P <password> -i deploy/sql/MprConfiguracionReglas/02_datos_demo.sql
sqlcmd -S localhost -U sa -P <password> -i deploy/sql/MprGestionReclamos/00_crear_base.sql
sqlcmd -S localhost -U sa -P <password> -i deploy/sql/MprGestionReclamos/01_crear_tablas.sql
sqlcmd -S localhost -U sa -P <password> -i deploy/sql/MprDocumentos/00_crear_base.sql
sqlcmd -S localhost -U sa -P <password> -i deploy/sql/MprDocumentos/01_crear_tablas.sql

# 2) RabbitMQ local (o vía Docker aislado, sin el resto del compose):
docker run -d --name rabbitmq -p 5672:5672 -p 15672:15672 rabbitmq:3.13-management

# 3) Seis terminales:
dotnet run --project src/services/MprClientes/MprClientes.Api                       # puerto 5101
dotnet run --project src/services/MprConfiguracionReglas/MprConfiguracionReglas.Api # puerto 5102
dotnet run --project src/services/MprDocumentos/MprDocumentos.Api                   # puerto 5104
dotnet run --project src/services/MprGestionReclamos/MprGestionReclamos.Api         # puerto 5103 (llama a MprConfiguracionReglas y MprDocumentos — inícialos antes)
dotnet run --project src/orchestration/Reimbursement.Orchestrator                   # puerto 5201
dotnet run --project src/gateway/Multiportal.ApiGateway                             # puerto 5000

# 4) La UI (Vitamedica.Multiportal.UI) se sigue ejecutando igual que hoy desde
#    Visual Studio 2026; con Apis:apiGateway:BaseUrl apuntando a localhost:5000
#    en Development, http://localhost:xxxx/Home/Clientes ya muestra datos reales.
```

## 8. URLs

| Servicio | URL local |
|---|---|
| Multiportal.ApiGateway | http://localhost:5000 |
| MprClientes.Api | http://localhost:5101 |
| MprConfiguracionReglas.Api | http://localhost:5102 |
| MprGestionReclamos.Api | http://localhost:5103 |
| MprDocumentos.Api | http://localhost:5104 |
| Reimbursement.Orchestrator | http://localhost:5201 |
| RabbitMQ (AMQP) | localhost:5672 |
| RabbitMQ (consola de administración) | http://localhost:15672 (guest/guest) |
| SQL Server (MprClientesDb) | localhost,1433 |
| SQL Server (MprConfiguracionReglasDb) | localhost,1434 (Docker Compose) / localhost,1433 (instancia local propia) |
| SQL Server (MprGestionReclamosDb) | localhost,1435 (Docker Compose) / localhost,1433 (instancia local propia) |
| SQL Server (MprDocumentosDb) | localhost,1436 (Docker Compose) / localhost,1433 (instancia local propia) |

## 9. Roadmap — próximos pasos (no implementados aquí)

1. ~~Conectar MprDocumentos al flujo real de Reclamo~~ — **hecho** (ver
   `UI_Decision_Log.md` DEC-005): `EnviarReclamoCasoDeUso` en
   MprGestionReclamos ahora consulta `GET /v1/documentos/reclamos/{id}` en
   MprDocumentos (vía el puerto `IDocumentosAportadosMprDocumentos`) en vez
   de recibir los IDs de documentos aportados directamente en el request.
   `POST /v1/reclamos/{id}/enviar` ya no requiere body. Pendiente distinto,
   no cubierto aquí: `Reimbursement.Orchestrator` sigue sin invocar a
   MprDocumentos en el flujo de "iniciar reembolso".
2. **MprPagos**: consumer idempotente de `ReclamoAprobadoParaPago` (el
   evento ya se publica — ver sección 2), `ConfirmarPago`, publica
   `PagoCompletado`. Es el primer consumidor real del exchange
   `multiportal.reembolsos`.
3. **MprAuditoria**: consumer de todos los eventos de integración, bitácora/
   timeline — es la pieza que alimenta la pantalla de resultado final del
   ejercicio original ("Reembolso #R-00001 ... Timeline").
4. Extender `HomeController` (o agregar un nuevo Controller) para exponer la
   pantalla de "Iniciar Reembolso" consumiendo
   `POST /v1/reembolsos/iniciar` del Orchestrator ya construido (hoy crea
   también el Reclamo cuando se envía `motivoId`), una pantalla para
   `EnviarReclamo`/`AprobarReclamo`/`RechazarReclamo` contra
   MprGestionReclamos directamente, y una pantalla de carga de documentos
   contra MprDocumentos.
5. **Decisión de almacenamiento definitivo para MprDocumentos**: reemplazar
   `AlmacenamientoArchivosLocal` (disco local, DEMO-ONLY) por una tecnología
   apta para múltiples réplicas (Azure Blob Storage, S3, u otra) — PENDIENTE,
   ver `deploy/sql/MprDocumentos/README.md`.
6. **Saga/compensaciones**: solo tiene sentido una vez que exista más de un
   paso compensable entre MprGestionReclamos, MprDocumentos y MprPagos — hoy
   con un único publisher y cero consumidores no hay nada que compensar.

## 10. Simplificaciones explícitas de este ejercicio

- **Autenticación Gateway↔microservicio**: no implementada (pendiente
  documentado en `UI_Architecture_Guide.md` sección 8). El Gateway hoy
  reenvía la petición sin agregar un token propio.
- **Observabilidad**: solo `HttpLogging` básico habilitado en los tres
  `*.Api`; no hay exporter de OpenTelemetry configurado — se deja el
  enganche (middleware) sin acoplarse a un backend concreto, tal como
  recomienda `UI_Architecture_Guide.md` para `ILogger<T>`.
- **Idempotencia de consumidores**: el mensaje `ReclamoAprobadoParaPago`
  incluye `MessageId` (el `OboxNid`) precisamente para que un futuro
  consumidor pueda deduplicar — pero como no existe ningún consumidor
  real todavía (MprPagos/MprAuditoria son roadmap), la idempotencia del
  lado consumidor no se puede probar end-to-end hoy.
- **Saga/compensaciones**: no implementadas — ver Roadmap punto 5.
- **Reintentos/dead-letter en RabbitMQ**: el exchange se declara `durable`
  y los mensajes se publican `Persistent`, pero no se configuró una
  dead-letter queue ni política de reintentos — se agrega cuando exista un
  consumidor real contra el cual probar fallos de procesamiento.
- **Tests de integración con Testcontainers**: no incluidos en este
  ejercicio (requieren Docker corriendo en CI); los tests actuales de
  MprGestionReclamos cubren la máquina de estados de `Reclamo` y el caso de
  uso `EnviarReclamo` con dobles de prueba (fakes), no contra SQL Server ni
  RabbitMQ reales. Los tests de MprDocumentos siguen el mismo criterio
  (`DocumentoReclamo.Subir` y `SubirDocumentoCasoDeUso` con fakes de
  `IRepositorioDocumentos`/`IAlmacenamientoArchivos`, no contra disco real
  ni SQL Server real).
- **Almacenamiento de archivos en disco local (MprDocumentos)**: DEMO-ONLY,
  no apto para múltiples réplicas del servicio ni para un entorno
  productivo — ver Roadmap punto 5 y `deploy/sql/MprDocumentos/README.md`.
  No se implementó control de virus/malware sobre el contenido subido (fuera
  de alcance del ejercicio, pero señalado como consideración de seguridad
  real antes de producción).

## 11. Consideraciones para producción (no implementadas, señaladas)

- Rotar el secreto de conexión a SQL Server fuera de `appsettings.Development.json`
  (hoy contraseña de ejemplo, entorno local desechable).
- Definir el mecanismo de autenticación real Gateway↔microservicio antes de
  desplegar fuera de la laptop de desarrollo.
- Decidir si el Gateway local (YARP) se reemplaza por Azure API Management
  en el ambiente destino, siguiendo el mapeo de `deploy/apim/README.md`.

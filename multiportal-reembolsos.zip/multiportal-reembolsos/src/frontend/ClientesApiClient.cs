using Vitamedica.Multiportal.UI.Models.Multiportal;

namespace Vitamedica.Multiportal.UI.Services;

/// <summary>
/// ApiClient tipado para el microservicio MprClientes, consumido a través de
/// Multiportal.ApiGateway (nunca directo al microservicio desde la UI — ver
/// UI_Architecture_Guide.md sección 4). Sigue el mismo patrón ya usado por
/// MultiportalApiClient/VigorApiClient: responsabilidad única de traducir
/// una llamada C# a una petición HTTP + su DTO de respuesta, sin lógica de
/// presentación ni de negocio.
///
/// Se nombra por el RECURSO (Clientes) y no por el sistema origen, siguiendo
/// el criterio de UI_Architecture_Guide.md sección 2 ("cuando una API
/// exponga más de 3-4 operaciones relacionadas con un mismo recurso, se
/// prefiere nombrar el cliente por el recurso").
/// </summary>
public class ClientesApiClient
{
    private readonly HttpClient _client;

    public ClientesApiClient(HttpClient client)
    {
        _client = client;
    }

    public async Task<List<ClienteDto>> ListarAsync(CancellationToken cancellationToken = default)
    {
        var resultado = await _client.GetFromJsonAsync<List<ClienteDto>>("api/clientes", cancellationToken);
        return resultado ?? new List<ClienteDto>();
    }
}

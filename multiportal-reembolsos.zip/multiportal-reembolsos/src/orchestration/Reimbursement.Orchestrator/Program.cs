using Reimbursement.Orchestrator.Aplicacion;
using Reimbursement.Orchestrator.Endpoints;
using Reimbursement.Orchestrator.Infraestructura;
using Reimbursement.Orchestrator.Puertos;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddProblemDetails();
builder.Services.AddOpenApi();

builder.Services.AddHttpClient<IClienteMprClientes, ClienteMprClientesHttp>(cliente =>
{
    cliente.BaseAddress = new Uri(builder.Configuration["Servicios:MprClientes:BaseUrl"]!);
});

builder.Services.AddHttpClient<IReglasMprConfiguracionReglas, ReglasMprConfiguracionReglasHttp>(cliente =>
{
    cliente.BaseAddress = new Uri(builder.Configuration["Servicios:MprConfiguracionReglas:BaseUrl"]!);
});

builder.Services.AddHttpClient<IReclamosMprGestionReclamos, ReclamosMprGestionReclamosHttp>(cliente =>
{
    cliente.BaseAddress = new Uri(builder.Configuration["Servicios:MprGestionReclamos:BaseUrl"]!);
});

builder.Services.AddScoped<IniciarReembolsoCasoDeUso>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseExceptionHandler();

var grupoReembolsos = app.MapGroup("/v1/reembolsos").WithTags("Reembolsos");
IniciarReembolsoEndpoint.Mapear(grupoReembolsos);

app.MapGet("/health", () => Results.Ok(new { estado = "Orchestrator operativo" }));

app.Run();

namespace Reimbursement.Orchestrator.Puertos;

/// <summary>
/// Puerto que el Orchestrator usa para "ValidarContextoCliente". El
/// Orchestrator no sabe CÓMO se determina una vigencia (esa regla vive en
/// MprClientes.Domain) — solo sabe que necesita preguntarle a MprClientes
/// (ver "El Orchestrator no ejecuta reglas internas" del ejercicio).
/// </summary>
public interface IClienteMprClientes
{
    Task<ContextoClienteDto?> ObtenerContextoClienteAsync(
        string poliza,
        int aseguradoId,
        CancellationToken cancellationToken);
}

public sealed record ContextoClienteDto(
    int AseguradoId,
    string NombreCompleto,
    string Poliza,
    string Certificado,
    string RolAsegurado,
    DateTime VigenciaInicio,
    DateTime VigenciaFin,
    bool EsVigente);

namespace Reimbursement.Orchestrator.Puertos;

/// <summary>
/// Puerto que el Orchestrator usa para el Paso 2 ("obtener reglas de
/// reembolso y documentos requeridos"). El Orchestrator no sabe CÓMO se
/// determinan las reglas ni qué documentos son obligatorios (esa lógica
/// vive en MprConfiguracionReglas.Domain) — solo sabe que necesita
/// preguntarle a MprConfiguracionReglas.
/// </summary>
public interface IReglasMprConfiguracionReglas
{
    Task<ReglaReembolsoDto?> ObtenerReglaAsync(int motivoId, CancellationToken cancellationToken);
}

public sealed record DocumentoRequeridoDto(int Id, string Nombre, bool Obligatorio, bool EsFactura);

public sealed record ReglaReembolsoDto(
    int MotivoId,
    string Motivo,
    decimal? Cobertura,
    decimal? Coaseguro,
    decimal? Deducible,
    decimal? LimitePorEvento,
    string? Moneda,
    bool EsNacional,
    bool Activo,
    IReadOnlyList<DocumentoRequeridoDto> Documentos);

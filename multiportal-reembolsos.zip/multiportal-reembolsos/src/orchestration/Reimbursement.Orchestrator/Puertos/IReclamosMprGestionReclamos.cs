namespace Reimbursement.Orchestrator.Puertos;

/// <summary>
/// Puerto que el Orchestrator usa para el tercer paso real de
/// POST /v1/reembolsos/iniciar: "Solicitar a MprGestionReclamos la
/// creación del Reclamo". El Orchestrator no conoce la máquina de estados
/// del Reclamo (eso vive en MprGestionReclamos.Domain) — solo pide que se
/// cree uno.
/// </summary>
public interface IReclamosMprGestionReclamos
{
    Task<ReclamoCreadoDto> CrearReclamoAsync(
        string poliza,
        int aseguradoId,
        int motivoId,
        CancellationToken cancellationToken);
}

public sealed record ReclamoCreadoDto(int Id, string Estado);

namespace Reimbursement.Orchestrator.Contratos;

/// <summary>
/// MotivoId es opcional: si no se envía, el Orchestrator no consulta
/// MprConfiguracionReglas y ese paso queda documentado como pendiente en
/// la respuesta, igual que ocurría antes de que este servicio existiera.
/// </summary>
public sealed record IniciarReembolsoRequest(string Poliza, int AseguradoId, int? MotivoId = null);

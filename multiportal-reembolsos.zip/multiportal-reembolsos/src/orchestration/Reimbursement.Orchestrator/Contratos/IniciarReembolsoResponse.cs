using Reimbursement.Orchestrator.Puertos;

namespace Reimbursement.Orchestrator.Contratos;

/// <summary>
/// Resultado de los pasos reales que este piloto coordina (contexto de
/// cliente + reglas de reembolso + creación del Reclamo). Los campos
/// SiguientesPasosPendientes documentan explícitamente qué falta — nunca se
/// simulan como si ya hubieran ocurrido (ver README.md de este proyecto).
/// </summary>
public sealed record IniciarReembolsoResponse(
    bool ContextoClienteValido,
    string NombreCompleto,
    string Poliza,
    string Certificado,
    DateTime VigenciaInicio,
    DateTime VigenciaFin,
    ReglaReembolsoDto? Regla,
    ReclamoCreadoDto? Reclamo,
    IReadOnlyList<string> SiguientesPasosPendientes);

using Reimbursement.Orchestrator.Contratos;
using Reimbursement.Orchestrator.Puertos;

namespace Reimbursement.Orchestrator.Aplicacion;

/// <summary>
/// Caso de uso de coordinación. Ejecuta tres pasos reales
/// (ValidarContextoCliente contra MprClientes; ObtenerReglaReembolso contra
/// MprConfiguracionReglas y CrearReclamo contra MprGestionReclamos, ambos
/// cuando se envía MotivoId); los pasos siguientes del flujo original
/// quedan documentados como pendientes en SiguientesPasosPendientes en vez
/// de simularse (ver README.md).
/// </summary>
public sealed class IniciarReembolsoCasoDeUso(
    IClienteMprClientes clienteMprClientes,
    IReglasMprConfiguracionReglas reglasMprConfiguracionReglas,
    IReclamosMprGestionReclamos reclamosMprGestionReclamos)
{
    private static readonly IReadOnlyList<string> PasosPendientesSinMotivo =
    [
        "Consultar MprConfiguracionReglas y crear el Reclamo en MprGestionReclamos — no se envió MotivoId en la solicitud.",
        "Solicitar a MprDocumentos la preparación de documentos",
    ];

    private static readonly IReadOnlyList<string> PasosPendientesConReclamo =
    [
        "Enviar el Reclamo (POST /v1/reclamos/{id}/enviar en MprGestionReclamos) una vez que la UI recolecte los documentos obligatorios",
        "Solicitar a MprDocumentos la preparación de documentos",
    ];

    public async Task<IniciarReembolsoResponse?> EjecutarAsync(
        IniciarReembolsoRequest solicitud,
        CancellationToken cancellationToken)
    {
        var contexto = await clienteMprClientes.ObtenerContextoClienteAsync(
            solicitud.Poliza, solicitud.AseguradoId, cancellationToken);

        if (contexto is null)
        {
            return null;
        }

        if (!contexto.EsVigente)
        {
            return new IniciarReembolsoResponse(
                contexto.EsVigente,
                contexto.NombreCompleto,
                contexto.Poliza,
                contexto.Certificado,
                contexto.VigenciaInicio,
                contexto.VigenciaFin,
                Regla: null,
                Reclamo: null,
                ["El contexto contractual no es vigente; no se continúa el flujo."]);
        }

        ReglaReembolsoDto? regla = null;
        ReclamoCreadoDto? reclamo = null;

        if (solicitud.MotivoId is not null)
        {
            regla = await reglasMprConfiguracionReglas.ObtenerReglaAsync(solicitud.MotivoId.Value, cancellationToken);

            if (regla is not null)
            {
                reclamo = await reclamosMprGestionReclamos.CrearReclamoAsync(
                    solicitud.Poliza, solicitud.AseguradoId, solicitud.MotivoId.Value, cancellationToken);
            }
        }

        return new IniciarReembolsoResponse(
            contexto.EsVigente,
            contexto.NombreCompleto,
            contexto.Poliza,
            contexto.Certificado,
            contexto.VigenciaInicio,
            contexto.VigenciaFin,
            regla,
            reclamo,
            reclamo is not null ? PasosPendientesConReclamo : PasosPendientesSinMotivo);
    }
}

using System.Net.Http.Json;
using Reimbursement.Orchestrator.Puertos;

namespace Reimbursement.Orchestrator.Infraestructura;

/// <summary>
/// Adaptador HTTP del puerto IReclamosMprGestionReclamos. Igual criterio
/// que los otros adaptadores del Orchestrator: comunicación
/// servicio-a-servicio directa, sin pasar por el Gateway.
/// </summary>
public sealed class ReclamosMprGestionReclamosHttp(HttpClient httpClient) : IReclamosMprGestionReclamos
{
    public async Task<ReclamoCreadoDto> CrearReclamoAsync(
        string poliza,
        int aseguradoId,
        int motivoId,
        CancellationToken cancellationToken)
    {
        using var respuesta = await httpClient.PostAsJsonAsync(
            "/v1/reclamos",
            new { Poliza = poliza, AseguradoId = aseguradoId, MotivoId = motivoId },
            cancellationToken);

        respuesta.EnsureSuccessStatusCode();

        var reclamo = await respuesta.Content.ReadFromJsonAsync<ReclamoResponseHttp>(cancellationToken: cancellationToken)
            ?? throw new InvalidOperationException("MprGestionReclamos devolvió una respuesta vacía al crear el Reclamo.");

        return new ReclamoCreadoDto(reclamo.Id, reclamo.Estado);
    }

    private sealed record ReclamoResponseHttp(int Id, string Estado);
}

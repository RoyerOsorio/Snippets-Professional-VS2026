using Reimbursement.Orchestrator.Puertos;

namespace Reimbursement.Orchestrator.Infraestructura;

/// <summary>
/// Adaptador HTTP del puerto IReglasMprConfiguracionReglas. Igual criterio
/// que ClienteMprClientesHttp: comunicación servicio-a-servicio directa,
/// sin pasar por el Gateway.
/// </summary>
public sealed class ReglasMprConfiguracionReglasHttp(HttpClient httpClient) : IReglasMprConfiguracionReglas
{
    public async Task<ReglaReembolsoDto?> ObtenerReglaAsync(int motivoId, CancellationToken cancellationToken)
    {
        using var respuesta = await httpClient.GetAsync($"/v1/reglas/{motivoId}", cancellationToken);

        if (respuesta.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return null;
        }

        respuesta.EnsureSuccessStatusCode();

        return await respuesta.Content.ReadFromJsonAsync<ReglaReembolsoDto>(cancellationToken: cancellationToken);
    }
}

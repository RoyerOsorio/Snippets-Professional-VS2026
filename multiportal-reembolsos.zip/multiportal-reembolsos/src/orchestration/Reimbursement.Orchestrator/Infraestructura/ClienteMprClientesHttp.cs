using Reimbursement.Orchestrator.Puertos;

namespace Reimbursement.Orchestrator.Infraestructura;

/// <summary>
/// Adaptador HTTP del puerto IClienteMprClientes. El Orchestrator llama
/// directamente al microservicio (no a través del Gateway) porque es
/// comunicación servicio-a-servicio interna, no tráfico de navegador — el
/// Gateway es la frontera externa de la aplicación, no un intermediario
/// obligatorio entre microservicios internos.
/// </summary>
public sealed class ClienteMprClientesHttp(HttpClient httpClient) : IClienteMprClientes
{
    public async Task<ContextoClienteDto?> ObtenerContextoClienteAsync(
        string poliza,
        int aseguradoId,
        CancellationToken cancellationToken)
    {
        using var respuesta = await httpClient.GetAsync(
            $"/v1/clientes/contexto?poliza={Uri.EscapeDataString(poliza)}&aseguradoId={aseguradoId}",
            cancellationToken);

        if (respuesta.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return null;
        }

        respuesta.EnsureSuccessStatusCode();

        return await respuesta.Content.ReadFromJsonAsync<ContextoClienteDto>(cancellationToken: cancellationToken);
    }
}

using Reimbursement.Orchestrator.Aplicacion;
using Reimbursement.Orchestrator.Contratos;

namespace Reimbursement.Orchestrator.Endpoints;

public static class IniciarReembolsoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapPost("/iniciar", IniciarAsync).WithName("IniciarReembolso");
    }

    private static async Task<IResult> IniciarAsync(
        IniciarReembolsoRequest solicitud,
        IniciarReembolsoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        var resultado = await casoDeUso.EjecutarAsync(solicitud, cancellationToken);

        if (resultado is null)
        {
            return Results.Problem(
                title: "Contexto de cliente no encontrado",
                detail: $"No se encontró contexto contractual para la póliza {solicitud.Poliza} y el asegurado {solicitud.AseguradoId}.",
                statusCode: StatusCodes.Status404NotFound);
        }

        return Results.Ok(resultado);
    }
}

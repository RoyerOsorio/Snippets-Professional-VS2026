# Reimbursement.Orchestrator — alcance actual

Este proyecto se entrega como **un solo proyecto** (no dividido en
Api/Application/Domain/Infrastructure) de forma deliberada: hoy coordina
tres pasos reales (consultar MprClientes, consultar MprConfiguracionReglas,
crear el Reclamo en MprGestionReclamos) y algunos pasos documentados como
pendientes porque los servicios que coordinarían (MprDocumentos) todavía no
existen en este repositorio. Dividir en 4 proyectos un coordinador de tres
pasos reales seguiría siendo sobreingeniería en esta etapa (ver "Regla
contra la sobreingeniería" del ejercicio). Cuando se agreguen los
siguientes microservicios (roadmap en `docs/demo/README.md`), este
proyecto se reorganiza en capas si la complejidad del caso de uso lo
justifica — no antes.

## Qué SÍ hace actualmente

`POST /v1/reembolsos/iniciar` — recibe `poliza` + `aseguradoId` (+
`motivoId` opcional):

1. Llama a `GET /v1/clientes/contexto` en **MprClientes real** y evalúa
   `ValidarContextoCliente`. Si el contexto no es vigente, el flujo se
   detiene aquí — no tiene sentido consultar reglas para un contexto
   inválido.
2. Si se envió `motivoId`, llama a `GET /v1/reglas/{motivoId}` en
   **MprConfiguracionReglas real** y devuelve la regla completa (cobertura,
   coaseguro, deducible, documentos requeridos). Si no se envía `motivoId`,
   los pasos 2 y 3 quedan documentados como pendientes en la respuesta —
   no se inventa un motivo por defecto.
3. Si el paso 2 encontró una regla, llama a `POST /v1/reclamos` en
   **MprGestionReclamos real**, que crea el Reclamo en estado `Creado`. El
   Reclamo creado (Id + Estado) se devuelve en la respuesta; el paso
   `EnviarReclamo` queda explícitamente como siguiente paso pendiente — no
   porque el Orchestrator necesite adivinar qué documentos aportó el
   usuario (eso ya lo resuelve `EnviarReclamoCasoDeUso` consultando a
   MprDocumentos directamente, ver `UI_Decision_Log.md` DEC-005), sino
   porque `EnviarReclamo` depende de una acción separada del usuario
   (terminar de subir documentos) que no ocurre en el mismo instante que
   "iniciar reembolso".

Esto demuestra el patrón de coordinación (Orchestrator → microservicios,
sin lógica de negocio propia) sin fingir que existen pasos que todavía no
están construidos.

## Qué está documentado como PENDIENTE (no implementado, no simulado)

1. `EnviarReclamo` — el usuario sube documentos a MprDocumentos y luego
   llama `POST /v1/reclamos/{id}/enviar` (ya construido en
   MprGestionReclamos, que a su vez ya consulta a MprDocumentos — DEC-005).
   Este Orchestrator no orquesta automáticamente ese paso porque depende
   de una interacción separada del usuario, no de datos que el
   Orchestrator ya tenga en el momento de "iniciar".
2. Invocar `POST /v1/documentos/reclamos/{reclamoId}` desde este
   Orchestrator como parte del flujo de "iniciar reembolso" — hoy la
   subida de documentos es un paso de UI independiente, disparado
   directamente contra MprDocumentos.
3. Consumir `ReclamoAprobadoParaPago` desde `MprPagos` y `MprAuditoria` —
   el evento **ya se publica** (Transactional Outbox + RabbitMQ, ver
   `MprGestionReclamos.Infrastructure/Mensajeria/`), pero no existe todavía
   ningún consumidor real.

No se agregan stubs que simulen estas respuestas — un stub que "funciona"
sin representar un servicio real generaría una falsa sensación de que el
flujo está completo. Se prefiere dejar el paso explícitamente ausente.

// ============================================================================
// Multiportal.ApiGateway — representación LOCAL de Azure API Management.
//
// Responsabilidad (conceptual, igual en local y en Azure APIM):
//   - Routing hacia Reimbursement.Orchestrator y hacia los microservicios
//     que sí deben ser consultados directamente por la UI (ej. MprClientes
//     para listar/consultar clientes; no todo tiene que pasar siempre por
//     el Orchestrator — el Orchestrator coordina PROCESOS multi-servicio,
//     no reemplaza cada consulta simple de un solo servicio).
//   - Punto de entrada externo único para la aplicación web.
//
// Lo que este Gateway explícitamente NO hace (ver "Responsabilidad del API
// Gateway" del ejercicio):
//   - No contiene lógica de negocio.
//   - No coordina procesos multi-servicio (eso es responsabilidad del
//     Orchestrator).
//   - No decide reglas de reembolso, vigencia, etc.
//
// En Azure APIM, este mismo routing se modela con políticas
// (<inbound>/<backend>) en vez de código C# — ver deploy/apim/README.md
// para el mapeo de cada ruta YARP a su equivalente conceptual en APIM.
// ============================================================================
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddReverseProxy()
    .LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"));

// Autenticación/token: en este piloto el Gateway reenvía la cookie de sesión
// tal como la UI ya la usa hoy contra la API existente (mismo patrón que
// Vitamedica.Multiportal.UI ya sigue). Un mecanismo de validación de token
// propio del Gateway (ej. JWT emitido por un STS) es una decisión de
// infraestructura PENDIENTE — no se implementa aquí para no anticipar una
// decisión que el equipo no ha tomado (ver UI_Architecture_Guide.md sección 8).

var app = builder.Build();

app.MapReverseProxy();

app.MapGet("/health", () => Results.Ok(new { estado = "Gateway operativo" }));

app.Run();

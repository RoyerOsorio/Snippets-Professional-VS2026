# MprPagos — Base de datos

## Crear/restaurar localmente

```bash
sqlcmd -S localhost,1437 -U sa -P "<password>" -i 00_crear_base.sql
sqlcmd -S localhost,1437 -U sa -P "<password>" -i 01_crear_tablas.sql
```

No hay `02_datos_demo.sql`: un Pago se crea únicamente a partir de un mensaje `ReclamoAprobadoParaPago` consumido de RabbitMQ — no tiene sentido precargar catálogo, mismo criterio que Reclamo en MprGestionReclamos y Documento en MprDocumentos.

## Alcance de este esquema — nota importante

**Este esquema no proviene de un archivo de esquema legado.** MprPagos es un microservicio nuevo: no existía como tabla en el monolito `Vitamedica.Multiportal`. El esquema (`MTP_PGPG_MPAGO`) se diseñó siguiendo la convención de nombres ya usada en el proyecto, pero es una propuesta nueva, no un mapeo 1:1 de algo existente.

## Idempotencia del consumidor — `PGPG_MENSAJE_ID_ORIGEN`

MprPagos es el **primer consumidor real** del exchange `multiportal.reembolsos` en este ejercicio (ver `UI_Decision_Log.md` DEC-003, que dejó esta idempotencia documentada como pendiente hasta que existiera un consumidor). `PGPG_MENSAJE_ID_ORIGEN` guarda el `MessageId` del mensaje RabbitMQ (el `OboxNid` que MprGestionReclamos le asignó al publicar) con una restricción `UNIQUE`. Esto da dos capas de protección contra procesar el mismo `ReclamoAprobadoParaPago` dos veces:

1. **Nivel aplicación** (`ProcesarReclamoAprobadoParaPagoCasoDeUso`): consulta si ya existe un Pago con ese `MensajeIdOrigen` antes de crear uno nuevo.
2. **Nivel base de datos** (`UQ_MTP_PGPG_MPAGO_MENSAJE_ID_ORIGEN`): si dos instancias del consumidor procesaran el mismo mensaje casi simultáneamente (condición de carrera que la verificación en aplicación por sí sola no cubre), el segundo `INSERT` fallaría por la restricción de unicidad.

## MTP_OBOX_MENSAJE — Transactional Outbox

Mismo patrón que en MprGestionReclamos: cuando `ConfirmarPago` se ejecuta, en la misma transacción de base de datos se inserta una fila aquí con el evento `PagoCompletado` serializado en JSON. Un `BackgroundService` (`OutboxPublisherHostedService`) sondea esta tabla y publica a RabbitMQ. No existe todavía ningún consumidor real de `PagoCompletado` (MprAuditoria sigue en roadmap).

## Database First — regenerar el modelo EF Core después de un cambio de esquema

```bash
cd src/services/MprPagos/MprPagos.Infrastructure
dotnet ef dbcontext scaffold \
    "Server=localhost,1437;Database=MprPagosDb;User Id=sa;Password=<password>;TrustServerCertificate=True;" \
    Microsoft.EntityFrameworkCore.SqlServer \
    --context MprPagosDbContext \
    --output-dir Persistencia/ModelosGenerados \
    --context-dir Persistencia \
    --no-onconfiguring \
    --force
```

- **Generado por scaffold (no editar a mano):** `Persistencia/ModelosGenerados/` y la clase parcial base `MprPagosDbContext`.
- **Escrito manualmente:** `Persistencia/Adaptadores/` (repositorio que implementa `IRepositorioPagos`, incluido el patrón Outbox), `Mensajeria/` (publisher de `PagoCompletado` y consumer de `ReclamoAprobadoParaPago`).
- La contraseña real **nunca** se comitea — mismo criterio que los demás microservicios.

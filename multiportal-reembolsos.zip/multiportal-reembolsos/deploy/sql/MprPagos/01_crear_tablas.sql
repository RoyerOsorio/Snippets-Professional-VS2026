-- ============================================================================
-- MprPagos - Tablas
--
-- Igual que MprGestionReclamos/MprDocumentos: esquema nuevo, no proviene
-- de un archivo de esquema legado entregado — MprPagos no existía como
-- tabla en el monolito Vitamedica.Multiportal.
--
-- MTP_PGPG_MPAGO: ciclo de vida del Pago (Pendiente, Completado — ver
-- MprPagos.Domain.Entidades.EstadoPago). PGPG_MENSAJE_ID_ORIGEN tiene una
-- restricción de unicidad: es el MessageId del mensaje RabbitMQ
-- (ReclamoAprobadoParaPago) que originó este Pago — evita crear un Pago
-- duplicado si RabbitMQ reentrega el mismo mensaje (at-least-once
-- delivery). Ver MprPagos.Application/Casos/ProcesarReclamoAprobadoParaPagoCasoDeUso.
--
-- MTP_OBOX_MENSAJE: tabla genérica de Transactional Outbox, mismo diseño
-- que la de MprGestionReclamos — MprPagos publica PagoCompletadoEvento.
-- ============================================================================
USE MprPagosDb;
GO

IF OBJECT_ID('dbo.MTP_PGPG_MPAGO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_PGPG_MPAGO
    (
        PGPG_NID                 int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        PGPG_RECLAMO_ID          int           NOT NULL,
        PGPG_POLIZA              varchar(20)   NOT NULL,
        PGPG_ASEGURADO_ID        int           NOT NULL,
        PGPG_MONTO_APROBADO      decimal(18,2) NOT NULL,
        PGPG_ESTADO              tinyint       NOT NULL, -- 0=Pendiente, 1=Completado
        PGPG_MENSAJE_ID_ORIGEN   bigint        NOT NULL,
        PGPG_FECHA_CREACION      datetime      NOT NULL,
        PGPG_FECHA_CONFIRMACION  datetime      NULL
    );

    CREATE UNIQUE INDEX UQ_MTP_PGPG_MPAGO_MENSAJE_ID_ORIGEN ON dbo.MTP_PGPG_MPAGO (PGPG_MENSAJE_ID_ORIGEN);
END
GO

IF OBJECT_ID('dbo.MTP_OBOX_MENSAJE', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_OBOX_MENSAJE
    (
        OBOX_NID               bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
        OBOX_TIPO_EVENTO       varchar(100)   NOT NULL,
        OBOX_PAYLOAD_JSON      nvarchar(max)  NOT NULL,
        OBOX_FECHA_CREACION    datetime       NOT NULL,
        OBOX_FECHA_PUBLICACION datetime       NULL,
        OBOX_PUBLICADO         bit            NOT NULL DEFAULT (0)
    );

    CREATE INDEX IX_OBOX_PUBLICADO ON dbo.MTP_OBOX_MENSAJE (OBOX_PUBLICADO) WHERE OBOX_PUBLICADO = 0;
END
GO

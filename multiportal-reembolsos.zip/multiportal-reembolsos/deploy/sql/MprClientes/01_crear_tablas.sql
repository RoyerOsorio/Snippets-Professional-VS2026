-- ============================================================================
-- MprClientes - Tablas del vertical slice piloto
--
-- Subconjunto de MprCliente.txt (fuente de verdad de esquema) necesario para:
--   1) Listar/consultar Clientes (= MTP_GRGR_GRUPO, el "Grupo" del esquema
--      legado corresponde 1:1 al concepto de Cliente que ya usa la UI en
--      ClienteViewModel — mismos campos: nombre/razón social, RFC, teléfono,
--      contacto, descripción corta, estatus).
--   2) Resolver el contexto contractual de un Asegurado bajo una Póliza
--      (Póliza -> Vigencia -> Certificado -> Rol del Asegurado), que es lo
--      que Reimbursement.Orchestrator necesita para "ValidarContextoCliente"
--      en el Paso 2 del flujo de reembolso.
--
-- Fuera de alcance del piloto (no se crean en este script): Agente,
-- Contratante, Promotor, Estado Civil, Sexo, Categoría de Póliza, Endoso —
-- son nullable en el esquema original y no bloquean el vertical slice.
-- ============================================================================
USE MprClientesDb;
GO

IF OBJECT_ID('dbo.MTP_GRGR_GRUPO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_GRGR_GRUPO
    (
        GRGR_NID                 tinyint      NOT NULL PRIMARY KEY,
        GRGR_DESCASEGURADORA     varchar(75)  NULL,
        GRGR_DIRECCION           varchar(150) NULL,
        GRGR_TELEFONO            varchar(15)  NULL,
        GRGR_NOMCONTACTO         varchar(100) NULL,
        GRGR_RFC                 varchar(13)  NULL,
        GRGR_TELCONTACTO         varchar(15)  NULL,
        GRGR_DESCRIPCION_CORTA   varchar(8)   NULL,
        GRGR_ESTATUS             varchar(4)   NULL,
        GRGR_FECHA_INSERT        datetime     NULL,
        GRGR_FECHA_UPDATE        datetime     NULL
    );
END
GO

IF OBJECT_ID('dbo.MTP_SBGR_SUBGRUPO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_SBGR_SUBGRUPO
    (
        SBGR_NID                 tinyint      NOT NULL PRIMARY KEY,
        GRGR_NID                 tinyint      NOT NULL,
        SBGR_DESCASEGURADORA     varchar(75)  NULL,
        SBGR_DESCRIPCION_CORTA   varchar(8)   NULL,
        SBGR_ESTATUS             varchar(4)   NULL,
        CONSTRAINT FK_SBGR_GRGR FOREIGN KEY (GRGR_NID) REFERENCES dbo.MTP_GRGR_GRUPO (GRGR_NID)
    );
END
GO

IF OBJECT_ID('dbo.MTP_PLPL_MPOLIZA', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_PLPL_MPOLIZA
    (
        PLPL_NID           int          NOT NULL PRIMARY KEY,
        SBGR_NID           tinyint      NOT NULL,
        PLPL_POLIZA        varchar(20)  NOT NULL,
        PLPL_EMISOR        varchar(8)   NULL,
        PLPL_TIPO_POLIZA   varchar(14)  NULL,
        PLPL_FECHA_EMISION smalldatetime NULL,
        PLPL_PRODUCTO      varchar(80)  NULL,
        CODIGO_PRODUCTO    varchar(20)  NULL,
        CONSTRAINT FK_PLPL_SBGR FOREIGN KEY (SBGR_NID) REFERENCES dbo.MTP_SBGR_SUBGRUPO (SBGR_NID)
    );
END
GO

IF OBJECT_ID('dbo.MTP_PLVG_DPOLIZA_VIGENCIA', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_PLVG_DPOLIZA_VIGENCIA
    (
        PLVG_NID             int          NOT NULL PRIMARY KEY,
        PLPL_NID             int          NOT NULL,
        PLVG_INICIO_VIGENCIA smalldatetime NOT NULL,
        PLVG_FIN_VIGENCIA    smalldatetime NOT NULL,
        PLVG_PLAN            varchar(30)  NULL,
        PLVG_COBERTURA       varchar(14)  NULL,
        CONSTRAINT FK_PLVG_PLPL FOREIGN KEY (PLPL_NID) REFERENCES dbo.MTP_PLPL_MPOLIZA (PLPL_NID)
    );
END
GO

IF OBJECT_ID('dbo.MTP_PLCR_3POLIZA_CERTIFICADO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_PLCR_3POLIZA_CERTIFICADO
    (
        PLCR_NID        bigint      NOT NULL PRIMARY KEY,
        PLCR_CERTIFICADO varchar(14) NOT NULL,
        PLVG_NID        int         NULL,
        CONSTRAINT FK_PLCR_PLVG FOREIGN KEY (PLVG_NID) REFERENCES dbo.MTP_PLVG_DPOLIZA_VIGENCIA (PLVG_NID)
    );
END
GO

IF OBJECT_ID('dbo.MTP_RARA_CROL_ASEGURADO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_RARA_CROL_ASEGURADO
    (
        RARA_NID                smallint     NOT NULL PRIMARY KEY,
        RARA_NOMBRE_ROL_ASEGURADO varchar(100) NOT NULL
    );
END
GO

IF OBJECT_ID('dbo.MTP_ASAS_MASEGURADO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_ASAS_MASEGURADO
    (
        ASAS_NID             int          NOT NULL PRIMARY KEY,
        ASAS_NOMBRE          varchar(50)  NOT NULL,
        ASAS_APPATERNO       varchar(50)  NOT NULL,
        ASAS_APMATERNO       varchar(50)  NULL,
        ASAS_FECHA_NACIMIENTO smalldatetime NOT NULL,
        ASAS_EMAIL           varchar(100) NULL,
        ASAS_TELEFONO        varchar(10)  NULL
    );
END
GO

IF OBJECT_ID('dbo.MTP_ASCR_RASEGURADO_CERTIFICADO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_ASCR_RASEGURADO_CERTIFICADO
    (
        ASCR_NID        bigint       NOT NULL PRIMARY KEY,
        PLCR_NID        bigint       NULL,
        ASAS_NID        int          NOT NULL,
        RARA_NID        smallint     NOT NULL,
        ASCR_FECHA_ALTA smalldatetime NOT NULL,
        ASCR_FECHA_BAJA smalldatetime NULL,
        CONSTRAINT FK_ASCR_PLCR FOREIGN KEY (PLCR_NID) REFERENCES dbo.MTP_PLCR_3POLIZA_CERTIFICADO (PLCR_NID),
        CONSTRAINT FK_ASCR_ASAS FOREIGN KEY (ASAS_NID) REFERENCES dbo.MTP_ASAS_MASEGURADO (ASAS_NID),
        CONSTRAINT FK_ASCR_RARA FOREIGN KEY (RARA_NID) REFERENCES dbo.MTP_RARA_CROL_ASEGURADO (RARA_NID)
    );
END
GO

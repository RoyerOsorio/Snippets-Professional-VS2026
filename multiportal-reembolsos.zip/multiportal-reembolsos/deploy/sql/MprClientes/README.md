# MprClientes — Base de datos

## Crear/restaurar localmente

```bash
sqlcmd -S localhost,1433 -U sa -P "<password>" -i 00_crear_base.sql
sqlcmd -S localhost,1433 -U sa -P "<password>" -i 01_crear_tablas.sql
sqlcmd -S localhost,1433 -U sa -P "<password>" -i 02_datos_demo.sql
```

O, si usas el `docker-compose` de `deploy/docker/`, estos tres scripts se ejecutan automáticamente al iniciar el contenedor `sqlserver-mprclientes` (ver `deploy/docker/docker-compose.yml`).

## Alcance de este script

Subconjunto de `MprCliente.txt` (fuente de verdad del esquema) necesario para el vertical slice piloto: Grupo (= Cliente en el lenguaje de la UI), Subgrupo, Póliza, Vigencia, Certificado, Rol de Asegurado y Asegurado. **No** se crean aquí las tablas de Agente, Contratante, Promotor, Estado Civil, Sexo, Categoría de Póliza ni Endoso — son nullable en el esquema original y no bloquean este flujo; se agregan cuando el ejercicio se extienda más allá del piloto.

## Database First — regenerar el modelo EF Core después de un cambio de esquema

```bash
cd src/services/MprClientes/MprClientes.Infrastructure
dotnet ef dbcontext scaffold \
    "Server=localhost,1433;Database=MprClientesDb;User Id=sa;Password=<password>;TrustServerCertificate=True;" \
    Microsoft.EntityFrameworkCore.SqlServer \
    --context MprClientesDbContext \
    --output-dir Persistencia/ModelosGenerados \
    --context-dir Persistencia \
    --no-onconfiguring \
    --force
```

- **Generado por scaffold (no editar a mano):** todo lo que queda bajo `Persistencia/ModelosGenerados/` y la clase parcial base `MprClientesDbContext` en `Persistencia/`.
- **Escrito manualmente:** `Persistencia/Adaptadores/` (los repositorios que implementan los puertos de `Application`), y cualquier `partial class` de extensión sobre una entidad generada.
- La contraseña real **nunca** se comitea — usar variables de entorno o `dotnet user-secrets` en desarrollo; en este ejercicio demo se usa una contraseña de ejemplo únicamente en `docker-compose.yml` (entorno local desechable).

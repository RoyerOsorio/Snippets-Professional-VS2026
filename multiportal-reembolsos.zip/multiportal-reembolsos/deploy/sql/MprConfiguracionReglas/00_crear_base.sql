-- ============================================================================
-- MprConfiguracionReglas - Creación de base de datos
-- Cada microservicio posee su propia base SQL Server. MprConfiguracionReglas
-- NUNCA debe ser consultada directamente por otro microservicio ni contener
-- FKs físicas hacia bases de otros bounded contexts (ver UI/Project: "no
-- crear foreign keys entre bases de diferentes microservicios").
-- ============================================================================
IF DB_ID('MprConfiguracionReglasDb') IS NULL
BEGIN
    CREATE DATABASE MprConfiguracionReglasDb;
END
GO

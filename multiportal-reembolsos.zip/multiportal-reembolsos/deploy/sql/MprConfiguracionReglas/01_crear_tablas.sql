-- ============================================================================
-- MprConfiguracionReglas - Tablas del vertical slice
--
-- Subconjunto de MprConfiguracionReglas.txt (fuente de verdad de esquema)
-- necesario para:
--   1) Consultar las reglas de reembolso asociadas a un Motivo (cobertura,
--      coaseguro, deducible, límite por evento) — MTP_MRMR_CMOTIVOREEMBOLSO.
--   2) Consultar los documentos que exige cada Motivo, y si son obligatorios
--      — MTP_DRDR_CDOCUMENTOREQUERIDO + MTP_MRDR_RMOTIVODOCUMENTO.
--   3) Consultar el flujo de reembolso y si requiere dictamen médico —
--      MTP_FRFR_CFLUJOREEMBOLSO.
--
-- Nota de alcance: el esquema entregado no define una FK explícita entre
-- MTP_FRFR_CFLUJOREEMBOLSO y MTP_MRMR_CMOTIVOREEMBOLSO. No se inventa esa
-- relación aquí — ver MprConfiguracionReglas.Domain.Entidades.FlujoReembolso.
-- ============================================================================
USE MprConfiguracionReglasDb;
GO

IF OBJECT_ID('dbo.MTP_MRMR_CMOTIVOREEMBOLSO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_MRMR_CMOTIVOREEMBOLSO
    (
        MRMR_NID          int           NOT NULL PRIMARY KEY,
        MRMR_MOTIVO       varchar(150)  NOT NULL,
        MRMR_CLAVECONFIG  varchar(20)   NULL,
        MRMR_COBERTURA    decimal(5,2)  NULL,
        MRMR_COASEGURO    decimal(5,2)  NULL,
        MRMR_LIMITEXEVENTO decimal(18,2) NULL,
        MRMR_MONEDA       varchar(3)    NULL,
        MRMR_DEDUCIBLE    decimal(18,2) NULL,
        MRMR_ESNACIONAL   bit           NULL,
        MRMR_ACTIVO       bit           NULL
    );
END
GO

IF OBJECT_ID('dbo.MTP_DRDR_CDOCUMENTOREQUERIDO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_DRDR_CDOCUMENTOREQUERIDO
    (
        DRDR_NID           int          NOT NULL PRIMARY KEY,
        DRDR_DOCUMENTO     varchar(150) NOT NULL,
        DRDR_OBSERVACIONES varchar(250) NULL,
        DRDR_ESFACTURA     bit          NULL
    );
END
GO

IF OBJECT_ID('dbo.MTP_MRDR_RMOTIVODOCUMENTO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_MRDR_RMOTIVODOCUMENTO
    (
        MRDR_NID            int NOT NULL PRIMARY KEY,
        MRMR_NID             int NOT NULL,
        DRDR_NID             int NOT NULL,
        DRDR_MAXIMOPERMITIDO int NULL,
        MRDR_OBLIGATORIO     bit NOT NULL,
        CONSTRAINT FK_MRDR_MRMR FOREIGN KEY (MRMR_NID) REFERENCES dbo.MTP_MRMR_CMOTIVOREEMBOLSO (MRMR_NID),
        CONSTRAINT FK_MRDR_DRDR FOREIGN KEY (DRDR_NID) REFERENCES dbo.MTP_DRDR_CDOCUMENTOREQUERIDO (DRDR_NID)
    );
END
GO

IF OBJECT_ID('dbo.MTP_FRFR_CFLUJOREEMBOLSO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_FRFR_CFLUJOREEMBOLSO
    (
        FRFR_NID      int          NOT NULL PRIMARY KEY,
        FRFR_FLUJO    varchar(100) NOT NULL,
        FRFR_DICMEDICO bit         NOT NULL
    );
END
GO

# MprConfiguracionReglas — Base de datos

## Crear/restaurar localmente

```bash
sqlcmd -S localhost,1433 -U sa -P "<password>" -i 00_crear_base.sql
sqlcmd -S localhost,1433 -U sa -P "<password>" -i 01_crear_tablas.sql
sqlcmd -S localhost,1433 -U sa -P "<password>" -i 02_datos_demo.sql
```

O, si usas el `docker-compose` de `deploy/docker/`, estos tres scripts se ejecutan automáticamente al iniciar el contenedor `sqlserver-mprconfiguracionreglas` (ver `deploy/docker/docker-compose.yml`).

## Alcance de este script

Subconjunto de `MprConfiguracionReglas.txt` (fuente de verdad del esquema) necesario para: Motivo de Reembolso (con cobertura/coaseguro/deducible/límite por evento), Documento Requerido, la relación Motivo↔Documento (con bandera de obligatoriedad) y Flujo de Reembolso (con `RequiereDictamenMedico`).

**Nota de alcance:** el esquema entregado no define una FK explícita entre `MTP_FRFR_CFLUJOREEMBOLSO` y `MTP_MRMR_CMOTIVOREEMBOLSO`. No se inventó esa relación — `FlujoReembolso` se consulta de forma independiente. Si el negocio confirma que existe esa relación, se agrega en una siguiente iteración (ver `MprConfiguracionReglas.Domain.Entidades.FlujoReembolso`).

## Database First — regenerar el modelo EF Core después de un cambio de esquema

```bash
cd src/services/MprConfiguracionReglas/MprConfiguracionReglas.Infrastructure
dotnet ef dbcontext scaffold \
    "Server=localhost,1433;Database=MprConfiguracionReglasDb;User Id=sa;Password=<password>;TrustServerCertificate=True;" \
    Microsoft.EntityFrameworkCore.SqlServer \
    --context MprConfiguracionReglasDbContext \
    --output-dir Persistencia/ModelosGenerados \
    --context-dir Persistencia \
    --no-onconfiguring \
    --force
```

- **Generado por scaffold (no editar a mano):** todo lo que queda bajo `Persistencia/ModelosGenerados/` y la clase parcial base `MprConfiguracionReglasDbContext` en `Persistencia/`.
- **Escrito manualmente:** `Persistencia/Adaptadores/` (los repositorios que implementan los puertos de `Application`), y cualquier `partial class` de extensión sobre una entidad generada.
- La contraseña real **nunca** se comitea — usar variables de entorno o `dotnet user-secrets` en desarrollo; en este ejercicio demo se usa una contraseña de ejemplo únicamente en `docker-compose.yml` (entorno local desechable).

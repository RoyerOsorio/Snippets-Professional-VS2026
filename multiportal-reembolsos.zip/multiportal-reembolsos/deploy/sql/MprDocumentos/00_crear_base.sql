-- ============================================================================
-- MprDocumentos - Creación de base de datos
-- Cada microservicio posee su propia base SQL Server. MprDocumentos NUNCA
-- debe ser consultada directamente por otro microservicio ni contener FKs
-- físicas hacia bases de otros bounded contexts (ReclamoId y
-- DocumentoRequeridoId son identificadores lógicos hacia MprGestionReclamos
-- y MprConfiguracionReglas respectivamente).
-- ============================================================================
IF DB_ID('MprDocumentosDb') IS NULL
BEGIN
    CREATE DATABASE MprDocumentosDb;
END
GO

-- ============================================================================
-- MprDocumentos - Tablas
--
-- Igual que MprGestionReclamos: esquema nuevo, no proviene de un archivo de
-- esquema legado entregado — la gestión de documentos adjuntos no existía
-- como tabla en el monolito Vitamedica.Multiportal. Se diseñó siguiendo la
-- misma convención de nombres del proyecto (prefijo de 4 letras + sufijo).
--
-- MTP_DOC_MDOCUMENTO: metadata de cada archivo aportado para un Reclamo.
-- El contenido binario NO se guarda en esta tabla — vive en el
-- almacenamiento configurado (ver Almacenamiento/AlmacenamientoArchivosLocal,
-- DEMO-ONLY/PROPUESTO); esta tabla solo referencia dónde está (ruta lógica).
-- ============================================================================
USE MprDocumentosDb;
GO

IF OBJECT_ID('dbo.MTP_DOC_MDOCUMENTO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_DOC_MDOCUMENTO
    (
        DOCU_NID                     int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        DOCU_RECLAMO_ID               int           NOT NULL,
        DOCU_DOCUMENTO_REQUERIDO_ID   int           NULL,
        DOCU_NOMBRE_ORIGINAL          varchar(260)  NOT NULL,
        DOCU_TIPO_CONTENIDO           varchar(100)  NOT NULL,
        DOCU_TAMANO_BYTES             bigint        NOT NULL,
        DOCU_RUTA_ALMACENAMIENTO      varchar(500)  NOT NULL,
        DOCU_FECHA_CARGA              datetime      NOT NULL
    );

    CREATE INDEX IX_MTP_DOC_MDOCUMENTO_RECLAMO_ID ON dbo.MTP_DOC_MDOCUMENTO (DOCU_RECLAMO_ID);
END
GO

# MprDocumentos — Base de datos

## Crear/restaurar localmente

```bash
sqlcmd -S localhost,1436 -U sa -P "<password>" -i 00_crear_base.sql
sqlcmd -S localhost,1436 -U sa -P "<password>" -i 01_crear_tablas.sql
```

No hay `02_datos_demo.sql`: igual que Reclamo en MprGestionReclamos, un Documento es una instancia transaccional creada mediante `POST /v1/documentos/reclamos/{reclamoId}` — no tiene sentido precargar catálogo.

## Alcance de este esquema — nota importante

**Este esquema no proviene de un archivo de esquema legado.** MprDocumentos es un microservicio nuevo: la gestión de archivos adjuntos a un Reclamo no existía como tabla en el monolito `Vitamedica.Multiportal`. El esquema (`MTP_DOC_MDOCUMENTO`) se diseñó siguiendo la convención de nombres ya usada en el proyecto, pero es una propuesta nueva. Si el negocio ya tiene un esquema real para documentos, este debe reemplazarse por ese.

## Contenido binario — no vive en SQL Server

`MTP_DOC_MDOCUMENTO` solo guarda metadata (`DOCU_RUTA_ALMACENAMIENTO` es una ruta lógica, no el archivo). El contenido físico lo maneja `IAlmacenamientoArchivos` (`MprDocumentos.Application/Puertos/`), cuya única implementación en este ejercicio (`AlmacenamientoArchivosLocal`, `MprDocumentos.Infrastructure/Almacenamiento/`) escribe a disco local bajo un directorio configurable (`Almacenamiento:DirectorioBase`).

**Esto es DEMO-ONLY / PROPUESTO, no una decisión arquitectónica definitiva** (ver `UI_Decision_Log.md` DEC-004): disco local no es apto para un despliegue con múltiples réplicas del servicio, porque cada réplica vería un subconjunto distinto de archivos. La tecnología definitiva de almacenamiento de blobs (Azure Blob Storage, S3, un volumen de red compartido, etc.) queda **PENDIENTE** — es una decisión de infraestructura que todavía no se ha tomado (sección 3 de las instrucciones del proyecto). Cuando se tome, solo cambia la implementación de `IAlmacenamientoArchivos`; el puerto y el resto del microservicio no se ven afectados.

## Database First — regenerar el modelo EF Core después de un cambio de esquema

```bash
cd src/services/MprDocumentos/MprDocumentos.Infrastructure
dotnet ef dbcontext scaffold \
    "Server=localhost,1436;Database=MprDocumentosDb;User Id=sa;Password=<password>;TrustServerCertificate=True;" \
    Microsoft.EntityFrameworkCore.SqlServer \
    --context MprDocumentosDbContext \
    --output-dir Persistencia/ModelosGenerados \
    --context-dir Persistencia \
    --no-onconfiguring \
    --force
```

- **Generado por scaffold (no editar a mano):** `Persistencia/ModelosGenerados/` y la clase parcial base `MprDocumentosDbContext`.
- **Escrito manualmente:** `Persistencia/Adaptadores/` (repositorio que implementa `IRepositorioDocumentos`), `Almacenamiento/` (adaptador de almacenamiento local).
- La contraseña real **nunca** se comitea — mismo criterio que los demás microservicios.

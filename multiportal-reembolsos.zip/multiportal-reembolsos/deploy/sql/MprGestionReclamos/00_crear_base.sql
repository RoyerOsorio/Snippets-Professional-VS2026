-- ============================================================================
-- MprGestionReclamos - Creación de base de datos
-- Cada microservicio posee su propia base SQL Server. MprGestionReclamos
-- NUNCA debe ser consultada directamente por otro microservicio ni contener
-- FKs físicas hacia bases de otros bounded contexts.
-- ============================================================================
IF DB_ID('MprGestionReclamosDb') IS NULL
BEGIN
    CREATE DATABASE MprGestionReclamosDb;
END
GO

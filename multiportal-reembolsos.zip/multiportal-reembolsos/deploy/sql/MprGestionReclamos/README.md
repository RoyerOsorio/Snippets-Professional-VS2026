# MprGestionReclamos — Base de datos

## Crear/restaurar localmente

```bash
sqlcmd -S localhost,1433 -U sa -P "<password>" -i 00_crear_base.sql
sqlcmd -S localhost,1433 -U sa -P "<password>" -i 01_crear_tablas.sql
```

No hay `02_datos_demo.sql` para este microservicio: los Reclamos se crean a través de `POST /v1/reclamos` (vía Orchestrator o directamente), no tiene sentido precargar catálogo — a diferencia de Motivo/Documento en MprConfiguracionReglas, un Reclamo es una instancia transaccional, no un catálogo.

## Alcance de este esquema — nota importante

**Este esquema no proviene del archivo `MprCliente.txt` / `MprConfiguracionReglas.txt` que sí sirvieron de fuente de verdad para los otros dos microservicios.** MprGestionReclamos es un microservicio nuevo: el ciclo de vida del Reclamo (`CrearReclamo`, `EnviarReclamo`, `AprobarReclamo`, `RechazarReclamo`) no existía como tabla en el monolito `Vitamedica.Multiportal`. El esquema (`MTP_RCRC_MRECLAMO`) se diseñó siguiendo la misma convención de nombres ya usada en el proyecto (prefijo de 4 letras + sufijo de tabla), pero es una propuesta nueva, no un mapeo 1:1 de algo existente. Si el negocio ya tiene un esquema real para reclamos, este debe reemplazarse por ese — no se inventó a partir de nada más que la convención de nombres.

## MTP_OBOX_MENSAJE — Transactional Outbox

Tabla genérica de patrón Outbox: cuando `AprobarReclamo` se ejecuta, en la misma transacción de base de datos se inserta una fila aquí con el evento `ReclamoAprobadoParaPago` serializado en JSON. Un `BackgroundService` (`OutboxPublisherHostedService`, en `MprGestionReclamos.Infrastructure/Mensajeria/`) sondea esta tabla y publica a RabbitMQ, marcando `OBOX_PUBLICADO = 1` solo después de que el broker confirma. Esto evita el problema clásico de "actualicé la base de datos pero el broker estaba caído" (o viceversa) sin necesitar una transacción distribuida (2PC).

## Database First — regenerar el modelo EF Core después de un cambio de esquema

```bash
cd src/services/MprGestionReclamos/MprGestionReclamos.Infrastructure
dotnet ef dbcontext scaffold \
    "Server=localhost,1433;Database=MprGestionReclamosDb;User Id=sa;Password=<password>;TrustServerCertificate=True;" \
    Microsoft.EntityFrameworkCore.SqlServer \
    --context MprGestionReclamosDbContext \
    --output-dir Persistencia/ModelosGenerados \
    --context-dir Persistencia \
    --no-onconfiguring \
    --force
```

- **Generado por scaffold (no editar a mano):** `Persistencia/ModelosGenerados/` y la clase parcial base `MprGestionReclamosDbContext`.
- **Escrito manualmente:** `Persistencia/Adaptadores/` (repositorio que implementa `IRepositorioReclamos`, incluido el patrón Outbox), `Integraciones/` (adaptador HTTP hacia MprConfiguracionReglas), `Mensajeria/` (publisher de RabbitMQ).
- La contraseña real **nunca** se comitea — mismo criterio que MprClientes/MprConfiguracionReglas.

-- ============================================================================
-- MprGestionReclamos - Tablas
--
-- A diferencia de MprClientes y MprConfiguracionReglas, este esquema NO
-- proviene de un archivo de esquema legado entregado — MprGestionReclamos es
-- un microservicio nuevo (el ciclo de vida del Reclamo no existía como tabla
-- en el monolito). Se diseñó siguiendo la misma convención de nombres del
-- proyecto (prefijo de 4 letras + sufijo de tabla).
--
-- MTP_RCRC_MRECLAMO: ciclo de vida del Reclamo (Creado, EnviadoParaRevision,
-- Aprobado, Rechazado — ver MprGestionReclamos.Domain.Entidades.EstadoReclamo).
--
-- MTP_OBOX_MENSAJE: tabla genérica de Transactional Outbox. No es específica
-- de Reclamo — cualquier evento de integración futuro de este microservicio
-- puede reutilizarla.
-- ============================================================================
USE MprGestionReclamosDb;
GO

IF OBJECT_ID('dbo.MTP_RCRC_MRECLAMO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_RCRC_MRECLAMO
    (
        RCRC_NID              int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        RCRC_POLIZA           varchar(20)   NOT NULL,
        RCRC_ASEGURADO_ID     int           NOT NULL,
        RCRC_MOTIVO_ID        int           NOT NULL,
        RCRC_ESTADO           tinyint       NOT NULL, -- 0=Creado, 1=EnviadoParaRevision, 2=Aprobado, 3=Rechazado
        RCRC_FECHA_CREACION   datetime      NOT NULL,
        RCRC_FECHA_ENVIO      datetime      NULL,
        RCRC_FECHA_RESOLUCION datetime      NULL,
        RCRC_MONTO_APROBADO   decimal(18,2) NULL,
        RCRC_MOTIVO_RECHAZO   varchar(250)  NULL
    );
END
GO

IF OBJECT_ID('dbo.MTP_OBOX_MENSAJE', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_OBOX_MENSAJE
    (
        OBOX_NID               bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
        OBOX_TIPO_EVENTO       varchar(100)   NOT NULL,
        OBOX_PAYLOAD_JSON      nvarchar(max)  NOT NULL,
        OBOX_FECHA_CREACION    datetime       NOT NULL,
        OBOX_FECHA_PUBLICACION datetime       NULL,
        OBOX_PUBLICADO         bit            NOT NULL DEFAULT (0)
    );

    CREATE INDEX IX_OBOX_PUBLICADO ON dbo.MTP_OBOX_MENSAJE (OBOX_PUBLICADO) WHERE OBOX_PUBLICADO = 0;
END
GO

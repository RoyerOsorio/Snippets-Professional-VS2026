-- ============================================================================
-- MprAuditoria - Creación de base de datos
-- Cada microservicio posee su propia base SQL Server. MprAuditoria NUNCA
-- debe ser consultada directamente por otro microservicio ni contener FKs
-- físicas hacia bases de otros bounded contexts (ReclamoId es un
-- identificador lógico hacia MprGestionReclamos).
-- ============================================================================
IF DB_ID('MprAuditoriaDb') IS NULL
BEGIN
    CREATE DATABASE MprAuditoriaDb;
END
GO

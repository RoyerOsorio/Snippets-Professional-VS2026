-- ============================================================================
-- MprAuditoria - Tablas
--
-- Esquema nuevo, no proviene de un archivo de esquema legado — MprAuditoria
-- no existía como tabla en el monolito Vitamedica.Multiportal.
--
-- MTP_AUDI_MEVENTO: bitácora append-only de eventos de integración
-- consumidos (ReclamoAprobadoParaPago, PagoCompletado). AUDI_MENSAJE_ID_ORIGEN
-- tiene una restricción de unicidad — mismo criterio de idempotencia que
-- PGPG_MENSAJE_ID_ORIGEN en MprPagos (ver UI_Decision_Log.md DEC-006 y
-- DEC-007). AUDI_RECLAMO_ID tiene un índice de soporte porque la consulta
-- principal (timeline por Reclamo) filtra por esa columna.
--
-- Sin tabla MTP_OBOX_MENSAJE aquí: a diferencia de MprGestionReclamos y
-- MprPagos, MprAuditoria es un consumidor terminal — no publica ningún
-- evento de integración propio, así que no necesita Transactional Outbox.
-- ============================================================================
USE MprAuditoriaDb;
GO

IF OBJECT_ID('dbo.MTP_AUDI_MEVENTO', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MTP_AUDI_MEVENTO
    (
        AUDI_NID                 bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
        AUDI_MENSAJE_ID_ORIGEN   bigint         NOT NULL,
        AUDI_TIPO_EVENTO         varchar(100)   NOT NULL,
        AUDI_RECLAMO_ID          int            NOT NULL,
        AUDI_PAYLOAD_JSON        nvarchar(max)  NOT NULL,
        AUDI_FECHA_OCURRENCIA    datetime       NOT NULL,
        AUDI_FECHA_REGISTRO      datetime       NOT NULL
    );

    CREATE UNIQUE INDEX UQ_MTP_AUDI_MEVENTO_MENSAJE_ID_ORIGEN ON dbo.MTP_AUDI_MEVENTO (AUDI_MENSAJE_ID_ORIGEN);
    CREATE INDEX IX_MTP_AUDI_MEVENTO_RECLAMO_ID ON dbo.MTP_AUDI_MEVENTO (AUDI_RECLAMO_ID);
END
GO

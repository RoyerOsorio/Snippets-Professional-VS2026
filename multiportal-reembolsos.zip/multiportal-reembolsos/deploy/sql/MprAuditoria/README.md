# MprAuditoria — Base de datos

## Crear/restaurar localmente

```bash
sqlcmd -S localhost,1438 -U sa -P "<password>" -i 00_crear_base.sql
sqlcmd -S localhost,1438 -U sa -P "<password>" -i 01_crear_tablas.sql
```

No hay `02_datos_demo.sql`: un registro de auditoría se crea únicamente a partir de un evento de integración consumido de RabbitMQ — no tiene sentido precargar catálogo, mismo criterio que Reclamo (MprGestionReclamos), Documento (MprDocumentos) y Pago (MprPagos).

## Alcance de este esquema — nota importante

**Este esquema no proviene de un archivo de esquema legado.** MprAuditoria es un microservicio nuevo: no existía como tabla en el monolito `Vitamedica.Multiportal`. El esquema (`MTP_AUDI_MEVENTO`) se diseñó siguiendo la convención de nombres ya usada en el proyecto, pero es una propuesta nueva, no un mapeo 1:1 de algo existente.

## Idempotencia de los consumidores — `AUDI_MENSAJE_ID_ORIGEN`

MprAuditoria consume **dos** eventos del exchange `multiportal.reembolsos`: `ReclamoAprobadoParaPago` (publicado por MprGestionReclamos, DEC-003) y `PagoCompletado` (publicado por MprPagos, DEC-006). `AUDI_MENSAJE_ID_ORIGEN` guarda el `MessageId` del mensaje RabbitMQ (el `OboxNid` que el microservicio publicador le asignó) con una restricción `UNIQUE`, dando las mismas dos capas de protección contra procesamiento duplicado que ya usa MprPagos:

1. **Nivel aplicación** (`RegistrarEventoAuditoriaCasoDeUso`): consulta si ya existe un registro con ese `MensajeIdOrigen` antes de insertar uno nuevo.
2. **Nivel base de datos** (`UQ_MTP_AUDI_MEVENTO_MENSAJE_ID_ORIGEN`): backstop ante una condición de carrera que la verificación en aplicación por sí sola no cubre.

Nota: el `MessageId` es único por mensaje individual, no por tipo de evento — un `ReclamoAprobadoParaPago` y un `PagoCompletado` nunca comparten `MessageId` (cada uno lleva el `OboxNid` de su propio microservicio de origen), así que no hay colisión entre los dos consumidores aunque escriban en la misma tabla.

## Sin Transactional Outbox

A diferencia de MprGestionReclamos y MprPagos, MprAuditoria **no** tiene tabla `MTP_OBOX_MENSAJE` ni `OutboxPublisherHostedService`. Es un consumidor terminal del ejercicio: no existe ningún microservicio adicional que necesite reaccionar a un evento propio de MprAuditoria. Se evaluó explícitamente y se decidió no introducir Outbox aquí — siguiendo la regla anti-sobreingeniería del proyecto (sección 11 de las instrucciones), no se agrega infraestructura de publicación sin un consumidor real que la necesite. Ver `UI_Decision_Log.md` DEC-007.

## Database First — regenerar el modelo EF Core después de un cambio de esquema

```bash
cd src/services/MprAuditoria/MprAuditoria.Infrastructure
dotnet ef dbcontext scaffold \
    "Server=localhost,1438;Database=MprAuditoriaDb;User Id=sa;Password=<password>;TrustServerCertificate=True;" \
    Microsoft.EntityFrameworkCore.SqlServer \
    --context MprAuditoriaDbContext \
    --output-dir Persistencia/ModelosGenerados \
    --context-dir Persistencia \
    --no-onconfiguring \
    --force
```

- **Generado por scaffold (no editar a mano):** `Persistencia/ModelosGenerados/` y la clase parcial base `MprAuditoriaDbContext`.
- **Escrito manualmente:** `Persistencia/Adaptadores/` (repositorio que implementa `IRepositorioEventosAuditoria`), `Mensajeria/` (dos consumidores: `ReclamoAprobadoParaPagoConsumerHostedService` y `PagoCompletadoConsumerHostedService`).
- La contraseña real **nunca** se comitea — mismo criterio que los demás microservicios.

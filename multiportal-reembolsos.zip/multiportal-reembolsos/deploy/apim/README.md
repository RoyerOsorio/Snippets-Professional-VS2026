# De YARP local a Azure API Management

Este documento traduce el `Multiportal.ApiGateway` (YARP) local a su equivalente conceptual en Azure APIM, para cuando el equipo decida provisionar APIM. **No se decide aquí si/cuándo se hace esa migración** — es una decisión de infraestructura pendiente (ver `UI_Architecture_Guide.md` sección 8 del Project). Este documento solo deja preparado el mapeo para que la migración sea mecánica cuando se apruebe.

## Mapeo de conceptos

| YARP (local) | Azure APIM (futuro) |
|---|---|
| `ReverseProxy:Routes` en `appsettings.json` | Operaciones dentro de una API de APIM |
| `Match.Path` | Plantilla de URL de la operación |
| `Transforms` (`PathPattern`) | Política `<rewrite-uri>` |
| `Clusters:*:Destinations` | Backend configurado en la API o vía `<set-backend-service>` |
| (no implementado en el piloto) | Política `<validate-jwt>` — validación de token en el borde |
| (no implementado en el piloto) | Política `<rate-limit>` / `<quota>` |
| `Program.cs` (código) | Policies XML (`<inbound>`, `<backend>`, `<outbound>`, `<on-error>`) |

## Ejemplo de policy equivalente a la ruta `clientes-route`

```xml
<policies>
  <inbound>
    <base />
    <rewrite-uri template="/v1/clientes/{**catch-all}" />
    <!-- <validate-jwt ... /> cuando exista la decisión de autenticación de microservicios -->
  </inbound>
  <backend>
    <forward-request />
  </backend>
  <outbound>
    <base />
  </outbound>
</policies>
```

## Por qué YARP para la demo local

YARP permite ejecutar el mismo concepto de Gateway sin depender de una suscripción de Azure para correr la demo en la laptop de cualquiera del equipo. El comportamiento de "single entry point + routing" es el mismo; lo que APIM añade en producción (políticas de gobierno, analítica, developer portal, gestión de suscripciones) no es necesario para demostrar el flujo técnico end-to-end.

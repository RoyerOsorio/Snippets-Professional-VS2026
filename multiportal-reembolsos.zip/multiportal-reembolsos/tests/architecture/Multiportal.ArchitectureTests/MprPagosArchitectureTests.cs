using FluentAssertions;
using NetArchTest.Rules;
using Xunit;

namespace Multiportal.ArchitectureTests;

/// <summary>
/// Mismas reglas arquitectónicas que los demás microservicios, aplicadas a
/// MprPagos: Domain no depende de infraestructura ni de frameworks
/// externos (incluido RabbitMQ, a pesar de que este servicio publica Y
/// consume mensajes — la dependencia a RabbitMQ.Client vive únicamente en
/// Infrastructure/Mensajeria), y Application no depende de EF Core
/// directamente.
/// </summary>
public class MprPagosArchitectureTests
{
    private static readonly System.Reflection.Assembly EnsamblajeDomain =
        typeof(MprPagos.Domain.Entidades.Pago).Assembly;

    private static readonly System.Reflection.Assembly EnsamblajeApplication =
        typeof(MprPagos.Application.Casos.ProcesarReclamoAprobadoParaPagoCasoDeUso).Assembly;

    [Fact]
    public void Domain_no_depende_de_EntityFrameworkCore()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("Microsoft.EntityFrameworkCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_AspNetCore()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("Microsoft.AspNetCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_Infrastructure()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("MprPagos.Infrastructure")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_RabbitMq()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOnAny("RabbitMQ")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Application_no_depende_de_EntityFrameworkCore_directamente()
    {
        var resultado = Types.InAssembly(EnsamblajeApplication)
            .Should()
            .NotHaveDependencyOn("Microsoft.EntityFrameworkCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Application_no_depende_de_RabbitMq_directamente()
    {
        var resultado = Types.InAssembly(EnsamblajeApplication)
            .Should()
            .NotHaveDependencyOnAny("RabbitMQ")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }
}

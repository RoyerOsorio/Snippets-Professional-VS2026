using FluentAssertions;
using NetArchTest.Rules;
using Xunit;

namespace Multiportal.ArchitectureTests;

/// <summary>
/// Mismas reglas arquitectónicas que los demás microservicios, aplicadas a
/// MprGestionReclamos: Domain no depende de infraestructura ni de
/// frameworks externos (incluido RabbitMQ, a pesar de que este servicio sí
/// publica eventos — la dependencia a RabbitMQ.Client vive únicamente en
/// Infrastructure/Mensajeria), y Application no depende de EF Core
/// directamente.
/// </summary>
public class MprGestionReclamosArchitectureTests
{
    private static readonly System.Reflection.Assembly EnsamblajeDomain =
        typeof(MprGestionReclamos.Domain.Entidades.Reclamo).Assembly;

    private static readonly System.Reflection.Assembly EnsamblajeApplication =
        typeof(MprGestionReclamos.Application.Casos.CrearReclamoCasoDeUso).Assembly;

    [Fact]
    public void Domain_no_depende_de_EntityFrameworkCore()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("Microsoft.EntityFrameworkCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_AspNetCore()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("Microsoft.AspNetCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_Infrastructure()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("MprGestionReclamos.Infrastructure")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_RabbitMq()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOnAny("RabbitMQ")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Application_no_depende_de_EntityFrameworkCore_directamente()
    {
        var resultado = Types.InAssembly(EnsamblajeApplication)
            .Should()
            .NotHaveDependencyOn("Microsoft.EntityFrameworkCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Application_no_depende_de_RabbitMq_directamente()
    {
        // Application conoce el evento ReclamoAprobadoParaPagoEvento (un DTO
        // propio), pero no el cliente de RabbitMQ — eso lo publica
        // OutboxPublisherHostedService en Infrastructure.
        var resultado = Types.InAssembly(EnsamblajeApplication)
            .Should()
            .NotHaveDependencyOnAny("RabbitMQ")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }
}

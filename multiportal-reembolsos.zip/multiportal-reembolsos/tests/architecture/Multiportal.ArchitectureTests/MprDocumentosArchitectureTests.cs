using FluentAssertions;
using NetArchTest.Rules;
using Xunit;

namespace Multiportal.ArchitectureTests;

/// <summary>
/// Mismas reglas arquitectónicas que los demás microservicios, aplicadas a
/// MprDocumentos: Domain no depende de infraestructura ni de frameworks
/// externos, y Application no depende de EF Core directamente (el
/// almacenamiento de archivos también es un puerto — IAlmacenamientoArchivos
/// — implementado en Infrastructure, igual que la persistencia de metadata).
/// </summary>
public class MprDocumentosArchitectureTests
{
    private static readonly System.Reflection.Assembly EnsamblajeDomain =
        typeof(MprDocumentos.Domain.Entidades.DocumentoReclamo).Assembly;

    private static readonly System.Reflection.Assembly EnsamblajeApplication =
        typeof(MprDocumentos.Application.Casos.SubirDocumentoCasoDeUso).Assembly;

    [Fact]
    public void Domain_no_depende_de_EntityFrameworkCore()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("Microsoft.EntityFrameworkCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_AspNetCore()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("Microsoft.AspNetCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_Infrastructure()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("MprDocumentos.Infrastructure")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Application_no_depende_de_EntityFrameworkCore_directamente()
    {
        var resultado = Types.InAssembly(EnsamblajeApplication)
            .Should()
            .NotHaveDependencyOn("Microsoft.EntityFrameworkCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Application_no_depende_de_Infrastructure()
    {
        var resultado = Types.InAssembly(EnsamblajeApplication)
            .Should()
            .NotHaveDependencyOn("MprDocumentos.Infrastructure")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }
}

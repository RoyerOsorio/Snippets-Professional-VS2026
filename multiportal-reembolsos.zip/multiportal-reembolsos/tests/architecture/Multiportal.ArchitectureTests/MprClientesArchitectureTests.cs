using FluentAssertions;
using NetArchTest.Rules;
using Xunit;

namespace Multiportal.ArchitectureTests;

/// <summary>
/// Valida las reglas arquitectónicas obligatorias del ejercicio para
/// MprClientes: Domain no depende de infraestructura ni de frameworks
/// externos, y Application no depende de EF Core directamente (pasa siempre
/// por los puertos que Infrastructure implementa).
/// </summary>
public class MprClientesArchitectureTests
{
    private static readonly System.Reflection.Assembly EnsamblajeDomain =
        typeof(MprClientes.Domain.Entidades.ContextoContractualCliente).Assembly;

    private static readonly System.Reflection.Assembly EnsamblajeApplication =
        typeof(MprClientes.Application.Casos.ObtenerContextoClienteCasoDeUso).Assembly;

    [Fact]
    public void Domain_no_depende_de_EntityFrameworkCore()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("Microsoft.EntityFrameworkCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_AspNetCore()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("Microsoft.AspNetCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_Infrastructure()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("MprClientes.Infrastructure")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_RabbitMq()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOnAny("RabbitMQ")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Application_no_depende_de_EntityFrameworkCore_directamente()
    {
        // Application solo conoce los puertos (Puertos/*); el DbContext y las
        // entidades generadas por scaffold viven exclusivamente en
        // Infrastructure (ver Database First dentro de la arquitectura
        // hexagonal, docs/demo/README.md).
        var resultado = Types.InAssembly(EnsamblajeApplication)
            .Should()
            .NotHaveDependencyOn("Microsoft.EntityFrameworkCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }
}

using FluentAssertions;
using NetArchTest.Rules;
using Xunit;

namespace Multiportal.ArchitectureTests;

/// <summary>
/// Mismas reglas arquitectónicas que MprClientesArchitectureTests, aplicadas
/// a MprConfiguracionReglas: Domain no depende de infraestructura ni de
/// frameworks externos, y Application no depende de EF Core directamente.
/// </summary>
public class MprConfiguracionReglasArchitectureTests
{
    private static readonly System.Reflection.Assembly EnsamblajeDomain =
        typeof(MprConfiguracionReglas.Domain.Entidades.ReglaReembolso).Assembly;

    private static readonly System.Reflection.Assembly EnsamblajeApplication =
        typeof(MprConfiguracionReglas.Application.Casos.ObtenerReglaReembolsoCasoDeUso).Assembly;

    [Fact]
    public void Domain_no_depende_de_EntityFrameworkCore()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("Microsoft.EntityFrameworkCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_AspNetCore()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("Microsoft.AspNetCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_Infrastructure()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOn("MprConfiguracionReglas.Infrastructure")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Domain_no_depende_de_RabbitMq()
    {
        var resultado = Types.InAssembly(EnsamblajeDomain)
            .Should()
            .NotHaveDependencyOnAny("RabbitMQ")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Application_no_depende_de_EntityFrameworkCore_directamente()
    {
        var resultado = Types.InAssembly(EnsamblajeApplication)
            .Should()
            .NotHaveDependencyOn("Microsoft.EntityFrameworkCore")
            .GetResult();

        resultado.IsSuccessful.Should().BeTrue();
    }
}

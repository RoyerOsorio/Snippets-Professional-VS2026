// ============================================================================
// Program.snippet.cs — Referencia de las modificaciones a realizar en tu Program.cs.
// Las líneas marcadas con  // (+)  son las que debes AÑADIR.
// ============================================================================

using Vitamedica.Multiportal.UI.Extensions;                 // (+)
using Vitamedica.Multiportal.UI.Infrastructure.Filters;     // (+)

var builder = WebApplication.CreateBuilder(args);

// Registra el filtro global que inyecta el LayoutViewModel (Header/Sidebar/Footer)
// en ViewData para todas las vistas.
builder.Services.AddControllersWithViews(options =>
{
    options.Filters.Add<LayoutActionFilter>();              // (+)
});

// Registra navegación, branding y factoría de layout en una sola línea.
builder.Services.AddMultiportalUi(builder.Configuration);   // (+)

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// IMPRESCINDIBLE para que el Header muestre el usuario y "Cerrar sesión":
// la autenticación externa (SSO) debe estar configurada antes de la autorización.
app.UseAuthentication();                                    // (+ si no existe)
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();

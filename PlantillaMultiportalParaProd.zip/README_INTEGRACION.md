# Guía de integración — Infraestructura de UI (Header, Sidebar, Footer)
## Vitamedica.Multiportal.UI · ASP.NET Core MVC (.NET 10) · Bootstrap 5.3.3 · Lucide

Esta guía indica **exactamente** qué archivos crear, cuáles modificar y cómo integrarlos. No asume nada del proyecto salvo lo verificado en `_Layout.txt` (proyecto `Vitamedica.Multiportal.UI`, con `HomeController` y `SesionController`, autenticación por sesión y logout por POST a `Sesion/Logout`).

---

## 1. Colocación de archivos (copiar tal cual la estructura)

```
Vitamedica.Multiportal.UI/
├── Models/ViewModels/
│   ├── MenuItemViewModel.cs
│   └── LayoutViewModel.cs                 (SidebarVM, CurrentUserVM, BrandingVM, LayoutVM)
├── Services/
│   ├── Navigation/
│   │   ├── INavigationProvider.cs         (interfaz + StaticNavigationProvider)
│   │   └── INavigationService.cs          (interfaz + NavigationService)
│   ├── Branding/
│   │   └── BrandingService.cs             (BrandingOptions + IBrandingService + BrandingService)
│   └── Layout/
│       └── LayoutViewModelFactory.cs      (interfaz + implementación)
├── Infrastructure/Filters/
│   └── LayoutActionFilter.cs
├── Extensions/
│   └── ServiceCollectionExtensions.cs     (AddMultiportalUi)
├── Views/
│   ├── _ViewImports.cshtml                (MODIFICAR: fusionar con el existente)
│   └── Shared/
│       ├── _Layout.cshtml                 (REEMPLAZAR el actual)
│       ├── _Header.cshtml                 (NUEVO)
│       ├── _Sidebar.cshtml                (NUEVO)
│       ├── _SidebarItems.cshtml           (NUEVO — partial recursivo)
│       └── _Footer.cshtml                 (NUEVO)
└── wwwroot/
    ├── css/  tokens.css · layout.css · header.css · sidebar.css · footer.css · site-custom.css
    └── js/   layout.js · sidebar.js · header.js
```

**Archivos que se MODIFICAN** (no se crean de cero): `Views/_ViewImports.cshtml`, `Views/Shared/_Layout.cshtml`, `Program.cs`, `appsettings.json`.
**Todo lo demás es NUEVO.**

---

## 2. _ViewImports.cshtml

Fusiona el contenido provisto con tu `_ViewImports.cshtml` (mantén los `@using`/TagHelpers que ya tuvieras). Debe quedar el `@addTagHelper *, Microsoft.AspNetCore.Mvc.TagHelpers` y los `@using` de los ViewModels y del filtro.

---

## 3. Program.cs (ver `Program.snippet.cs`)

Añade **tres cosas**:

1. `builder.Services.AddControllersWithViews(options => options.Filters.Add<LayoutActionFilter>());`
2. `builder.Services.AddMultiportalUi(builder.Configuration);`
3. Verifica que existan `app.UseAuthentication();` y `app.UseAuthorization();` (en ese orden, tras `UseRouting`). Sin `UseAuthentication`, `User.Identity.IsAuthenticated` será false y el Header no mostrará el menú de usuario.

No se requieren paquetes NuGet adicionales.

---

## 4. appsettings.json (ver `appsettings.Branding.snippet.json`)

Fusiona la sección `"Branding"`. Campos:
- `SystemName`: nombre del sistema por defecto (texto dinámico del Header).
- `SystemNameByClient`: mapa opcional host → nombre, para multi-cliente.
- `CompanyName`, `LegalName`, `AddressLine`, `Version`: alimentan el Footer.
- `ShowChangePassword`: **pendiente R2** — déjalo en `true` si el sistema real expone cambio de contraseña; ponlo en `false` cuando el SSO gestione credenciales.

El nombre del sistema también puede venir de un claim `system_name` del usuario (tiene prioridad sobre la configuración).

---

## 5. Carga de CSS (ya resuelta en `_Layout.cshtml`)

Orden obligatorio (los tokens primero): Bootstrap → `tokens.css` → `layout.css` → `header.css` → `sidebar.css` → `footer.css` → `site-custom.css`. `asp-append-version="true"` cachebustea automáticamente.

> Producción sin CDN: descarga Bootstrap 5.3.3 a `wwwroot/lib/bootstrap/` y cambia los `href`/`src`. Igual para Inter (auto-hospedaje recomendado) y Lucide.

---

## 6. Carga de JavaScript (ya resuelta en `_Layout.cshtml`)

Orden: Bootstrap bundle → Lucide → `layout.js` → `sidebar.js` → `header.js`. `layout.js` define `window.VM` y **debe** ir antes que `sidebar.js`/`header.js`.

---

## 7. Lucide Icons

Se cargan por CDN y se renderizan con `lucide.createIcons()` (invocado en `layout.js` al `DOMContentLoaded` y reexpuesto como `window.VM.refreshIcons()`). Los íconos se declaran en el markup como `<i data-lucide="nombre"></i>`. Si inyectas HTML dinámico con íconos nuevos, llama `window.VM.refreshIcons()` después.

---

## 8. Controladores/acciones referenciados

El menú y el Footer enlazan a acciones mediante Tag Helpers. Ajusta los nombres a tu ruteo real o crea los controladores:
- Sidebar: `Home/Index` (Tablero), `Reembolsos/{Nueva,Retroceder,Pagos,Index}`.
- Header: `Perfil/Index`, `Cuenta/CambiarContrasena`, `Sesion/Logout` (POST, ya existe).
- Footer: `Legal/{Privacidad,AvisoPrivacidad,DerechosArco,Terminos}`.

Enlaces a acciones aún inexistentes no rompen la compilación (se resuelven en runtime); crea las vistas conforme avancen los módulos. Para añadir módulos al Sidebar, edita **solo** `StaticNavigationProvider`.

---

## 9. Resultado esperado

- Header azul `#007acc` fijo (sticky), con toggle, logo, nombre dinámico centrado y menú de usuario; texto/íconos blancos con foco visible.
- Sidebar multinivel con estado activo (barra izquierda), submenús animados, colapso a riel en desktop/tablet, drawer en móvil, scroll propio y persistencia (colapso, grupos abiertos, densidad).
- Footer institucional con información legal, copyright, empresa y versión; responsive.
- Accesibilidad: landmarks `banner`/`navigation`/`contentinfo`, skip link, `aria-expanded`/`aria-current`, navegación por teclado, `prefers-reduced-motion`.

---

## 10. Impacto en el Design System

**Ninguno.** Esta implementación materializa el Layout Maestro v1.1 y la Guía v1.1 ya aprobados; no introduce decisiones nuevas de diseño. No se requiere actualizar documentación.

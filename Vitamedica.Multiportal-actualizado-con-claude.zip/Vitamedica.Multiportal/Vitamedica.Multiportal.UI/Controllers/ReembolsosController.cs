﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Vitamedica.Multiportal.UI.Models.ActiveDirectory;
using Vitamedica.Multiportal.UI.Models.ViewModels;
using Vitamedica.Multiportal.UI.Services;

namespace Vitamedica.Multiportal.UI.Controllers
{
    [Authorize]
    public class ReembolsosController : Controller
    {
        private const int TamanioPaginaPorDefecto = 25;

        public IActionResult Index()
        {
            var resultado = Paginar(ObtenerSolicitudesSimuladas(), pagina: 1, tamanioPagina: TamanioPaginaPorDefecto);
            return View(resultado);
        }

        // ====================================================================
        // Fase 2 — filtros conectados al listado simulado de Fase 1.
        // Fase 3 — se agrega paginación real (pagina/tamanioPagina) sobre el
        // resultado ya filtrado (ver UI_Decision_Log.md). Sigue devolviendo un
        // PartialView (no JSON): reutiliza exactamente el mismo marcado Razor
        // que ya usa Index() para la carga inicial, en vez de reconstruir la
        // fila en JavaScript.
        //
        // Fix (ver DEC-Pagos-Index-Paginacion.md, "Hallazgo: pie de tabla no
        // se actualiza en Reembolsos/Buscar"): antes devolvía solo
        // Partials/_ResultadosSolicitudes (el <tbody>), por lo que el pie
        // (#pieTablaSolicitudes) nunca llegaba a actualizarse tras un fetch,
        // aunque reembolsos-index.js ya intentaba reemplazarlo. Ahora
        // devuelve Partials/_ResultadosYPaginacionSolicitudes, que concatena
        // ambos fragmentos — mismo patrón ya usado en Pagos (Fase F3).
        // ====================================================================
        [HttpGet]
        public IActionResult Buscar(SolicitudReembolsoFiltroViewModel filtro, int pagina = 1, int tamanioPagina = TamanioPaginaPorDefecto)
        {
            var filtrado = AplicarFiltro(ObtenerSolicitudesSimuladas(), filtro);
            var resultado = Paginar(filtrado, pagina, tamanioPagina);
            return PartialView("Partials/_ResultadosYPaginacionSolicitudes", resultado);
        }

        public IActionResult Crear()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
            {
                try
                {
                    return View();
                }
                catch (Exception ex)
                {

                }
            }
            return View(new UserProfile());
        }

        // ====================================================================
        // Fase D — recibe el id de la fila seleccionada en Reembolsos/Index
        // (el enlace "Ver detalle" ya lo mandaba desde Fase 1, pero esta
        // acción lo ignoraba). Alcance acotado (ver UI_Decision_Log.md): solo
        // se conecta el encabezado (folio, estaciones, datos del paciente/
        // beneficiario) — el resto de Detalle.cshtml (titular, reclamación,
        // evidencias, notas, saldo) sigue hardcodeado, documentado como
        // pendiente de un modelo de dictamen que todavía no está definido.
        //
        // Si el id no corresponde a ninguna solicitud simulada: 404, no
        // redirección — decisión explícita del usuario.
        // ====================================================================
        public IActionResult Detalle(int id)
        {
            var solicitud = ObtenerSolicitudesSimuladas().FirstOrDefault(s => s.Id == id);
            if (solicitud == null)
                return NotFound();

            var detalle = new SolicitudReembolsoDetalleViewModel
            {
                Id = solicitud.Id,
                Folio = solicitud.Folio,
                Poliza = solicitud.Poliza,
                NombreBeneficiario = solicitud.NombreBeneficiario,
                Parentesco = solicitud.Parentesco,
                Fecha = solicitud.Fecha,
                Estatus = solicitud.Estatus,
                EstacionActual = solicitud.EstacionActual,
                Estaciones = TraducirAEstaciones(solicitud.EstacionActual),
            };

            return View(detalle);
        }

        // ====================================================================
        // Simulación temporal del listado del Tablero de Reembolsos — sin base
        // de datos ni Service todavía (ver Fase 1, UI_Decision_Log.md). Cuando
        // exista persistencia/API real, este método se sustituye por una
        // llamada a un Service/ApiClient inyectado (ej. await
        // _reembolsosService.ObtenerSolicitudesAsync()), sin que Index()/Buscar()
        // ni la vista necesiten cambiar de forma — todos ya consumen
        // List<SolicitudReembolsoResumenViewModel>, nunca este método.
        // Mismo patrón ya usado en ClientesController.ObtenerModulosSimulados().
        //
        // Fase 3: se amplía de 8 a 24 filas (mismo patrón/forma, sin campos
        // nuevos) para que la paginación sea demostrable con el tamaño de
        // página más chico del selector (10) — con 8 filas jamás habría una
        // segunda página. Cambio aprobado explícitamente por el usuario.
        // ====================================================================
        private static List<SolicitudReembolsoResumenViewModel> ObtenerSolicitudesSimuladas() => new()
        {
            new SolicitudReembolsoResumenViewModel { Id = 1,  Folio = "0104271661", Poliza = "34521098", NombreBeneficiario = "Marisol Hernández Duarte",     Parentesco = "Titular",  Monto = 12480.00m, Fecha = new DateTime(2026, 7, 3),  EstacionActual = "Dictamen médico",         Estatus = "En proceso", Cobertura = "GMM Mayor",  Flujo = "Ordinario", FolioFiscal = "3F2A9B7C-D1E4" },
            new SolicitudReembolsoResumenViewModel { Id = 2,  Folio = "0104271662", Poliza = "34558820", NombreBeneficiario = "Roberto Carlos Nieto Salas",    Parentesco = "Titular",  Monto = 3260.50m,  Fecha = new DateTime(2026, 7, 2),  EstacionActual = "Validación documental",   Estatus = "Corregido",  Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "8C4D2E1F-A9B3" },
            new SolicitudReembolsoResumenViewModel { Id = 3,  Folio = "0104271663", Poliza = "34509912", NombreBeneficiario = "Fernanda Paola Ríos Castillo",  Parentesco = "Cónyuge", Monto = 850.00m,   Fecha = new DateTime(2026, 7, 1),  EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "Maternidad", Flujo = "Maternidad", FolioFiscal = "1A2B3C4D-5E6F" },
            new SolicitudReembolsoResumenViewModel { Id = 4,  Folio = "0104271664", Poliza = "34577345", NombreBeneficiario = "Alejandro Gómez Treviño",       Parentesco = "Titular",  Monto = 32800.00m, Fecha = new DateTime(2026, 6, 30), EstacionActual = "Autorización de pago",    Estatus = "Aprobado",   Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "7D8E9F0A-B1C2" },
            new SolicitudReembolsoResumenViewModel { Id = 5,  Folio = "0104271665", Poliza = "34512276", NombreBeneficiario = "Itzel Guadalupe Montes Vera",   Parentesco = "Hijo(a)", Monto = 1420.00m,  Fecha = new DateTime(2026, 6, 29), EstacionActual = "Dictamen médico",         Estatus = "En proceso", Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "4B5C6D7E-8F9A" },
            new SolicitudReembolsoResumenViewModel { Id = 6,  Folio = "0104271666", Poliza = "34598010", NombreBeneficiario = "Sergio Iván Delgado Rosales",   Parentesco = "Titular",  Monto = 620.00m,   Fecha = new DateTime(2026, 6, 28), EstacionActual = "Revisión de póliza",      Estatus = "Rechazado",  Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "2E3F4A5B-6C7D" },
            new SolicitudReembolsoResumenViewModel { Id = 7,  Folio = "0104271667", Poliza = "34533187", NombreBeneficiario = "Daniela Contreras Barajas",     Parentesco = "Titular",  Monto = 5140.00m,  Fecha = new DateTime(2026, 6, 27), EstacionActual = "Validación documental",   Estatus = "Corregido",  Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "9A0B1C2D-3E4F" },
            new SolicitudReembolsoResumenViewModel { Id = 8,  Folio = "0104271668", Poliza = "34561429", NombreBeneficiario = "Luis Fernando Aguilar Peña",    Parentesco = "Cónyuge",  Monto = 9930.00m,  Fecha = new DateTime(2026, 6, 26), EstacionActual = "Pago autorizado",         Estatus = "En proceso", Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "5C6D7E8F-9A0B" },
            new SolicitudReembolsoResumenViewModel { Id = 9,  Folio = "0104271669", Poliza = "34544567", NombreBeneficiario = "Karla Jimena Suárez Ponce",     Parentesco = "Titular",  Monto = 2150.00m,  Fecha = new DateTime(2026, 6, 25), EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "6A7B8C9D-0E1F" },
            new SolicitudReembolsoResumenViewModel { Id = 10, Folio = "0104271670", Poliza = "34590233", NombreBeneficiario = "Óscar Iván Beltrán Solís",      Parentesco = "Hijo(a)",  Monto = 780.00m,   Fecha = new DateTime(2026, 6, 24), EstacionActual = "Dictamen médico",         Estatus = "Aprobado",   Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "0F1E2D3C-4B5A" },
            new SolicitudReembolsoResumenViewModel { Id = 11, Folio = "0104271671", Poliza = "34567891", NombreBeneficiario = "Paulina Isabel Cordero Luna",   Parentesco = "Titular",  Monto = 15600.00m, Fecha = new DateTime(2026, 6, 23), EstacionActual = "Autorización de pago",    Estatus = "Aprobado",   Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "1B2C3D4E-5F6A" },
            new SolicitudReembolsoResumenViewModel { Id = 12, Folio = "0104271672", Poliza = "34523456", NombreBeneficiario = "Emilio Rodrigo Vargas Nuño",    Parentesco = "Cónyuge",  Monto = 430.00m,   Fecha = new DateTime(2026, 6, 22), EstacionActual = "Revisión de póliza",      Estatus = "Rechazado",  Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "2C3D4E5F-6A7B" },
            new SolicitudReembolsoResumenViewModel { Id = 13, Folio = "0104271673", Poliza = "34578901", NombreBeneficiario = "Ximena Alejandra Torres Campos",Parentesco = "Titular",  Monto = 890.00m,   Fecha = new DateTime(2026, 6, 21), EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "Maternidad", Flujo = "Maternidad", FolioFiscal = "3D4E5F6A-7B8C" },
            new SolicitudReembolsoResumenViewModel { Id = 14, Folio = "0104271674", Poliza = "34534567", NombreBeneficiario = "Iván Alberto Reséndiz Cano",     Parentesco = "Titular",  Monto = 7230.00m,  Fecha = new DateTime(2026, 6, 20), EstacionActual = "Validación documental",   Estatus = "Corregido",  Cobertura = "GMM Mayor",  Flujo = "Ordinario", FolioFiscal = "4E5F6A7B-8C9D" },
            new SolicitudReembolsoResumenViewModel { Id = 15, Folio = "0104271675", Poliza = "34589012", NombreBeneficiario = "Regina Montserrat Ochoa Lara",  Parentesco = "Hijo(a)",  Monto = 310.00m,   Fecha = new DateTime(2026, 6, 19), EstacionActual = "Dictamen médico",         Estatus = "En proceso", Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "5F6A7B8C-9D0E" },
            new SolicitudReembolsoResumenViewModel { Id = 16, Folio = "0104271676", Poliza = "34545678", NombreBeneficiario = "Gerardo Iván Palacios Meza",    Parentesco = "Titular",  Monto = 21400.00m, Fecha = new DateTime(2026, 6, 18), EstacionActual = "Pago autorizado",         Estatus = "Aprobado",   Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "6A7B8C9D-0E1F" },
            new SolicitudReembolsoResumenViewModel { Id = 17, Folio = "0104271677", Poliza = "34590123", NombreBeneficiario = "Alondra Sofía Miranda Vega",    Parentesco = "Cónyuge",  Monto = 1980.00m,  Fecha = new DateTime(2026, 6, 17), EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "7B8C9D0E-1F2A" },
            new SolicitudReembolsoResumenViewModel { Id = 18, Folio = "0104271678", Poliza = "34556789", NombreBeneficiario = "Tomás Eduardo Salinas Rocha",   Parentesco = "Titular",  Monto = 540.00m,   Fecha = new DateTime(2026, 6, 16), EstacionActual = "Revisión de póliza",      Estatus = "Rechazado",  Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "8C9D0E1F-2A3B" },
            new SolicitudReembolsoResumenViewModel { Id = 19, Folio = "0104271679", Poliza = "34501234", NombreBeneficiario = "Valeria Guadalupe Espinoza Ríos",Parentesco = "Titular", Monto = 3720.00m,  Fecha = new DateTime(2026, 6, 15), EstacionActual = "Validación documental",   Estatus = "Corregido",  Cobertura = "GMM Mayor",  Flujo = "Ordinario", FolioFiscal = "9D0E1F2A-3B4C" },
            new SolicitudReembolsoResumenViewModel { Id = 20, Folio = "0104271680", Poliza = "34567345", NombreBeneficiario = "Rodrigo Emiliano Castañeda Ibarra", Parentesco = "Hijo(a)", Monto = 6100.00m, Fecha = new DateTime(2026, 6, 14), EstacionActual = "Dictamen médico",         Estatus = "En proceso", Cobertura = "Maternidad", Flujo = "Maternidad", FolioFiscal = "0E1F2A3B-4C5D" },
            new SolicitudReembolsoResumenViewModel { Id = 21, Folio = "0104271681", Poliza = "34512890", NombreBeneficiario = "Melissa Andrea Guerrero Payán", Parentesco = "Titular",  Monto = 980.00m,   Fecha = new DateTime(2026, 6, 13), EstacionActual = "Autorización de pago",    Estatus = "Aprobado",   Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "1F2A3B4C-5D6E" },
            new SolicitudReembolsoResumenViewModel { Id = 22, Folio = "0104271682", Poliza = "34578456", NombreBeneficiario = "Diego Armando Cervantes Uribe", Parentesco = "Cónyuge",  Monto = 14250.00m, Fecha = new DateTime(2026, 6, 12), EstacionActual = "Pago autorizado",         Estatus = "Aprobado",   Cobertura = "GMM Mayor",  Flujo = "Urgencia",  FolioFiscal = "2A3B4C5D-6E7F" },
            new SolicitudReembolsoResumenViewModel { Id = 23, Folio = "0104271683", Poliza = "34523901", NombreBeneficiario = "Natalia Fernanda Bravo Solano", Parentesco = "Titular",  Monto = 460.00m,   Fecha = new DateTime(2026, 6, 11), EstacionActual = "Recepción de documentos", Estatus = "En proceso", Cobertura = "Dental",     Flujo = "Ordinario", FolioFiscal = "3B4C5D6E-7F8A" },
            new SolicitudReembolsoResumenViewModel { Id = 24, Folio = "0104271684", Poliza = "34589567", NombreBeneficiario = "Jorge Luis Montoya Zepeda",     Parentesco = "Titular",  Monto = 2870.00m,  Fecha = new DateTime(2026, 6, 10), EstacionActual = "Revisión de póliza",      Estatus = "Rechazado",  Cobertura = "GMM Menor",  Flujo = "Ordinario", FolioFiscal = "4C5D6E7F-8A9B" },
        };

        // ====================================================================
        // Filtro en memoria sobre la lista simulada — sustituye a la futura
        // llamada real (Service/ApiClient con filtro en el servidor de datos).
        // Cada campo nulo/"Todos"/"Todas" significa "sin restricción" (ver
        // SolicitudReembolsoFiltroViewModel). AND entre campos, no OR — mismo
        // criterio que el filtro combinado del Legacy (ver Legacy_Functional_
        // Gap_Analysis.md).
        // ====================================================================
        private static List<SolicitudReembolsoResumenViewModel> AplicarFiltro(
            List<SolicitudReembolsoResumenViewModel> solicitudes,
            SolicitudReembolsoFiltroViewModel filtro)
        {
            IEnumerable<SolicitudReembolsoResumenViewModel> query = solicitudes;

            if (!string.IsNullOrWhiteSpace(filtro.Folio))
                query = query.Where(s => s.Folio.Contains(filtro.Folio, StringComparison.OrdinalIgnoreCase));

            if (filtro.FechaDesde.HasValue)
                query = query.Where(s => s.Fecha.Date >= filtro.FechaDesde.Value.Date);

            if (filtro.FechaHasta.HasValue)
                query = query.Where(s => s.Fecha.Date <= filtro.FechaHasta.Value.Date);

            if (!string.IsNullOrWhiteSpace(filtro.Estatus) && filtro.Estatus != "Todos")
                query = query.Where(s => string.Equals(s.Estatus, filtro.Estatus, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.Poliza))
                query = query.Where(s => s.Poliza.Contains(filtro.Poliza, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.Cobertura) && filtro.Cobertura != "Todas")
                query = query.Where(s => string.Equals(s.Cobertura, filtro.Cobertura, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.Flujo) && filtro.Flujo != "Todos")
                query = query.Where(s => string.Equals(s.Flujo, filtro.Flujo, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(filtro.FolioFiscal))
                query = query.Where(s => s.FolioFiscal.Contains(filtro.FolioFiscal, StringComparison.OrdinalIgnoreCase));

            return query.ToList();
        }

        // ====================================================================
        // Paginación (Fase 3) — se aplica siempre después del filtro, nunca
        // antes. La página solicitada se ajusta (clamp) al rango válido
        // [1, TotalPaginas]: si el filtro deja menos páginas de las que
        // existían y la página pedida ya no existe, se regresa la última
        // página válida en vez de una lista vacía por error de rango — mismo
        // criterio (simplificado) que ListaTablero en el Legacy.
        // ====================================================================
        private static SolicitudReembolsoResultadoViewModel Paginar(
            List<SolicitudReembolsoResumenViewModel> solicitudes,
            int pagina,
            int tamanioPagina)
        {
            if (tamanioPagina <= 0)
                tamanioPagina = TamanioPaginaPorDefecto;

            var totalRegistros = solicitudes.Count;
            var totalPaginas = totalRegistros == 0
                ? 1
                : (int)Math.Ceiling(totalRegistros / (double)tamanioPagina);

            if (pagina < 1)
                pagina = 1;
            if (pagina > totalPaginas)
                pagina = totalPaginas;

            var solicitudesPagina = solicitudes
                .Skip((pagina - 1) * tamanioPagina)
                .Take(tamanioPagina)
                .ToList();

            return new SolicitudReembolsoResultadoViewModel
            {
                Solicitudes = solicitudesPagina,
                Pagina = pagina,
                TamanioPagina = tamanioPagina,
                TotalRegistros = totalRegistros,
                TotalPaginas = totalPaginas,
            };
        }

        // ====================================================================
        // Fase D — traduce EstacionActual (texto libre del listado, más
        // granular) a las 4 estaciones fijas de Reembolsos/Detalle. Es una
        // traducción de presentación, mismo criterio que el badge de Estatus
        // en _ResultadosSolicitudes.cshtml — no es una regla de negocio nueva.
        // No se introduce un quinto estado visual para "Rechazado": la
        // estación en la que se rechazó simplemente queda marcada "actual"
        // (decisión explícita del usuario — mantener las 4 estaciones tal
        // como existen hoy en la vista).
        // ====================================================================
        private static IReadOnlyList<EstacionDetalleViewModel> TraducirAEstaciones(string estacionActual)
        {
            string[] nombres =
            {
                "Recepción de documentos",
                "Dictamen administrativo",
                "Autorización de pago",
                "Pago autorizado",
            };

            var indiceActual = ResolverIndiceEstacion(estacionActual);

            var estaciones = new List<EstacionDetalleViewModel>();
            for (var i = 0; i < nombres.Length; i++)
            {
                var numero = i + 1;
                estaciones.Add(new EstacionDetalleViewModel
                {
                    Nombre = nombres[i],
                    Estado = numero < indiceActual ? "hecho" : numero == indiceActual ? "actual" : "pendiente",
                });
            }

            return estaciones;
        }

        private static int ResolverIndiceEstacion(string estacionActual)
        {
            if (estacionActual.Contains("Recepción", StringComparison.OrdinalIgnoreCase))
                return 1;

            if (estacionActual.Contains("Autorización de pago", StringComparison.OrdinalIgnoreCase))
                return 3;

            if (estacionActual.Contains("Pago autorizado", StringComparison.OrdinalIgnoreCase))
                return 4;

            // "Dictamen médico", "Validación documental", "Revisión de póliza"
            // — todas caen en "Dictamen administrativo", la única estación
            // intermedia de las 4 fijas.
            return 2;
        }
    }
}

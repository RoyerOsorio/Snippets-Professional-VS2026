namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// Datos de encabezado de Reembolsos/Detalle para una solicitud específica
/// (Fase D, ver UI_Decision_Log.md). Alcance deliberadamente acotado: solo
/// incluye los campos que ya existían en SolicitudReembolsoResumenViewModel
/// (folio, estación/estatus, datos del paciente/beneficiario). El resto de
/// Detalle.cshtml (datos del asegurado titular, reclamación/partidas,
/// evidencias, notas del trámite, saldo por beneficiario) sigue hardcodeado
/// en esta fase — conectarlo requeriría modelar datos de dictamen que no
/// están definidos todavía (ver Fase4_Reembolsos_Detalle_Id_Analizar_
/// Proponer.md, sección 1).
///
/// Es exclusivo de esta vista: no reutiliza SolicitudReembolsoResumenViewModel
/// directamente, para no acoplar Detalle a cambios futuros del listado
/// (por ejemplo, si el listado agrega/quita columnas que Detalle no necesita).
/// </summary>
public class SolicitudReembolsoDetalleViewModel
{
    public int Id { get; set; }
    public string Folio { get; set; } = string.Empty;
    public string Poliza { get; set; } = string.Empty;
    public string NombreBeneficiario { get; set; } = string.Empty;
    public string Parentesco { get; set; } = string.Empty;
    public DateTime Fecha { get; set; }
    public string Estatus { get; set; } = string.Empty;
    public string EstacionActual { get; set; } = string.Empty;

    /// <summary>Las 4 estaciones fijas de la vista, ya traducidas a
    /// hecho/actual/pendiente a partir de EstacionActual — ver
    /// ReembolsosController.TraducirAEstaciones. Traducción de presentación,
    /// mismo criterio que el badge de Estatus en Reembolsos/Index.</summary>
    public IReadOnlyList<EstacionDetalleViewModel> Estaciones { get; set; } = new List<EstacionDetalleViewModel>();
}

/// <summary>Una estación de la timeline de Reembolsos/Detalle.</summary>
public class EstacionDetalleViewModel
{
    public string Nombre { get; set; } = string.Empty;

    /// <summary>"hecho" | "actual" | "pendiente".</summary>
    public string Estado { get; set; } = string.Empty;
}

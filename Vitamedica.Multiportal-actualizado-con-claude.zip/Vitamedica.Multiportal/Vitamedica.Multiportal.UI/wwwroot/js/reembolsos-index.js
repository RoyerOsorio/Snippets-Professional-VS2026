/* ============================================================================
   reembolsos-index.js — Interacciones exclusivas de Views/Reembolsos/Index.cshtml.

   Fase 2: filtros conectados vía fetch a ReembolsosController.Buscar (ver
   UI_Decision_Log.md) — primera vez que un archivo {pagina}.js de este
   proyecto necesita importar un módulo de core/, por lo que este archivo se
   carga como <script type="module"> (ver @section Scripts en Index.cshtml) en
   vez del <script> clásico no-módulo que usan las demás páginas. Al ser un
   módulo ES ya tiene su propio scope aislado (JavaScript_Architecture_Guide.md,
   sección 6), por lo que ya no necesita la IIFE que sí usan los archivos de
   página clásicos del proyecto.

   Fase 3: se agrega paginación real — el selector "Mostrar" (#pageSize) y los
   controles de navegación (Primera/Anterior/números/Siguiente/Última) ahora
   viajan como pagina/tamanioPagina en la misma búsqueda por fetch. El pie de
   la tabla (contador + rango + nav, id="pieTablaSolicitudes") se reemplaza
   igual que el <tbody> — mismo mecanismo DOMParser + replaceWith, extendido a
   dos fragmentos en vez de uno.

   Fase E: se implementa el contrato de estados de carga/vacío/error
   (UI_Coding_Standards.md sección 4, JavaScript_Architecture_Guide.md
   sección 5) — reemplaza el window.alert() genérico que usaba Fase 2 como
   solución mínima. "Vacío" lo decide Razor con datos (ver
   _ResultadosSolicitudes.cshtml); este archivo solo alterna cuál de los 3
   <tbody> hermanos (contenido/vacío ya resuelto por el servidor, cargando,
   error) queda visible en cada etapa de la búsqueda.

   Sin datos hardcodeados aquí: tanto la carga inicial (Razor, en Index.cshtml)
   como cada búsqueda (fetch + PartialView) traen los datos ya resueltos por
   el Controller — este archivo solo orquesta la interacción.
   ============================================================================ */
import { getHtml } from "./core/http.js";
import { refreshIcons } from "./core/icons.js";

const TAMANIO_PAGINA_POR_DEFECTO = 25;
const ID_TBODY_CARGANDO = "tbodyCargandoSolicitudes";
const ID_TBODY_ERROR = "tbodyErrorSolicitudes";
const ID_TBODY_RESULTADOS = "cuerpoTablaSolicitudes";

document.addEventListener("DOMContentLoaded", function () {
    initModalNota();
    initFiltros();
});

// ---- Modal de Notas — título con el folio de la fila que lo abrió ----
function initModalNota() {
    var modalNota = document.getElementById("modalNota");
    if (!modalNota) return;

    modalNota.addEventListener("show.bs.modal", function (event) {
        var trigger = event.relatedTarget;
        if (!trigger) return;

        var folio = trigger.getAttribute("data-folio");
        var title = modalNota.querySelector("#modalNotaLabel");
        if (title && folio) {
            title.textContent = "Notas de la solicitud";
        }
    });
}

// ---- Filtros + paginación — búsqueda vía fetch, sin recargar la página ----
function initFiltros() {
    var form = document.querySelector(".filters-form");
    if (!form) return;

    var btnBuscar = form.querySelector("button[type=submit]");
    var pageSize = document.getElementById("pageSize");
    var tablaPanel = document.querySelector(".table-panel");

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        // Cambiar de filtro siempre vuelve a página 1: la página actual
        // podría ya no existir con el nuevo criterio.
        buscar(1);
    });

    form.addEventListener("reset", function () {
        // El reset nativo del formulario ocurre antes de este evento; se
        // difiere un turno para leer los campos ya restablecidos (mismo
        // patrón ya usado en clientes-index.js). "Limpiar filtros" también
        // resetea página y tamaño de página a sus valores por defecto —
        // #pageSize vive fuera de <form>, así que el reset nativo no lo toca.
        setTimeout(function () {
            if (pageSize) pageSize.value = String(TAMANIO_PAGINA_POR_DEFECTO);
            buscar(1);
        }, 0);
    });

    if (pageSize) {
        pageSize.addEventListener("change", function () {
            // Cambiar el tamaño de página también vuelve a página 1.
            buscar(1);
        });
    }

    // Delegación de eventos: el <ul> de paginación se reemplaza por completo
    // en cada búsqueda (mismo mecanismo que el <tbody>), por lo que el
    // listener de clic se ata al contenedor de la tabla, que sí persiste —
    // nunca al <ul> ni a sus <a>, que no.
    if (tablaPanel) {
        tablaPanel.addEventListener("click", function (e) {
            var link = e.target.closest(".pagination-vm .page-link");
            if (!link) return;
            e.preventDefault();

            var item = link.closest(".page-item");
            if (item && item.classList.contains("disabled")) return;

            var pagina = parseInt(link.getAttribute("data-pagina"), 10);
            if (!pagina || pagina < 1) return;

            buscar(pagina);
        });
    }

    function buscar(pagina) {
        var params = new URLSearchParams();
        agregarSiTieneValor(params, "folio", "fFolio");
        agregarSiTieneValor(params, "fechaDesde", "fFechaDesde", convertirFecha);
        agregarSiTieneValor(params, "fechaHasta", "fFechaHasta", convertirFecha);
        agregarSiTieneValor(params, "estatus", "fEstatus", excluirValorTodos);
        agregarSiTieneValor(params, "poliza", "fPoliza");
        agregarSiTieneValor(params, "cobertura", "fCobertura", excluirValorTodos);
        agregarSiTieneValor(params, "flujo", "fFlujo", excluirValorTodos);
        agregarSiTieneValor(params, "folioFiscal", "fFolioFiscal");

        params.set("pagina", String(pagina || 1));
        params.set("tamanioPagina", String((pageSize && pageSize.value) || TAMANIO_PAGINA_POR_DEFECTO));

        if (btnBuscar) btnBuscar.disabled = true;
        mostrarEstadoTabla(ID_TBODY_CARGANDO);

        getHtml("/Reembolsos/Buscar?" + params.toString())
            .then(function (html) {
                reemplazarResultados(html);
            })
            .catch(function (error) {
                console.error("[reembolsos-index]", error);
                // Se oculta el resultado de la búsqueda anterior en vez de
                // dejarlo visible junto al mensaje de error — decisión
                // explícita del usuario (Fase E): evita mostrar datos
                // potencialmente obsoletos junto a un aviso de falla.
                mostrarEstadoTabla(ID_TBODY_ERROR);
            })
            .finally(function () {
                if (btnBuscar) btnBuscar.disabled = false;
            });
    }
}

// ---- Estados de carga/vacío/error (Fase E) ----
// Alterna cuál de los <tbody> hermanos de la tabla queda visible. "Vacío" no
// se maneja aquí: ya llega decidido por el servidor como parte del <tbody>
// de "contenido" (ver _ResultadosSolicitudes.cshtml) — solo "cargando" y
// "error" son estados que este archivo controla, porque ocurren antes de que
// el servidor responda o cuando nunca llega a responder.
function mostrarEstadoTabla(idTbodyVisible) {
    [ID_TBODY_RESULTADOS, ID_TBODY_CARGANDO, ID_TBODY_ERROR].forEach(function (id) {
        var tbody = document.getElementById(id);
        if (tbody) tbody.hidden = (id !== idTbodyVisible);
    });
}

function agregarSiTieneValor(params, nombreParametro, idCampo, transformar) {
    var campo = document.getElementById(idCampo);
    if (!campo) return;

    var valor = campo.value;
    if (transformar) valor = transformar(valor);
    if (valor) params.set(nombreParametro, valor);
}

function excluirValorTodos(valor) {
    return (valor === "Todos" || valor === "Todas") ? "" : valor;
}

// El Date Picker entrega dd/mm/aaaa; se convierte a aaaa-mm-dd (ISO 8601)
// antes de enviarlo, para que el model binder de ASP.NET Core lo interprete
// de forma confiable sin depender de la cultura configurada en el servidor.
// El propio componente Date Picker no se modifica.
function convertirFecha(valor) {
    var partes = (valor || "").split("/");
    if (partes.length !== 3) return "";
    return partes[2] + "-" + partes[1] + "-" + partes[0];
}

function reemplazarResultados(html) {
    var doc = new DOMParser().parseFromString(html, "text/html");

    var nuevoCuerpo = doc.getElementById(ID_TBODY_RESULTADOS);
    var cuerpoActual = document.getElementById(ID_TBODY_RESULTADOS);
    if (nuevoCuerpo && cuerpoActual) {
        cuerpoActual.replaceWith(nuevoCuerpo);
    }

    // El nuevo <tbody> (contenido o vacío, ya decidido por el servidor) queda
    // visible; cargando/error se ocultan — cubre tanto el camino normal como
    // una búsqueda exitosa que llega después de un error previo.
    mostrarEstadoTabla(ID_TBODY_RESULTADOS);

    // Fase 3: el pie (contador + rango + nav) llega en el mismo HTML y se
    // reemplaza igual que el <tbody> — ya no se recalculan "N resultados" ni
    // "Mostrando X–Y de Z" en JavaScript (Fase 2 lo hacía y asumía siempre
    // página 1; en Fase 3 ese cálculo depende de la página real y vive solo
    // en _PaginacionSolicitudes.cshtml, sin duplicarlo aquí).
    var nuevoPie = doc.getElementById("pieTablaSolicitudes");
    var pieActual = document.getElementById("pieTablaSolicitudes");
    if (nuevoPie && pieActual) {
        pieActual.replaceWith(nuevoPie);
    }

    // Refresco de íconos Lucide vía core/icons.js — ver DEC-Limpieza-WindowVM.md
    // (cierra la discrepancia registrada en DEC-Reembolsos-Index-Filtros.md:
    // window.VM.refreshIcons() nunca estuvo definido en el proyecto).
    refreshIcons();
}

/* ============================================================================
   pagos-index.js — Interacciones exclusivas de Views/Pagos/Index.cshtml.

   Fase F2 (ver UI_Decision_Log.md): filtros conectados vía fetch a
   PagosController.Buscar, mismo patrón ya validado en reembolsos-index.js
   (Reembolsos Fase 2/3): core/http.js (getHtml), PartialView (no JSON),
   DOMParser + replaceWith (nunca innerHTML + concatenación). Este archivo
   pasa de script clásico (IIFE) a módulo ES porque necesita `import` de
   core/http.js — al tener scope aislado por especificación del lenguaje, ya
   no necesita la IIFE.

   Fase F3: se agrega paginación real + selector "Mostrar" (tamaño de
   página), mismo mecanismo ya implementado en reembolsos-index.js:
   - buscar(pagina) ahora envía "pagina" y "tamanioPagina" en la query.
   - PagosController.Buscar ahora devuelve _ResultadosYPaginacionPagos
     (tbody + pie concatenados), por lo que reemplazarResultados localiza y
     reemplaza DOS fragmentos: #cuerpoTablaPagos y #pieTablaPagos, ambos
     recalculados por Razor en el servidor — ya no se actualizan
     "tableCount"/"tableRange" a mano desde JS.
   - El cambio de "Mostrar" reinicia siempre a la página 1.
   - Los clics de paginación se delegan sobre .table-panel porque el <nav>
     completo se reemplaza en cada búsqueda (los listeners puestos
     directamente sobre los <a> se perderían).

   Fase F4: se implementa el contrato de estados de carga/vacío/error
   (UI_Coding_Standards.md sección 4, JavaScript_Architecture_Guide.md
   sección 5) — reemplaza el window.alert() genérico que usaba Fase F2/F3
   como solución mínima. "Vacío" lo decide Razor con datos (ver
   _ResultadosPagos.cshtml); este archivo solo alterna cuál de los 3
   <tbody> hermanos (contenido/vacío ya resuelto por el servidor, cargando,
   error) queda visible en cada etapa de la búsqueda — mismo mecanismo que
   reembolsos-index.js.
   ============================================================================ */
import { getHtml } from "./core/http.js";
import { refreshIcons } from "./core/icons.js";

const ID_TBODY_CARGANDO = "tbodyCargandoPagos";
const ID_TBODY_ERROR = "tbodyErrorPagos";
const ID_TBODY_RESULTADOS = "cuerpoTablaPagos";

document.addEventListener("DOMContentLoaded", function () {
    initModalRetro();
    initFiltros();
});

// ---- Modal "Retro" — nombre de archivo seleccionado + confirmación simulada ----
function initModalRetro() {
    var input = document.getElementById("inputRetroArchivo");
    var nombre = document.getElementById("retroArchivoNombre");
    var confirmBtn = document.getElementById("btnConfirmarRetro");
    var modalEl = document.getElementById("modalRetro");

    if (input && nombre) {
        input.addEventListener("change", function () {
            nombre.textContent = input.files && input.files.length > 0
                ? input.files[0].name
                : "Ningún archivo seleccionado";
        });
    }

    if (confirmBtn && modalEl) {
        confirmBtn.addEventListener("click", function () {
            bootstrap.Modal.getOrCreateInstance(modalEl).hide();
        });
    }
}

// ---- Filtros + paginación — búsqueda vía fetch, sin recargar la página ----
function initFiltros() {
    var form = document.querySelector(".filters-form");
    var tablePanel = document.querySelector(".table-panel");
    var pageSize = document.getElementById("pageSize");
    if (!form) return;

    var btnBuscar = form.querySelector("button[type=submit]");

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        buscar(1);
    });

    form.addEventListener("reset", function () {
        // El reset nativo del formulario ocurre antes de este evento; se
        // difiere un turno para leer los campos ya restablecidos (mismo
        // patrón ya usado en reembolsos-index.js/clientes-index.js).
        setTimeout(function () { buscar(1); }, 0);
    });

    if (pageSize) {
        pageSize.addEventListener("change", function () {
            buscar(1);
        });
    }

    // Delegación de eventos: el <nav> de paginación se reemplaza por
    // completo en cada búsqueda (viene dentro de #pieTablaPagos), así que
    // el listener se pone sobre .table-panel (que nunca se reemplaza) en
    // lugar de sobre cada <a> individual.
    if (tablePanel) {
        tablePanel.addEventListener("click", function (e) {
            var link = e.target.closest(".pagination-vm .page-link[data-pagina]");
            if (!link) return;

            e.preventDefault();

            var item = link.closest(".page-item");
            if (item && item.classList.contains("disabled")) return;

            var pagina = parseInt(link.getAttribute("data-pagina"), 10);
            if (!isNaN(pagina)) buscar(pagina);
        });
    }

    function buscar(pagina) {
        var params = new URLSearchParams();
        agregarSiTieneValor(params, "folio", "fFolio");
        agregarSiTieneValor(params, "fechaDesde", "fFechaDesde", convertirFecha);
        agregarSiTieneValor(params, "fechaHasta", "fFechaHasta", convertirFecha);
        params.set("pagina", pagina || 1);
        params.set("tamanioPagina", pageSize ? pageSize.value : "25");

        if (btnBuscar) btnBuscar.disabled = true;
        mostrarEstadoTabla(ID_TBODY_CARGANDO);

        getHtml("/Pagos/Buscar?" + params.toString())
            .then(function (html) {
                reemplazarResultados(html);
            })
            .catch(function (error) {
                console.error("[pagos-index]", error);
                // Se oculta el resultado de la búsqueda anterior en vez de
                // dejarlo visible junto al mensaje de error — mismo criterio
                // ya aprobado explícitamente para Reembolsos (Fase E).
                mostrarEstadoTabla(ID_TBODY_ERROR);
            })
            .finally(function () {
                if (btnBuscar) btnBuscar.disabled = false;
            });
    }
}

// ---- Estados de carga/vacío/error (Fase F4) ----
// Alterna cuál de los <tbody> hermanos de la tabla queda visible. "Vacío" no
// se maneja aquí: ya llega decidido por el servidor como parte del <tbody>
// de "contenido" (ver _ResultadosPagos.cshtml) — solo "cargando" y "error"
// son estados que este archivo controla, porque ocurren antes de que el
// servidor responda o cuando nunca llega a responder.
function mostrarEstadoTabla(idTbodyVisible) {
    [ID_TBODY_RESULTADOS, ID_TBODY_CARGANDO, ID_TBODY_ERROR].forEach(function (id) {
        var tbody = document.getElementById(id);
        if (tbody) tbody.hidden = (id !== idTbodyVisible);
    });
}

function agregarSiTieneValor(params, nombreParametro, idCampo, transformar) {
    var campo = document.getElementById(idCampo);
    if (!campo) return;

    var valor = campo.value;
    if (transformar) valor = transformar(valor);
    if (valor) params.set(nombreParametro, valor);
}

// El Date Picker entrega dd/mm/aaaa; se convierte a aaaa-mm-dd (ISO 8601)
// antes de enviarlo, mismo criterio ya usado en reembolsos-index.js.
function convertirFecha(valor) {
    var partes = (valor || "").split("/");
    if (partes.length !== 3) return "";
    return partes[2] + "-" + partes[1] + "-" + partes[0];
}

function reemplazarResultados(html) {
    var doc = new DOMParser().parseFromString(html, "text/html");

    var nuevoCuerpo = doc.getElementById(ID_TBODY_RESULTADOS);
    var cuerpoActual = document.getElementById(ID_TBODY_RESULTADOS);
    if (nuevoCuerpo && cuerpoActual) {
        cuerpoActual.replaceWith(nuevoCuerpo);
    }

    // El nuevo <tbody> (contenido o vacío, ya decidido por el servidor) queda
    // visible; cargando/error se ocultan — cubre tanto el camino normal como
    // una búsqueda exitosa que llega después de un error previo.
    mostrarEstadoTabla(ID_TBODY_RESULTADOS);

    var nuevoPie = doc.getElementById("pieTablaPagos");
    var pieActual = document.getElementById("pieTablaPagos");
    if (nuevoPie && pieActual) {
        pieActual.replaceWith(nuevoPie);
    }

    // Refresco de íconos Lucide vía core/icons.js — ver DEC-Limpieza-WindowVM.md.
    refreshIcons();
}

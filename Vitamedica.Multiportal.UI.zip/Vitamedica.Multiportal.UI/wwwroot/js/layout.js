/* ============================================================================
   layout.js — Orquestación base del shell.
   Expone window.VM con utilidades compartidas (almacenamiento, íconos).
   ============================================================================ */
(function () {
    "use strict";

    const STORAGE = {
        collapsed: "vm.sidebar.collapsed",
        openGroups: "vm.sidebar.openGroups",
        density: "vm.density"
    };

    // Acceso seguro a localStorage (puede estar deshabilitado en algunos entornos).
    const store = {
        get(key) { try { return window.localStorage.getItem(key); } catch { return null; } },
        set(key, val) { try { window.localStorage.setItem(key, val); } catch { /* no-op */ } },
        getJSON(key, fallback) {
            const raw = this.get(key);
            if (!raw) return fallback;
            try { return JSON.parse(raw); } catch { return fallback; }
        },
        setJSON(key, val) { this.set(key, JSON.stringify(val)); }
    };

    const BREAKPOINT = { mobileMax: 767.98, tabletMax: 1199.98 };

    function viewport() {
        const w = window.innerWidth;
        if (w <= BREAKPOINT.mobileMax) return "mobile";
        if (w <= BREAKPOINT.tabletMax) return "tablet";
        return "desktop";
    }

    // (Re)genera los íconos Lucide del DOM actual.
    function refreshIcons() {
        if (window.lucide && typeof window.lucide.createIcons === "function") {
            window.lucide.createIcons();
        }
    }

    // Restaura la densidad persistida antes de pintar interacciones.
    function applyDensity() {
        const density = store.get(STORAGE.density) || "comoda";
        document.body.classList.toggle("density-compact", density === "compacta");
    }

    window.VM = { STORAGE, store, viewport, refreshIcons };

    document.addEventListener("DOMContentLoaded", function () {
        applyDensity();
        refreshIcons();
    });
})();

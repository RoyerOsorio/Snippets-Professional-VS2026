/* ============================================================================
   header.js — Interacciones del Header no cubiertas por Bootstrap.
   El menú de usuario usa el dropdown nativo de Bootstrap; aquí solo se gestiona
   la preferencia de densidad y el refresco de íconos al abrir el menú.
   ============================================================================ */
(function () {
    "use strict";

    const VM = window.VM;
    const { STORAGE, store } = VM;

    const densityToggle = document.querySelector("[data-density-toggle]");

    function applyDensitySelection(value) {
        const compact = value === "compacta";
        document.body.classList.toggle("density-compact", compact);
        store.set(STORAGE.density, value);

        if (!densityToggle) return;
        densityToggle.querySelectorAll(".density-option").forEach(btn => {
            const active = btn.getAttribute("data-density") === value;
            btn.classList.toggle("is-active", active);
            btn.setAttribute("aria-pressed", String(active));
        });
    }

    if (densityToggle) {
        densityToggle.addEventListener("click", function (e) {
            const btn = e.target.closest(".density-option");
            if (!btn) return;
            applyDensitySelection(btn.getAttribute("data-density"));
        });

        // Sincroniza el control con la preferencia ya aplicada por layout.js.
        const current = store.get(STORAGE.density) || "comoda";
        applyDensitySelection(current);
    }

    // Los íconos del panel de usuario ya están en el DOM inicial; si en el futuro
    // se cargan de forma diferida, refrescarlos al mostrar el dropdown:
    const userMenu = document.querySelector(".user-menu");
    if (userMenu) {
        userMenu.addEventListener("shown.bs.dropdown", VM.refreshIcons);
    }
})();

using MprPagos.Api.Endpoints.Pagos;

namespace MprPagos.Api.Extensiones;

public static class ExtensionesEndpoints
{
    public static void MapearEndpointsPagos(this WebApplication app)
    {
        var grupo = app.MapGroup("/v1/pagos").WithTags("Pagos");

        ObtenerPagoEndpoint.Mapear(grupo);
        ConfirmarPagoEndpoint.Mapear(grupo);
    }
}

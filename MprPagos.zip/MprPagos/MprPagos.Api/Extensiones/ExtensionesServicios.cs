using MprPagos.Application.Casos;
using MprPagos.Infrastructure.Extensiones;

namespace MprPagos.Api.Extensiones;

public static class ExtensionesServicios
{
    public static IServiceCollection AgregarServiciosMprPagos(
        this IServiceCollection servicios,
        IConfiguration configuracion)
    {
        servicios.AgregarInfrastructureMprPagos(configuracion);

        servicios.AddScoped<ProcesarReclamoAprobadoParaPagoCasoDeUso>();
        servicios.AddScoped<ObtenerPagoCasoDeUso>();
        servicios.AddScoped<ConfirmarPagoCasoDeUso>();

        return servicios;
    }
}

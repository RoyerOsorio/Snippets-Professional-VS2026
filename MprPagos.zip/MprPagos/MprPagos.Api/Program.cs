using MprPagos.Api.Extensiones;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddProblemDetails();
builder.Services.AddOpenApi();
builder.Services.AgregarServiciosMprPagos(builder.Configuration);

builder.Services.AddHttpLogging(_ => { });

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpLogging();
app.UseExceptionHandler();

app.MapearEndpointsPagos();

app.MapGet("/health", () => Results.Ok(new { estado = "MprPagos operativo" }));

app.Run();

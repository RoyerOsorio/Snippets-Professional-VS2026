using MprPagos.Application.Casos;
using MprPagos.Contracts.Responses;
using MprPagos.Domain.Excepciones;

namespace MprPagos.Api.Endpoints.Pagos;

public static class ObtenerPagoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapGet("/{pagoId:int}", ObtenerAsync).WithName("ObtenerPago");
    }

    private static async Task<IResult> ObtenerAsync(
        int pagoId,
        ObtenerPagoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            var pago = await casoDeUso.EjecutarAsync(pagoId, cancellationToken);
            return Results.Ok(AResponse(pago));
        }
        catch (PagoNoEncontradoException ex)
        {
            return Results.Problem(title: "Pago no encontrado", detail: ex.Message, statusCode: StatusCodes.Status404NotFound);
        }
    }

    internal static PagoResponse AResponse(Application.Dtos.PagoDto pago) => new(
        pago.Id, pago.ReclamoId, pago.Poliza, pago.AseguradoId, pago.MontoAprobado,
        pago.Estado.ToString(), pago.FechaCreacion, pago.FechaConfirmacion);
}

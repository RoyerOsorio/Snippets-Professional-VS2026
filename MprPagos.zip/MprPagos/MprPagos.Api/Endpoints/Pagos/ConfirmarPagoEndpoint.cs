using MprPagos.Application.Casos;
using MprPagos.Domain.Excepciones;

namespace MprPagos.Api.Endpoints.Pagos;

/// <summary>
/// Sin body: el monto a pagar ya se conoce desde que MprGestionReclamos
/// publicó ReclamoAprobadoParaPago (MontoAprobado) — ConfirmarPago solo
/// marca que el pago efectivamente se realizó, no permite editar el monto.
/// </summary>
public static class ConfirmarPagoEndpoint
{
    public static void Mapear(RouteGroupBuilder grupo)
    {
        grupo.MapPost("/{pagoId:int}/confirmar", ConfirmarAsync).WithName("ConfirmarPago");
    }

    private static async Task<IResult> ConfirmarAsync(
        int pagoId,
        ConfirmarPagoCasoDeUso casoDeUso,
        CancellationToken cancellationToken)
    {
        try
        {
            var pago = await casoDeUso.EjecutarAsync(pagoId, DateTime.UtcNow, cancellationToken);
            return Results.Ok(ObtenerPagoEndpoint.AResponse(pago));
        }
        catch (PagoNoEncontradoException ex)
        {
            return Results.Problem(title: "Pago no encontrado", detail: ex.Message, statusCode: StatusCodes.Status404NotFound);
        }
        catch (TransicionEstadoInvalidaException ex)
        {
            return Results.Problem(title: "Transición de estado inválida", detail: ex.Message, statusCode: StatusCodes.Status409Conflict);
        }
    }
}

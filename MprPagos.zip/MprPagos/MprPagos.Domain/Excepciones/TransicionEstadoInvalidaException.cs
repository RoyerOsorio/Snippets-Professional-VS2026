namespace MprPagos.Domain.Excepciones;

/// <summary>
/// Se lanza cuando se intenta una transición de estado que Pago no
/// permite desde su estado actual (ej. Confirmar un Pago ya Completado).
/// </summary>
public sealed class TransicionEstadoInvalidaException(string mensaje) : Exception(mensaje);

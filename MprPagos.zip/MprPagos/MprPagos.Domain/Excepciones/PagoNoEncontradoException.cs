namespace MprPagos.Domain.Excepciones;

public sealed class PagoNoEncontradoException(string mensaje) : Exception(mensaje);

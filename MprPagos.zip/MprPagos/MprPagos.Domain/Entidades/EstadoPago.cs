namespace MprPagos.Domain.Entidades;

public enum EstadoPago
{
    Pendiente = 0,
    Completado = 1,
}

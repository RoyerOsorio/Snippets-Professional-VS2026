using MprPagos.Domain.Excepciones;

namespace MprPagos.Domain.Entidades;

/// <summary>
/// Agregado de dominio: ciclo de vida del Pago originado por un Reclamo
/// aprobado. MprPagos es el primer consumidor real del exchange
/// `multiportal.reembolsos` — nace a partir del evento de integración
/// ReclamoAprobadoParaPago publicado por MprGestionReclamos (ver
/// UI_Decision_Log.md DEC-003 y DEC-006).
///
/// ReclamoId es un identificador lógico hacia MprGestionReclamos — sin FK
/// física entre bases, mismo criterio ya aplicado en MprDocumentos.
///
/// MensajeIdOrigen es el MessageId del mensaje RabbitMQ que originó este
/// Pago (el OboxNid de MprGestionReclamos) — se persiste con restricción
/// de unicidad para que el procesamiento de mensajes duplicados
/// (redelivery de RabbitMQ) sea idempotente: si el mensaje ya se procesó,
/// no se crea un segundo Pago.
///
/// Transiciones permitidas: Pendiente -> Completado.
/// </summary>
public sealed class Pago
{
    public int Id { get; }
    public int ReclamoId { get; }
    public string Poliza { get; }
    public int AseguradoId { get; }
    public decimal MontoAprobado { get; }
    public EstadoPago Estado { get; private set; }
    public long MensajeIdOrigen { get; }
    public DateTime FechaCreacion { get; }
    public DateTime? FechaConfirmacion { get; private set; }

    public Pago(
        int id,
        int reclamoId,
        string poliza,
        int aseguradoId,
        decimal montoAprobado,
        EstadoPago estado,
        long mensajeIdOrigen,
        DateTime fechaCreacion,
        DateTime? fechaConfirmacion)
    {
        Id = id;
        ReclamoId = reclamoId;
        Poliza = poliza;
        AseguradoId = aseguradoId;
        MontoAprobado = montoAprobado;
        Estado = estado;
        MensajeIdOrigen = mensajeIdOrigen;
        FechaCreacion = fechaCreacion;
        FechaConfirmacion = fechaConfirmacion;
    }

    /// <summary>
    /// Fábrica invocada por el consumidor de RabbitMQ al procesar
    /// ReclamoAprobadoParaPago. Siempre nace en estado Pendiente. El Id
    /// real lo asigna la base de datos; aquí se usa 0 como marcador de
    /// "todavía no persistido", igual criterio que las demás entidades.
    /// </summary>
    public static Pago CrearDesdeReclamoAprobado(
        int reclamoId, string poliza, int aseguradoId, decimal montoAprobado,
        long mensajeIdOrigen, DateTime fechaCreacion) =>
        new(0, reclamoId, poliza, aseguradoId, montoAprobado, EstadoPago.Pendiente, mensajeIdOrigen, fechaCreacion, null);

    /// <summary>
    /// Paso "ConfirmarPago". Quien llama (Application/Infrastructure) es
    /// responsable de publicar el evento de integración PagoCompletado —
    /// esta entidad no conoce mensajería.
    /// </summary>
    public void Confirmar(DateTime fechaConfirmacion)
    {
        if (Estado != EstadoPago.Pendiente)
        {
            throw new TransicionEstadoInvalidaException(
                $"No se puede confirmar un Pago en estado {Estado}. Solo es válido desde Pendiente.");
        }

        Estado = EstadoPago.Completado;
        FechaConfirmacion = fechaConfirmacion;
    }
}

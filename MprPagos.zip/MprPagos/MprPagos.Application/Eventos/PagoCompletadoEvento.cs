namespace MprPagos.Application.Eventos;

/// <summary>
/// Evento de integración publicado cuando ConfirmarPago se ejecuta con
/// éxito. MprAuditoria lo consumiría para su bitácora/timeline — no
/// existe todavía en este repositorio (roadmap, docs/demo/README.md), por
/// lo que hoy el evento se publica pero no tiene consumidores reales,
/// igual situación que tuvo ReclamoAprobadoParaPago antes de que existiera
/// MprPagos (ver DEC-003).
/// </summary>
public sealed record PagoCompletadoEvento(
    int PagoId,
    int ReclamoId,
    string Poliza,
    int AseguradoId,
    decimal MontoPagado,
    DateTime FechaConfirmacion);

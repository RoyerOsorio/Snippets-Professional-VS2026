using MprPagos.Domain.Entidades;

namespace MprPagos.Application.Dtos;

public sealed record PagoDto(
    int Id,
    int ReclamoId,
    string Poliza,
    int AseguradoId,
    decimal MontoAprobado,
    EstadoPago Estado,
    DateTime FechaCreacion,
    DateTime? FechaConfirmacion);

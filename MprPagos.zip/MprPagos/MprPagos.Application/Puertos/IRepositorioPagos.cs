using MprPagos.Application.Eventos;
using MprPagos.Domain.Entidades;

namespace MprPagos.Application.Puertos;

public interface IRepositorioPagos
{
    Task<Pago?> ObtenerPorIdAsync(int pagoId, CancellationToken cancellationToken);

    /// <summary>
    /// Usado por ProcesarReclamoAprobadoParaPagoCasoDeUso para la
    /// verificación de idempotencia a nivel de aplicación, antes de
    /// intentar el INSERT (que además tiene una restricción de unicidad
    /// en base de datos como segunda barrera — ver
    /// deploy/sql/MprPagos/README.md).
    /// </summary>
    Task<Pago?> ObtenerPorMensajeIdOrigenAsync(long mensajeIdOrigen, CancellationToken cancellationToken);

    Task<Pago> CrearAsync(Pago pago, CancellationToken cancellationToken);

    /// <summary>
    /// Persiste la transición a Completado y escribe la fila de
    /// OutboxMensajes correspondiente a PagoCompletadoEvento dentro de la
    /// MISMA transacción (Transactional Outbox) — mismo patrón que
    /// MprGestionReclamos.Infrastructure/Persistencia/Adaptadores/RepositorioReclamosEfCore.
    /// </summary>
    Task ActualizarYPublicarEventoAsync(
        Pago pago,
        PagoCompletadoEvento evento,
        CancellationToken cancellationToken);
}

using MprPagos.Application.Dtos;
using MprPagos.Application.Puertos;
using MprPagos.Domain.Entidades;

namespace MprPagos.Application.Casos;

/// <summary>
/// Consumido por el BackgroundService que escucha RabbitMQ
/// (Infrastructure/Mensajeria/ReclamoAprobadoParaPagoConsumerHostedService)
/// cada vez que llega un mensaje ReclamoAprobadoParaPago. Es idempotente:
/// si ya existe un Pago creado a partir del mismo MensajeIdOrigen (el
/// MessageId del mensaje RabbitMQ, que es el OboxNid de MprGestionReclamos),
/// no crea un segundo Pago — devuelve el existente. Esto protege contra
/// redelivery de RabbitMQ (at-least-once delivery), no solo contra el
/// reintento de publicación que ya maneja el propio Outbox de origen.
/// </summary>
public sealed class ProcesarReclamoAprobadoParaPagoCasoDeUso(IRepositorioPagos repositorio)
{
    public async Task<PagoDto> EjecutarAsync(
        long mensajeIdOrigen,
        int reclamoId,
        string poliza,
        int aseguradoId,
        decimal montoAprobado,
        DateTime fechaCreacion,
        CancellationToken cancellationToken)
    {
        var existente = await repositorio.ObtenerPorMensajeIdOrigenAsync(mensajeIdOrigen, cancellationToken);

        if (existente is not null)
        {
            return APagoDto(existente);
        }

        var pago = Pago.CrearDesdeReclamoAprobado(reclamoId, poliza, aseguradoId, montoAprobado, mensajeIdOrigen, fechaCreacion);
        var creado = await repositorio.CrearAsync(pago, cancellationToken);

        return APagoDto(creado);
    }

    internal static PagoDto APagoDto(Pago pago) => new(
        pago.Id, pago.ReclamoId, pago.Poliza, pago.AseguradoId, pago.MontoAprobado,
        pago.Estado, pago.FechaCreacion, pago.FechaConfirmacion);
}

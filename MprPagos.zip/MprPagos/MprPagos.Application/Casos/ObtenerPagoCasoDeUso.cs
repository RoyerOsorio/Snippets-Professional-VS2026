using MprPagos.Application.Dtos;
using MprPagos.Application.Puertos;
using MprPagos.Domain.Excepciones;

namespace MprPagos.Application.Casos;

public sealed class ObtenerPagoCasoDeUso(IRepositorioPagos repositorio)
{
    public async Task<PagoDto> EjecutarAsync(int pagoId, CancellationToken cancellationToken)
    {
        var pago = await repositorio.ObtenerPorIdAsync(pagoId, cancellationToken);

        if (pago is null)
        {
            throw new PagoNoEncontradoException($"No existe un Pago con Id {pagoId}.");
        }

        return ProcesarReclamoAprobadoParaPagoCasoDeUso.APagoDto(pago);
    }
}

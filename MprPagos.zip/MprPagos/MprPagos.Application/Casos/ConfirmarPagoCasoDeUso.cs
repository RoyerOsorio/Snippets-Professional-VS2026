using MprPagos.Application.Dtos;
using MprPagos.Application.Eventos;
using MprPagos.Application.Puertos;
using MprPagos.Domain.Excepciones;

namespace MprPagos.Application.Casos;

public sealed class ConfirmarPagoCasoDeUso(IRepositorioPagos repositorio)
{
    public async Task<PagoDto> EjecutarAsync(int pagoId, DateTime fechaConfirmacion, CancellationToken cancellationToken)
    {
        var pago = await repositorio.ObtenerPorIdAsync(pagoId, cancellationToken);

        if (pago is null)
        {
            throw new PagoNoEncontradoException($"No existe un Pago con Id {pagoId}.");
        }

        pago.Confirmar(fechaConfirmacion);

        var evento = new PagoCompletadoEvento(
            pago.Id, pago.ReclamoId, pago.Poliza, pago.AseguradoId, pago.MontoAprobado, fechaConfirmacion);

        await repositorio.ActualizarYPublicarEventoAsync(pago, evento, cancellationToken);

        return ProcesarReclamoAprobadoParaPagoCasoDeUso.APagoDto(pago);
    }
}

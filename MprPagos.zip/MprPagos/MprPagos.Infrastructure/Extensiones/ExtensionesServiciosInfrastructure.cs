using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MprPagos.Application.Puertos;
using MprPagos.Infrastructure.Mensajeria;
using MprPagos.Infrastructure.Persistencia;
using MprPagos.Infrastructure.Persistencia.Adaptadores;

namespace MprPagos.Infrastructure.Extensiones;

public static class ExtensionesServiciosInfrastructure
{
    public static IServiceCollection AgregarInfrastructureMprPagos(
        this IServiceCollection servicios,
        IConfiguration configuracion)
    {
        servicios.AddDbContext<MprPagosDbContext>(opciones =>
            opciones.UseSqlServer(configuracion.GetConnectionString("MprPagosDb")));

        servicios.AddScoped<IRepositorioPagos, RepositorioPagosEfCore>();

        servicios.Configure<RabbitMqOpciones>(configuracion.GetSection("RabbitMq"));
        servicios.AddHostedService<OutboxPublisherHostedService>();
        servicios.AddHostedService<ReclamoAprobadoParaPagoConsumerHostedService>();

        return servicios;
    }
}

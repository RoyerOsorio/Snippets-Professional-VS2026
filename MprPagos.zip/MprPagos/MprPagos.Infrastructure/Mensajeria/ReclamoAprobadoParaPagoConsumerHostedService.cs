using System.Text;
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MprPagos.Application.Casos;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace MprPagos.Infrastructure.Mensajeria;

/// <summary>
/// Primer consumidor real del exchange `multiportal.reembolsos` en este
/// ejercicio. Declara su propia cola (`ColaReclamoAprobadoParaPago`) y la
/// enlaza al exchange con la routing key `reclamo.aprobado-para-pago` que
/// ya usa MprGestionReclamos para publicar (ver
/// MprGestionReclamos.Infrastructure/Mensajeria/OutboxPublisherHostedService).
///
/// Idempotencia: el `MessageId` de la propiedad AMQP (el OboxNid que
/// MprGestionReclamos asignó al publicar, ver DEC-003) se pasa como
/// `mensajeIdOrigen` a ProcesarReclamoAprobadoParaPagoCasoDeUso, que
/// verifica si ya existe un Pago creado a partir de ese mensaje antes de
/// crear uno nuevo — protege contra redelivery de RabbitMQ (at-least-once
/// delivery: un mensaje puede reentregarse si el ack se pierde).
///
/// Manejo de errores: sin dead-letter queue configurada todavía (ver
/// docs/demo/README.md, simplificaciones explícitas) — un mensaje que
/// falla al procesarse se vuelve a encolar (nack con requeue) y RabbitMQ
/// lo reintenta indefinidamente. Aceptable para este ejercicio; en
/// producción se necesitaría una política de reintentos con límite y una
/// dead-letter queue para mensajes “envenenados”.
/// </summary>
public sealed class ReclamoAprobadoParaPagoConsumerHostedService(
    IServiceScopeFactory scopeFactory,
    IOptions<RabbitMqOpciones> opciones,
    ILogger<ReclamoAprobadoParaPagoConsumerHostedService> logger) : BackgroundService
{
    private static readonly JsonSerializerOptions OpcionesJson = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true,
    };

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var config = opciones.Value;

        var factory = new ConnectionFactory
        {
            HostName = config.HostName,
            Port = config.Port,
            UserName = config.UserName,
            Password = config.Password,
        };

        await using var conexion = await factory.CreateConnectionAsync(stoppingToken);
        await using var canal = await conexion.CreateChannelAsync(cancellationToken: stoppingToken);

        await canal.ExchangeDeclareAsync(config.Exchange, ExchangeType.Topic, durable: true, cancellationToken: stoppingToken);
        await canal.QueueDeclareAsync(
            config.ColaReclamoAprobadoParaPago, durable: true, exclusive: false, autoDelete: false,
            cancellationToken: stoppingToken);
        await canal.QueueBindAsync(
            config.ColaReclamoAprobadoParaPago, config.Exchange, config.RoutingKeyReclamoAprobadoParaPago,
            cancellationToken: stoppingToken);

        var consumidor = new AsyncEventingBasicConsumer(canal);
        consumidor.ReceivedAsync += async (_, entrega) =>
        {
            await ProcesarMensajeAsync(canal, entrega, stoppingToken);
        };

        await canal.BasicConsumeAsync(
            config.ColaReclamoAprobadoParaPago, autoAck: false, consumidor, cancellationToken: stoppingToken);

        logger.LogInformation(
            "Escuchando {Cola} (enlazada a {Exchange}/{RoutingKey}).",
            config.ColaReclamoAprobadoParaPago, config.Exchange, config.RoutingKeyReclamoAprobadoParaPago);

        // BasicConsumeAsync es asíncrono por evento — esta espera mantiene
        // vivo el BackgroundService hasta que se solicite el shutdown.
        await Task.Delay(Timeout.Infinite, stoppingToken).ContinueWith(_ => { }, TaskScheduler.Default);
    }

    private async Task ProcesarMensajeAsync(IChannel canal, BasicDeliverEventArgs entrega, CancellationToken cancellationToken)
    {
        try
        {
            var mensajeIdTexto = entrega.BasicProperties.MessageId;

            if (string.IsNullOrWhiteSpace(mensajeIdTexto) || !long.TryParse(mensajeIdTexto, out var mensajeIdOrigen))
            {
                // Mensaje sin MessageId válido no puede procesarse de forma
                // idempotente — se descarta (nack sin requeue) en vez de
                // arriesgar duplicados silenciosos.
                logger.LogWarning("Mensaje descartado: MessageId ausente o inválido ({MessageId}).", mensajeIdTexto);
                await canal.BasicNackAsync(entrega.DeliveryTag, multiple: false, requeue: false, cancellationToken);
                return;
            }

            var payload = JsonSerializer.Deserialize<ReclamoAprobadoParaPagoMensaje>(
                Encoding.UTF8.GetString(entrega.Body.ToArray()), OpcionesJson);

            if (payload is null)
            {
                logger.LogWarning("Mensaje descartado: payload no se pudo deserializar (MessageId={MessageId}).", mensajeIdOrigen);
                await canal.BasicNackAsync(entrega.DeliveryTag, multiple: false, requeue: false, cancellationToken);
                return;
            }

            using var scope = scopeFactory.CreateScope();
            var casoDeUso = scope.ServiceProvider.GetRequiredService<ProcesarReclamoAprobadoParaPagoCasoDeUso>();

            await casoDeUso.EjecutarAsync(
                mensajeIdOrigen, payload.ReclamoId, payload.Poliza, payload.AseguradoId,
                payload.MontoAprobado, DateTime.UtcNow, cancellationToken);

            await canal.BasicAckAsync(entrega.DeliveryTag, multiple: false, cancellationToken);

            logger.LogInformation(
                "Procesado ReclamoAprobadoParaPago (MessageId={MessageId}, ReclamoId={ReclamoId}).",
                mensajeIdOrigen, payload.ReclamoId);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Fallo al procesar mensaje de {Cola} — se reencola.", opciones.Value.ColaReclamoAprobadoParaPago);
            await canal.BasicNackAsync(entrega.DeliveryTag, multiple: false, requeue: true, cancellationToken);
        }
    }

    /// <summary>
    /// Copia local del payload esperado — MprPagos NO referencia el
    /// ensamblado de MprGestionReclamos.Application (bounded contexts
    /// separados); el contrato del mensaje es la única dependencia
    /// compartida, y es implícito (JSON), no un tipo compartido.
    /// </summary>
    private sealed record ReclamoAprobadoParaPagoMensaje(
        int ReclamoId, string Poliza, int AseguradoId, decimal MontoAprobado, DateTime FechaResolucion);
}

namespace MprPagos.Infrastructure.Mensajeria;

/// <summary>
/// Opciones compartidas por el publisher (OutboxPublisherHostedService,
/// publica PagoCompletado) y el consumer
/// (ReclamoAprobadoParaPagoConsumerHostedService, consume
/// ReclamoAprobadoParaPago) — ambos hablan con el mismo exchange
/// `multiportal.reembolsos` que ya usa MprGestionReclamos.
/// </summary>
public sealed class RabbitMqOpciones
{
    public string HostName { get; set; } = "localhost";
    public int Port { get; set; } = 5672;
    public string UserName { get; set; } = "guest";
    public string Password { get; set; } = "guest";
    public string Exchange { get; set; } = "multiportal.reembolsos";

    /// <summary>Routing key con la que MprGestionReclamos publica el evento que este servicio consume.</summary>
    public string RoutingKeyReclamoAprobadoParaPago { get; set; } = "reclamo.aprobado-para-pago";

    /// <summary>Cola propia de MprPagos — cada consumidor declara y usa su propia cola, nunca comparte cola con otro microservicio.</summary>
    public string ColaReclamoAprobadoParaPago { get; set; } = "mprpagos.reclamo-aprobado-para-pago";

    /// <summary>Routing key con la que este servicio publica PagoCompletado.</summary>
    public string RoutingKeyPagoCompletado { get; set; } = "pago.completado";

    public int IntervaloPollingSegundos { get; set; } = 5;
}

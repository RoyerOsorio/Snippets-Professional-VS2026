using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MprPagos.Infrastructure.Persistencia;
using RabbitMQ.Client;

namespace MprPagos.Infrastructure.Mensajeria;

/// <summary>
/// Segunda mitad del patrón Transactional Outbox para MprPagos: sondea
/// dbo.MTP_OBOX_MENSAJE por filas no publicadas (PagoCompletadoEvento) y
/// las publica a RabbitMQ. Mismo diseño que
/// MprGestionReclamos.Infrastructure/Mensajeria/OutboxPublisherHostedService
/// — ver ese archivo para la explicación completa del patrón.
/// </summary>
public sealed class OutboxPublisherHostedService(
    IServiceScopeFactory scopeFactory,
    IOptions<RabbitMqOpciones> opciones,
    ILogger<OutboxPublisherHostedService> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var config = opciones.Value;

        var factory = new ConnectionFactory
        {
            HostName = config.HostName,
            Port = config.Port,
            UserName = config.UserName,
            Password = config.Password,
        };

        await using var conexion = await factory.CreateConnectionAsync(stoppingToken);
        await using var canal = await conexion.CreateChannelAsync(cancellationToken: stoppingToken);

        await canal.ExchangeDeclareAsync(config.Exchange, ExchangeType.Topic, durable: true, cancellationToken: stoppingToken);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await PublicarPendientesAsync(canal, config, stoppingToken);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Fallo al publicar mensajes pendientes del Outbox de MprPagos.");
            }

            await Task.Delay(TimeSpan.FromSeconds(config.IntervaloPollingSegundos), stoppingToken);
        }
    }

    private async Task PublicarPendientesAsync(IChannel canal, RabbitMqOpciones config, CancellationToken cancellationToken)
    {
        using var scope = scopeFactory.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<MprPagosDbContext>();

        var pendientes = await dbContext.OutboxMensajes
            .Where(m => !m.OboxPublicado)
            .OrderBy(m => m.OboxNid)
            .Take(50)
            .ToListAsync(cancellationToken);

        foreach (var mensaje in pendientes)
        {
            var routingKey = mensaje.OboxTipoEvento switch
            {
                "PagoCompletadoEvento" => config.RoutingKeyPagoCompletado,
                _ => mensaje.OboxTipoEvento,
            };

            var cuerpo = System.Text.Encoding.UTF8.GetBytes(mensaje.OboxPayloadJson);

            var propiedades = new BasicProperties
            {
                MessageId = mensaje.OboxNid.ToString(),
                ContentType = "application/json",
                Persistent = true,
            };

            await canal.BasicPublishAsync(
                config.Exchange, routingKey, mandatory: false, propiedades, cuerpo, cancellationToken);

            mensaje.OboxPublicado = true;
            mensaje.OboxFechaPublicacion = DateTime.UtcNow;

            logger.LogInformation(
                "Publicado {TipoEvento} (OboxNid={OboxNid}) en {Exchange}/{RoutingKey}.",
                mensaje.OboxTipoEvento, mensaje.OboxNid, config.Exchange, routingKey);
        }

        if (pendientes.Count > 0)
        {
            await dbContext.SaveChangesAsync(cancellationToken);
        }
    }
}

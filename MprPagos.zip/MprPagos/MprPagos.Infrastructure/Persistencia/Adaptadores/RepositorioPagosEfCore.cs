using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using MprPagos.Application.Eventos;
using MprPagos.Application.Puertos;
using MprPagos.Domain.Entidades;
using PagoGenerado = MprPagos.Infrastructure.Persistencia.ModelosGenerados.Pago;

namespace MprPagos.Infrastructure.Persistencia.Adaptadores;

/// <summary>
/// Adaptador escrito a mano. Implementa el puerto IRepositorioPagos.
/// ActualizarYPublicarEventoAsync replica el mismo patrón Transactional
/// Outbox que RepositorioReclamosEfCore en MprGestionReclamos.
/// </summary>
public sealed class RepositorioPagosEfCore(MprPagosDbContext dbContext) : IRepositorioPagos
{
    private static readonly JsonSerializerOptions OpcionesJson = new(JsonSerializerDefaults.Web);

    public async Task<Pago?> ObtenerPorIdAsync(int pagoId, CancellationToken cancellationToken)
    {
        var entidad = await dbContext.Pagos.AsNoTracking()
            .FirstOrDefaultAsync(p => p.PgpgNid == pagoId, cancellationToken);

        return entidad is null ? null : AEntidadDominio(entidad);
    }

    public async Task<Pago?> ObtenerPorMensajeIdOrigenAsync(long mensajeIdOrigen, CancellationToken cancellationToken)
    {
        var entidad = await dbContext.Pagos.AsNoTracking()
            .FirstOrDefaultAsync(p => p.PgpgMensajeIdOrigen == mensajeIdOrigen, cancellationToken);

        return entidad is null ? null : AEntidadDominio(entidad);
    }

    public async Task<Pago> CrearAsync(Pago pago, CancellationToken cancellationToken)
    {
        var entidad = new PagoGenerado
        {
            PgpgReclamoId = pago.ReclamoId,
            PgpgPoliza = pago.Poliza,
            PgpgAseguradoId = pago.AseguradoId,
            PgpgMontoAprobado = pago.MontoAprobado,
            PgpgEstado = (byte)pago.Estado,
            PgpgMensajeIdOrigen = pago.MensajeIdOrigen,
            PgpgFechaCreacion = pago.FechaCreacion,
        };

        dbContext.Pagos.Add(entidad);
        await dbContext.SaveChangesAsync(cancellationToken);

        return AEntidadDominio(entidad);
    }

    public async Task ActualizarYPublicarEventoAsync(
        Pago pago,
        PagoCompletadoEvento evento,
        CancellationToken cancellationToken)
    {
        var entidad = await dbContext.Pagos.FirstAsync(p => p.PgpgNid == pago.Id, cancellationToken);
        entidad.PgpgEstado = (byte)pago.Estado;
        entidad.PgpgFechaConfirmacion = pago.FechaConfirmacion;

        dbContext.OutboxMensajes.Add(new ModelosGenerados.OutboxMensaje
        {
            OboxTipoEvento = nameof(PagoCompletadoEvento),
            OboxPayloadJson = JsonSerializer.Serialize(evento, OpcionesJson),
            OboxFechaCreacion = evento.FechaConfirmacion,
            OboxPublicado = false,
        });

        // Un único SaveChangesAsync ⇒ una única transacción: el Pago pasa
        // a Completado y el mensaje queda en Outbox atómicamente.
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    private static Pago AEntidadDominio(PagoGenerado entidad) => new(
        entidad.PgpgNid,
        entidad.PgpgReclamoId,
        entidad.PgpgPoliza,
        entidad.PgpgAseguradoId,
        entidad.PgpgMontoAprobado,
        (Domain.Entidades.EstadoPago)entidad.PgpgEstado,
        entidad.PgpgMensajeIdOrigen,
        entidad.PgpgFechaCreacion,
        entidad.PgpgFechaConfirmacion);
}

namespace MprPagos.Contracts.Responses;

/// <summary>
/// Estado como string (no el enum de Domain) — Contracts es la frontera
/// pública del microservicio, mismo criterio que ReclamoResponse en
/// MprGestionReclamos.
/// </summary>
public sealed record PagoResponse(
    int Id,
    int ReclamoId,
    string Poliza,
    int AseguradoId,
    decimal MontoAprobado,
    string Estado,
    DateTime FechaCreacion,
    DateTime? FechaConfirmacion);

/* ============================================================================
   reembolso-solicitud.js — Interacciones exclusivas de la vista Solicitud de
   Reembolso. La búsqueda de la Sección 1 (Datos del asegurado titular) es la
   única parte de esta vista conectada a datos reales — consulta MprClientes
   vía HomeController.BuscarContextoAsegurado (ver UI_Decision_Log.md DEC-009
   y UI_Architecture_Guide.md sección 4: Browser → Controller → ApiClient →
   API, nunca fetch directo al Gateway). El resto (beneficiarios más allá del
   propio titular, categorías de reclamación, facturas, envío final) sigue
   sin backend y se mantiene simulado, sin cambios respecto a la versión
   anterior de este archivo.
   ============================================================================ */
(function () {
    "use strict";

    // Demo: Estado/Municipio ya no se capturan manualmente (dropdowns) — se
    // autocompletan como inputs deshabilitados a partir del Código Postal.
    // Reemplazar por una llamada real de catálogo (SEPOMEX u otro servicio).
    var ESTADO_MUNICIPIO_POR_CP = {
        "75070": { estado: "Puebla", municipio: "Chilchotla" },
        "03100": { estado: "Ciudad de México", municipio: "Benito Juárez" },
        "44100": { estado: "Jalisco", municipio: "Guadalajara" }
    };

    // ---- Revelado progresivo de secciones (Sección 1 -> 2 -> 3) ----
    // Alcance: únicamente el comportamiento de mostrar/ocultar. Sin nuevas
    // validaciones, sin nuevos campos, sin cambios en el flujo de envío.
    var aseguradoSeleccionado = false;
    var seccion2Revelada = false;
    var seccion3Revelada = false;

    // Poliza + AseguradoId del contexto real aplicado en la Sección 1 (ver
    // aplicarContextoAsegurado) — se reutilizan al presionar "Registrar"
    // para llamar a HomeController.IniciarReembolso (ver
    // UI_Decision_Log.md DEC-013).
    var contextoPoliza = null;
    var contextoAseguradoId = null;

    document.addEventListener("DOMContentLoaded", function () {
        initDerechohabienteModal();
        initCodigoPostalLookup();
        initBeneficiarioSelect();
        initCategorySelection();
        initDocBlocks();
        initFacturaGenerators();
        initFacturaLineas();
        initCancelConfirm();
        initProgressiveSections();
        initRegistrarGate();
        initRegistroExitoso();
        if (window.VM && typeof window.VM.refreshIcons === "function") {
            window.VM.refreshIcons();
        }
    });

    // ---- 1. Modal Derechohabiente: búsqueda + autocompletado ----
    function initDerechohabienteModal() {
        var modalEl = document.getElementById("modalDerechohabiente");
        if (!modalEl) return;

        // Fiel a la referencia: el modal se muestra automáticamente al entrar,
        // ya que es el punto de partida obligatorio del flujo.
        if (modalEl.hasAttribute("data-autoshow")) {
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        }

        var form = modalEl.querySelector("[data-buscar-form]");
        var resultsWrap = modalEl.querySelector("[data-buscar-resultados]");

        form.addEventListener("submit", function (e) {
            e.preventDefault();
            var poliza = (form.querySelector("input[name='poliza']").value || "").trim();
            var aseguradoIdInput = form.querySelector("input[name='aseguradoId']");
            var aseguradoId = (aseguradoIdInput.value || "").trim();

            if (!poliza || !aseguradoId) {
                resultsWrap.innerHTML =
                    '<div class="solicitar-hint"><i data-lucide="search-x" aria-hidden="true"></i>' +
                    "Indica la póliza y el número de asegurado.</div>";
                resultsWrap.hidden = false;
                if (window.VM) window.VM.refreshIcons();
                return;
            }

            resultsWrap.innerHTML = '<div class="solicitar-hint">Buscando…</div>';
            resultsWrap.hidden = false;

            var url = "/Home/BuscarContextoAsegurado?poliza=" + encodeURIComponent(poliza) + "&aseguradoId=" + encodeURIComponent(aseguradoId);
            fetch(url, { headers: { "X-Requested-With": "XMLHttpRequest" } })
                .then(function (respuesta) { return respuesta.json(); })
                .then(function (resultado) {
                    if (!resultado.ok) {
                        resultsWrap.innerHTML =
                            '<div class="solicitar-hint"><i data-lucide="search-x" aria-hidden="true"></i>' +
                            (resultado.error || "No se encontró ningún asegurado con esa póliza y número de asegurado.") + "</div>";
                        resultsWrap.hidden = false;
                        if (window.VM) window.VM.refreshIcons();
                        return;
                    }

                    resultsWrap.innerHTML =
                        '<table class="table table-sm align-middle mb-0" role="table">' +
                        '<thead><tr><th>Certificado</th><th>Nombre Completo</th><th>Rol</th><th></th></tr></thead>' +
                        '<tbody><tr class="derechohabiente-row" style="cursor:pointer" tabindex="0" role="button">' +
                        "<td>" + resultado.certificado + "</td>" +
                        "<td>" + resultado.nombreCompleto + "</td>" +
                        "<td>" + resultado.rolAsegurado + "</td>" +
                        '<td><span class="btn-text-vm" style="padding:4px 8px">Seleccionar</span></td>' +
                        "</tr></tbody></table>";

                    var row = resultsWrap.querySelector(".derechohabiente-row");
                    var seleccionar = function () {
                        aplicarContextoAsegurado(resultado);
                        var bsModal = bootstrap.Modal.getOrCreateInstance(modalEl);
                        bsModal.hide();
                    };
                    row.addEventListener("click", seleccionar);
                    row.addEventListener("keydown", function (ev) {
                        if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); seleccionar(); }
                    });
                })
                .catch(function () {
                    resultsWrap.innerHTML =
                        '<div class="solicitar-hint"><i data-lucide="search-x" aria-hidden="true"></i>' +
                        "No fue posible consultar el asegurado. Intenta de nuevo.</div>";
                    resultsWrap.hidden = false;
                    if (window.VM) window.VM.refreshIcons();
                });
        });
    }

    // Aplica el ContextoClienteDto real devuelto por MprClientes (ver
    // HomeController.BuscarContextoAsegurado, UI_Decision_Log.md DEC-009).
    // "Miembro desde" no tiene equivalente en MprClientes hoy: se deja sin
    // poblar (queda "—") en vez de simular un valor, siguiendo el mismo
    // criterio de honestidad de datos que DetalleSolicitud (DEC-008). El
    // selector de Beneficiario/paciente solo ofrece al propio titular — no se
    // inventan dependientes: MprClientes no expone todavía un listado de
    // beneficiarios/derechohabientes por asegurado.
    function aplicarContextoAsegurado(data) {
        contextoPoliza = data.poliza;
        contextoAseguradoId = data.aseguradoId;

        setFieldText("campoNumeroEmpleado", data.certificado);
        setFieldText("campoNombreTitular", data.nombreCompleto);
        setFieldText("campoFechaInicioVigencia", data.vigenciaInicio);
        setFieldText("campoFechaFinVigencia", data.vigenciaFin);

        var resumen = document.getElementById("resumenAsegurado");
        if (resumen) {
            resumen.textContent = data.nombreCompleto + " · Póliza " + data.poliza + (data.esVigente ? "" : " · Vigencia vencida");
        }

        var select = document.getElementById("selectBeneficiario");
        if (select) {
            select.innerHTML = '<option value="">-- Seleccionar Beneficiario --</option>';
            var opt = document.createElement("option");
            opt.value = "titular-" + data.aseguradoId;
            opt.textContent = data.nombreCompleto + " (" + data.rolAsegurado + ")";
            opt.setAttribute("data-parentesco", data.rolAsegurado);
            select.appendChild(opt);
            select.disabled = false;
        }

        aseguradoSeleccionado = true;
        evaluarGateSeccion2();
    }

    function setFieldText(id, value) {
        var el = document.getElementById(id);
        if (el) el.textContent = value;
    }

    // ---- 2. Código Postal -> Estado/Municipio (demo, inputs deshabilitados) ----
    function initCodigoPostalLookup() {
        var cp = document.getElementById("inputCP");
        var estado = document.getElementById("inputEstado");
        var municipio = document.getElementById("inputMunicipio");
        if (!cp || !estado || !municipio) return;

        function sync() {
            var valor = (cp.value || "").trim();
            var datos = ESTADO_MUNICIPIO_POR_CP[valor];
            estado.value = datos ? datos.estado : "";
            municipio.value = datos ? datos.municipio : "";
            // Los inputs quedan deshabilitados (no editables ni disparan sus
            // propios eventos): se notifica el gate de la Sección 1 aquí mismo.
            evaluarGateSeccion2();
        }

        cp.addEventListener("input", sync);
        cp.addEventListener("change", sync);
    }

    // ---- 3. Beneficiario -> Parentesco autocompletado ----
    function initBeneficiarioSelect() {
        var select = document.getElementById("selectBeneficiario");
        var parentesco = document.getElementById("campoParentesco");
        if (!select || !parentesco) return;

        select.addEventListener("change", function () {
            var opt = select.options[select.selectedIndex];
            parentesco.textContent = opt ? (opt.getAttribute("data-parentesco") || "—") : "—";
            evaluarGateSeccion3(select.value);
        });
    }

    // ---- 4. Selector de categorías: un clic selecciona Y agrega la categoría
    // a la solicitud en un solo gesto (sustituye el antiguo par "clic en tab" +
    // checkbox "Solicitar" independiente — ver Analisis_UX_SolicitudReembolso_
    // DatosReclamacion.md §2.2). La navegación por flechas SOLO mueve el foco
    // (roving tabindex), sin alterar la inclusión: así recorrer categorías con
    // el teclado no las agrega por accidente. Activar (clic/Enter/Espacio) es
    // lo único que decide inclusión.
    function initCategorySelection() {
        var nav = document.querySelector("[data-category-nav]");
        if (!nav) return;
        var buttons = Array.prototype.slice.call(nav.querySelectorAll(".category-nav-btn"));

        function mostrarPanel(btn) {
            buttons.forEach(function (b) {
                var seleccionado = b === btn;
                b.setAttribute("aria-selected", String(seleccionado));
                b.tabIndex = seleccionado ? 0 : -1;
                var panel = document.getElementById(b.getAttribute("aria-controls"));
                if (panel) panel.classList.toggle("is-active", seleccionado);
            });
        }

        function alternarInclusion(btn) {
            var key = btn.getAttribute("data-category-key");
            var input = document.querySelector("[data-categoria-incluida='" + key + "']");
            if (!input) return;

            var yaActiva = btn.getAttribute("aria-selected") === "true";
            var yaIncluida = input.value === "true";

            if (yaIncluida && yaActiva) {
                // Un segundo clic sobre la categoría que ya se está viendo Y ya
                // está incluida la retira de la solicitud (no descarta los
                // documentos ya cargados, por si el usuario la vuelve a
                // seleccionar más adelante en la misma sesión — ver pregunta 7
                // del análisis, pendiente de confirmación de negocio).
                input.value = "false";
            } else {
                input.value = "true";
                mostrarPanel(btn);
            }

            actualizarBadgeCategoria(key);
            actualizarResumenReclamacion();
        }

        buttons.forEach(function (btn, idx) {
            btn.tabIndex = btn.getAttribute("aria-selected") === "true" ? 0 : -1;
            btn.addEventListener("click", function () { alternarInclusion(btn); });
            btn.addEventListener("keydown", function (e) {
                if (e.key === "ArrowDown") { e.preventDefault(); enfocarSiguiente(idx, 1); }
                if (e.key === "ArrowUp") { e.preventDefault(); enfocarSiguiente(idx, -1); }
                if (e.key === "Enter" || e.key === " ") { e.preventDefault(); alternarInclusion(btn); }
            });
        });

        function enfocarSiguiente(idx, delta) {
            buttons[(idx + delta + buttons.length) % buttons.length].focus();
        }

        // Pinta el estado inicial (categoría 0 activa + incluida por defecto,
        // igual que el comportamiento previo con el checkbox premarcado).
        buttons.forEach(function (btn) {
            actualizarBadgeCategoria(btn.getAttribute("data-category-key"));
        });
        actualizarResumenReclamacion();
    }

    // ---- 4.1 Badge de categoría (check + contador) y resumen agregado ----
    function actualizarBadgeCategoria(key) {
        var input = document.querySelector("[data-categoria-incluida='" + key + "']");
        var badge = document.querySelector("[data-category-badge='" + key + "']");
        if (!input || !badge) return;
        badge.hidden = input.value !== "true";
        actualizarContadorCategoria(key);
    }

    // Cuenta documentos "cargados" dentro de la categoría: hoy solo Factura
    // simula un estado real de carga (ver initFacturaGenerators); los demás
    // campos de documento no tienen todavía un mecanismo de carga real (ver
    // documentoRequeridoCargado más abajo), así que de momento solo suman si
    // llegaran a tener valor. Único punto a extender cuando exista carga real.
    function contarDocumentosCategoria(key) {
        var panel = document.querySelector("[data-category-panel='" + key + "']");
        if (!panel) return 0;
        var total = 0;
        panel.querySelectorAll(".doc-file-input").forEach(function (input) {
            if ((input.value || "").trim().length > 0) total++;
        });
        return total;
    }

    function actualizarContadorCategoria(key) {
        var countEl = document.querySelector("[data-category-count='" + key + "']");
        if (countEl) countEl.textContent = String(contarDocumentosCategoria(key));
    }

    // Resumen agregado fijo en el encabezado de la Sección 3 (categorías
    // incluidas · documentos cargados · monto total) — visión de conjunto que
    // el flujo anterior no ofrecía (solo mostraba una categoría a la vez).
    function actualizarResumenReclamacion() {
        var resumen = document.getElementById("resumenReclamacion");
        if (!resumen) return;

        var categoriasIncluidas = 0;
        var documentosTotales = 0;
        var montoTotal = 0;

        document.querySelectorAll("[data-categoria-incluida]").forEach(function (input) {
            if (input.value !== "true") return;
            categoriasIncluidas++;
            var key = input.getAttribute("data-categoria-incluida");
            documentosTotales += contarDocumentosCategoria(key);
            var montoEl = document.querySelector("#panel-" + key + " [data-factura-monto]");
            if (montoEl) {
                var monto = parseFloat(montoEl.textContent.replace(/[^\d.]/g, ""));
                if (!isNaN(monto)) montoTotal += monto;
            }
        });

        if (categoriasIncluidas === 0) {
            resumen.textContent = "Aún no se ha seleccionado ningún servicio";
        } else {
            var textoCategorias = categoriasIncluidas + (categoriasIncluidas === 1 ? " categoría" : " categorías");
            var textoDocumentos = documentosTotales + (documentosTotales === 1 ? " documento" : " documentos");
            var textoMonto = montoTotal.toLocaleString("es-MX", { style: "currency", currency: "MXN" });
            resumen.textContent = textoCategorias + " · " + textoDocumentos + " · " + textoMonto;
        }

        evaluarBotonRegistrar();
    }

    // ---- 6. Bloques de documento (acordeón interno + agregar/quitar filas) ----
    function initDocBlocks() {
        document.querySelectorAll("[data-doc-toggle]").forEach(function (header) {
            var body = document.getElementById(header.getAttribute("aria-controls"));
            header.addEventListener("click", function () {
                var expanded = header.getAttribute("aria-expanded") === "true";
                header.setAttribute("aria-expanded", String(!expanded));
                if (body) body.hidden = expanded;
            });
        });

        document.querySelectorAll("[data-doc-add]").forEach(function (btn) {
            btn.addEventListener("click", function () {
                var list = document.getElementById(btn.getAttribute("data-doc-add"));
                if (!list) return;
                var template = list.querySelector(".doc-file-row");
                if (!template) return;
                var clone = template.cloneNode(true);
                clone.querySelectorAll("input[type=text]").forEach(function (i) { i.value = ""; });
                list.appendChild(clone);
                wireRemoveButton(clone.querySelector(".doc-file-remove"));
                if (window.VM) window.VM.refreshIcons();
            });
        });

        document.querySelectorAll(".doc-file-remove").forEach(wireRemoveButton);
    }

    function wireRemoveButton(btn) {
        if (!btn || btn.dataset.wired) return;
        btn.dataset.wired = "1";
        btn.addEventListener("click", function () {
            var row = btn.closest(".doc-file-row");
            var list = row ? row.parentElement : null;
            if (list && list.querySelectorAll(".doc-file-row").length > 1) {
                row.remove();
            }
        });
    }

    // ---- 7. Generador de Factura: tabs de método (PDF/XML/Generar XML) +
    // una sola acción de carga, en vez de 4 botones de color compitiendo entre
    // sí (ver Analisis_UX_SolicitudReembolso_DatosReclamacion.md §2.4). ----
    var FACTURA_METODOS = {
        pdf: { icono: "upload", etiqueta: "Cargar PDF", pista: "Formatos permitidos: PDF · máx. 5 MB" },
        xml: { icono: "upload", etiqueta: "Cargar XML", pista: "Formatos permitidos: XML · máx. 5 MB" },
        generar: { icono: "sparkles", etiqueta: "Generar XML", pista: "Se genera a partir de los datos ya capturados en esta solicitud" }
    };

    function initFacturaGenerators() {
        document.querySelectorAll("[data-factura-generator]").forEach(function (gen) {
            var empty = gen.querySelector("[data-factura-empty]");
            var loaded = gen.querySelector("[data-factura-loaded]");
            var totalEl = gen.querySelector("[data-factura-total]");
            var montoEl = gen.querySelector("[data-factura-monto]");
            var actionBtn = gen.querySelector("[data-factura-action='cargar']");
            var actionIcon = gen.querySelector("[data-factura-action-icon]");
            var actionLabel = gen.querySelector("[data-factura-action-label]");
            var hint = gen.querySelector("[data-factura-hint]");
            var methodTabs = Array.prototype.slice.call(gen.querySelectorAll("[data-factura-method]"));
            var panel = gen.closest("[data-category-panel]");
            var categoryKey = panel ? panel.getAttribute("data-category-panel") : null;

            function refrescarCategoria() {
                if (!categoryKey) return;
                actualizarContadorCategoria(categoryKey);
                actualizarResumenReclamacion();
            }

            function aplicarMetodo(metodo) {
                methodTabs.forEach(function (tab) {
                    var activo = tab.getAttribute("data-factura-method") === metodo;
                    tab.classList.toggle("is-active", activo);
                    tab.setAttribute("aria-selected", String(activo));
                });
                var config = FACTURA_METODOS[metodo];
                if (!config) return;
                if (actionIcon) actionIcon.setAttribute("data-lucide", config.icono);
                if (actionLabel) actionLabel.textContent = config.etiqueta;
                if (hint) hint.textContent = config.pista;
                if (window.VM && typeof window.VM.refreshIcons === "function") window.VM.refreshIcons();
            }

            methodTabs.forEach(function (tab) {
                tab.addEventListener("click", function () {
                    aplicarMetodo(tab.getAttribute("data-factura-method"));
                });
            });

            if (actionBtn) {
                actionBtn.addEventListener("click", function () {
                    if (empty) empty.hidden = true;
                    if (loaded) loaded.hidden = false;
                    if (totalEl) totalEl.textContent = "1";
                    if (montoEl) montoEl.textContent = "$ 1,250.00";
                    refrescarCategoria();
                });
            }

            gen.querySelectorAll("[data-factura-action='limpiar']").forEach(function (btn) {
                btn.addEventListener("click", function () {
                    if (empty) empty.hidden = false;
                    if (loaded) loaded.hidden = true;
                    if (totalEl) totalEl.textContent = "0";
                    if (montoEl) montoEl.textContent = "$ 0.00";
                    refrescarCategoria();
                });
            });

            aplicarMetodo("pdf");
        });
    }

    // ---- 8. Gastos en el Extranjero: líneas de factura con Moneda/Fecha/Monto ----
    function initFacturaLineas() {
        document.querySelectorAll("[data-factura-lineas-add]").forEach(function (btn) {
            btn.addEventListener("click", function () {
                var list = document.getElementById(btn.getAttribute("data-factura-lineas-add"));
                if (!list) return;
                var template = list.querySelector(".factura-line");
                if (!template) return;
                var clone = template.cloneNode(true);
                clone.querySelectorAll("input").forEach(function (i) { i.value = ""; });
                clone.querySelectorAll("select").forEach(function (s) { s.selectedIndex = 0; });
                list.appendChild(clone);
                wireRemoveButton(clone.querySelector(".doc-file-remove"));
                // Date Picker de la fila clonada: components/date-picker.js (ES module) no es
                // importable desde este script clásico, por lo que se inicializa aquí
                // directamente sobre window.flatpickr (mismo vendor, mismas opciones —
                // ver JavaScript_Architecture_Guide.md, sección "Contenido agregado
                // dinámicamente").
                clone.querySelectorAll('[data-component="date-picker"]').forEach(function (input) {
                    if (window.flatpickr && !input._flatpickr) {
                        window.flatpickr(input, { dateFormat: "d/m/Y", locale: "es", allowInput: true, disableMobile: true });
                    }
                });
                if (window.VM) window.VM.refreshIcons();
            });
        });
    }

    // ---- 9. Confirmación al cancelar ----
    function initCancelConfirm() {
        var cancelBtn = document.querySelector("[data-cancelar-solicitud]");
        var modalEl = document.getElementById("modalConfirmarCancelar");
        if (!cancelBtn || !modalEl) return;
        cancelBtn.addEventListener("click", function () {
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        });
        var confirmBtn = modalEl.querySelector("[data-confirmar-cancelar]");
        if (confirmBtn) {
            confirmBtn.addEventListener("click", function () {
                window.location.href = confirmBtn.getAttribute("data-href") || "/";
            });
        }
    }

    // ---- 10. Revelado progresivo de secciones (Sección 1 -> 2 -> 3) ----

    // Lista única y centralizada de campos de la Sección 1 que determinan si
    // está "completa". Cualquier ajuste a este gate se hace en un solo lugar.
    var SECCION1_CAMPOS_REQUERIDOS = [
        "inputCorreo",
        "inputTelefono",
        "inputCP",
        "inputEstado",
        "inputMunicipio",
        "inputFechaPadecimiento"
    ];

    // Campos de SECCION1_CAMPOS_REQUERIDOS que son de solo lectura (autocompletados,
    // no capturados por el usuario) — no necesitan listener propio de "input"/"change"
    // en initProgressiveSections(), ya que su cambio se notifica desde quien los llena
    // (ver initCodigoPostalLookup, que llama a evaluarGateSeccion2() directamente).
    var SECCION1_CAMPOS_AUTOCOMPLETADOS = ["inputEstado", "inputMunicipio"];

    function campoTieneValor(id) {
        var el = document.getElementById(id);
        if (!el) return false;
        return (el.value || "").trim().length > 0;
    }

    function seccion1Completa() {
        return aseguradoSeleccionado && SECCION1_CAMPOS_REQUERIDOS.every(campoTieneValor);
    }

    // Revela una <section> oculta con transición vía bootstrap.Collapse (ya
    // usado en esta misma vista para los modales) y mueve el foco a su primer
    // campo interactivo, sin recargar la página ni afectar datos capturados.
    function revelarSeccion(wrapperId, collapseId) {
        var wrapper = document.getElementById(wrapperId);
        var collapseEl = document.getElementById(collapseId);
        if (!wrapper || !collapseEl) return;

        wrapper.hidden = false;
        bootstrap.Collapse.getOrCreateInstance(collapseEl, { toggle: false }).show();

        var primerCampo = wrapper.querySelector("input, select, textarea, button");
        if (primerCampo) primerCampo.focus();
    }

    function evaluarGateSeccion2() {
        if (seccion2Revelada) return; // Regla: una vez revelada, no se vuelve a evaluar ni a ocultar.
        if (!seccion1Completa()) return;
        seccion2Revelada = true;
        revelarSeccion("seccionPacienteWrapper", "seccionPaciente");
    }

    function evaluarGateSeccion3(valorSeleccionado) {
        if (seccion3Revelada) return; // Regla: una vez revelada, no se vuelve a evaluar ni a ocultar.
        if (!valorSeleccionado) return;
        seccion3Revelada = true;
        revelarSeccion("seccionReclamacionWrapper", "seccionReclamacion");
    }

    // El campo de fecha (Date Picker / Flatpickr) es inicializado por el
    // componente compartido components/date-picker.js, cargado vía site.js.
    // Ese componente no se modifica en esta solicitud: en su lugar, se lee su
    // instancia pública (input._flatpickr, convención propia de Flatpickr) una
    // vez ya creada, para enterarse también de fechas elegidas con el
    // calendario (no solo tecleadas). Espera acotada sin temporizadores: si la
    // instancia aún no existe, reintenta en la siguiente vuelta de microtareas
    // hasta un límite fijo; si nunca aparece, el campo sigue cubierto por los
    // listeners nativos de "input"/"change" ya registrados en
    // initProgressiveSections (degradación seguridad, sin romper el resto).
    var FLATPICKR_INTENTOS_MAXIMOS = 20;

    function engancharFechaPadecimiento(intentosRestantes) {
        var input = document.getElementById("inputFechaPadecimiento");
        if (!input) return;

        var instancia = input._flatpickr;
        if (instancia) {
            instancia.config.onChange.push(evaluarGateSeccion2);
            return;
        }
        if (intentosRestantes <= 0 || !window.queueMicrotask) return;
        queueMicrotask(function () {
            engancharFechaPadecimiento(intentosRestantes - 1);
        });
    }

    function initProgressiveSections() {
        var seccion1 = document.getElementById("seccionAsegurado");
        if (!seccion1) return; // Esta vista no aplica.

        SECCION1_CAMPOS_REQUERIDOS.forEach(function (id) {
            if (SECCION1_CAMPOS_AUTOCOMPLETADOS.indexOf(id) !== -1) return;
            var el = document.getElementById(id);
            if (!el) return;
            el.addEventListener("input", evaluarGateSeccion2);
            el.addEventListener("change", evaluarGateSeccion2);
        });

        engancharFechaPadecimiento(FLATPICKR_INTENTOS_MAXIMOS);
    }

    // ---- 11. Habilitación de Registrar (validación continua de Sección 3) ----

    // Único punto de extensión para cuando exista carga real de archivos: hoy
    // ningún botón "Cargar" de documento individual registra estado real (no
    // hay mecanismo que lo permita todavía), así que esta función no bloquea
    // el botón. El día que exista ese mecanismo, es la única función a
    // cambiar — no la lógica de habilitación que la llama.
    function documentoRequeridoCargado(fila) {
        return true;
    }

    // Una categoría con documentos marcados "Documento requerido" (banner ya
    // renderizado por el servidor) solo cuenta como completa si cada una de
    // sus filas de archivo pasa documentoRequeridoCargado.
    function categoriaDocumentosRequeridosCompletos(dataId) {
        var contenedor = document.getElementById(dataId);
        if (!contenedor) return true;
        var completo = true;
        contenedor.querySelectorAll(".doc-block-body").forEach(function (body) {
            if (!body.querySelector(".doc-required-banner")) return; // sin requisito, no evalúa
            body.querySelectorAll(".doc-file-row").forEach(function (fila) {
                if (!documentoRequeridoCargado(fila)) completo = false;
            });
        });
        return completo;
    }

    function seccion3Completa() {
        var inputs = document.querySelectorAll("[data-categoria-incluida]");
        var algunaSolicitada = false;
        var completa = true;
        inputs.forEach(function (input) {
            if (input.value !== "true") return;
            algunaSolicitada = true;
            var key = input.getAttribute("data-categoria-incluida");
            if (!categoriaDocumentosRequeridosCompletos("data-" + key)) completa = false;
        });
        return algunaSolicitada && completa;
    }

    function evaluarBotonRegistrar() {
        var btn = document.getElementById("btnRegistrar");
        if (!btn) return;
        btn.disabled = !seccion3Completa();
    }

    // La activación/desactivación de categorías ya notifica a
    // evaluarBotonRegistrar() desde actualizarResumenReclamacion() (single
    // choke point, ver initCategorySelection) — initRegistrarGate() solo
    // pinta el estado inicial del botón al cargar la página.
    function initRegistrarGate() {
        evaluarBotonRegistrar();
    }

    // ---- 12. Registrar -> POST real a IniciarReembolso -> modal -> redirect ----
    // Llama a HomeController.IniciarReembolso, que a su vez llama a
    // Reimbursement.Orchestrator vía ReembolsosApiClient — nunca fetch
    // directo al Gateway desde el navegador (UI_Architecture_Guide.md
    // sección 4). Primera vez que "Registrar" hace algo real en esta vista
    // (ver UI_Decision_Log.md DEC-013): antes solo mostraba el modal y
    // redirigía al Tablero sin persistir nada.
    function initRegistroExitoso() {
        var form = document.getElementById("formSolicitudReembolso");
        var modalEl = document.getElementById("modalRegistroExitoso");
        if (!form || !modalEl) return;

        var mensaje = document.getElementById("mensajeRegistroExitoso");
        var btnCerrar = document.getElementById("btnCerrarRegistroExitoso");
        var tokenInput = form.querySelector('input[name="__RequestVerificationToken"]');
        var token = tokenInput ? tokenInput.value : "";

        form.addEventListener("submit", async function (e) {
            e.preventDefault();
            var btn = document.getElementById("btnRegistrar");
            if (btn && btn.disabled) return;

            if (!contextoPoliza || !contextoAseguradoId) {
                window.alert("Selecciona primero un asegurado en la Sección 1.");
                return;
            }

            var textoOriginal = btn ? btn.innerHTML : "";
            if (btn) { btn.disabled = true; btn.textContent = "Registrando…"; }

            try {
                var respuesta = await fetch("/Home/IniciarReembolso", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                        "RequestVerificationToken": token
                    },
                    body: new URLSearchParams({ poliza: contextoPoliza, aseguradoId: contextoAseguradoId }).toString()
                });
                var resultado = await respuesta.json();

                if (!resultado.ok) {
                    window.alert(resultado.error || "No fue posible registrar la solicitud. Intenta de nuevo.");
                    if (btn) { btn.disabled = false; btn.innerHTML = textoOriginal; }
                    return;
                }

                if (mensaje) {
                    mensaje.textContent = "La solicitud fue registrada correctamente. Folio R-" +
                        String(resultado.reclamoId).padStart(5, "0") + " (" + resultado.estado + ").";
                }
                if (btnCerrar) {
                    btnCerrar.setAttribute("data-href", "/Home/DetalleSolicitud/" + resultado.reclamoId);
                }
                bootstrap.Modal.getOrCreateInstance(modalEl).show();
            } catch (err) {
                window.alert("No fue posible registrar la solicitud. Intenta de nuevo.");
                if (btn) { btn.disabled = false; btn.innerHTML = textoOriginal; }
            }
        });

        if (btnCerrar) {
            btnCerrar.addEventListener("click", function () {
                window.location.href = btnCerrar.getAttribute("data-href") || "/";
            });
        }
    }
})();
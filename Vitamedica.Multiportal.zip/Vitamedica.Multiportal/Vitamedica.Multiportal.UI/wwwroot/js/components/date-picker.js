/* ============================================================================
   components/date-picker.js
   Responsabilidad: envolver la librería de terceros Flatpickr (cargada como
   vendor global en _Layout.cshtml, antes de site.js)
   para el componente Date Picker, variante fecha única.

   Depende de: window.flatpickr (vendor, wwwroot/lib/flatpickr/dist/flatpickr.min.js
   + l10n/es.js), cargados antes de este módulo. Esta es la única dependencia
   global implícita permitida en el proyecto (excepción documentada, no aplica
   a módulos internos).
   Consumido por: site.js

   Contrato: se auto-inicializa sobre todo input con [data-component="date-picker"]
   presente en el DOM. No contiene
   lógica de negocio. Es idempotente y expone reinit() para el caso de
   filas de formulario agregadas dinámicamente (ej. clonado de líneas de factura).
   ============================================================================ */

const SELECTOR = '[data-component="date-picker"]';

function createInstance(input) {
    if (!window.flatpickr) return;
    // Idempotencia: no crear una segunda instancia sobre el mismo input.
    if (input._flatpickr) return;

    window.flatpickr(input, {
        dateFormat: "d/m/Y",
        locale: "es",
        allowInput: true,
        disableMobile: true,
    });
}

export function initDatePicker(root = document) {
    root.querySelectorAll(SELECTOR).forEach(createInstance);
}

/**
 * Reinicializa el Date Picker sobre un contenedor específico — uso previsto
 * para contenido agregado dinámicamente después de la carga inicial (ej. una
 * fila de formulario clonada que incluye un input de fecha), evitando que
 * cada pantalla reimplemente su propia lógica de detección — ver
 * JavaScript_Architecture_Guide.md, sección "Inicialización, refresco y
 * contenido dinámico".
 */
export function reinitDatePicker(root) {
    initDatePicker(root);
}

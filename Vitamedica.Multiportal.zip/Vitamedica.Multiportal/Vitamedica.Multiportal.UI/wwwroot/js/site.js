﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

/* ============================================================================
   site.js — Punto de entrada único de JavaScript.

   Responsabilidad: registro de inicializadores, orquestando core/ y
   components/ tras DOMContentLoaded. Es el único módulo cargado
   directamente desde _Layout.cshtml (<script type="module">); toda
   pantalla nueva se conecta agregando su inicializador aquí, no
   añadiendo otro <script> suelto al Layout.

   Depende de: core/dom-ready.js, core/density-preference.js,
   components/sidebar.js, components/date-picker.js

   Mecanismo: ES Modules nativos — ver JavaScript_Architecture_Guide.md,
   sección "Módulos y punto de entrada".
   ============================================================================ */

import { onReady } from './core/dom-ready.js';
import { initDensityPreference } from './core/density-preference.js';
import { initSidebar } from './components/sidebar.js';
import { initDatePicker } from './components/date-picker.js';

// Refresco de íconos Lucide: no se extrajo a core/icons.js porque sus dos
// únicos puntos de uso residen en este mismo archivo, no en dos módulos
// distintos (criterio de promoción a core/, ver JavaScript_Architecture_Guide.md).
function refreshIcons() {
    if (window.lucide && typeof window.lucide.createIcons === "function") {
        window.lucide.createIcons();
    }
}

onReady(() => {
    initSidebar();
    initDensityPreference();
    initDatePicker();

    // Pintado inicial de íconos.
    refreshIcons();

    // Refresco al abrir el menú de usuario (los íconos del panel se insertan
    // en el DOM al abrir el dropdown, por lo que necesitan un segundo pintado).
    const userMenu = document.querySelector(".user-menu");
    if (userMenu) {
        userMenu.addEventListener("shown.bs.dropdown", refreshIcons);
    }
});




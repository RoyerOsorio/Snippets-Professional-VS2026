/* ============================================================================
   pagos-index.js — Interacciones exclusivas de Views/Pagos/Index.
   Sin lógica de negocio: solo refleja en pantalla el nombre del archivo
   seleccionado en el modal "Retro" y simula la confirmación de carga.
   ============================================================================ */
(function () {
    "use strict";

    document.addEventListener("DOMContentLoaded", function () {
        var input = document.getElementById("inputRetroArchivo");
        var nombre = document.getElementById("retroArchivoNombre");
        var confirmBtn = document.getElementById("btnConfirmarRetro");
        var modalEl = document.getElementById("modalRetro");

        if (input && nombre) {
            input.addEventListener("change", function () {
                nombre.textContent = input.files && input.files.length > 0
                    ? input.files[0].name
                    : "Ningún archivo seleccionado";
            });
        }

        if (confirmBtn && modalEl) {
            confirmBtn.addEventListener("click", function () {
                bootstrap.Modal.getOrCreateInstance(modalEl).hide();
            });
        }
    });
})();

/* ============================================================================
   detalle-solicitud.js — Interacciones exclusivas de Views/Reembolsos/Detalle.
   Los comportamientos genéricos (abrir/cerrar doc-block, agregar/quitar filas
   de evidencia) ya viven en reembolso-solicitud.js y se reutilizan tal cual
   desde esta vista (ver @section Scripts). Aquí solo se resuelve lo propio de
   Detalle: modal ICD/CPT, modal Histórico ICD, el switch "Procedente" y — solo
   cuando la vista trae un Reclamo real (ver [data-reclamo-id] en
   .detalle-actions, HomeController.DetalleSolicitud, UI_Decision_Log.md
   DEC-008) — Aprobar/Rechazar contra MprGestionReclamos vía los endpoints
   AJAX del propio Controller (Browser → Controller → ApiClient → API, nunca
   directo al Gateway — UI_Architecture_Guide.md sección 4). Sin Id de
   Reclamo, el comportamiento es el mismo simulado/sin backend que ya existía.
   ============================================================================ */
(function () {
    "use strict";

    var HISTORICO_ICD_DEMO = [
        { folio: "0100326135", motivo: "Consulta médica", concepto: "GASTOS EN EL EXTRANJERO", dx: "Z71.9" },
        { folio: "0098214410", motivo: "Revisión anual", concepto: "CONSULTAS", dx: "Z00.0" }
    ];

    document.addEventListener("DOMContentLoaded", function () {
        initIcdModal();
        initHistoricoIcdModal();
        initProcedenteSwitches();
        initAgregarNota();
        initRechazarTramite();
        initSiguienteDetalle();
        initAccionesReclamoReal();
        if (window.VM && typeof window.VM.refreshIcons === "function") {
            window.VM.refreshIcons();
        }
    });

    // ---- Modal ICD/CPT (botón de cabecera y badge por partida) ----
    function initIcdModal() {
        var modalEl = document.getElementById("modalIcd");
        if (!modalEl) return;

        var icdInput = modalEl.querySelector("#icdCodigo");
        var icdDesc = modalEl.querySelector("#icdDescripcion");
        var cptInput = modalEl.querySelector("#cptCodigo");
        var cptDesc = modalEl.querySelector("#cptDescripcion");

        document.querySelectorAll("[data-icd-open]").forEach(function (trigger) {
            trigger.addEventListener("click", function () {
                var prefill = trigger.getAttribute("data-icd-prefill") === "true";
                if (prefill) {
                    icdInput.value = "Z719";
                    icdDesc.value = "CONSULTA, NO ESPECIFICADA";
                    cptInput.value = "L7999FE";
                    cptDesc.value = "Alergenos a Medicamentos";
                } else {
                    [icdInput, icdDesc, cptInput, cptDesc].forEach(function (el) { el.value = ""; });
                }
                bootstrap.Modal.getOrCreateInstance(modalEl).show();
            });
        });

        var limpiarBtn = modalEl.querySelector("[data-icd-limpiar]");
        if (limpiarBtn) {
            limpiarBtn.addEventListener("click", function () {
                [icdInput, icdDesc, cptInput, cptDesc].forEach(function (el) { el.value = ""; });
            });
        }
    }

    // ---- Modal Histórico ICD ----
    function initHistoricoIcdModal() {
        var modalEl = document.getElementById("modalHistoricoIcd");
        if (!modalEl) return;
        var tbody = modalEl.querySelector("[data-historico-body]");

        var trigger = document.querySelector("[data-historico-icd-open]");
        if (trigger) {
            trigger.addEventListener("click", function () {
                tbody.innerHTML = HISTORICO_ICD_DEMO.map(function (r) {
                    return "<tr><td>" + r.folio + "</td><td>" + r.motivo + "</td><td>" + r.concepto + "</td><td>" + r.dx + "</td></tr>";
                }).join("");
                bootstrap.Modal.getOrCreateInstance(modalEl).show();
            });
        }
    }

    // ---- Switch "Procedente": habilita Observaciones solo cuando NO procede ----
    function initProcedenteSwitches() {
        document.querySelectorAll("[data-procedente-switch]").forEach(function (sw) {
            var obsId = sw.getAttribute("data-procedente-switch");
            var obs = document.getElementById(obsId);
            if (!obs) return;

            function sync() { obs.disabled = sw.checked; if (sw.checked) obs.value = ""; }
            sw.addEventListener("change", sync);
            sync();
        });
    }

    // ---- Aside Notas del trámite: alta de nota nueva (front-end únicamente, sin backend) ----
    // Inserta la nota al inicio del note-timeline ya existente y refleja el
    // conteo en notes-panel-badge. Reutiliza las clases .note-item/.note-icon/
    // .note-body/.note-text/.note-meta ya definidas para las notas estáticas.
    // El panel ya no es un modal: está siempre visible junto al contenido.
    function initAgregarNota() {
        var panelEl = document.getElementById("panelNotasDetalle");
        if (!panelEl) return;

        var input = panelEl.querySelector("#notaNuevoTexto");
        var btn = panelEl.querySelector("#btnAgregarNotaDetalle");
        var timeline = panelEl.querySelector("[data-note-timeline]");
        var badge = panelEl.querySelector(".notes-panel-badge");
        if (!input || !btn || !timeline) return;

        function agregarNota() {
            var texto = (input.value || "").trim();
            if (!texto) { input.focus(); return; }

            var li = document.createElement("li");
            li.className = "note-item";
            li.innerHTML =
                '<span class="note-icon"><i data-lucide="message-square" aria-hidden="true"></i></span>' +
                '<div class="note-body">' +
                '<p class="note-text"></p>' +
                '<span class="note-meta"></span>' +
                '<hr class="border border-secondary opacity-75">' +
                '</div>';
            li.querySelector(".note-text").textContent = texto;
            li.querySelector(".note-meta").textContent = "Dictamen administrativo · jmjimenez · " + fechaHoyCorta();
            timeline.insertBefore(li, timeline.firstChild);

            input.value = "";
            if (badge) badge.textContent = String((parseInt(badge.textContent, 10) || 0) + 1);
            if (window.VM && typeof window.VM.refreshIcons === "function") window.VM.refreshIcons();
        }

        btn.addEventListener("click", agregarNota);
        input.addEventListener("keydown", function (e) {
            if (e.key === "Enter") { e.preventDefault(); agregarNota(); }
        });
    }

    function fechaHoyCorta() {
        var d = new Date();
        return d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear();
    }

    // ---- Rechazar trámite: revela el campo "Motivo rechazo" en la propia
    // página (sin modal todavía) — el modal aparece hasta pulsar "Siguiente". ----
    function initRechazarTramite() {
        var btnRechazar = document.getElementById("btnRechazarTramite");
        var wrapper = document.getElementById("motivoRechazoWrapper");
        var input = document.getElementById("inputMotivoRechazo");
        var btnLimpiar = document.getElementById("btnLimpiarMotivoRechazo");
        if (!btnRechazar || !wrapper) return;

        btnRechazar.addEventListener("click", function () {
            wrapper.hidden = false;
            if (input) input.focus();
        });

        if (btnLimpiar && input) {
            btnLimpiar.addEventListener("click", function () {
                input.value = "";
                input.focus();
            });
        }
    }

    // ---- Siguiente: si "Rechazar trámite" ya se activó (campo visible),
    // continúa el flujo de rechazo (Documentos a solicitar); si no, continúa
    // el flujo normal de finalización (Conceptos que se pagarán). Ambos
    // modales redirigen al Tablero (Home/Index) al aceptar — sin backend. ----
    function initSiguienteDetalle() {
        var btn = document.getElementById("btnRegistrarDetalle");
        var wrapperRechazo = document.getElementById("motivoRechazoWrapper");
        var modalFinalizar = document.getElementById("modalFinalizarTramite");
        var modalDocumentos = document.getElementById("modalDocumentosSolicitar");
        if (!btn) return;

        // Con un Reclamo real (data-reclamo-id), initAccionesReclamoReal()
        // es la única responsable de "Registrar"/"Rechazar trámite" — este
        // flujo simulado con modales queda solo para el modo sin Id.
        var acciones = document.querySelector(".detalle-actions[data-reclamo-id]");
        if (acciones && acciones.getAttribute("data-reclamo-id")) return;

        btn.addEventListener("click", function () {
            var rechazoActivo = !!(wrapperRechazo && !wrapperRechazo.hidden);
            var modalEl = rechazoActivo ? modalDocumentos : modalFinalizar;
            if (modalEl) bootstrap.Modal.getOrCreateInstance(modalEl).show();
        });

        ["btnAceptarFinalizarTramite", "btnAceptarDocumentosSolicitar"].forEach(function (id) {
            var aceptarBtn = document.getElementById(id);
            if (!aceptarBtn) return;
            aceptarBtn.addEventListener("click", function () {
                window.location.href = aceptarBtn.getAttribute("data-href") || "/";
            });
        });
    }

    // ---- Aprobar/Rechazar reales (solo cuando la vista trae un Reclamo real) ----
    // Llama a los endpoints AJAX del propio Controller (HomeController.AprobarReclamo/
    // RechazarReclamo), que a su vez llaman a MprGestionReclamos vía
    // ReclamosApiClient — nunca fetch directo al Gateway desde el navegador
    // (ver UI_Architecture_Guide.md sección 4 y UI_Decision_Log.md DEC-008).
    function initAccionesReclamoReal() {
        var acciones = document.querySelector(".detalle-actions[data-reclamo-id]");
        var reclamoId = acciones ? acciones.getAttribute("data-reclamo-id") : "";
        if (!acciones || !reclamoId) return;

        var btnRegistrar = document.getElementById("btnRegistrarDetalle");
        var btnRechazar = document.getElementById("btnRechazarTramite");
        var wrapperRechazo = document.getElementById("motivoRechazoWrapper");
        var inputMotivo = document.getElementById("inputMotivoRechazo");
        var inputMonto = document.getElementById("inputMontoAprobado");
        var tokenInput = document.querySelector('input[name="__RequestVerificationToken"]');
        var token = tokenInput ? tokenInput.value : "";

        function mostrarError(mensaje) {
            window.alert(mensaje);
        }

        async function llamar(accion, body) {
            var respuesta = await fetch("/Home/" + accion, {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    "RequestVerificationToken": token
                },
                body: new URLSearchParams(body).toString()
            });
            return respuesta.json();
        }

        if (btnRegistrar) {
            btnRegistrar.addEventListener("click", async function () {
                // Si "Rechazar trámite" ya reveló el campo de motivo, "Registrar"
                // completa el rechazo en vez de la aprobación — mismo criterio
                // de flujo único que ya usaba el modo simulado.
                var rechazoActivo = !!(wrapperRechazo && !wrapperRechazo.hidden);

                if (rechazoActivo) {
                    var motivo = (inputMotivo && inputMotivo.value || "").trim();
                    if (!motivo) { mostrarError("Indica el motivo de rechazo."); if (inputMotivo) inputMotivo.focus(); return; }
                    var resultadoRechazo = await llamar("RechazarReclamo", { id: reclamoId, motivoRechazo: motivo });
                    if (resultadoRechazo.ok) { window.location.reload(); } else { mostrarError(resultadoRechazo.error || "No fue posible rechazar el trámite."); }
                    return;
                }

                var monto = inputMonto ? parseFloat(inputMonto.value) : NaN;
                if (!inputMonto || isNaN(monto) || monto < 0) {
                    mostrarError("Indica un monto aprobado válido antes de Registrar.");
                    if (inputMonto) inputMonto.focus();
                    return;
                }
                var resultadoAprobar = await llamar("AprobarReclamo", { id: reclamoId, montoAprobado: monto });
                if (resultadoAprobar.ok) { window.location.reload(); } else { mostrarError(resultadoAprobar.error || "No fue posible aprobar el trámite."); }
            });
        }
    }
})();
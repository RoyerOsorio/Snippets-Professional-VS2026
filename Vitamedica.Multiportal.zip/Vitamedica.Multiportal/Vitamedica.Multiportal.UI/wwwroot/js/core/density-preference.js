/* ============================================================================
   core/density-preference.js

   Responsabilidad: lectura, escritura y aplicación de la preferencia de
   densidad visual del usuario (cómoda/compacta), persistida entre sesiones.

   Depende de: core/storage.js
   Consumido por: site.js
   ============================================================================ */

import { get, set, STORAGE_KEYS } from './storage.js';

function applyDensityClass(value) {
    document.body.classList.toggle("density-compact", value === "compacta");
}

function syncToggleUI(densityToggle, value) {
    if (!densityToggle) return;
    densityToggle.querySelectorAll(".density-option").forEach((btn) => {
        const active = btn.getAttribute("data-density") === value;
        btn.classList.toggle("is-active", active);
        btn.setAttribute("aria-pressed", String(active));
    });
}

function applyDensitySelection(value, densityToggle) {
    applyDensityClass(value);
    set(STORAGE_KEYS.density, value);
    syncToggleUI(densityToggle, value);
}

export function initDensityPreference() {
    const current = get(STORAGE_KEYS.density) || "comoda";

    // Restaura la densidad persistida antes de cualquier pintado visible.
    applyDensityClass(current);

    const densityToggle = document.querySelector("[data-density-toggle]");
    if (!densityToggle) return;

    // Sincroniza el control visual (botones Cómoda/Compacta) con la
    // preferencia ya aplicada.
    syncToggleUI(densityToggle, current);

    densityToggle.addEventListener("click", (e) => {
        const btn = e.target.closest(".density-option");
        if (!btn) return;
        applyDensitySelection(btn.getAttribute("data-density"), densityToggle);
    });
}

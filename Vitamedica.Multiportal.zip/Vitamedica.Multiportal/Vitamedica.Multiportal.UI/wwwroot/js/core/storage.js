/* ============================================================================
   core/storage.js

   Responsabilidad: acceso seguro a localStorage (puede estar deshabilitado
   en algunos entornos) + helpers de serialización JSON. Utilidad transversal
   sin conocimiento de ningún componente ni módulo de negocio específico.

   Depende de: nada.
   Consumido por: core/density-preference.js, components/sidebar.js
   (extraído a core/ por repetirse en 2 módulos distintos — ver
   JavaScript_Architecture_Guide.md, criterio de promoción a core/).
   ============================================================================ */

export function get(key) {
    try {
        return window.localStorage.getItem(key);
    } catch {
        return null;
    }
}

export function set(key, value) {
    try {
        window.localStorage.setItem(key, value);
    } catch {
        /* no-op: localStorage puede estar deshabilitado */
    }
}

export function getJSON(key, fallback) {
    const raw = get(key);
    if (!raw) return fallback;
    try {
        return JSON.parse(raw);
    } catch {
        return fallback;
    }
}

export function setJSON(key, value) {
    set(key, JSON.stringify(value));
}

export const STORAGE_KEYS = {
    collapsed: "vm.sidebar.collapsed",
    openGroups: "vm.sidebar.openGroups",
    density: "vm.density"
};

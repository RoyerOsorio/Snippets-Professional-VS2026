using System.Diagnostics;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
//using Vitamedica.Multiportal.Application.Interfaces;
using Vitamedica.Multiportal.UI.Models;
using Vitamedica.Multiportal.UI.Models.ActiveDirectory;
using Vitamedica.Multiportal.UI.Models.ViewModels;
using Vitamedica.Multiportal.UI.Services;

namespace Vitamedica.Multiportal.UI.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly MultiportalApiClient _multiportalApiClient;
        private readonly ClientesApiClient _clientesApiClient;
        private readonly ReclamosApiClient _reclamosApiClient;
        private readonly AuditoriaApiClient _auditoriaApiClient;
        private readonly PagosApiClient _pagosApiClient;
        private readonly ReembolsosApiClient _reembolsosApiClient;
        private readonly ILogger<HomeController> _logger;

        public HomeController(
            MultiportalApiClient multiportalApiClient,
            ClientesApiClient clientesApiClient,
            ReclamosApiClient reclamosApiClient,
            AuditoriaApiClient auditoriaApiClient,
            PagosApiClient pagosApiClient,
            ReembolsosApiClient reembolsosApiClient,
            ILogger<HomeController> logger)
        {
            _multiportalApiClient = multiportalApiClient;
            _clientesApiClient = clientesApiClient;
            _reclamosApiClient = reclamosApiClient;
            _auditoriaApiClient = auditoriaApiClient;
            _pagosApiClient = pagosApiClient;
            _reembolsosApiClient = reembolsosApiClient;
            _logger = logger;
        }
        public async Task<IActionResult> Index()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.FindFirstValue(ClaimTypes.Name) ?? string.Empty;

                    var _user = await _multiportalApiClient.GetUserProfile(name);
                    if(_user != null)
                        return View(new UserProfile
                        {
                            ApellidoMaterno = _user.ApellidoMaterno,
                            ApellidoPaterno = _user.ApellidoPaterno,
                            Clave = _user.Clave,
                            CorreoElectronico = _user.CorreoElectronico,
                            GrgrCk = _user.GrgrCk,
                            MemeCk = _user.MemeCk,
                            Nombre = _user.Nombre,
                            NombreCompleto = _user.NombreCompleto,
                            NombreORazonSocial = _user.NombreORazonSocial,
                            NombreUsuario = _user.NombreUsuario,
                            NominaEmpleado = _user.NominaEmpleado,
                            PrprId = _user.PrprId,
                            RFC = _user.RFC,
                            TipoUsuario = _user.TipoUsuario,
                            TipoUsuarioDescripcion = _user.TipoUsuarioDescripcion
                        });

                    //var _user = _activeDirectoryApplication.GetUser(name);
                    //if (_user != null)
                    //    return View(new UserProfile
                    //    {
                    //        ApellidoMaterno = _user.ApellidoMaterno,
                    //        ApellidoPaterno = _user.ApellidoPaterno,
                    //        Clave = _user.Clave,
                    //        CorreoElectronico = _user.CorreoElectronico,
                    //        GrgrCk = _user.GrgrCk,
                    //        MemeCk = _user.MemeCk,
                    //        Nombre = _user.Nombre,
                    //        NombreCompleto = _user.NombreCompleto,
                    //        NombreORazonSocial = _user.NombreORazonSocial,
                    //        NombreUsuario = _user.NombreUsuario,
                    //        NominaEmpleado = _user.NominaEmpleado,
                    //        PrprId = _user.PrprId,
                    //        RFC = _user.RFC,
                    //        TipoUsuario = (ActiveDirectory.Model.ViewModels.TipoUsuario)_user.TipoUsuario,
                    //        TipoUsuarioDescripcion = _user.TipoUsuarioDescripcion
                    //    });
                }
                catch (Exception ex)
                {

                }
            }
            return View(new UserProfile());
        }

        public IActionResult ReembolsoSolicitud()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
            {
                try
                {
                    return View();
                }
                catch (Exception ex)
                {

                }
            }
            return View(new UserProfile());
        }

        // Búsqueda de contexto del Asegurado para la Sección 1 de
        // ReembolsoSolicitud (ver UI_Decision_Log.md DEC-009). Único endpoint
        // AJAX de esta vista conectado a datos reales: consulta MprClientes vía
        // ClientesApiClient (Browser → Controller → ApiClient → API, nunca
        // directo al Gateway — UI_Architecture_Guide.md sección 4).
        //
        // Alcance deliberadamente acotado: reemplaza únicamente la búsqueda por
        // "número de empleado" (dato que no existe en ningún microservicio
        // construido) por Poliza + AseguradoId, que sí son el identificador real
        // de MprClientes /contexto. Beneficiarios/derechohabientes, categorías
        // de reclamación, facturas y el envío final del formulario siguen
        // hardcodeados — dependen de capacidades de negocio que ningún
        // microservicio expone todavía; no se simulan aquí para no ocultar ese
        // pendiente.
        [HttpGet]
        public async Task<IActionResult> BuscarContextoAsegurado(string poliza, int aseguradoId)
        {
            try
            {
                var contexto = await _clientesApiClient.ObtenerContextoAsync(poliza, aseguradoId, HttpContext.RequestAborted);

                if (contexto is null)
                {
                    return Json(new { ok = false, error = "No se encontró ningún asegurado con esa póliza y número de asegurado." });
                }

                return Json(new
                {
                    ok = true,
                    aseguradoId = contexto.AseguradoId,
                    nombreCompleto = contexto.NombreCompleto,
                    poliza = contexto.Poliza,
                    certificado = contexto.Certificado,
                    rolAsegurado = contexto.RolAsegurado,
                    vigenciaInicio = contexto.VigenciaInicio.ToString("dd/MM/yyyy"),
                    vigenciaFin = contexto.VigenciaFin.ToString("dd/MM/yyyy"),
                    esVigente = contexto.EsVigente
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al consultar el contexto del Asegurado (Poliza={Poliza}, AseguradoId={AseguradoId}) vía MprClientes.", poliza, aseguradoId);
                return Json(new { ok = false, error = "No fue posible consultar el asegurado. Intenta de nuevo." });
            }
        }

        // MotivoId de piloto para el botón "Registrar" (ver UI_Decision_Log.md
        // DEC-013). MprConfiguracionReglas solo tiene UN MotivoReembolso real
        // sembrado hoy (Id=1, "Consulta médica ambulatoria") — mapear las 8
        // categorías hardcodeadas de la Sección 3 a Motivos reales requeriría
        // una decisión de negocio que no está definida en el contexto
        // disponible, así que no se inventa aquí. Este piloto usa siempre ese
        // único Motivo real, sin importar qué categoría eligió el usuario en
        // la Sección 3, únicamente para demostrar la cadena
        // UI → Gateway → Orchestrator → MprClientes/MprConfiguracionReglas/
        // MprGestionReclamos → BD funcionando de punta a punta. El mapeo
        // categoría↔Motivo real sigue PENDIENTE.
        private const int MotivoPilotoId = 1;

        // Registrar la solicitud de reembolso: primera llamada de la UI al
        // Reimbursement.Orchestrator (POST /v1/reembolsos/iniciar), en vez de
        // a un microservicio directamente — mismo patrón Browser → Controller
        // → ApiClient → API (UI_Architecture_Guide.md sección 4), el
        // navegador nunca llama directo al Gateway. Ver UI_Decision_Log.md
        // DEC-013 para el alcance completo (piloto con MotivoId fijo).
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> IniciarReembolso(string poliza, int aseguradoId)
        {
            try
            {
                var resultado = await _reembolsosApiClient.IniciarAsync(poliza, aseguradoId, MotivoPilotoId, HttpContext.RequestAborted);

                if (resultado is null)
                {
                    return Json(new { ok = false, error = $"No se encontró ningún asegurado con póliza {poliza} y número de asegurado {aseguradoId}." });
                }

                if (!resultado.ContextoClienteValido)
                {
                    return Json(new { ok = false, error = "La vigencia del contrato no es válida; no se puede registrar la solicitud." });
                }

                if (resultado.Reclamo is null)
                {
                    return Json(new { ok = false, error = "No fue posible crear el trámite (no se encontró la regla de reembolso)." });
                }

                return Json(new { ok = true, reclamoId = resultado.Reclamo.Id, estado = resultado.Reclamo.Estado });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al iniciar el reembolso (Poliza={Poliza}, AseguradoId={AseguradoId}) vía Reimbursement.Orchestrator.", poliza, aseguradoId);
                return Json(new { ok = false, error = "No fue posible registrar la solicitud. Intenta de nuevo más tarde." });
            }
        }

        // Detalle de un Reclamo. Primera integración real de esta pantalla
        // (ver UI_Decision_Log.md DEC-008): cuando se visita con un Id
        // (/Home/DetalleSolicitud/5), consulta el Reclamo real en
        // MprGestionReclamos y su historial real en MprAuditoria. Sin Id
        // (acceso actual, sin ningún flujo de navegación que pase uno todavía),
        // conserva exactamente el comportamiento hardcodeado previo — no se
        // rompe el único acceso existente a esta vista.
        //
        // Alcance deliberadamente acotado: solo folio/estado, historial y
        // Aprobar/Rechazar se conectan a datos reales. Facturas por concepto,
        // ICD/CPT, saldo por beneficiario y notas del trámite siguen
        // hardcodeados dentro de la vista — dependen de capacidades de negocio
        // que ningún microservicio construido expone todavía; no se simulan
        // aquí para no ocultar ese pendiente.
        public async Task<IActionResult> DetalleSolicitud(int? id)
        {
            if (User == null || User.Identity == null || !User.Identity.IsAuthenticated)
            {
                return View(new UserProfile());
            }

            if (id is null)
            {
                return View(new DetalleSolicitudViewModel { DatosReales = false });
            }

            var vm = new DetalleSolicitudViewModel { DatosReales = true, ReclamoId = id };

            try
            {
                var reclamo = await _reclamosApiClient.ObtenerAsync(id.Value, HttpContext.RequestAborted);
                if (reclamo is null)
                {
                    vm.ErrorCargaDatos = $"No se encontró ningún Reclamo con Id {id.Value}.";
                    return View(vm);
                }

                vm.Folio = $"R-{reclamo.Id:00000}";
                vm.EstadoReal = reclamo.Estado;
                vm.MontoAprobado = reclamo.MontoAprobado;
                vm.MotivoRechazo = reclamo.MotivoRechazo;
                vm.Estaciones = DetalleSolicitudViewModel.EstacionesParaEstado(reclamo.Estado);

                var timeline = await _auditoriaApiClient.ObtenerTimelineAsync(id.Value, HttpContext.RequestAborted);
                vm.Timeline = timeline
                    .OrderBy(e => e.FechaOcurrencia)
                    .Select(e => new EventoAuditoriaTimelineItemViewModel { TipoEvento = e.TipoEvento, FechaOcurrencia = e.FechaOcurrencia })
                    .ToList();
            }
            catch (Exception ex)
            {
                // MprGestionReclamos/MprAuditoria/Gateway no disponible: se
                // registra y se muestra la vista con un mensaje de error en
                // vez de propagar un 500 (mismo criterio que Clientes(),
                // UI_Architecture_Guide.md sección 6).
                _logger.LogError(ex, "Error al consultar el Reclamo {ReclamoId} vía MprGestionReclamos/MprAuditoria.", id.Value);
                vm.ErrorCargaDatos = "No fue posible consultar los datos del trámite en este momento. Intenta de nuevo más tarde.";
            }

            return View(vm);
        }

        // Aprobar el Reclamo (transición real vía MprGestionReclamos). Llamado
        // por AJAX desde detalle-solicitud.js — sigue el patrón Browser →
        // Controller → ApiClient → API (UI_Architecture_Guide.md sección 4):
        // el navegador nunca llama directo al Gateway ni al microservicio.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AprobarReclamo(int id, decimal montoAprobado)
        {
            try
            {
                var reclamo = await _reclamosApiClient.AprobarAsync(id, montoAprobado, HttpContext.RequestAborted);
                return Json(new { ok = true, estado = reclamo.Estado });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al aprobar el Reclamo {ReclamoId} vía MprGestionReclamos.", id);
                return Json(new { ok = false, error = "No fue posible aprobar el trámite. Verifica el monto e intenta de nuevo." });
            }
        }

        // Rechazar el Reclamo (transición real vía MprGestionReclamos). Mismo
        // patrón que AprobarReclamo.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RechazarReclamo(int id, string motivoRechazo)
        {
            try
            {
                var reclamo = await _reclamosApiClient.RechazarAsync(id, motivoRechazo, HttpContext.RequestAborted);
                return Json(new { ok = true, estado = reclamo.Estado });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al rechazar el Reclamo {ReclamoId} vía MprGestionReclamos.", id);
                return Json(new { ok = false, error = "No fue posible rechazar el trámite. Intenta de nuevo." });
            }
        }

        // Listado de Pagos. Primera integración real de esta pantalla (ver
        // UI_Decision_Log.md DEC-011): consulta GET /v1/pagos en MprPagos
        // (agregado en la misma decisión) para poblar Póliza y Monto.
        //
        // Alcance deliberadamente acotado: Titular, Motivo, Folio, Fecha de
        // descarga y Complemento siguen sin conectar — dependen de
        // capacidades de negocio (join a MprClientes, doble join
        // MprGestionReclamos→MprConfiguracionReglas, una convención de Folio,
        // conciliación bancaria) que ningún microservicio construido expone
        // todavía. No se simulan aquí para no ocultar ese pendiente — ver
        // PagoSolicitudViewModel.
        public async Task<IActionResult> PagoSolicitud()
        {
            if (User == null || User.Identity == null || !User.Identity.IsAuthenticated)
            {
                return View(new UserProfile());
            }

            var vm = new PagoSolicitudViewModel();

            try
            {
                var pagos = await _pagosApiClient.ListarAsync(HttpContext.RequestAborted);
                vm.Pagos = pagos
                    .Select(p => new PagoFilaViewModel { Id = p.Id, Poliza = p.Poliza, Monto = p.MontoAprobado })
                    .ToList();
            }
            catch (Exception ex)
            {
                // MprPagos/Gateway no disponible: se registra y se muestra la
                // vista con lista vacía en vez de propagar un error 500 —
                // mismo criterio que Clientes()/DetalleSolicitud
                // (UI_Architecture_Guide.md sección 6).
                _logger.LogError(ex, "Error al consultar el listado de Pagos vía MprPagos.");
                vm.ErrorCargaDatos = "No fue posible consultar los pagos en este momento. Intenta de nuevo más tarde.";
            }

            return View(vm);
        }

        // Listado de Clientes (Patrón UI-001 CRUD Maestro). Primera integración
        // real del ejercicio de microservicios: Browser → Controller →
        // ClientesApiClient → Multiportal.ApiGateway → MprClientes → SQL Server
        // (ver docs/demo/README.md del ejercicio). CreacionCliente/DetalleCliente
        // permanecen con datos simulados: dependen de catálogos de Módulos/
        // Coberturas/Documentos que pertenecen a MprConfiguracionReglas, todavía
        // no construido — no se simulan aquí para no ocultar ese pendiente.
        public async Task<IActionResult> Clientes()
        {
            try
            {
                var clientesApi = await _clientesApiClient.ListarAsync(HttpContext.RequestAborted);

                var clientes = clientesApi.Select(c => new ClienteViewModel
                {
                    Id = c.Id,
                    NombreORazonSocial = c.NombreORazonSocial,
                    Rfc = c.Rfc,
                    Telefono = c.Telefono,
                    NombreContacto = c.NombreContacto,
                    DescripcionCorta = c.DescripcionCorta,
                    Estatus = c.Estatus
                }).ToList();

                return View(clientes);
            }
            catch (Exception ex)
            {
                // MprClientes/Gateway no disponible: se registra y se muestra la
                // vista con lista vacía en vez de propagar un error 500 — la
                // vista ya debe distinguir estado de carga/vacío/error conforme
                // a UI_Architecture_Guide.md sección 6.
                _logger.LogError(ex, "Error al consultar el listado de Clientes vía MprClientes.");
                return View(new List<ClienteViewModel>());
            }
        }

        // Alta de Cliente — formulario compartido con DetalleCliente vía
        // Views/Shared/Partials/_ClienteForm.cshtml. Modelo vacío.
        public IActionResult CreacionCliente()
        {
            var cliente = new ClienteViewModel { ModulosSeleccionados = new List<int> { 1 } };
            CargarCatalogosModuloCoberturaDocumento(cliente);
            return View(cliente);
        }

        // Edición de Cliente — mismo formulario que CreacionCliente, precargado
        // con datos de ejemplo. Fase sin persistencia: no consulta ningún origen
        // de datos real, "id" solo identifica cuál registro demo mostrar.
        public IActionResult DetalleCliente(int id)
        {
            var cliente = new ClienteViewModel
            {
                Id = id,
                NombreORazonSocial = "Grupo Modelo",
                Rfc = "GMO850101AB1",
                Direccion = "Av. Revolución 1000, Guadalajara, Jalisco",
                Telefono = "3336012000",
                NombreContacto = "Laura Fuentes",
                TelefonoContacto = "3336012001",
                TelefonoInterior = "102",
                TelefonoAtencion = "018001234567",
                DescripcionCorta = "GRPMOD",
                FechaCorte = "25/07/2026",
                FechaDiaHabil = "05/08/2026",
                PrestadorServicio = "Bupa México",
                ImprimeCredencial = true,
                Estatus = "Activo",
                Filiales = new List<FilialViewModel>
                {
                    new FilialViewModel
                    {
                        Id = 1,
                        NombreORazonSocial = "Grupo Modelo — Planta Guadalajara",
                        Rfc = "GMO850101AB2",
                        Telefono = "3336012050",
                        NombreContacto = "Mario Solís",
                        DescripcionCorta = "GDL"
                    }
                },
                ModulosSeleccionados = new List<int> { 1, 3 },
                CoberturasSeleccionadas = new List<int> { 1, 4 },
                DocumentosSeleccionados = new List<int> { 1, 2, 8 }
            };

            CargarCatalogosModuloCoberturaDocumento(cliente);
            return View(cliente);
        }

        // ====================================================================
        // Simulación temporal de obtención de datos — Módulos / Coberturas /
        // Documentos requeridos. Sin base de datos ni servicio todavía: cuando
        // exista persistencia real, estos 3 métodos se sustituyen por llamadas
        // a un Service inyectado (ej. await _catalogoService.GetModulosAsync()),
        // sin que Razor ni JavaScript necesiten cambiar — ambos consumen las
        // propiedades ya resueltas del ViewModel, nunca este método.
        // ====================================================================
        private static void CargarCatalogosModuloCoberturaDocumento(ClienteViewModel vm)
        {
            vm.CatalogoModulos = ObtenerModulosSimulados();
            vm.CatalogoCoberturas = ObtenerCoberturasSimuladas();
            vm.CatalogoDocumentos = ObtenerDocumentosSimulados();
        }

        private static List<ModuloCatalogoItem> ObtenerModulosSimulados() => new()
        {
            new ModuloCatalogoItem { Id = 1, Nombre = "Carga de Documentos" },
            new ModuloCatalogoItem { Id = 2, Nombre = "Dictamen Administrativo" },
            new ModuloCatalogoItem { Id = 3, Nombre = "Dictamen Medico" },
            new ModuloCatalogoItem { Id = 4, Nombre = "Pagos" },
            new ModuloCatalogoItem { Id = 5, Nombre = "Cuentas Bancarias" }
        };

        private static List<CoberturaCatalogoItem> ObtenerCoberturasSimuladas() => new()
        {
            new CoberturaCatalogoItem { Id = 1, Nombre = "Consultas" },
            new CoberturaCatalogoItem { Id = 2, Nombre = "Medicamentos" },
            new CoberturaCatalogoItem { Id = 3, Nombre = "Vacunas" },
            new CoberturaCatalogoItem { Id = 4, Nombre = "Laboratorio y Gabinete" },
            new CoberturaCatalogoItem { Id = 5, Nombre = "Cuidados Preventivos" },
            new CoberturaCatalogoItem { Id = 6, Nombre = "Exámenes de Audición" },
            new CoberturaCatalogoItem { Id = 7, Nombre = "Lentes" },
            new CoberturaCatalogoItem { Id = 8, Nombre = "Gastos en el Extranjero" }
        };

        private static List<DocumentoCatalogoItem> ObtenerDocumentosSimulados() => new()
        {
            new DocumentoCatalogoItem { Id = 1, Nombre = "Receta Médica", CoberturaId = 1 },
            new DocumentoCatalogoItem { Id = 2, Nombre = "Orden Médica", CoberturaId = 1 },
            new DocumentoCatalogoItem { Id = 3, Nombre = "Factura XML / PDF", CoberturaId = 1 },
            new DocumentoCatalogoItem { Id = 4, Nombre = "Receta Médica", CoberturaId = 2 },
            new DocumentoCatalogoItem { Id = 5, Nombre = "Factura XML / PDF", CoberturaId = 2 },
            new DocumentoCatalogoItem { Id = 6, Nombre = "Receta Médica", CoberturaId = 3 },
            new DocumentoCatalogoItem { Id = 7, Nombre = "Orden Médica", CoberturaId = 3 },
            new DocumentoCatalogoItem { Id = 8, Nombre = "Factura XML / PDF", CoberturaId = 3 },
            new DocumentoCatalogoItem { Id = 9, Nombre = "Orden Médica", CoberturaId = 4 },
            new DocumentoCatalogoItem { Id = 10, Nombre = "Factura XML / PDF", CoberturaId = 4 },
            new DocumentoCatalogoItem { Id = 11, Nombre = "Orden Médica", CoberturaId = 5 },
            new DocumentoCatalogoItem { Id = 12, Nombre = "Factura XML / PDF", CoberturaId = 5 },
            new DocumentoCatalogoItem { Id = 13, Nombre = "Orden Médica", CoberturaId = 6 },
            new DocumentoCatalogoItem { Id = 14, Nombre = "Factura XML / PDF", CoberturaId = 6 },
            new DocumentoCatalogoItem { Id = 15, Nombre = "Receta Médica", CoberturaId = 7 },
            new DocumentoCatalogoItem { Id = 16, Nombre = "Factura XML / PDF", CoberturaId = 7 },
            new DocumentoCatalogoItem { Id = 17, Nombre = "Factura Hospital", CoberturaId = 8 },
            new DocumentoCatalogoItem { Id = 18, Nombre = "Factura XML / PDF", CoberturaId = 8 }
        };

        // Portal de autoservicio del Asegurado. Alcance de esta integración
        // (ver UI_Decision_Log.md DEC-012): con poliza+aseguradoId en query
        // string, conecta la Sección 1 ("Datos del asegurado titular") a
        // MprClientes vía GET /v1/clientes/contexto — mismo patrón que la
        // Sección 1 de ReembolsoSolicitud (DEC-009). Sin esos parámetros (el
        // único acceso existente hasta esta decisión — no hay todavía
        // ningún enlace de navegación que los pase), conserva exactamente
        // el comportamiento 100% hardcodeado previo.
        //
        // Alcance deliberadamente acotado: Grupo y "Miembro desde" no tienen
        // origen real todavía; Datos del Asegurado/Derechohabiente, Datos de
        // la reclamación, Notas del trámite, y los modales "Conoce tu
        // saldo"/"Mensajes" siguen hardcodeados — dependen de capacidades de
        // negocio que ningún microservicio construido expone todavía.
        public async Task<IActionResult> Asegurado(string? poliza, int? aseguradoId)
        {
            if (User == null || User.Identity == null || !User.Identity.IsAuthenticated)
            {
                return View(new UserProfile());
            }

            if (poliza is null || aseguradoId is null)
            {
                return View(new AseguradoViewModel { DatosReales = false });
            }

            var vm = new AseguradoViewModel { DatosReales = true };

            try
            {
                var contexto = await _clientesApiClient.ObtenerContextoAsync(poliza, aseguradoId.Value, HttpContext.RequestAborted);
                if (contexto is null)
                {
                    vm.ErrorCargaDatos = $"No se encontró ningún asegurado con póliza {poliza} y número de asegurado {aseguradoId}.";
                    return View(vm);
                }

                vm.Certificado = contexto.Certificado;
                vm.Titular = contexto.NombreCompleto;
                vm.Correo = contexto.Correo;
                vm.Telefono = contexto.Telefono;
                vm.VigenciaInicio = contexto.VigenciaInicio;
                vm.VigenciaFin = contexto.VigenciaFin;
                vm.Edad = CalcularEdad(contexto.FechaNacimiento);
            }
            catch (Exception ex)
            {
                // MprClientes/Gateway no disponible: se registra y se
                // muestra la vista con un mensaje de error en vez de
                // propagar un 500 (mismo criterio que Clientes()/
                // DetalleSolicitud, UI_Architecture_Guide.md sección 6).
                _logger.LogError(ex, "Error al consultar el contexto del Asegurado (Poliza={Poliza}, AseguradoId={AseguradoId}) vía MprClientes.", poliza, aseguradoId);
                vm.ErrorCargaDatos = "No fue posible consultar los datos del asegurado en este momento. Intenta de nuevo más tarde.";
            }

            return View(vm);
        }

        // Cálculo de edad a partir de la fecha de nacimiento — es
        // presentación (redondeo de años cumplidos), no una regla de
        // negocio de MprClientes, por eso vive aquí y no en el backend.
        private static int CalcularEdad(DateTime fechaNacimiento)
        {
            var hoy = DateTime.Today;
            var edad = hoy.Year - fechaNacimiento.Year;
            if (fechaNacimiento.Date > hoy.AddYears(-edad))
            {
                edad--;
            }
            return edad;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

using System.Diagnostics;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
//using Vitamedica.Multiportal.Application.Interfaces;
using Vitamedica.Multiportal.UI.Models;
using Vitamedica.Multiportal.UI.Models.ActiveDirectory;
using Vitamedica.Multiportal.UI.Models.ViewModels;
using Vitamedica.Multiportal.UI.Services;

namespace Vitamedica.Multiportal.UI.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly MultiportalApiClient _multiportalApiClient;
        public HomeController(MultiportalApiClient multiportalApiClient)
        {
            _multiportalApiClient = multiportalApiClient;
        }
        public async Task<IActionResult> Index()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.FindFirstValue(ClaimTypes.Name) ?? string.Empty;

                    var _user = await _multiportalApiClient.GetUserProfile(name);
                    if(_user != null)
                        return View(new UserProfile
                        {
                            ApellidoMaterno = _user.ApellidoMaterno,
                            ApellidoPaterno = _user.ApellidoPaterno,
                            Clave = _user.Clave,
                            CorreoElectronico = _user.CorreoElectronico,
                            GrgrCk = _user.GrgrCk,
                            MemeCk = _user.MemeCk,
                            Nombre = _user.Nombre,
                            NombreCompleto = _user.NombreCompleto,
                            NombreORazonSocial = _user.NombreORazonSocial,
                            NombreUsuario = _user.NombreUsuario,
                            NominaEmpleado = _user.NominaEmpleado,
                            PrprId = _user.PrprId,
                            RFC = _user.RFC,
                            TipoUsuario = _user.TipoUsuario,
                            TipoUsuarioDescripcion = _user.TipoUsuarioDescripcion
                        });

                    //var _user = _activeDirectoryApplication.GetUser(name);
                    //if (_user != null)
                    //    return View(new UserProfile
                    //    {
                    //        ApellidoMaterno = _user.ApellidoMaterno,
                    //        ApellidoPaterno = _user.ApellidoPaterno,
                    //        Clave = _user.Clave,
                    //        CorreoElectronico = _user.CorreoElectronico,
                    //        GrgrCk = _user.GrgrCk,
                    //        MemeCk = _user.MemeCk,
                    //        Nombre = _user.Nombre,
                    //        NombreCompleto = _user.NombreCompleto,
                    //        NombreORazonSocial = _user.NombreORazonSocial,
                    //        NombreUsuario = _user.NombreUsuario,
                    //        NominaEmpleado = _user.NominaEmpleado,
                    //        PrprId = _user.PrprId,
                    //        RFC = _user.RFC,
                    //        TipoUsuario = (ActiveDirectory.Model.ViewModels.TipoUsuario)_user.TipoUsuario,
                    //        TipoUsuarioDescripcion = _user.TipoUsuarioDescripcion
                    //    });
                }
                catch (Exception ex)
                {

                }
            }
            return View(new UserProfile());
        }

        public IActionResult ReembolsoSolicitud()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
            {
                try
                {
                    return View();
                }
                catch (Exception ex)
                {

                }
            }
            return View(new UserProfile());
        }

        public IActionResult DetalleSolicitud()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
            {
                try
                {
                    return View();
                }
                catch (Exception ex)
                {

                }
            }
            return View(new UserProfile());
        }

        public IActionResult PagoSolicitud()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
            {
                try
                {
                    return View();
                }
                catch (Exception ex)
                {

                }
            }
            return View(new UserProfile());
        }

        // Listado de Clientes (Patrón UI-001 CRUD Maestro). Fase sin persistencia:
        // datos hardcodeados, sin servicio ni repositorio.
        public IActionResult Clientes()
        {
            var clientes = new List<ClienteViewModel>
            {
                new ClienteViewModel
                {
                    Id = 1,
                    NombreORazonSocial = "Grupo Modelo",
                    Rfc = "GMO850101AB1",
                    Telefono = "3336012000",
                    NombreContacto = "Laura Fuentes",
                    DescripcionCorta = "GRPMOD",
                    Estatus = "Activo"
                },
                new ClienteViewModel
                {
                    Id = 2,
                    NombreORazonSocial = "Smurfit",
                    Rfc = "SKP970615C22",
                    Telefono = "5555230000",
                    NombreContacto = "Roberto Díaz",
                    DescripcionCorta = "SMURFIT",
                    Estatus = "Activo"
                },
                new ClienteViewModel
                {
                    Id = 3,
                    NombreORazonSocial = "Cliente Demo Inactivo",
                    Rfc = "CDI010101X11",
                    Telefono = "5511112222",
                    NombreContacto = "Ana Torres",
                    DescripcionCorta = "DEMOINA",
                    Estatus = "Inactivo"
                }
            };

            return View(clientes);
        }

        // Alta de Cliente — formulario compartido con DetalleCliente vía
        // Views/Shared/Partials/_ClienteForm.cshtml. Modelo vacío.
        public IActionResult CreacionCliente()
        {
            var cliente = new ClienteViewModel { ModulosSeleccionados = new List<int> { 1 } };
            CargarCatalogosModuloCoberturaDocumento(cliente);
            return View(cliente);
        }

        // Edición de Cliente — mismo formulario que CreacionCliente, precargado
        // con datos de ejemplo. Fase sin persistencia: no consulta ningún origen
        // de datos real, "id" solo identifica cuál registro demo mostrar.
        public IActionResult DetalleCliente(int id)
        {
            var cliente = new ClienteViewModel
            {
                Id = id,
                NombreORazonSocial = "Grupo Modelo",
                Rfc = "GMO850101AB1",
                Direccion = "Av. Revolución 1000, Guadalajara, Jalisco",
                Telefono = "3336012000",
                NombreContacto = "Laura Fuentes",
                TelefonoContacto = "3336012001",
                TelefonoInterior = "102",
                TelefonoAtencion = "018001234567",
                DescripcionCorta = "GRPMOD",
                FechaCorte = "25/07/2026",
                FechaDiaHabil = "05/08/2026",
                PrestadorServicio = "Bupa México",
                ImprimeCredencial = true,
                Estatus = "Activo",
                Filiales = new List<FilialViewModel>
                {
                    new FilialViewModel
                    {
                        Id = 1,
                        NombreORazonSocial = "Grupo Modelo — Planta Guadalajara",
                        Rfc = "GMO850101AB2",
                        Telefono = "3336012050",
                        NombreContacto = "Mario Solís",
                        DescripcionCorta = "GDL"
                    }
                },
                ModulosSeleccionados = new List<int> { 1, 3 },
                CoberturasSeleccionadas = new List<int> { 1, 4 },
                DocumentosSeleccionados = new List<int> { 1, 2, 8 }
            };

            CargarCatalogosModuloCoberturaDocumento(cliente);
            return View(cliente);
        }

        // ====================================================================
        // Simulación temporal de obtención de datos — Módulos / Coberturas /
        // Documentos requeridos. Sin base de datos ni servicio todavía: cuando
        // exista persistencia real, estos 3 métodos se sustituyen por llamadas
        // a un Service inyectado (ej. await _catalogoService.GetModulosAsync()),
        // sin que Razor ni JavaScript necesiten cambiar — ambos consumen las
        // propiedades ya resueltas del ViewModel, nunca este método.
        // ====================================================================
        private static void CargarCatalogosModuloCoberturaDocumento(ClienteViewModel vm)
        {
            vm.CatalogoModulos = ObtenerModulosSimulados();
            vm.CatalogoCoberturas = ObtenerCoberturasSimuladas();
            vm.CatalogoDocumentos = ObtenerDocumentosSimulados();
        }

        private static List<ModuloCatalogoItem> ObtenerModulosSimulados() => new()
        {
            new ModuloCatalogoItem { Id = 1, Nombre = "Carga de Documentos" },
            new ModuloCatalogoItem { Id = 2, Nombre = "Dictamen Administrativo" },
            new ModuloCatalogoItem { Id = 3, Nombre = "Dictamen Medico" },
            new ModuloCatalogoItem { Id = 4, Nombre = "Pagos" },
            new ModuloCatalogoItem { Id = 5, Nombre = "Cuentas Bancarias" }
        };

        private static List<CoberturaCatalogoItem> ObtenerCoberturasSimuladas() => new()
        {
            new CoberturaCatalogoItem { Id = 1, Nombre = "Consultas" },
            new CoberturaCatalogoItem { Id = 2, Nombre = "Medicamentos" },
            new CoberturaCatalogoItem { Id = 3, Nombre = "Vacunas" },
            new CoberturaCatalogoItem { Id = 4, Nombre = "Laboratorio y Gabinete" },
            new CoberturaCatalogoItem { Id = 5, Nombre = "Cuidados Preventivos" },
            new CoberturaCatalogoItem { Id = 6, Nombre = "Exámenes de Audición" },
            new CoberturaCatalogoItem { Id = 7, Nombre = "Lentes" },
            new CoberturaCatalogoItem { Id = 8, Nombre = "Gastos en el Extranjero" }
        };

        private static List<DocumentoCatalogoItem> ObtenerDocumentosSimulados() => new()
        {
            new DocumentoCatalogoItem { Id = 1, Nombre = "Receta Médica", CoberturaId = 1 },
            new DocumentoCatalogoItem { Id = 2, Nombre = "Orden Médica", CoberturaId = 1 },
            new DocumentoCatalogoItem { Id = 3, Nombre = "Factura XML / PDF", CoberturaId = 1 },
            new DocumentoCatalogoItem { Id = 4, Nombre = "Receta Médica", CoberturaId = 2 },
            new DocumentoCatalogoItem { Id = 5, Nombre = "Factura XML / PDF", CoberturaId = 2 },
            new DocumentoCatalogoItem { Id = 6, Nombre = "Receta Médica", CoberturaId = 3 },
            new DocumentoCatalogoItem { Id = 7, Nombre = "Orden Médica", CoberturaId = 3 },
            new DocumentoCatalogoItem { Id = 8, Nombre = "Factura XML / PDF", CoberturaId = 3 },
            new DocumentoCatalogoItem { Id = 9, Nombre = "Orden Médica", CoberturaId = 4 },
            new DocumentoCatalogoItem { Id = 10, Nombre = "Factura XML / PDF", CoberturaId = 4 },
            new DocumentoCatalogoItem { Id = 11, Nombre = "Orden Médica", CoberturaId = 5 },
            new DocumentoCatalogoItem { Id = 12, Nombre = "Factura XML / PDF", CoberturaId = 5 },
            new DocumentoCatalogoItem { Id = 13, Nombre = "Orden Médica", CoberturaId = 6 },
            new DocumentoCatalogoItem { Id = 14, Nombre = "Factura XML / PDF", CoberturaId = 6 },
            new DocumentoCatalogoItem { Id = 15, Nombre = "Receta Médica", CoberturaId = 7 },
            new DocumentoCatalogoItem { Id = 16, Nombre = "Factura XML / PDF", CoberturaId = 7 },
            new DocumentoCatalogoItem { Id = 17, Nombre = "Factura Hospital", CoberturaId = 8 },
            new DocumentoCatalogoItem { Id = 18, Nombre = "Factura XML / PDF", CoberturaId = 8 }
        };

        public IActionResult Asegurado()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
            {
                try
                {
                    return View();
                }
                catch (Exception ex)
                {

                }
            }
            return View(new UserProfile());
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

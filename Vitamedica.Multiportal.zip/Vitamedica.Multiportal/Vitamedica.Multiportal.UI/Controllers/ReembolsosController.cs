﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Vitamedica.Multiportal.UI.Models.ActiveDirectory;
using Vitamedica.Multiportal.UI.Services;

namespace Vitamedica.Multiportal.UI.Controllers
{
    [Authorize]
    public class ReembolsosController : Controller
    {
        
        public IActionResult Index()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
            {
                try
                {
                    return View();
                }
                catch (Exception ex)
                {

                }
            }
            return View(new UserProfile());
        }

        public IActionResult Crear()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
            {
                try
                {
                    return View();
                }
                catch (Exception ex)
                {

                }
            }
            return View(new UserProfile());
        }

        public IActionResult Detalle()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
            {
                try
                {
                    return View();
                }
                catch (Exception ex)
                {

                }
            }
            return View(new UserProfile());
        }

    }
}

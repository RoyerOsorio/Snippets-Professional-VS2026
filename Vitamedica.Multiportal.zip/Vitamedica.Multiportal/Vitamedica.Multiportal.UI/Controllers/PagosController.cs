﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Vitamedica.Multiportal.UI.Controllers
{
    [Authorize]
    public class PagosController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}

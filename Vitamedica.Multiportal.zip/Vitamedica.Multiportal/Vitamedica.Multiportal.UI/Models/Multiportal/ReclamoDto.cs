namespace Vitamedica.Multiportal.UI.Models.Multiportal;

/// <summary>
/// DTO de la integración real con MprGestionReclamos (vía Multiportal.ApiGateway,
/// ruta /api/reclamos). Forma cruda de GET /v1/reclamos/{id} — nunca se pasa
/// directamente a la vista, el Controller la traduce a DetalleSolicitudViewModel
/// (ver UI_Architecture_Guide.md sección 2, "Models y ViewModels"). Estado llega
/// como string porque MprGestionReclamos.Contracts.Responses.ReclamoResponse
/// expone el estado del Domain como texto, no como el enum interno del
/// microservicio (frontera pública desacoplada del Domain — ver DEC-003).
/// </summary>
public class ReclamoDto
{
    public int Id { get; set; }
    public string Poliza { get; set; } = string.Empty;
    public int AseguradoId { get; set; }
    public int MotivoId { get; set; }
    public string Estado { get; set; } = string.Empty;
    public DateTime FechaCreacion { get; set; }
    public DateTime? FechaEnvio { get; set; }
    public DateTime? FechaResolucion { get; set; }
    public decimal? MontoAprobado { get; set; }
    public string? MotivoRechazo { get; set; }
}

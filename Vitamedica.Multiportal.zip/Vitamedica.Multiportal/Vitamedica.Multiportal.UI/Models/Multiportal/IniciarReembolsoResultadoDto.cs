namespace Vitamedica.Multiportal.UI.Models.Multiportal;

/// <summary>
/// Espejo de Reimbursement.Orchestrator.Contratos.IniciarReembolsoResponse
/// (POST /v1/reembolsos/iniciar, vía Gateway /api/reembolsos/iniciar). Ver
/// Vitamedica.Multiportal.UI.Services.ReembolsosApiClient.IniciarAsync y
/// UI_Decision_Log.md DEC-013.
///
/// Solo se mapean los campos que el Controller necesita para decidir el
/// resultado de la llamada (Reclamo creado o no) — Regla y
/// SiguientesPasosPendientes del contrato original no se exponen aquí
/// porque ninguna pantalla los consume todavía.
/// </summary>
public class IniciarReembolsoResultadoDto
{
    public bool ContextoClienteValido { get; set; }
    public string NombreCompleto { get; set; } = string.Empty;
    public string Poliza { get; set; } = string.Empty;
    public string Certificado { get; set; } = string.Empty;
    public DateTime VigenciaInicio { get; set; }
    public DateTime VigenciaFin { get; set; }
    public ReclamoCreadoResumenDto? Reclamo { get; set; }
}

/// <summary>
/// Forma mínima del Reclamo recién creado por el Orchestrator (Id + Estado
/// crudos) — distinta de ReclamoDto (DEC-008), que es la forma completa que
/// devuelve MprGestionReclamos directamente vía GET /v1/reclamos/{id}.
/// </summary>
public class ReclamoCreadoResumenDto
{
    public int Id { get; set; }
    public string Estado { get; set; } = string.Empty;
}

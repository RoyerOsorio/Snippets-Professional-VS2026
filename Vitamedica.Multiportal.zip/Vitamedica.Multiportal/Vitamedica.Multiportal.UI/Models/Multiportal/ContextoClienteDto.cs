namespace Vitamedica.Multiportal.UI.Models.Multiportal;

/// <summary>
/// Espejo de MprClientes.Contracts.Responses.ContextoClienteResponse
/// (GET /v1/clientes/contexto, vía Gateway /api/clientes/contexto).
/// Ver Vitamedica.Multiportal.UI.Services.ClientesApiClient.ObtenerContextoAsync,
/// UI_Decision_Log.md DEC-009 y DEC-012 (Correo/Telefono/FechaNacimiento,
/// agregados para Views/Home/Asegurado).
/// </summary>
public class ContextoClienteDto
{
    public int AseguradoId { get; set; }
    public string NombreCompleto { get; set; } = string.Empty;
    public string Poliza { get; set; } = string.Empty;
    public string Certificado { get; set; } = string.Empty;
    public string RolAsegurado { get; set; } = string.Empty;
    public DateTime VigenciaInicio { get; set; }
    public DateTime VigenciaFin { get; set; }
    public bool EsVigente { get; set; }
    public string? Correo { get; set; }
    public string? Telefono { get; set; }
    public DateTime FechaNacimiento { get; set; }
}

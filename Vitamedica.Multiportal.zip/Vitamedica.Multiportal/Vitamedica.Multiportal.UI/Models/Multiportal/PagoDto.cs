namespace Vitamedica.Multiportal.UI.Models.Multiportal;

/// <summary>
/// DTO de la integración real con MprPagos (vía Multiportal.ApiGateway, ruta
/// /api/pagos). Forma cruda de GET /v1/pagos — nunca se pasa directamente a
/// la vista, el Controller la traduce a PagoSolicitudViewModel (ver
/// UI_Architecture_Guide.md sección 2, "Models y ViewModels"). Estado llega
/// como string porque MprPagos.Contracts.Responses.PagoResponse expone el
/// estado del Domain como texto, no como el enum interno del microservicio
/// (frontera pública desacoplada del Domain — mismo criterio que ReclamoDto,
/// ver DEC-003/DEC-008).
/// </summary>
public class PagoDto
{
    public int Id { get; set; }
    public int ReclamoId { get; set; }
    public string Poliza { get; set; } = string.Empty;
    public int AseguradoId { get; set; }
    public decimal MontoAprobado { get; set; }
    public string Estado { get; set; } = string.Empty;
    public DateTime FechaCreacion { get; set; }
    public DateTime? FechaConfirmacion { get; set; }
}

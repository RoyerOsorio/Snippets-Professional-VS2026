namespace Vitamedica.Multiportal.UI.Models.Multiportal;

/// <summary>
/// DTO de la integración real con MprClientes (vía Multiportal.ApiGateway).
/// Sigue el mismo patrón que GroupDto/UserResumeDto: forma cruda de la
/// respuesta HTTP, nunca se pasa directamente a una vista — el Controller la
/// traduce a ClienteViewModel (ver UI_Architecture_Guide.md sección 2,
/// "Models y ViewModels").
/// </summary>
public class ClienteDto
{
    public int Id { get; set; }
    public string? NombreORazonSocial { get; set; }
    public string? Rfc { get; set; }
    public string? Telefono { get; set; }
    public string? NombreContacto { get; set; }
    public string? DescripcionCorta { get; set; }
    public string Estatus { get; set; } = string.Empty;
}

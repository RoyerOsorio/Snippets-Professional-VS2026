namespace Vitamedica.Multiportal.UI.Models.Multiportal;

/// <summary>
/// DTO de la integración real con MprAuditoria (vía Multiportal.ApiGateway,
/// ruta /api/auditoria). Forma cruda de un elemento de
/// GET /v1/auditoria/reclamos/{reclamoId} — nunca se pasa directamente a la
/// vista, el Controller la traduce a un ítem de la propiedad Timeline de
/// DetalleSolicitudViewModel. PayloadJson se conserva como texto crudo: su
/// forma depende de qué microservicio publicó el evento (ReclamoAprobadoParaPago
/// o PagoCompletado) y MprAuditoria no lo tipa — la UI tampoco lo interpreta,
/// solo lo conserva disponible por si en el futuro hace falta mostrarlo.
/// </summary>
public class EventoAuditoriaDto
{
    public long Id { get; set; }
    public string TipoEvento { get; set; } = string.Empty;
    public int ReclamoId { get; set; }
    public string PayloadJson { get; set; } = string.Empty;
    public DateTime FechaOcurrencia { get; set; }
    public DateTime FechaRegistro { get; set; }
}

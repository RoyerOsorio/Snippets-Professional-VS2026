namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// ViewModel de Views/Home/DetalleSolicitud.cshtml.
///
/// Alcance de esta primera integración real (ver UI_Decision_Log.md DEC-008):
/// SOLO folio/estado del Reclamo (MprGestionReclamos), el historial de eventos
/// (MprAuditoria) y las acciones Aprobar/Rechazar. El resto de la pantalla
/// (facturas por concepto, ICD/CPT, saldo por beneficiario, notas del trámite)
/// sigue siendo hardcodeado dentro de la propia vista — depende de capacidades
/// de negocio (partidas, montos por concepto, coberturas) que no existen en
/// ningún microservicio construido, y no se simulan aquí para no ocultar ese
/// pendiente (ver UI_Architecture_Guide.md sección "qué no se debe simular").
///
/// DatosReales=false reproduce exactamente el comportamiento previo a esta
/// integración (folio y estaciones hardcodeados) — se activa cuando la vista
/// se visita sin un Id de Reclamo, para no romper el único acceso existente a
/// esta pantalla mientras no hay todavía ningún flujo de navegación real que
/// pase un Id (ver Roadmap, docs/demo/README.md).
/// </summary>
public class DetalleSolicitudViewModel
{
    public bool DatosReales { get; set; }

    public int? ReclamoId { get; set; }

    /// <summary>Folio a mostrar en el encabezado. En modo real: "R-{Id:00000}". En modo demo: el folio hardcodeado original.</summary>
    public string Folio { get; set; } = string.Empty;

    /// <summary>Estado crudo del Reclamo tal como lo devuelve MprGestionReclamos (Creado/EnviadoParaRevision/Aprobado/Rechazado). Null en modo demo.</summary>
    public string? EstadoReal { get; set; }

    public decimal? MontoAprobado { get; set; }

    public string? MotivoRechazo { get; set; }

    /// <summary>Historial de eventos de MprAuditoria para este Reclamo, ya ordenado por fecha de ocurrencia. Vacío en modo demo.</summary>
    public List<EventoAuditoriaTimelineItemViewModel> Timeline { get; set; } = new();

    /// <summary>Mensaje a mostrar si la consulta a MprGestionReclamos/MprAuditoria falló (Gateway/microservicio no disponible, o Reclamo no encontrado). Null si no hubo error.</summary>
    public string? ErrorCargaDatos { get; set; }

    /// <summary>
    /// Etapas visuales del stage-timeline ya existente en la vista (Recepción de
    /// documentos → Dictamen administrativo → Autorización de pago → Pago
    /// autorizado). Es una traducción de UI del Estado real del Reclamo, no un
    /// concepto que exista como tal en MprGestionReclamos — se documenta aquí,
    /// explícitamente, en vez de dejarla implícita en la vista.
    /// </summary>
    public List<EstacionTramiteViewModel> Estaciones { get; set; } = new();

    public static List<EstacionTramiteViewModel> EstacionesParaEstado(string? estado)
    {
        // Mapeo Estado (MprGestionReclamos) -> índice de etapa visual.
        // EnviadoParaRevision es el único estado real intermedio; se traduce a
        // "Dictamen administrativo" porque es la etapa en la que esta misma
        // pantalla existe para actuar (Aprobar/Rechazar).
        var indiceActual = estado switch
        {
            "Creado" => 0,
            "EnviadoParaRevision" => 1,
            "Aprobado" => 3,
            "Rechazado" => 1,
            _ => 0
        };

        var nombres = new[] { "Recepción de documentos", "Dictamen administrativo", "Autorización de pago", "Pago autorizado" };
        var resultado = new List<EstacionTramiteViewModel>();
        for (int i = 0; i < nombres.Length; i++)
        {
            resultado.Add(new EstacionTramiteViewModel
            {
                Nombre = nombres[i],
                // "Rechazado" no tiene una etapa visual propia en el
                // stage-timeline existente (solo hecho/actual/pendiente) — se
                // señaliza con el badge de Estado real, no con una clase CSS
                // nueva sin justificación (ver sección "Estado del trámite" en
                // la vista).
                Estado = i < indiceActual ? "hecho" : i == indiceActual ? "actual" : "pendiente"
            });
        }
        return resultado;
    }
}

public class EstacionTramiteViewModel
{
    public string Nombre { get; set; } = string.Empty;
    public string Estado { get; set; } = string.Empty; // "hecho" | "actual" | "pendiente" | "rechazado"
}

public class EventoAuditoriaTimelineItemViewModel
{
    public string TipoEvento { get; set; } = string.Empty;
    public DateTime FechaOcurrencia { get; set; }
}

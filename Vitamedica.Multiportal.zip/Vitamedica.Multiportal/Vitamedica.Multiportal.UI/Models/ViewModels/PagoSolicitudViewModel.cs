namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// ViewModel de Views/Home/PagoSolicitud.
///
/// Alcance de esta integración (ver UI_Decision_Log.md DEC-011): conecta
/// ÚNICAMENTE Póliza y Monto a datos reales de MprPagos (GET /v1/pagos vía
/// Multiportal.ApiGateway). El Gap Analysis de DEC-011 identificó que
/// Titular (requiere join a MprClientes por AseguradoId), Motivo (requiere
/// un doble join MprGestionReclamos→MprConfiguracionReglas), Folio (no
/// existe como concepto en Pago — requeriría inventar una convención de
/// presentación) y Complemento/conciliación bancaria (no existe en ningún
/// microservicio del ejercicio) no tienen todavía un origen de datos real.
/// Esos campos NO se simulan aquí — se muestran explícitamente como "No
/// disponible" en la vista, mismo criterio de honestidad de datos que
/// "Miembro desde" en ReembolsoSolicitud (ver DEC-009).
/// </summary>
public class PagoSolicitudViewModel
{
    /// <summary>
    /// Mensaje de error a mostrar cuando MprPagos/Gateway no responde. La
    /// vista se muestra igual (sin 500), con la lista de Pagos vacía —
    /// mismo criterio que Clientes()/DetalleSolicitud (ver
    /// UI_Architecture_Guide.md sección 6).
    /// </summary>
    public string? ErrorCargaDatos { get; set; }

    public List<PagoFilaViewModel> Pagos { get; set; } = new();
}

/// <summary>
/// Una fila real de la tabla de Pagos. Solo Id (clave interna, no se
/// muestra), Poliza y Monto provienen de MprPagos — ver alcance en
/// PagoSolicitudViewModel.
/// </summary>
public class PagoFilaViewModel
{
    public int Id { get; set; }
    public string Poliza { get; set; } = string.Empty;
    public decimal Monto { get; set; }
}

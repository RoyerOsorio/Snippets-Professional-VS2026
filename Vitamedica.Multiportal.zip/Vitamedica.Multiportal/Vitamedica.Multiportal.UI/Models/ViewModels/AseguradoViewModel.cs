namespace Vitamedica.Multiportal.UI.Models.ViewModels;

/// <summary>
/// ViewModel de Views/Home/Asegurado — portal de autoservicio del Asegurado.
///
/// Alcance de esta integración (ver UI_Decision_Log.md DEC-012): con
/// Poliza+AseguradoId en query string, conecta ÚNICAMENTE la Sección 1
/// ("Datos del asegurado titular") a MprClientes (GET /v1/clientes/contexto)
/// — mismo patrón que la Sección 1 de ReembolsoSolicitud (DEC-009). Sin esos
/// parámetros, la vista conserva el comportamiento 100% hardcodeado previo
/// (DatosReales = false).
///
/// Grupo y "Miembro desde" no tienen todavía un origen de datos real — se
/// muestran explícitamente como "No disponible" en vez de simular un valor,
/// mismo criterio de honestidad de datos que "Miembro desde" en DEC-009.
/// "Datos del Asegurado/Derechohabiente", "Datos de la reclamación", "Notas
/// del trámite" y los modales "Conoce tu saldo"/"Mensajes" siguen
/// hardcodeados en la vista, sin cambio — dependen de capacidades de
/// negocio que ningún microservicio construido expone todavía.
/// </summary>
public class AseguradoViewModel
{
    public bool DatosReales { get; set; }

    /// <summary>
    /// Mensaje de error a mostrar cuando MprClientes/Gateway no responde, o
    /// cuando no se encontró un Asegurado con la Poliza+AseguradoId dados.
    /// La vista se muestra igual (sin 500) — mismo criterio que
    /// Clientes()/DetalleSolicitud (UI_Architecture_Guide.md sección 6).
    /// </summary>
    public string? ErrorCargaDatos { get; set; }

    // Solo poblados cuando DatosReales = true y no hubo error.
    public string? Certificado { get; set; }
    public string? Titular { get; set; }
    public string? Correo { get; set; }
    public string? Telefono { get; set; }
    public DateTime? VigenciaInicio { get; set; }
    public DateTime? VigenciaFin { get; set; }
    public int? Edad { get; set; }
}

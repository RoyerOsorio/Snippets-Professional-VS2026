using Vitamedica.Multiportal.UI.Models.Multiportal;

namespace Vitamedica.Multiportal.UI.Services;

/// <summary>
/// ApiClient tipado para el microservicio MprPagos, consumido a través de
/// Multiportal.ApiGateway (nunca directo al microservicio desde la UI — ver
/// UI_Architecture_Guide.md sección 4). Mismo patrón ya usado por
/// ReclamosApiClient/ClientesApiClient: responsabilidad única de traducir
/// una llamada C# a una petición HTTP + su DTO de respuesta, sin lógica de
/// presentación ni de negocio.
///
/// Alcance de esta primera integración (ver UI_Decision_Log.md DEC-011):
/// solo el listado (GET /v1/pagos, agregado en MprPagos.Api en la misma
/// decisión). ObtenerPago/ConfirmarPago no se exponen aquí porque ninguna
/// pantalla conectada hoy los necesita todavía.
/// </summary>
public class PagosApiClient
{
    private readonly HttpClient _client;

    public PagosApiClient(HttpClient client)
    {
        _client = client;
    }

    public async Task<List<PagoDto>> ListarAsync(CancellationToken cancellationToken = default)
    {
        var resultado = await _client.GetFromJsonAsync<List<PagoDto>>("api/pagos", cancellationToken);
        return resultado ?? new List<PagoDto>();
    }
}

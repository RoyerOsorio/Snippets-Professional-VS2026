using Vitamedica.Multiportal.UI.Models.Multiportal;

namespace Vitamedica.Multiportal.UI.Services;

/// <summary>
/// ApiClient tipado para el microservicio MprAuditoria, consumido a través de
/// Multiportal.ApiGateway (nunca directo al microservicio desde la UI — ver
/// UI_Architecture_Guide.md sección 4). Mismo patrón ya usado por
/// ClientesApiClient/ReclamosApiClient.
///
/// Alcance: un único método, porque MprAuditoria expone un único endpoint de
/// consulta (ver UI_Decision_Log.md DEC-007).
/// </summary>
public class AuditoriaApiClient
{
    private readonly HttpClient _client;

    public AuditoriaApiClient(HttpClient client)
    {
        _client = client;
    }

    public async Task<List<EventoAuditoriaDto>> ObtenerTimelineAsync(int reclamoId, CancellationToken cancellationToken = default)
    {
        var resultado = await _client.GetFromJsonAsync<List<EventoAuditoriaDto>>(
            $"api/auditoria/reclamos/{reclamoId}", cancellationToken);
        return resultado ?? new List<EventoAuditoriaDto>();
    }
}

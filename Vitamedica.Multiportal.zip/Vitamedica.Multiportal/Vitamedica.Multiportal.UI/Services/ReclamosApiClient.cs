using Vitamedica.Multiportal.UI.Models.Multiportal;

namespace Vitamedica.Multiportal.UI.Services;

/// <summary>
/// ApiClient tipado para el microservicio MprGestionReclamos, consumido a
/// través de Multiportal.ApiGateway (nunca directo al microservicio desde la
/// UI — ver UI_Architecture_Guide.md sección 4). Mismo patrón ya usado por
/// ClientesApiClient: responsabilidad única de traducir una llamada C# a una
/// petición HTTP + su DTO de respuesta, sin lógica de presentación ni de
/// negocio.
///
/// Alcance de esta primera integración (ver UI_Decision_Log.md DEC-008):
/// solo lectura de un Reclamo por Id y las dos transiciones Aprobar/Rechazar.
/// EnviarReclamo y CrearReclamo no se exponen aquí porque ninguna pantalla
/// conectada hoy los necesita todavía.
/// </summary>
public class ReclamosApiClient
{
    private readonly HttpClient _client;

    public ReclamosApiClient(HttpClient client)
    {
        _client = client;
    }

    public async Task<ReclamoDto?> ObtenerAsync(int reclamoId, CancellationToken cancellationToken = default)
    {
        var respuesta = await _client.GetAsync($"api/reclamos/{reclamoId}", cancellationToken);
        if (respuesta.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return null;
        }
        respuesta.EnsureSuccessStatusCode();
        return await respuesta.Content.ReadFromJsonAsync<ReclamoDto>(cancellationToken: cancellationToken);
    }

    public async Task<ReclamoDto> AprobarAsync(int reclamoId, decimal montoAprobado, CancellationToken cancellationToken = default)
    {
        var respuesta = await _client.PostAsJsonAsync(
            $"api/reclamos/{reclamoId}/aprobar",
            new { MontoAprobado = montoAprobado },
            cancellationToken);
        respuesta.EnsureSuccessStatusCode();
        return (await respuesta.Content.ReadFromJsonAsync<ReclamoDto>(cancellationToken: cancellationToken))!;
    }

    public async Task<ReclamoDto> RechazarAsync(int reclamoId, string motivoRechazo, CancellationToken cancellationToken = default)
    {
        var respuesta = await _client.PostAsJsonAsync(
            $"api/reclamos/{reclamoId}/rechazar",
            new { MotivoRechazo = motivoRechazo },
            cancellationToken);
        respuesta.EnsureSuccessStatusCode();
        return (await respuesta.Content.ReadFromJsonAsync<ReclamoDto>(cancellationToken: cancellationToken))!;
    }
}

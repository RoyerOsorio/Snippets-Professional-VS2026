using Vitamedica.Multiportal.UI.Models.Multiportal;

namespace Vitamedica.Multiportal.UI.Services;

/// <summary>
/// ApiClient tipado para Reimbursement.Orchestrator, consumido a través de
/// Multiportal.ApiGateway (ruta /api/reembolsos/*, nunca directo al
/// Orchestrator desde la UI — ver UI_Architecture_Guide.md sección 4). Es la
/// primera vez que la UI llama al Orchestrator en vez de a un microservicio
/// directamente: hasta DEC-012, todas las pantallas conectadas iban
/// Browser → Controller → ApiClient → Gateway → Microservicio; esta es
/// Browser → Controller → ApiClient → Gateway → Orchestrator → Microservicios
/// (ver UI_Decision_Log.md DEC-013).
/// </summary>
public class ReembolsosApiClient
{
    private readonly HttpClient _client;

    public ReembolsosApiClient(HttpClient client)
    {
        _client = client;
    }

    /// <summary>
    /// Llama a POST /api/reembolsos/iniciar. Devuelve null cuando el
    /// Orchestrator responde 404 (no se encontró contexto contractual para
    /// esa Poliza+AseguradoId en MprClientes).
    /// </summary>
    public async Task<IniciarReembolsoResultadoDto?> IniciarAsync(
        string poliza,
        int aseguradoId,
        int? motivoId,
        CancellationToken cancellationToken = default)
    {
        var respuesta = await _client.PostAsJsonAsync(
            "api/reembolsos/iniciar",
            new { Poliza = poliza, AseguradoId = aseguradoId, MotivoId = motivoId },
            cancellationToken);

        if (respuesta.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return null;
        }

        respuesta.EnsureSuccessStatusCode();
        return await respuesta.Content.ReadFromJsonAsync<IniciarReembolsoResultadoDto>(cancellationToken: cancellationToken);
    }
}

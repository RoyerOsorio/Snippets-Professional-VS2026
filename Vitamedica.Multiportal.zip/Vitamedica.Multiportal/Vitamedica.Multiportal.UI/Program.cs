using Microsoft.AspNetCore.Authentication.Cookies;
using System.ServiceModel;
using Vitamedica.Multiportal.UI.Agents;
using Vitamedica.Multiportal.UI.Extensions;
using Vitamedica.Multiportal.UI.Infrastructure.Filters;
using Vitamedica.Multiportal.UI.Models.EndPoint;
using Vitamedica.Multiportal.UI.Services;
//using Vitamedica.Multiportal.Application.Dependency;
//using Vitamedica.Multiportal.Infrastructure.Dependency;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
//builder.Services.AddControllersWithViews();

//builder.Services.AddApplication();
//builder.Services.AddInfrastructure(builder.Configuration);

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Sesion/Login";
        //options.AccessDeniedPath = "/Sesion/AccessDenied";
    });

//builder.Services.AddControllersWithViews();
builder.Services.AddControllersWithViews(options => options.Filters.Add<LayoutActionFilter>());
builder.Services.AddMultiportalUi(builder.Configuration);

var authSettings = builder.Configuration.GetSection("ExternalServices:ActiveDirectory").Get<EndPointSetting>();

if (authSettings != null)
{
    builder.Services.AddSingleton(authSettings);



    builder.Services.AddScoped<IActiveDirectoryService>(provider =>
    {
        var mode = authSettings.BaseUrl.StartsWith("https")
                   ? BasicHttpSecurityMode.Transport
                   : BasicHttpSecurityMode.None;

        var binding = new BasicHttpBinding(mode);
        var endPoint = new EndpointAddress(authSettings.BaseUrl);

        return new ActiveDirectoryServiceClient(binding, endPoint);
    });
}

//API's

builder.Services.AddHttpClient<MultiportalApiClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Apis:apiMultiportal:BaseUrl"]!);
});
builder.Services.AddHttpClient<VigorApiClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Apis:apiVigor:BaseUrl"]!);
});

// Ejercicio de microservicios (piloto MprClientes): la UI llama siempre al
// Gateway, nunca directo al microservicio — mismo patrón Browser → Controller
// → ApiClient → API que ya usan MultiportalApiClient/VigorApiClient (ver
// UI_Architecture_Guide.md sección 4 y docs/demo/README.md del ejercicio).
builder.Services.AddHttpClient<ClientesApiClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Apis:apiGateway:BaseUrl"]!);
});

// DetalleSolicitud (ver UI_Decision_Log.md DEC-008): mismo Gateway, mismo
// patrón — ReclamosApiClient/AuditoriaApiClient nunca llaman directo a
// MprGestionReclamos/MprAuditoria.
builder.Services.AddHttpClient<ReclamosApiClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Apis:apiGateway:BaseUrl"]!);
});
builder.Services.AddHttpClient<AuditoriaApiClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Apis:apiGateway:BaseUrl"]!);
});

// PagoSolicitud (ver UI_Decision_Log.md DEC-011): mismo Gateway, mismo
// patrón — PagosApiClient nunca llama directo a MprPagos.
builder.Services.AddHttpClient<PagosApiClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Apis:apiGateway:BaseUrl"]!);
});

// Registrar de ReembolsoSolicitud → Reimbursement.Orchestrator (ver
// UI_Decision_Log.md DEC-013): mismo Gateway (ruta /api/reembolsos/*, no
// nueva infraestructura) — ReembolsosApiClient nunca llama directo al
// Orchestrator ni a los microservicios que este coordina.
builder.Services.AddHttpClient<ReembolsosApiClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Apis:apiGateway:BaseUrl"]!);
});

//Agentes
builder.Services.AddScoped<AuthAgent>();
//

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}



app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();


app.Run();
